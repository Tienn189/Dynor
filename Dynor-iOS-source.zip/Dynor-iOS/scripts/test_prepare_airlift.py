"""Offline integrity checks for the pinned AirliftFFI downloader."""
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import prepare_airlift as dependency


class DownloadResponse(io.BytesIO):
    headers = {}


class AirliftPreparationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.contents = {path: (path + " fixture").encode() for path in dependency.EXPECTED_PATHS}
        provenance = {
            "repository": "https://github.com/Mak5er/AirCard-iOS",
            "revision": dependency.REVISION,
            "files": [{"path": path, "sha256": hashlib.sha256(data).hexdigest()}
                      for path, data in self.contents.items()],
        }
        manifest = self.root / "ThirdParty/AirCard/provenance.json"
        manifest.parent.mkdir(parents=True)
        manifest.write_text(json.dumps(provenance))

    def archive(self, contents=None):
        result = io.BytesIO()
        with zipfile.ZipFile(result, "w") as bundle:
            for path, data in (self.contents if contents is None else contents).items():
                upstream = path.removeprefix("Frameworks/")
                bundle.writestr(f"AirCard-iOS-{dependency.REVISION}/{upstream}", data)
            bundle.writestr("../../unexpected", "Never extract unrelated files")
        return result.getvalue()

    def install_fixture(self):
        for path, data in self.contents.items():
            target = self.root / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)

    def test_valid_existing_framework_skips_network(self):
        self.install_fixture()
        with patch.object(dependency, "urlopen", side_effect=AssertionError("No download expected")):
            dependency.prepare_airlift(self.root)

    def test_missing_framework_installs_only_verified_seven_files(self):
        with patch.object(dependency, "urlopen", return_value=DownloadResponse(self.archive())) as request:
            dependency.prepare_airlift(self.root)
        self.assertEqual(request.call_args.args[0].full_url, dependency.ARCHIVE_URL)
        self.assertTrue(dependency.existing_matches(self.root, dependency.load_hashes(self.root)))
        installed = [path for path in (self.root / "Frameworks").rglob("*") if path.is_file()]
        self.assertEqual(len(installed), 7)

    def test_corrupt_existing_framework_is_repaired(self):
        self.install_fixture()
        target = self.root / next(iter(self.contents))
        target.write_bytes(b"corrupt")
        with patch.object(dependency, "urlopen", return_value=DownloadResponse(self.archive())):
            dependency.prepare_airlift(self.root)
        self.assertTrue(dependency.existing_matches(self.root, dependency.load_hashes(self.root)))

    def test_hash_mismatch_preserves_existing_files(self):
        self.install_fixture()
        path = next(iter(self.contents))
        target = self.root / path
        target.write_bytes(b"existing")
        modified = dict(self.contents)
        modified[path] = b"invalid download"
        with patch.object(dependency, "urlopen", return_value=DownloadResponse(self.archive(modified))):
            with self.assertRaisesRegex(ValueError, "SHA-256 mismatch"):
                dependency.prepare_airlift(self.root)
        self.assertEqual(target.read_bytes(), b"existing")

    def test_missing_archive_file_is_rejected(self):
        modified = dict(self.contents)
        modified.pop(next(iter(modified)))
        with patch.object(dependency, "urlopen", return_value=DownloadResponse(self.archive(modified))):
            with self.assertRaisesRegex(ValueError, "missing required"):
                dependency.prepare_airlift(self.root)
        self.assertFalse((self.root / dependency.FRAMEWORK_PATH).exists())

    def test_download_and_extraction_size_limits(self):
        with patch.object(dependency, "urlopen", return_value=DownloadResponse(self.archive())):
            with patch.object(dependency, "MAX_DOWNLOAD_BYTES", 10):
                with self.assertRaisesRegex(ValueError, "download limit"):
                    dependency.prepare_airlift(self.root)
        with patch.object(dependency, "urlopen", return_value=DownloadResponse(self.archive())):
            with patch.object(dependency, "MAX_FILE_BYTES", 10):
                with self.assertRaisesRegex(ValueError, "oversized"):
                    dependency.prepare_airlift(self.root)


if __name__ == "__main__":
    unittest.main()
