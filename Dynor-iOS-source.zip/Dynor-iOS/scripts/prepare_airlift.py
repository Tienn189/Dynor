#!/usr/bin/env python3
"""Fetch the pinned AirliftFFI binary dependency and verify its provenance hashes."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import stat
import tempfile
from urllib.request import Request, urlopen
import zipfile

REVISION = "40640c4d827aeab8d798285b57d24fcf6be070d0"
ARCHIVE_URL = f"https://codeload.github.com/Mak5er/AirCard-iOS/zip/{REVISION}"
FRAMEWORK_PATH = Path("Frameworks/AirliftFFI.xcframework")
MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024
MAX_FILE_BYTES = 100 * 1024 * 1024
MAX_TOTAL_BYTES = 200 * 1024 * 1024
CHUNK_BYTES = 64 * 1024
EXPECTED_PATHS = {
    str(FRAMEWORK_PATH / "Info.plist"),
    *(str(FRAMEWORK_PATH / platform / suffix)
      for platform in ("ios-arm64", "ios-arm64-simulator")
      for suffix in ("Headers/airlift.h", "Headers/module.modulemap", "libairlift_ffi.a")),
}


def load_hashes(source_root: Path) -> dict[str, str]:
    provenance = json.loads((source_root / "ThirdParty/AirCard/provenance.json").read_text())
    if (provenance.get("revision") != REVISION
            or provenance.get("repository") != "https://github.com/Mak5er/AirCard-iOS"):
        raise ValueError("Airlift provenance does not match the pinned upstream revision.")
    entries = provenance.get("files", [])
    hashes = {entry["path"]: entry["sha256"] for entry in entries}
    if len(entries) != 7 or set(hashes) != EXPECTED_PATHS:
        raise ValueError("Airlift provenance must list exactly the seven framework files.")
    if any(not isinstance(value, str) or not re.fullmatch(r"[a-f0-9]{64}", value)
           for value in hashes.values()):
        raise ValueError("Airlift provenance contains an invalid SHA-256 hash.")
    return hashes


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(CHUNK_BYTES):
            digest.update(chunk)
    return digest.hexdigest()


def existing_matches(source_root: Path, hashes: dict[str, str]) -> bool:
    for relative, expected in hashes.items():
        path = source_root / relative
        if (path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_FILE_BYTES
                or sha256_file(path) != expected):
            return False
    return True


def download_archive(destination: Path) -> None:
    request = Request(ARCHIVE_URL, headers={"User-Agent": "Dynor-native-build"})
    with urlopen(request, timeout=60) as response, destination.open("wb") as output:
        declared = response.headers.get("Content-Length")
        if declared and int(declared) > MAX_DOWNLOAD_BYTES:
            raise ValueError("Airlift archive exceeds the 100 MiB download limit.")
        count = 0
        while chunk := response.read(CHUNK_BYTES):
            count += len(chunk)
            if count > MAX_DOWNLOAD_BYTES:
                raise ValueError("Airlift archive exceeds the 100 MiB download limit.")
            output.write(chunk)


def extract_verified(archive: Path, staging: Path, hashes: dict[str, str]) -> None:
    prefix = f"AirCard-iOS-{REVISION}/"
    with zipfile.ZipFile(archive) as bundle:
        files: dict[str, zipfile.ZipInfo] = {}
        for info in bundle.infolist():
            # Upstream stores this framework at its repository root.
            upstream = info.filename.removeprefix(prefix)
            relative = "Frameworks/" + upstream
            if not info.filename.startswith(prefix) or relative not in hashes:
                continue
            if relative in files:
                raise ValueError(f"Duplicate Airlift archive member: {relative}")
            mode = info.external_attr >> 16
            if (info.is_dir() or info.flag_bits & 1
                    or stat.S_IFMT(mode) not in (0, stat.S_IFREG)
                    or info.file_size > MAX_FILE_BYTES):
                raise ValueError(f"Invalid or oversized Airlift archive member: {relative}")
            files[relative] = info
        if set(files) != set(hashes):
            raise ValueError("Pinned archive is missing required Airlift framework files.")
        if sum(info.file_size for info in files.values()) > MAX_TOTAL_BYTES:
            raise ValueError("Airlift framework exceeds the 200 MiB expanded-size limit.")
        total = 0
        for relative, info in files.items():
            target = staging / Path(relative).relative_to(FRAMEWORK_PATH)
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            count = 0
            with bundle.open(info) as incoming, target.open("xb") as outgoing:
                while chunk := incoming.read(CHUNK_BYTES):
                    count += len(chunk)
                    total += len(chunk)
                    if count > MAX_FILE_BYTES or total > MAX_TOTAL_BYTES:
                        raise ValueError("Airlift framework exceeded extraction size limits.")
                    digest.update(chunk)
                    outgoing.write(chunk)
            if count != info.file_size or digest.hexdigest() != hashes[relative]:
                raise ValueError(f"Airlift SHA-256 mismatch: {relative}")


def prepare_airlift(source_root: Path) -> None:
    source_root = source_root.resolve()
    hashes = load_hashes(source_root)
    if existing_matches(source_root, hashes):
        print("AirliftFFI: all seven pinned SHA-256 hashes verified; download skipped.")
        return
    framework = source_root / FRAMEWORK_PATH
    framework.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".airlift-", dir=framework.parent) as temporary:
        work = Path(temporary)
        archive = work / "upstream.zip"
        print(f"Downloading AirliftFFI from pinned revision {REVISION}…")
        download_archive(archive)
        staging = work / "verified"
        staging.mkdir()
        extract_verified(archive, staging, hashes)
        # Do not touch an existing framework until every downloaded file verifies.
        backup = work / "previous"
        had_existing = framework.exists() or framework.is_symlink()
        if had_existing:
            framework.replace(backup)
        try:
            staging.replace(framework)
        except BaseException:
            if had_existing:
                backup.replace(framework)
            raise
    print("AirliftFFI: installed seven files with verified pinned SHA-256 hashes.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parents[1])
    prepare_airlift(parser.parse_args().source_root)
