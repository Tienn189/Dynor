# Thiết lập gói Tendies mã hóa cho Dynor

Website riêng: [Dynor Vault](https://dynor-vault.amberstingray1.chatgpt.site). Công cụ nhận `.tendies`, mã hóa ngay trong trình duyệt và tạo `.dynor`. File hình nền gốc không được tải lên website hoặc Supabase trong bước mã hóa. Khóa nội dung được gửi qua HTTPS tới Edge Function dành cho quản trị viên để đăng ký; chỉ sau khi đăng ký thành công mới có thể tải file mã hóa về.

Đây là hệ thống **cần triển khai backend trước khi dùng**, không chỉ là đổi đuôi file. Site riêng và quyền quản trị Supabase là hai lớp truy cập khác nhau: mở được Site vẫn phải đăng nhập email OTP bằng tài khoản có trong `dynor_admins`. Bản mã nguồn không chứa khóa giải mã production; các khóa cố định trong fixture là dữ liệu kiểm thử.

## 1. Dùng đúng project, tài khoản và quyền VIP hiện có

Project mặc định của app và website là `https://wkivekbodwbinmvargts.supabase.co`, project ref `wkivekbodwbinmvargts`. Nếu đổi project, phải đổi cấu hình công khai tương ứng trong app và website rồi build/publish lại. Supabase publishable/anon key chỉ nhận diện project; nó không phải khóa nội dung hay service-role key.

Giữ nguyên hệ thống OTP, tài khoản, thanh toán và `dynor_vip` hiện có. Không tạo hệ thống VIP thứ hai. Backend kiểm tra quyền VIP bằng `plan_id` và `vip_expires_at`: quyền `lifetime` với ngày hết hạn `null`, hoặc ngày hết hạn còn ở tương lai. Việc hỗ trợ kiểm tra bản ghi lifetime không tự bật bán gói lifetime trong ứng dụng.

## 2. Chạy SQL

Trong Supabase Dashboard → SQL Editor của đúng project:

1. Nếu chưa thiết lập Gallery online, chạy toàn bộ [Supabase/sql/wallpaper_online.sql](Supabase/sql/wallpaper_online.sql) theo [hướng dẫn online](WALLPAPER_ONLINE_SETUP.md). Không chạy lại script cũ có các `create policy` nếu đã thiết lập.
2. Chạy **nguyên nội dung** [Supabase/sql/encrypted_packages.sql](Supabase/sql/encrypted_packages.sql). Đây là schema chính xác cho hai Edge Function bên dưới; không tự tạo bảng khóa với quyền đọc công khai. Script bổ sung bảng gói, RLS, quyền service-only và RPC giới hạn yêu cầu.
3. Authentication → Users → sao chép UID tài khoản quản trị của chính bạn. Chạy SQL sau, thay giá trị mẫu bằng UUID thật:

```sql
insert into public.dynor_admins(user_id)
values ('YOUR-AUTH-USER-UUID'::uuid)
on conflict do nothing;
```

Không cấp `select` bảng `dynor_encrypted_packages` cho `anon` hoặc `authenticated`, kể cả để website quản trị tự đọc khóa. Quản trị viên đăng ký gói qua Function; chỉ server có service-role credential mới truy cập dữ liệu khóa. Bản ghi gói dùng UUID mới cho mỗi lần mã hóa; API không ghi đè ID, hash, khóa hoặc chính sách của gói đã có.

## 3. Tạo và lưu secret KEK một lần

`DYNOR_PACKAGE_KEK` là Base64 chuẩn của **đúng 32 byte ngẫu nhiên**. Nó dùng mã hóa khóa nội dung trong cơ sở dữ liệu và chỉ nằm ở Supabase Edge Function Secrets cùng bản sao bảo mật của bạn. Không nhập nó vào Dynor Vault, source iOS, GitHub, Sites, URL, ảnh chụp hoặc log build.

Trên máy tin cậy đã cài Supabase CLI và Python 3, mở terminal tại thư mục source có `project.yml`. Tắt shell tracing; lệnh dưới tạo file tạm chỉ chủ tài khoản đọc được và không in giá trị khóa:

```bash
set +x
umask 077
dynor_secret_dir="$(mktemp -d)"
python3 - "$dynor_secret_dir/package.env" <<'PY'
import base64
import secrets
import sys

with open(sys.argv[1], "x", encoding="ascii") as output:
    output.write("DYNOR_PACKAGE_KEK=" + base64.b64encode(secrets.token_bytes(32)).decode("ascii") + "\n")
PY
supabase login
supabase secrets set --project-ref wkivekbodwbinmvargts --env-file "$dynor_secret_dir/package.env"
```

Lưu bản sao của secret vào trình quản lý bí mật tin cậy bằng phương thức nhập file an toàn trước khi xóa file tạm. Không dùng `cat`, `echo` hoặc chế độ log debug để xem khóa. Khi đã xác nhận secret được lưu trên Supabase và bản sao bảo mật có thể khôi phục, dọn file tạm trong cùng phiên shell:

```bash
rm -- "$dynor_secret_dir/package.env"
rmdir -- "$dynor_secret_dir"
unset dynor_secret_dir
```

**Không chạy lại bước tạo khóa để cập nhật app hoặc deploy Function. Không tự động xoay KEK.** Thay/mất KEK làm server không mở được các khóa nội dung cũ và các `.dynor` đã phát hành ngừng cài được. Phiên bản hiện tại không có key version hay quy trình migration tự động. Nếu cần xoay, phải lên kế hoạch mở và bọc lại tất cả khóa bằng KEK cũ/mới trước khi chuyển secret; không chỉ ghi đè giá trị trong Dashboard.

Hai Function còn cần `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, thường đã có sẵn trong môi trường Edge Functions. Nếu project thiếu, cấu hình phía server qua Supabase Secrets; không chuyển service-role key sang website hoặc iOS.

## 4. Deploy đúng hai Edge Function

Source dùng thư mục `Supabase/` viết hoa, khác layout CLI mặc định `supabase/functions/`. Lệnh sau tạo layout deploy tạm, giữ nguyên cả hai module dùng chung. Chạy từ thư mục chứa `project.yml`, sau bước đăng nhập CLI:

```bash
dynor_deploy_dir="$(mktemp -d)"
supabase init --workdir "$dynor_deploy_dir"
mkdir -p "$dynor_deploy_dir/supabase/functions"
cp -R Supabase/_shared Supabase/dynor-register-package Supabase/dynor-package-key "$dynor_deploy_dir/supabase/functions/"
supabase functions deploy dynor-register-package --project-ref wkivekbodwbinmvargts --no-verify-jwt --workdir "$dynor_deploy_dir"
supabase functions deploy dynor-package-key --project-ref wkivekbodwbinmvargts --no-verify-jwt --workdir "$dynor_deploy_dir"
```

Deploy thành công cả hai rồi xóa thư mục deploy tạm:

```bash
rm -rf -- "$dynor_deploy_dir"
unset dynor_deploy_dir
```

`--no-verify-jwt` tắt kiểm tra JWT tại **gateway của hai Function này** để tương thích cấu hình publishable key; không tắt đăng nhập trong code. Hai handler luôn xác minh Bearer token bằng `auth.getUser(jwt)`. `dynor-register-package` kiểm tra thêm quyền `dynor_admins`; `dynor-package-key` kiểm tra gói, hash, trạng thái active, chính sách VIP và quota. Không bỏ các kiểm tra này và không áp dụng thay đổi gateway hàng loạt cho Function khác.

Không deploy riêng `index.ts` mà bỏ `_shared/package-handlers.mjs` hoặc `_shared/package-crypto.mjs`. Thiếu secret/schema hoặc lỗi tra quyền đều phải dừng cấp khóa. Giới hạn hiện tại là **30 lần yêu cầu khóa/tài khoản/60 giây**, gồm cả yêu cầu sai định dạng; hết quota trả 429 và cần chờ rồi thử lại.

## 5. Mã hóa và phát hành nội dung

1. Mở [Dynor Vault](https://dynor-vault.amberstingray1.chatgpt.site), đăng nhập OTP bằng email quản trị đã cấp ở bước 2.
2. Chọn `.tendies` hợp lệ, không rỗng, tối đa 50 MiB. Trình duyệt kiểm tra dấu hiệu ZIP; Dynor vẫn kiểm tra toàn bộ archive và descriptor khi cài.
3. Chọn chính sách gói **Yêu cầu VIP**. Mặc định bật. Khi tắt, mọi tài khoản Dynor đã đăng nhập đều có thể xin khóa của gói đang active nếu có file; đây không phải gói dành riêng cho người mua.
4. Mã hóa và chờ đăng ký thành công, sau đó tải `ten-goi.dynor`. Công cụ không xuất khóa hoặc tạo file giải mã. Không chia sẻ file `.tendies` gốc nếu mục tiêu là chỉ phân phối bản mã hóa.
5. Có thể gửi `.dynor` trực tiếp cho người dùng. Nếu muốn hiện ở Khám phá, mở trang quản trị Gallery hiện có, upload `.dynor` làm **File tải về**, thêm bìa/video và publish bài. Không upload `.tendies` gốc làm file tải thay thế.

**Quyền VIP của gói độc lập với `is_vip` của bài Gallery.** `is_vip` kiểm soát tải từ catalog; `requires_vip` của gói kiểm soát cấp khóa kể cả khi file được nhập cục bộ. Muốn bảo vệ nội dung VIP, bật cả hai. Chỉ bật VIP cho bài Gallery trong khi đăng ký gói `requires_vip = false` không ngăn tài khoản thường mở bản `.dynor` được người khác gửi. API không sửa chính sách gói cũ: khi muốn đổi chính sách, tạo và phát hành gói mới với UUID mới.

Nếu đăng ký thành công nhưng đóng trang trước khi tải file, khóa không được lưu trong local/session storage để khôi phục. Mở lại `.tendies` gốc và mã hóa thành gói mới; không cố ghi đè ID cũ. Giữ bản gốc riêng ở nơi an toàn để có thể phát hành lại khi cần.

## 6. Cài bằng ứng dụng iOS

Build/cài IPA mới bằng pipeline hiện có. Nhập `.dynor` qua Thư viện → `+`, Tệp → Mở bằng Dynor, hoặc tải từ Khám phá. Thư viện lưu **bản mã hóa**. File `.tendies` cũ vẫn nhập và cài bình thường; nó không tự trở thành file được bảo vệ.

Với `.dynor`, **mỗi lần cài cần kết nối mạng và tài khoản đăng nhập còn hợp lệ**. Gói VIP yêu cầu quyền VIP hợp lệ ở thời điểm xin khóa. Khóa nội dung không được cache để cài offline. App tạo khóa P-256 không xuất được trong Secure Enclave; server bọc khóa nội dung cho khóa công khai này. Tham chiếu khóa thiết bị nằm trong Keychain `ThisDeviceOnly`. Không có fallback sang khóa tĩnh khi Secure Enclave/server không sẵn sàng; Simulator không thay thế kiểm tra trên iPhone thật.

Trong màn hình xem trước, chọn **Chuẩn bị cài hình nền**, chờ hoàn tất rồi chọn **Cài hình nền**. Dynor truy cập PosterBoard trực tiếp theo phương thức của [3105](https://github.com/YangJiiii/3105), không cần pairing record hoặc VPN. Sau giải mã, gói vẫn phải qua kiểm tra ZIP, CRC, đường dẫn, giới hạn giải nén và descriptor trước khi ghi.

Phạm vi hỗ trợ: **iOS 18.0–18.7.1**, **iOS 26.0–26.6.1** và **iOS 27** với một trong các build **24A5355q, 24A5370h, 24A5380h, 24A5390f**. App kiểm tra build thực tế; các build iOS 27 khác không được tự cho phép bằng lựa chọn beta. Trên iOS 27, tạo và sử dụng một hình nền **Bộ sưu tập (Collections)** của Apple trước khi chuẩn bị cài. Sau khi cài, khởi động lại iPhone rồi vào **Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập** để chọn mẫu vừa cài.

Ảnh thường vẫn lưu vào Photos/chia sẻ ảnh; `.dynor` và `.tendies` không có nút xuất/chia sẻ gói trong app.

Bản rõ tạm nằm trong `Application Support/Dynor/InstallStaging/<UUID>` với file protection đầy đủ, quyền thư mục 0700/file 0600 và loại khỏi backup. App cố dọn staging khi thành công/lỗi và dọn lại staging cũ lúc khởi động. Crash hoặc hệ điều hành không cho xóa có thể để lại dữ liệu đến lần dọn sau; thao tác xóa không phải cam kết xóa an toàn mọi dấu vết. Nội dung đã cài vào PosterBoard cần tồn tại để iOS hiển thị hình nền.

## 7. Dừng cấp quyền một gói

Trong SQL Editor bằng tài khoản sở hữu project, thay UUID mẫu bằng `package_id` của gói:

```sql
update public.dynor_encrypted_packages
set active = false
where package_id = 'PACKAGE-UUID'::uuid;
```

Muốn cho phép lại, đặt `active = true`. Để kiểm tra danh sách mà không đọc cột chứa khóa:

```sql
select package_id, original_name, requires_vip, active, created_at
from public.dynor_encrypted_packages
order by created_at desc;
```

Ẩn bài Gallery không tự thu hồi gói đã tải: phải tắt `active` nếu muốn ngừng cấp khóa. Thu hồi chặn lần cấp khóa tiếp theo; không xóa hình nền đã cài và không thu hồi được khóa đã cấp cho một thao tác đang chạy. Không xóa bảng hay mất KEK để thu hồi từng gói.

## Giới hạn bảo vệ và kiểm tra trước khi dùng

IPA tự ký có thể bị sửa hoặc ký lại. Backend này xác thực **tài khoản và quyền của gói**, không dùng App Attest để chứng minh ứng dụng Dynor nguyên bản. Client khác có token hợp lệ và quyền gói có thể gọi giao thức cấp khóa bằng khóa P-256 của chính nó; Secure Enclave ở app chính không khiến server tự nhận diện được client gốc. Không quảng cáo đây là cách tuyệt đối buộc mọi `.dynor` chỉ mở được trong IPA của bạn.

Trong lúc cài, khóa nội dung và dữ liệu đã giải mã phải được sử dụng bởi tiến trình app; sau khi cài, PosterBoard giữ nội dung. Thiết bị bị can thiệp, client đã sửa hoặc tài khoản có quyền có thể trích xuất và phân phối lại. Cơ chế này tránh nhúng khóa dùng chung trong source và quản lý việc cấp khóa; không có cam kết chống trích xuất tuyệt đối.

Xem [VERIFICATION.md](VERIFICATION.md) để kiểm tra đúng/sai quyền, hash/tag, thu hồi, cleanup và tương thích iOS. Chạy unit test/mô phỏng trên Linux không xác nhận deploy Supabase, Secure Enclave, build Xcode hoặc cài hình nền trên iPhone thành công.
