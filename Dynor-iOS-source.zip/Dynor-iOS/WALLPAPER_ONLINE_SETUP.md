# Dynor Wallpaper Online — thiết lập trên iPhone

## 1. Tạo bảng và Storage
1. Safari → https://supabase.com/dashboard → project Login Dynor → SQL Editor → New query.
2. Dán toàn bộ `Supabase/sql/wallpaper_online.sql` và nhấn Run **một lần**. Không chạy lại nguyên script nếu đã tạo policies.
3. Authentication → Users → tìm tài khoản email quản trị của bạn → copy **User UID** (UUID).
4. SQL Editor → New query → chạy lệnh bên dưới, thay UUID bằng UID thật của tài khoản bạn:
   `insert into public.dynor_admins(user_id) values ('UUID-CUA-BAN') on conflict do nothing;`
   Không cấp quyền quản trị cho UID của người khác.
5. Storage → kiểm tra hai buckets `dynor-previews` (public) và `dynor-downloads` (private).

## 2. Deploy Edge Function để tải file
1. Edge Functions → Deploy a new function → tên `dynor-wallpaper-download`.
2. Dán toàn bộ `Supabase/dynor-wallpaper-download/index.ts` rồi Deploy.
3. Nếu cấu hình có tùy chọn `Verify JWT`, tắt kiểm tra JWT ở gateway **chỉ cho function này**, vì function tự xác minh JWT bằng `auth.getUser()`. Đảm bảo function vẫn yêu cầu Authorization Bearer hợp lệ.
4. Supabase Edge Functions có sẵn `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` trong nhiều project; nếu function báo thiếu cấu hình, thêm các biến qua Supabase Secrets. Không đặt service-role key trong app iOS hay website quản trị.

## 3. Trang quản trị trên iPhone
1. Tạo một GitHub Pages repo riêng, ví dụ `Dynor-Studio`.
2. Upload `Admin/index.html` vào root repo, bật GitHub Pages → Deploy from branch → main/root.
3. Mở website bằng Safari, đăng nhập OTP bằng email đã cấp quyền ở bước 1.
4. Chọn ảnh bìa, video MP4 tùy chọn và file tải (JPG, PNG, `.tendies`, `.zip`, ...), rồi nhấn Đăng hình nền.
5. Danh sách dưới form cho phép Ẩn/Hiện bài. File private không thể tải trực tiếp qua URL công khai.

## 4. App iOS
1. Build IPA bằng workflow/codemagic đang có trong project.
2. Cài bản IPA mới **một lần** để nhận tính năng Online Gallery.
3. Từ đó, đăng bài mới trên Dynor Studio không cần build lại IPA; app cập nhật khi mở tab hoặc kéo xuống.
4. Thả tim yêu cầu đăng nhập; yêu thích lưu trong `dynor_favorites` theo `user_id`.
5. Nút **Tải và mở trong Dynor** gọi Edge Function để xác minh phiên đăng nhập, trạng thái published và VIP rồi mới cấp URL riêng có hiệu lực 60 giây. Ảnh và `.tendies` tự thêm vào Thư viện rồi mở màn hình xem trước trong Dynor; các định dạng khác báo không hỗ trợ và được dọn khỏi thư mục tải tạm. App không xuất hoặc chia sẻ gói Tendies.
6. Với `.tendies` hoặc `.dynor`, chọn **Chuẩn bị cài hình nền**, chờ hoàn tất rồi chọn **Cài hình nền**. Dynor truy cập PosterBoard trực tiếp theo phương thức của [3105](https://github.com/YangJiiii/3105), không cần pairing record hoặc VPN. Gói `.dynor` vẫn cần Internet và tài khoản đủ quyền mỗi lần cài.
7. Hỗ trợ **iOS 18.0–18.7.1**, **iOS 26.0–26.6.1** và **iOS 27** với build **24A5355q, 24A5370h, 24A5380h hoặc 24A5390f**. App kiểm tra build thực tế. Trên iOS 27, tạo và sử dụng một hình nền **Bộ sưu tập (Collections)** của Apple trước khi chuẩn bị cài.
8. Sau khi cài, khởi động lại iPhone rồi vào **Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập** để chọn mẫu vừa cài. Xem hướng dẫn chi tiết trong `README.md`.

## Lưu ý
- Chưa thể xác nhận build IPA thành công trên macOS trong môi trường này. Hãy chạy Codemagic và gửi log nếu gặp lỗi.
- App hiện chỉ dùng Gallery online ở tab Khám phá; GalleryView.swift cũ được giữ nguyên làm mã nguồn dự phòng. Phần quảng cáo mô phỏng cũ không còn nằm trong tab Khám phá online.
- Video MP4 cần định dạng được AVPlayer trên iOS hỗ trợ (nên dùng H.264/AAC).
- Supabase Storage giới hạn kích thước tùy gói/cấu hình; nếu upload thất bại do giới hạn, cần điều chỉnh cấu hình hoặc tối ưu file.
- Nếu dùng nội dung VIP trả phí trên App Store, cần kiểm tra quy định thanh toán Apple trước khi phát hành.
- Với gói mã hóa `.dynor`, triển khai thêm SQL và hai Edge Function theo [ENCRYPTED_TENDIES_SETUP.md](ENCRYPTED_TENDIES_SETUP.md), rồi upload `.dynor` làm file tải về. Quyền VIP của gói và bài Gallery độc lập; muốn bảo vệ nội dung VIP phải bật cả hai.
