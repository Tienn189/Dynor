# Dynor — iOS native 1.3.0 (build 6)

Ứng dụng SwiftUI cho iPhone/iPad, minimum iOS 18. Tính năng cài hình nền chuyển sang cơ chế của [3105](https://github.com/YangJiiii/3105/tree/a72617ed4c764a65d8aac1e91aca95231e72a2cb), ghim revision `a72617ed4c764a65d8aac1e91aca95231e72a2cb`.

## Thay đổi cài hình nền

- Gỡ AirliftFFI, tab Pairing, nhập pairing record, Bonjour và yêu cầu LocalDevVPN.
- Truy cập PosterBoard trực tiếp bằng cơ chế cấp quyền của 3105: iOS 18 dùng bước chuẩn bị kernel do người dùng bấm; iOS 26/27 dùng MHA-C2.
- Quét cấu trúc PosterBoard thực tế thay vì cố định thư mục thế hệ `61`.
- Kiểm tra archive, CRC, đường dẫn, giới hạn giải nén và descriptor trước khi ghi; dùng staging, journal và rollback của bộ cài 3105.
- Giữ luồng nhập từ Tệp/Thư viện/Khám phá, bộ chọn tài liệu sao chép, ảnh thường, tài khoản và gói mã hóa `.dynor`.
- Giữ tiến trình/log; khóa xóa và mở tệp khác trong lúc chuẩn bị/cài. Dynor không tự khởi động lại hoặc tự chọn màn hình khóa.

## Phiên bản được phép thử cài

Theo chính sách của 3105 tại revision đã ghim:

| Hệ thống | Phạm vi |
| --- | --- |
| iOS 18 | 18.0–18.7.1 |
| iOS 26 | 26.0–26.6.1 |
| iOS 27.0 Developer Beta 1 | `24A5355q` |
| iOS 27.0 Developer Beta 2 | `24A5370h` |
| iOS 27.0 Developer Beta 3 / Public Beta 1 | `24A5380h` |
| iOS 27.0 Developer Beta 4 / Public Beta 2 | `24A5390f` |

Các build iOS 27 khác và các phiên bản ngoài bảng bị chặn. App đọc build thực tế; không có bộ chọn beta để tự mở khóa. Các phạm vi này đến từ upstream, chưa phải kết quả thử Dynor trên iPhone.

## Ký và cài ứng dụng

Cơ chế MHA-C2 cần bundle identifier **`com.apple.mobile.MobileHouseArrest`**. Tên hiển thị vẫn là **Dynor**. Giữ nguyên identifier này khi ký IPA. Theo hướng dẫn 3105, tính năng truy cập thiết bị yêu cầu **chứng chỉ enterprise**; SideStore, AltStore, 3uTools và LiveContainer không phải đường cài được upstream hỗ trợ. Mã nguồn không kèm chứng chỉ, provisioning profile hay IPA đã ký.

Identifier mới khác bản Dynor cũ (`com.dynor.wallpapers`), nên iOS có thể coi đây là ứng dụng khác; thư viện và Keychain cũ không tự chuyển sang. Giữ bản cũ khi cần lấy lại tệp gốc, nhập lại hình nền và đăng nhập lại ở bản mới. Dynor dùng cùng identifier với 3105: không cài chồng nếu cần giữ ứng dụng/dữ liệu 3105 đang có trên máy.

## Cài hình nền

1. Build và ký bản mới; kiểm tra **1.3.0 (build 6)** trong Cài đặt.
2. Vào **Thư viện → +**, chọn `.tendies` hoặc `.dynor`. Cũng có thể mở tệp bằng Dynor từ Tệp hoặc chọn **Tải và mở trong Dynor** ở Khám phá.
3. Trên iOS 27, tạo và dùng một hình nền **Bộ sưu tập / Collections** mặc định của Apple trước để khởi tạo kho PosterBoard.
4. Trong màn hình gói, bấm **Chuẩn bị cài hình nền**. Trên iOS 18, thao tác kernel có thể làm ứng dụng thoát hoặc thiết bị khởi động lại nếu thất bại; bước này chỉ chạy khi bạn bấm nút.
5. Khi chuẩn bị thành công, bấm **Cài hình nền** và giữ Dynor mở đến khi hoàn tất.
6. Khởi động lại iPhone rồi vào **Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập** để chọn mẫu đã thêm.

Gói `.dynor` cần đăng nhập và Internet mỗi lần cài để kiểm tra quyền/lấy khóa; gói VIP cần VIP còn hiệu lực. Archive giải mã và bản sao staging được lưu tạm trong vùng có bảo vệ rồi dọn sau khi cài/lỗi. Nội dung đã ghi vào PosterBoard tiếp tục tồn tại để iOS hiển thị hình nền. Xem [ENCRYPTED_TENDIES_SETUP.md](ENCRYPTED_TENDIES_SETUP.md). Gói `.tendies`/`.dynor` không có nút xuất hoặc chia sẻ gói trong app.

Ảnh thông thường vẫn lưu vào Photos sau khi được cấp quyền. Mở **Ảnh → Chia sẻ → Dùng làm hình nền** rồi xác nhận bằng giao diện iOS.

## Build trên Codemagic hoặc GitHub

Repository chứa ZIP cần cập nhật **cả** `Dynor-iOS-source.zip` và cấu hình CI ở ngoài ZIP (`codemagic.yaml` hoặc `.github/workflows/build-ipa.yml`). Cấu hình nằm trong ZIP không tự thay thế cấu hình mà CI đang dùng. Nếu repo có `project.yml` và `Dynor/` ở gốc, CI ưu tiên source đã giải nén; hãy cập nhật toàn bộ source đó.

CI tạo icon và project bằng XcodeGen, chạy XCTest trên iPhone Simulator arm64 rồi archive iPhoneOS. Không còn tải XCFramework khi build. Codemagic xuất **Dynor-IPA.zip** chứa **Dynor-unsigned.ipa**; GitHub Actions xuất artifact **Dynor-native-unsigned-IPA**. Các IPA đều chưa ký. Log và kết quả XCTest được lưu trong artifacts.

## Build trên Mac

Cần Xcode 16 trở lên, XcodeGen và Mac Apple Silicon cho Simulator arm64.

```bash
python3 scripts/prepare_icons.py --source-root .
xcodegen generate --spec project.yml
xcodebuild -project Dynor.xcodeproj -scheme Dynor \
  -destination 'platform=iOS Simulator,name=iPhone 16,arch=arm64' test
xcodebuild -project Dynor.xcodeproj -scheme Dynor -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -archivePath build/Dynor.xcarchive \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' archive
```

Đổi tên Simulator theo máy của bạn. Simulator chỉ kiểm tra logic và UI; không chạy truy cập PosterBoard thật.

## Kiểm chứng và dịch vụ

Xem [VERIFICATION.md](VERIFICATION.md) và [INTEGRATION_STATUS.md](INTEGRATION_STATUS.md). Bản tích hợp cần lần build macOS/Xcode thành công và kiểm tra trên iPhone đích trước khi coi là đã xác nhận hoạt động. Chưa build IPA hoặc thử cài wallpaper trên thiết bị trong môi trường Linux này.

Backend tài khoản, VIP và kho online được giữ lại. Cấu hình triển khai nằm trong [WALLPAPER_ONLINE_SETUP.md](WALLPAPER_ONLINE_SETUP.md), [ENCRYPTED_TENDIES_SETUP.md](ENCRYPTED_TENDIES_SETUP.md) và [PAYMENT_SETUP.md](PAYMENT_SETUP.md). Không đặt service-role key hoặc webhook secret trong app.

## Nguồn và giấy phép

Phần truy cập thiết bị và bộ cài hình nền lấy từ **3105**, GPL-3.0, revision nêu trên. Xem `ThirdParty/3105/` để biết giấy phép, provenance và thông báo nguồn phụ thuộc. Khi phân phối bản dẫn xuất, giữ các thông báo giấy phép và cung cấp mã nguồn tương ứng theo điều khoản áp dụng.

Bộ chọn tài liệu và mã descriptor còn giữ nguồn MIT từ [AirCard-iOS](https://github.com/Mak5er/AirCard-iOS/tree/40640c4d827aeab8d798285b57d24fcf6be070d0); xem `ThirdParty/AirCard/LICENSE`. Không còn framework Airlift hoặc phụ thuộc Rust. Ảnh mẫu: `Dynor/Resources/Wallpapers/sources.json` (Unsplash).
