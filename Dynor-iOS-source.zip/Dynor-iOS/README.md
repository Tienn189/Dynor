# Dynor — iOS native 1.1

Ứng dụng SwiftUI cho iPhone/iPad **iOS 18 trở lên**. AirliftFFI đi kèm được build với minimum iOS 18, nên bản này nâng deployment target từ 17 lên 18 để khớp thư viện native.

## Các lỗi đã sửa

- Bộ chọn tệp nhận mọi kiểu tài liệu rồi kiểm tra đuôi/nội dung sau khi chọn: `.tendies` bị nhà cung cấp Tệp nhận thành ZIP hoặc dữ liệu chung không còn bị lọc khỏi picker.
- Nhập file qua security scope và `NSFileCoordinator` trên luồng nền; yêu cầu tải tài liệu iCloud khi cần. Lưu nguyên bản `.tendies`, hỗ trợ nhiều tệp, giới hạn 50 MiB/tệp và báo lỗi cụ thể.
- Nhập pairing record `.plist`, `.mobiledevicepairing`, `.mobilepair` thật; kiểm tra plist XML/binary, sao chép vào Application Support với file protection, loại credentials khỏi backup. Không chỉ lưu tên tệp như bản trước. Giới hạn 5 MiB.
- iOS dưới 27: nhập pairing record có sẵn. iOS 27 trở lên: thêm **Ghép nối iPhone này**, quảng bá Bonjour, hiển thị PIN, thực hiện handshake bằng AirliftFFI và lưu record nhận được.
- Viền các nút danh mục như “Tất cả” được vẽ bằng `strokeBorder` và có khoảng đệm trong thanh cuộn, tránh cắt viền trên/dưới và hai đầu.
- Thư viện → mở tệp Tendies → **Cài hình nền**: kiểm tra archive, tự tìm PosterBoard container, ghi các descriptor và cập nhật tùy chọn bằng AirliftFFI thật. Có tiến trình, log và lỗi khi chưa kết nối hoặc ghi chưa hoàn tất.
- Có hỗ trợ “Mở bằng Dynor” qua `onOpenURL` cho Tendies/pairing. Các thao tác đổi/xóa record bị khóa khi đang cài.

## Cài hình nền

### Tendies

1. Vào **Pairing**. iOS 18–26: nhập file pairing của chính thiết bị từ SideStore, AltStore, LiveContainer, Jitterbug hoặc máy tính. iOS 27+: có thể dùng **Ghép nối iPhone này**, rồi nhập PIN tại Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép nối với Dynor; vẫn có thể nhập file có sẵn.
2. Bật LocalDevVPN hoặc WireGuard ở chế độ loopback phù hợp (`10.7.0.1` / `127.0.0.1`). Dynor không tự cài hay cấu hình VPN.
3. Mở **Thư viện → +**, nhập `.tendies`, mở tệp và bấm **Cài hình nền**. Giữ Dynor mở, iPhone đã mở khóa và VPN hoạt động đến khi hoàn tất.
4. Nhấn giữ màn hình khóa → Thêm hình nền để chọn mẫu mới. Nếu mẫu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại. Dynor không tự respring hoặc tự chọn thay màn hình khóa hiện tại.

Airlift upstream công bố tương thích tới iOS 27.2 beta 2 và đã bị vá từ 27.2 beta 3. Bản Dynor này cho phép thử cài trên **iOS 18–27.1** và chặn **toàn bộ iOS 27.2 trở lên**, vì chưa có allowlist build beta chính xác. Không giả định mọi archive/phiên bản đều hoạt động. Ghép nối ngay trên thiết bị vẫn có nút trên iOS 27+, nhưng khả năng cài là điều kiện riêng.

Installer kiểm tra đường dẫn, loại tệp, kích thước trước khi giải nén, giới hạn dữ liệu giải nén và xác minh CRC. Archive không chứa descriptor PosterBoard sẽ bị từ chối. Nếu một phần đã được ghi rồi mới lỗi, thông báo nêu rõ chưa hoàn tất. Import record chỉ báo đã lưu; kết nối được kiểm tra khi thao tác với dịch vụ thiết bị.

### Ảnh thông thường

Ảnh trong Thư viện hoặc Khám phá vẫn được lưu vào Photos sau khi cấp quyền. Mở Ảnh → Chia sẻ → Dùng làm hình nền rồi xác nhận bằng giao diện của iOS. Gallery mẫu vẫn dùng cơ chế mở khóa qua 5 lượt quảng cáo mô phỏng hiện có.

## Build trên GitHub

Repository dùng ZIP chỉ cần hai tệp:

```text
.github/workflows/build-ipa.yml
Dynor-iOS-source.zip
```

Thay **cả source ZIP và workflow** bằng bản kèm theo. Giữ ZIP ở gốc, không cần giải nén. Workflow nằm bên trong ZIP sẽ không tự chạy nếu chưa được đặt ở `.github/workflows/build-ipa.yml` ngoài repository.

Mở **Actions → Build Dynor native IPA → Run workflow**. Workflow trên runner macOS 15 arm64 sẽ:

1. Giải nén source an toàn, tạo icon và project bằng XcodeGen.
2. Chạy XCTest trên iPhone Simulator arm64; lưu kết quả `Dynor-test-results`.
3. Archive ứng dụng arm64 bằng Xcode, đóng gói `Payload/Dynor.app` thành IPA.
4. Upload artifact **Dynor-native-unsigned-IPA**; lấy `Dynor-unsigned.ipa` bên trong. Khi lỗi, xem artifact **Dynor-build-log**.

**IPA unsigned cần được ký/sideload bằng phương thức hợp lệ cho thiết bị.** Không có chứng chỉ hoặc provisioning profile kèm mã nguồn. Gói đầy đủ chứa framework static arm64 cho iOS và Simulator. Gói tải nhẹ không chứa binary; workflow chạy `scripts/prepare_airlift.py` để tải đúng revision upstream và xác minh SHA-256 trước khi build.

Nếu repo có `project.yml` và `Dynor/` ở gốc, workflow ưu tiên source đã giải nén. Khi đó hãy cập nhật toàn bộ source cùng `Frameworks/`, `DynorTests/`, `ThirdParty/` thay vì chỉ thay ZIP.

## Build trên Codemagic

Repository `Tienn189/Dynor` hiện có `codemagic.yaml`. Cập nhật file này cùng ZIP để bước tải Airlift chạy trước XcodeGen. Chọn nhánh bản sửa rồi chạy workflow **Dynor iOS IPA**. Pipeline chạy các test trên iPhone Simulator arm64, archive ứng dụng và xuất **Dynor-IPA.zip** chứa IPA unsigned. Log và kết quả XCTest được lưu trong artifacts. Không cần chuyển sang GitHub Actions nếu bạn tiếp tục dùng Codemagic.

Lỗi `There is no XCFramework found at '.../Frameworks/AirliftFFI.xcframework'` xảy ra khi `codemagic.yaml` trong repository là bản cũ, không có bước `prepare_airlift.py`, trong khi ZIP nhẹ không kèm `Frameworks/`. Từ bản này `project.yml` có `options.preGenCommand` nên chính XcodeGen sẽ chạy `scripts/prepare_airlift.py` (tải đúng revision và xác minh SHA-256, bỏ qua nếu đã đủ 7 tệp) ngay trước khi sinh project. Chỉ cần thay `Dynor-iOS-source.zip` là build tự lấy được Airlift, kể cả khi `codemagic.yaml` chưa được cập nhật.

## Build và test trên Mac

Cần Xcode 16 trở lên, XcodeGen, Mac Apple Silicon để chạy Simulator với framework arm64 đi kèm.

```bash
python3 scripts/prepare_airlift.py --source-root .
python3 scripts/prepare_icons.py --source-root .
xcodegen generate --spec project.yml
xcodebuild -project Dynor.xcodeproj -scheme Dynor \
  -destination 'platform=iOS Simulator,name=iPhone 16' test
xcodebuild -project Dynor.xcodeproj -scheme Dynor -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -archivePath build/Dynor.xcarchive \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' archive
```

Đổi tên Simulator theo máy của bạn. Intel Mac chỉ build cho thiết bị; Simulator x86_64 không có slice tương ứng.

## Phạm vi kiểm chứng

Xem `VERIFICATION.md`. Môi trường sửa mã là Linux, không có Xcode/Swift compiler hoặc iPhone; chưa xác nhận build IPA, quyền iCloud/Local Network, handshake hoặc kết quả cài hình nền trên thiết bị. Workflow đã bổ sung compile/test thật trên macOS trước khi archive; cần xem Actions và thử trên thiết bị đích.

Đăng nhập Google/SMS, quảng cáo thật và thanh toán StoreKit vẫn chưa tích hợp. Hồ sơ/ưu đãi/quảng cáo trong bản này là trải nghiệm cục bộ như phiên bản trước.

## Nguồn và giấy phép

AirliftFFI và mã pairing/Tendies được điều chỉnh từ [Mak5er/AirCard-iOS](https://github.com/Mak5er/AirCard-iOS), MIT, revision `40640c4d827aeab8d798285b57d24fcf6be070d0`. Xem `ThirdParty/AirCard/LICENSE`, `provenance.json` và `Cargo.lock`. Hash các file framework được đối chiếu với Git tree upstream. Ảnh mẫu: `Dynor/Resources/Wallpapers/sources.json` (Unsplash). Icon theo nguồn ban đầu do người dùng cung cấp.
