# Dynor — iOS native 1.2.1 (build 4)

Ứng dụng SwiftUI cho iPhone/iPad **iOS 18 trở lên**. AirliftFFI đi kèm được build với minimum iOS 18, nên bản này nâng deployment target từ 17 lên 18 để khớp thư viện native.

## Các lỗi đã sửa

- Bộ chọn tệp dùng `UIDocumentPickerViewController` ở chế độ sao chép như AirCard, nhận các UTI Tendies đã đăng ký cùng ZIP/archive/data/ảnh. Chỉ bắt đầu nhập và mở xem trước sau khi bộ chọn đã đóng.
- Đăng ký mở `.tendies` theo cả `com.dynor.tendies` và `com.aircard.tendies` với vai trò Viewer. Kiểm tra tệp đã mở thay cho metadata `isRegularFile` có thể thiếu ở nhà cung cấp tài liệu; giữ tên và đuôi tệp khi URL của provider là mã tạm.
- Nhập file qua security scope và `NSFileCoordinator` trên luồng nền; yêu cầu tải tài liệu iCloud khi cần. Lưu nguyên bản `.tendies`, hỗ trợ nhiều tệp, giới hạn 50 MiB/tệp và báo lỗi cụ thể.
- Nhập pairing record `.plist`, `.mobiledevicepairing`, `.mobilepair` thật; kiểm tra plist XML/binary, sao chép vào Application Support với file protection, loại credentials khỏi backup. Không chỉ lưu tên tệp như bản trước. Giới hạn 5 MiB.
- iOS dưới 27: nhập pairing record có sẵn. iOS 27 trở lên: thêm **Ghép nối iPhone này**, quảng bá Bonjour, hiển thị PIN, thực hiện handshake bằng AirliftFFI và lưu record nhận được.
- Viền các nút danh mục như “Tất cả” được vẽ bằng `strokeBorder` và có khoảng đệm trong thanh cuộn, tránh cắt viền trên/dưới và hai đầu.
- Thư viện → mở tệp Tendies → **Cài hình nền**: kiểm tra archive, tự tìm PosterBoard container, ghi các descriptor và cập nhật tùy chọn bằng AirliftFFI thật. Có tiến trình, log và lỗi khi chưa kết nối hoặc ghi chưa hoàn tất.
- “Mở bằng Dynor” từ Tệp tự chuyển tới Thư viện và mở hình nền vừa nhập; file pairing mở tab Pairing. Nhập một tệp trong Thư viện cũng mở ngay màn hình xem trước/cài đặt.
- Khám phá → **Tải và mở trong Dynor**: ảnh và `.tendies` được thêm vào Thư viện rồi mở ngay màn hình xem trước; Tendies có nút **Cài hình nền**. Tệp định dạng khác giữ bảng chia sẻ.
- Tự tìm địa chỉ IPv4 đang hoạt động của thiết bị, ưu tiên Wi-Fi và dùng `10.7.0.1` dự phòng. Không ép kết nối trực tiếp tới địa chỉ loopback.
- Nhận diện descriptor theo cấu trúc bên trong gói, hỗ trợ hai chiều tên extension Collections/Mercury cũ và mới, giữ các identifier ký hiệu và suggestion metadata cần cho PosterKit.
- Khóa mở tệp khác, xóa hình nền và đổi/xóa pairing trong khi đang cài.

## Cài hình nền

### Bản sửa nhập tệp 1.2.1

Build nhánh `codex/dynor-tendies-aircard` trên Codemagic rồi cài IPA mới. Trong **Cài đặt** của Dynor, kiểm tra **Phiên bản 1.2.1 (build 4)**. Cập nhật ZIP trên GitHub không tự cập nhật ứng dụng đã cài trên iPhone.

Vào **Thư viện → +** hoặc **Nhập ảnh / Tendies**, chọn tệp `.tendies`. Với một tệp, Dynor mở ngay màn hình xem trước sau khi nhập. Có thể dùng **Tệp → nhấn giữ tệp → Chia sẻ → Dynor** nếu thao tác chạm đang mở ứng dụng khác. Trường hợp không chọn được tệp hoặc nhập vẫn lỗi cần ghi lại vị trí lưu, tên/đuôi và thông báo lỗi để kiểm tra trên thiết bị.

### Tendies

1. Vào **Pairing**. iOS 18–26: nhập file pairing của chính thiết bị từ SideStore, AltStore, LiveContainer, Jitterbug hoặc máy tính. iOS 27+: có thể dùng **Ghép nối iPhone này**, rồi nhập PIN tại Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép nối với Dynor; vẫn có thể nhập file có sẵn.
2. Bật LocalDevVPN hoặc WireGuard với cấu hình kết nối thiết bị phù hợp (`10.7.0.1` là địa chỉ dự phòng). Cho phép **Mạng cục bộ** khi iOS hỏi. Dynor tự tìm thêm địa chỉ mạng của thiết bị, không tự cài hay cấu hình VPN.
3. Mở **Thư viện → +** để nhập `.tendies`, mở tệp bằng Dynor từ ứng dụng Tệp, hoặc dùng **Tải và mở trong Dynor** ở Khám phá. Tại màn hình xem trước, bấm **Cài hình nền**. Giữ Dynor mở, iPhone đã mở khóa và VPN hoạt động đến khi hoàn tất.
4. Nhấn giữ màn hình khóa → Thêm hình nền để chọn mẫu mới. Nếu mẫu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại. Dynor không tự respring hoặc tự chọn thay màn hình khóa hiện tại.

Phạm vi cài Tendies theo AirCard là **iOS 18.0–27.2 beta 2**. Dynor cho phép thử trực tiếp trên **iOS 18–27.1**. Với **iOS 27.2.0**, chọn đúng **beta 1** hoặc **beta 2** trong bộ chọn phiên bản ở màn hình cài: iOS chỉ trả về `27.2`, còn upstream chưa công bố danh sách build để tự phân biệt thứ tự beta. Lựa chọn này là thông tin bạn cung cấp, không phải build đã được Dynor tự xác minh. **27.2 beta 3 trở lên, RC, 27.2 chính thức, 27.2.1 trở lên và các bản tương lai bị chặn**, vì upstream công bố Airlift đã bị vá từ 27.2 beta 3.

Các bản iOS 27 developer beta 1–4 và public beta 1–2 bạn yêu cầu nằm trong luồng iOS 27.0 khi hệ thống báo `27.0`. Điều này cho phép thử cài, chưa chứng minh từng beta hoặc từng gói Tendies hoạt động trên thiết bị. Ghép nối ngay trên thiết bị trên iOS 27 và điều kiện cho phép cài là hai điều kiện riêng.

Installer kiểm tra đường dẫn, loại tệp, kích thước trước khi giải nén, giới hạn dữ liệu giải nén và xác minh CRC. Archive không chứa descriptor PosterBoard sẽ bị từ chối. Nếu một phần đã được ghi rồi mới lỗi, thông báo nêu rõ chưa hoàn tất. Import record chỉ báo đã lưu; kết nối được kiểm tra khi thao tác với dịch vụ thiết bị.

### Ảnh thông thường

Ảnh trong Thư viện hoặc Khám phá vẫn được lưu vào Photos sau khi cấp quyền. Mở Ảnh → Chia sẻ → Dùng làm hình nền rồi xác nhận bằng giao diện của iOS. Gallery mẫu vẫn dùng cơ chế mở khóa qua 5 lượt quảng cáo mô phỏng hiện có.

## Build trên GitHub

Repository dùng ZIP chỉ cần hai tệp:

```text
.github/workflows/build-ipa.yml
Dynor-iOS-source.zip
```

Thay **cả source ZIP và workflow** bằng bản kèm theo. Giữ ZIP ở gốc, không cần giải nén. Workflow nằm bên trong ZIP sẽ không tự chạy nếu chưa được đặt ở `.github/workflows/build-ipa.yml` ngoài repository.

Mở **Actions → Build Dynor native IPA → Run workflow**. Workflow trên runner macOS 15 arm64 sẽ:

1. Giải nén source an toàn, tạo icon và project bằng XcodeGen.
2. Chạy XCTest trên iPhone Simulator arm64; lưu kết quả `Dynor-test-results`.
3. Archive ứng dụng arm64 bằng Xcode, đóng gói `Payload/Dynor.app` thành IPA.
4. Upload artifact **Dynor-native-unsigned-IPA**; lấy `Dynor-unsigned.ipa` bên trong. Khi lỗi, xem artifact **Dynor-build-log**.

**IPA unsigned cần được ký/sideload bằng phương thức hợp lệ cho thiết bị.** Không có chứng chỉ hoặc provisioning profile kèm mã nguồn. Gói đầy đủ chứa framework static arm64 cho iOS và Simulator. Gói tải nhẹ không chứa binary; workflow chạy `scripts/prepare_airlift.py` để tải đúng revision upstream và xác minh SHA-256 trước khi build.

Nếu repo có `project.yml` và `Dynor/` ở gốc, workflow ưu tiên source đã giải nén. Khi đó hãy cập nhật toàn bộ source cùng `Frameworks/`, `DynorTests/`, `ThirdParty/` thay vì chỉ thay ZIP.

## Build trên Codemagic

Repository `Tienn189/Dynor` hiện có `codemagic.yaml`. Cập nhật file này cùng ZIP để bước tải Airlift chạy trước XcodeGen. Chọn nhánh bản sửa rồi chạy workflow **Dynor iOS IPA**. Pipeline chạy các test trên iPhone Simulator arm64, archive ứng dụng và xuất **Dynor-IPA.zip** chứa IPA unsigned. Log và kết quả XCTest được lưu trong artifacts. Không cần chuyển sang GitHub Actions nếu bạn tiếp tục dùng Codemagic.

Lỗi `There is no XCFramework found at '.../Frameworks/AirliftFFI.xcframework'` xảy ra khi `codemagic.yaml` trong repository là bản cũ, không có bước `prepare_airlift.py`, trong khi ZIP nhẹ không kèm `Frameworks/`. Từ bản này `project.yml` có `options.preGenCommand` nên chính XcodeGen sẽ chạy `scripts/prepare_airlift.py` (tải đúng revision và xác minh SHA-256, bỏ qua nếu đã đủ 7 tệp) ngay trước khi sinh project. Chỉ cần thay `Dynor-iOS-source.zip` là build tự lấy được Airlift, kể cả khi `codemagic.yaml` chưa được cập nhật.

## Build và test trên Mac

Cần Xcode 16 trở lên, XcodeGen, Mac Apple Silicon để chạy Simulator với framework arm64 đi kèm.

```bash
python3 scripts/prepare_airlift.py --source-root .
python3 scripts/prepare_icons.py --source-root .
xcodegen generate --spec project.yml
xcodebuild -project Dynor.xcodeproj -scheme Dynor \
  -destination 'platform=iOS Simulator,name=iPhone 16' test
xcodebuild -project Dynor.xcodeproj -scheme Dynor -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -archivePath build/Dynor.xcarchive \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' archive
```

Đổi tên Simulator theo máy của bạn. Intel Mac chỉ build cho thiết bị; Simulator x86_64 không có slice tương ứng.

## Phạm vi kiểm chứng

Xem `VERIFICATION.md`. Môi trường sửa mã là Linux, không có Xcode/Swift compiler hoặc iPhone; chưa xác nhận build IPA, quyền iCloud/Local Network, handshake hoặc kết quả cài hình nền trên thiết bị. Workflow đã bổ sung compile/test thật trên macOS trước khi archive; cần xem Actions và thử trên thiết bị đích.

Đăng nhập Google/SMS, quảng cáo thật và thanh toán StoreKit vẫn chưa tích hợp. Hồ sơ/ưu đãi/quảng cáo trong bản này là trải nghiệm cục bộ như phiên bản trước.

## Nguồn và giấy phép

AirliftFFI và mã pairing/Tendies được điều chỉnh từ [Mak5er/AirCard-iOS](https://github.com/Mak5er/AirCard-iOS), MIT, revision `40640c4d827aeab8d798285b57d24fcf6be070d0`. Xem `ThirdParty/AirCard/LICENSE`, `provenance.json` và `Cargo.lock`. Hash các file framework được đối chiếu với Git tree upstream. Ảnh mẫu: `Dynor/Resources/Wallpapers/sources.json` (Unsplash). Icon theo nguồn ban đầu do người dùng cung cấp.
