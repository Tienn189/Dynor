# Kiểm chứng Dynor 1.3.0 (build 6)

Bản này thay cơ chế cài wallpaper bằng mã 3105 ghim tại `a72617ed4c764a65d8aac1e91aca95231e72a2cb`. Không dùng kết quả kiểm thử Airlift của phiên bản cũ để xác nhận bộ cài mới.

## Phạm vi kiểm tra

Môi trường sửa mã là Linux. **Chưa build IPA bằng Xcode, chưa chạy XCTest trên Simulator và chưa thử cài wallpaper trên iPhone.** Kiểm tra cú pháp, cấu hình hoặc kiểm thử Node không chứng minh native access thành công.

Các kiểm tra đã chạy trong bản bàn giao:

- `node --test Supabase/tests/encrypted-packages.test.mjs Tools/DynorVault/tests/crypto.test.mjs`: hai tệp kiểm thử đều đạt, không lỗi.
- Parse YAML của `project.yml`, `codemagic.yaml` và GitHub Actions; `bash -n` cho 11 khối shell CI, parse AST các Python heredoc: đạt.
- Parse các tệp Python/JSON, kiểm tra include native nội bộ và 27 SHA-256 nguồn 3105 đã ghim: đạt.
- `git diff --check`: đạt.
- Thêm XCTest cho phạm vi iOS/build, đường dẫn container, quét kho nhiều thế hệ, biến thể gói, symlink, ghi/đổi identifier, rollback và khôi phục theo journal. Các XCTest này **chưa chạy** trong Linux.

CI giữ bước XCTest trên iPhone Simulator arm64 trước khi archive iPhoneOS; cần kiểm tra log và artifact từ lần chạy macOS.

## Kiểm tra trên Mac

1. Chạy `python3 scripts/prepare_icons.py --source-root .`, `xcodegen generate --spec project.yml` rồi `xcodebuild test` cho scheme Dynor trên iPhone Simulator arm64.
2. Xác nhận compile/link các nguồn native và bridging header, Info.plist bản 1.3.0/build 6, bundle `com.apple.mobile.MobileHouseArrest`, UTI `.tendies` và `.dynor`.
3. Chạy các XCTest import, UTI, archive, descriptor, policy hỗ trợ iOS và gói mã hóa. Simulator phải từ chối truy cập thiết bị thật.
4. Archive iPhoneOS unsigned; kiểm tra executable arm64 và cấu trúc `Payload/Dynor.app`. Ký enterprise giữ nguyên bundle ID trước khi thử thiết bị.

## Kiểm tra trên iPhone

Ghi lại model, iOS, build, cách ký và kết quả thực tế. Các giới hạn dưới đây lấy từ 3105; chưa được xác nhận riêng với Dynor:

| Phiên bản | Luồng cần xác nhận |
| --- | --- |
| iOS 18.0–18.7.1 | Bấm chuẩn bị bằng tay, chạy route kernel, phát hiện PosterBoard, cài gói. Thất bại có thể thoát app/khởi động lại máy. |
| iOS 26.0–26.6.1 | Chuẩn bị qua MHA-C2 với enterprise và bundle ID đúng; không hỏi pairing/VPN. |
| iOS 27.0 `24A5355q`, `24A5370h`, `24A5380h`, `24A5390f` | Mỗi build cần thử riêng, có hình nền Apple Collections đang dùng trước khi chuẩn bị. |
| Ngoài phạm vi / build 27 khác | Nút chuẩn bị/cài bị khóa, báo không hỗ trợ; không chạy native access. |

Kiểm tra nhập `.tendies` từ local/iCloud, mở bằng Dynor, tải từ Khám phá và luồng một/nhiều tệp. Mở `.dynor` phải kiểm tra đăng nhập/VIP, cấp khóa và giải mã; khóa sai, gói bị sửa hoặc quyền bị thu hồi phải lỗi trước ghi. Ảnh vẫn lưu Photos/chia sẻ được.

Kiểm tra quét nhiều generation PosterBoard, descriptor Collections/Photos/Mercury, gói full container/ordered. Archive hỏng, CRC sai, path traversal, symlink, quá giới hạn hoặc thiếu descriptor phải bị từ chối. Lỗi ghi phải không báo thành công; kiểm tra journal/rollback, khóa thao tác trong lúc cài và khôi phục trạng thái UI sau lỗi.

Sau cài, khởi động lại iPhone rồi chọn hình nền qua Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập. Xác nhận hình nền đã có từ trước vẫn còn. Dynor không tự reboot hoặc tự chọn wallpaper.

Bundle ID mới không tự di chuyển thư viện và Keychain cũ. Thử nhập lại tệp, đăng nhập mới và xác nhận truy cập backend. Không cài chồng lên 3105 đang có nếu cần giữ dữ liệu ứng dụng đó.

## Gói mã hóa và backend

Các bộ kiểm thử Node nằm tại `Supabase/tests/encrypted-packages.test.mjs` và `Tools/DynorVault/tests/crypto.test.mjs`. Cần chạy lại và ghi kết quả cho bản bàn giao. Triển khai theo `ENCRYPTED_TENDIES_SETUP.md` rồi xác nhận luồng production riêng. Việc kiểm thử Node thành công không xác nhận khả năng cài PosterBoard trên thiết bị.
