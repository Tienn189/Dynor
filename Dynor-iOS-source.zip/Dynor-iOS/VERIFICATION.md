# Kiểm chứng bản sửa 1.1

## Đã chạy trong môi trường Linux

- Parser tree-sitter Swift kiểm tra 14 tệp Swift (11 tệp ứng dụng, 3 tệp test): không có node lỗi hoặc thiếu cú pháp. Đây không phải Swift typecheck.
- Parse YAML project/workflow; kiểm tra tất cả `run` bằng `bash -n`; parse Python helper và các đoạn Python trong workflow: đạt.
- Kiểm tra helper giải nén source thật và fixture framework đi kèm; từ chối đường dẫn traversal/tuyệt đối/backslash, duplicate, symlink và nhiều project; ưu tiên source đã giải nén: đạt.
- Kiểm tra logic chọn iPhone Simulator từ JSON: chọn runtime mới nhất có thiết bị khả dụng, lỗi rõ khi không có: đạt.
- Parse BSD ar/Mach-O ở cả hai slice AirliftFFI: đủ các symbol C được sử dụng; thư viện chỉ có arm64 và minimum OS 18. Đã nâng deployment target app lên iOS 18. Header C qua kiểm tra cú pháp.
- Git blob hash của 7 file framework khớp Git tree upstream revision `40640c4d827aeab8d798285b57d24fcf6be070d0`; SHA-256 lưu tại `ThirdParty/AirCard/provenance.json`.
- Rà soát thủ công chữ ký FFI/zlib, vòng đời con trỏ callback, worker queue, serialized install, snapshot inputs, khóa đổi pairing trong khi cài, cancellation và callback cũ trong pairing.

## Kiểm thử đã thêm, chưa chạy trong Linux

15 XCTest cases trong `DynorTests/`:

- 5 test import: giữ nguyên byte/name `.tendies`, tệp rỗng/thư mục, kích thước giới hạn, pairing XML/binary, dữ liệu plist không hợp lệ.
- 7 test archive: CRC, traversal/absolute/Windows paths, symlink/case collision, lệch local header/truncated ZIP, quá cỡ/encryption, thiếu/dư tệp sau giải nén, bounded DEFLATE và kích thước khai báo sai.
- 3 test compatibility: iOS 18/26/27.0/27.1 được phép thử, iOS 17 bị chặn, iOS 27.2/27.3/28 bị chặn.

Workflow GitHub Actions chạy XCTest bằng iPhone Simulator arm64 trước khi archive IPA. Chỉ Actions thành công mới xác nhận compile/link/test trên macOS. Kết quả và log được upload thành artifact.

## Cần kiểm tra trên iPhone đích

- Import `.tendies` từ Tệp local và iCloud (file chưa tải), file có chữ hoa trong extension, từ nhiều nhà cung cấp.
- Import `pairingFile.plist` và `rp_pairing_file.plist` thật; đóng/mở lại Dynor, kiểm tra bản sao còn dùng được; file gốc giữ nguyên.
- Trên iOS 18–26: không có nút ghép nối tại chỗ, vẫn nhập file được. Trên iOS 27+: nút Ghép nối, quyền Mạng cục bộ, PIN Settings, thành công/hủy/từ chối quyền và thử lại.
- Bật LocalDevVPN, thử cài archive hợp lệ: tìm container, ghi descriptor, refresh preferences, chọn wallpaper trong Lock Screen. Ngắt VPN/file record sai phải báo lỗi, không báo đã cài.
- Kiểm tra nhánh lỗi sau khi đã ghi một phần và không cho thay/xóa pairing giữa lượt cài.
- Kiểm tra viền “Tất cả” và danh mục hai đầu thanh cuộn, chế độ sáng/tối và cỡ chữ lớn.
- Ảnh thông thường: cấp/từ chối quyền Photos, lưu và dùng làm hình nền qua giao diện hệ thống.

Môi trường này không có Xcode/Swift compiler, iOS Simulator hoặc iPhone: **chưa build IPA, chưa thực thi XCTest, chưa xác nhận handshake hay cài hình nền trên thiết bị**. Native code đã được tích hợp thay cho placeholder; kết quả thực tế phụ thuộc iOS, pairing và VPN. Bản này không tự respring. iOS 27.2+ bị chặn bảo thủ, kể cả beta 1/2 chưa có allowlist build.

## Sửa lỗi thiếu AirliftFFI.xcframework trên Codemagic

- Nguyên nhân: log Codemagic có bước "Tạo icon và project Xcode" (yaml cũ, không gọi `prepare_airlift.py`) cộng với ZIP nhẹ không có `Frameworks/`, nên `xcodebuild archive` báo "There is no XCFramework found".
- Cách sửa: thêm `options.preGenCommand: python3 scripts/prepare_airlift.py --source-root .` vào `project.yml`. Đã kiểm tra YAML parse đúng, lệnh gọi đúng script khi chạy từ thư mục chứa `project.yml`, và 6 test Python offline của helper vẫn đạt.
- Chưa kiểm chứng trong môi trường sửa mã: tải thật từ GitHub (sandbox chặn `codeload.github.com`) và chạy XcodeGen/Xcode thật. Cần chạy lại build Codemagic để xác nhận.

## Gói tải nhẹ

- Bỏ binary `Frameworks/` khỏi ZIP để dễ tải lên GitHub qua web. Workflow tải Airlift theo commit cố định và xác minh SHA-256 đủ 7 tệp trước khi tạo project.
- Đã chạy 6 kiểm thử Python cho tải/khôi phục thư viện, hash sai, thiếu member và giới hạn dung lượng: đạt.
- Đã thử thật với source không có Frameworks: tải archive theo commit từ GitHub và cài đủ 7 tệp với SHA-256 đúng: đạt. Kiểm tra này không thay thế build Xcode hoặc thử trên iPhone.
