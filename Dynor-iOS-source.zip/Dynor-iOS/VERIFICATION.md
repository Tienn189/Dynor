# Bản sửa 1.2.2 (build 5) — nhập pairing

Chỉ rà soát mã; môi trường sửa không có Swift/Xcode nên **chưa compile, chưa chạy XCTest, chưa thử trên iPhone**. Đã thêm 3 test: picker pairing nhận `.plist`/UTI dynamic/mọi tài liệu, tệp pairing không đuôi, tệp pairing bị thêm `.txt`. Cần kiểm tra trên máy: nhập `pairingFile.plist`, `*.mobiledevicepairing`, tệp không đuôi từ Tệp (On My iPhone, iCloud Drive, SideStore/LiveContainer), mở lại ứng dụng và xác nhận bản sao còn dùng được.

# Kiểm chứng bản sửa 1.2.1 (build 4)

## Đã kiểm tra trong môi trường Linux

- Tải mã nguồn công khai AirCard; HEAD là `40640c4d827aeab8d798285b57d24fcf6be070d0`, trùng revision đã ghim trong Dynor. Đối chiếu luồng Tendies, cấu trúc PosterBoard, chữ ký FFI và cách chọn địa chỉ mạng với upstream.
- Đủ 7 tệp AirliftFFI được xác minh SHA-256 theo `ThirdParty/AirCard/provenance.json`. Chạy `scripts/prepare_airlift.py` với bộ framework này xác minh đủ hash và bỏ qua tải lại.
- Parser tree-sitter Swift kiểm tra **23 tệp Swift**, không có node lỗi hoặc thiếu cú pháp. Đây là kiểm tra cú pháp, không phải Swift typecheck, compile hay link.
- Đối chiếu picker với AirCard: dùng native copy-based picker, nhận mọi UTI cho đuôi Tendies và ZIP/archive/data. Parse `project.yml` xác nhận hai UTI Tendies, archive/ZIP conformance, vai trò Viewer và phiên bản 1.2.1/build 4. Chưa kiểm tra thao tác chọn tệp trên iPhone.
- **6 kiểm thử Python** trong `scripts/test_prepare_airlift.py` đạt: tải/khôi phục framework, hash sai, thiếu member và giới hạn dung lượng.
- Parse YAML của `project.yml`, `codemagic.yaml` và `.github/workflows/build-ipa.yml`; kiểm tra các khối shell bằng `bash -n`; parse các Python helper bằng `ast.parse`: đạt.
- Rà soát thủ công vòng đời C-string khi cấu hình Airlift: Rust sao chép chuỗi đồng bộ; Swift giữ bộ nhớ tới khi hai lời gọi cấu hình hoàn tất. Địa chỉ loopback, interface tunnel và interface không hoạt động không được thêm làm ứng viên thiết bị.

Các kiểm tra trên không xác nhận việc cài hình nền thành công trên iPhone.

## XCTest đã có, chưa chạy trong Linux

**33 phương thức kiểm thử** trong `DynorTests/`:

- 7 test import: giữ nguyên byte/name `.tendies`, tệp rỗng/thư mục, giới hạn dung lượng, pairing XML/binary, dữ liệu plist không hợp lệ, từ chối URL web, tên provider/URL tạm không làm mất đuôi tệp.
- 3 test loại tài liệu: picker nhận các UTI Dynor/AirCard và mọi UTI Tendies đã đăng ký, có các fallback provider, Info.plist của app khai báo mở tệp bằng cả hai UTI với vai trò Viewer.
- 7 test archive: CRC, traversal/absolute/Windows paths, symlink/case collision, local header lệch/truncated ZIP, dung lượng/encryption, thiếu/dư tệp sau giải nén, bounded DEFLATE và kích thước khai báo sai.
- 6 test descriptor: tên extension cũ/mới hai chiều, gói full container, bỏ metadata macOS, không lấy nhầm tên thư mục ngoài archive, giữ suggestion metadata, đồng bộ identifier số và giữ identifier ký hiệu, từ chối descriptor rỗng.
- 4 test địa chỉ mạng: Wi-Fi đứng trước các interface khác, loại loopback/tunnel, loại địa chỉ sai/interface tắt, fallback và loại trùng.
- 6 test compatibility: iOS 18–27.1 được phép thử; iOS thấp hơn minimum bị chặn; iOS 27.2.0 chỉ mở cài khi người dùng chọn beta 1/2; beta 3+/RC/chính thức bị chặn; chọn beta không mở được 27.2.1+/bản tương lai; điều kiện ghép nối tách khỏi điều kiện cài.

Workflow GitHub Actions/Codemagic chạy XCTest trên iPhone Simulator arm64 trước khi archive IPA. Cần lần chạy macOS thành công để xác nhận compile, link và kết quả XCTest; log và test results được lưu thành artifact.

## Cần kiểm tra trên iPhone đích

Ghi lại model máy, phiên bản iOS và build thực tế khi kiểm tra. Việc app cho phép thử cài chưa chứng minh từng beta đã hoạt động.

| Nhóm phiên bản | Cần xác nhận |
| --- | --- |
| iOS 18–26.x, đặc biệt iOS 26 mà người dùng yêu cầu | Nhập pairing của chính thiết bị; không có ghép nối tại chỗ; cài và chọn Tendies qua Màn hình khóa. |
| iOS 27.0 developer beta 1, 2, 3, 4 | Kiểm tra riêng từng beta: phiên bản/build, nhập pairing hoặc PIN trong Cài đặt, kết nối LocalDevVPN, cài descriptor và chọn hình nền. |
| iOS 27.0 public beta 1, 2 | Kiểm tra riêng từng public beta với cùng quy trình, không suy ra kết quả từ developer beta. |
| iOS 27.1 | Ghép nối, cài và chọn hình nền; chưa có kiểm chứng thiết bị trong môi trường sửa mã. |
| iOS 27.2 beta 1 và beta 2 | Khi chưa chọn bản beta thì cài bị khóa. Chọn đúng beta đang dùng mở khả năng thử cài; kiểm tra native write và kết quả trong Màn hình khóa riêng trên mỗi build. |
| iOS 27.2 beta 3+, RC, bản chính thức, 27.2.1+, bản tương lai | Cài bị khóa; chọn nhãn beta không được mở cài cho point release/bản tương lai. Không cần thực hiện native write để kiểm tra nhánh bị chặn. |

Các luồng cần kiểm tra cùng phiên bản đích:

- Nhập `.tendies` từ Tệp local và iCloud chưa tải; tên có chữ hoa trong extension; nhà cung cấp tài liệu khác nhau. Thử khi có/không cài AirCard cùng máy: tệp phải chọn được, “Chia sẻ → Dynor” xuất hiện. Hủy hoặc vuốt đóng picker rồi mở lại; nhập một/nhiều tệp và kiểm tra chuyển sheet sang màn hình xem trước.
- Từ Khám phá, tải `.tendies` và ảnh qua **Tải và mở trong Dynor**: thêm vào Thư viện và mở ngay màn hình xem trước. Định dạng khác phải báo không hỗ trợ, không mở bảng chia sẻ và được dọn khỏi thư mục tải tạm. Kiểm tra đăng nhập/VIP theo quyền nội dung hiện có.
- Mở gói Tendies từ Thư viện hoặc Khám phá: không có nút chia sẻ/xuất gói, vẫn có thể cài hình nền. Mở ảnh: vẫn lưu vào Photos và chia sẻ ảnh gốc được.
- Import `pairingFile.plist` và `rp_pairing_file.plist` thật; đóng/mở lại Dynor và kiểm tra bản sao còn dùng được, file gốc giữ nguyên. Trên iOS 27, thử ghép nối PIN thành công, hủy, từ chối quyền Mạng cục bộ và thử lại.
- Bật LocalDevVPN và mở khóa máy: tìm PosterBoard container, ghi các descriptor Collections/Mercury theo tên cũ/mới, cập nhật preferences, chọn wallpaper trong Màn hình khóa. Thử Wi-Fi bật/tắt và cấu hình VPN tương thích. Ngắt VPN hoặc dùng pairing sai phải báo lỗi.
- Kiểm tra gói full container, descriptor đơn, suggestion metadata và identifier ký hiệu. Gói hỏng hoặc không có descriptor phải bị từ chối trước khi ghi.
- Kiểm tra nhánh lỗi sau khi ghi một phần: báo chưa hoàn tất; khóa đổi/xóa pairing, xóa hình nền và mở tệp khác trong lượt cài. Hoàn tất hoặc lỗi phải khôi phục trạng thái nút và tự khóa màn hình như trước lượt cài.
- Kiểm tra viền danh mục, chế độ sáng/tối, cỡ chữ lớn. Ảnh thông thường: cấp/từ chối quyền Photos, lưu và đặt làm hình nền qua giao diện hệ thống.

Môi trường này không có Swift compiler, Xcode, iOS Simulator hoặc iPhone: **chưa build IPA, chưa thực thi XCTest, chưa xác nhận handshake hoặc cài hình nền trên thiết bị**. Dynor không tự respring hoặc tự chọn thay màn hình khóa. Upstream chưa cung cấp allowlist build beta; lựa chọn beta 1/2 ở iOS 27.2 là người dùng báo phiên bản đang dùng, không phải xác minh build tự động.

## Framework và build

- `project.yml` giữ `options.preGenCommand: python3 scripts/prepare_airlift.py --source-root .`. XcodeGen sẽ tải framework đã ghim và xác minh 7 SHA-256 khi source chưa có `Frameworks/`; nếu đã đủ bộ đúng hash thì bỏ qua tải lại.
- Gói tải nhẹ có thể bỏ `Frameworks/`; không bỏ `scripts/prepare_airlift.py` hoặc `ThirdParty/AirCard/provenance.json`. Cần mạng khi build lần đầu mà chưa có framework.
- Kiểm tra tải/xác minh framework không thay thế XcodeGen, archive bằng Xcode hoặc thử trên thiết bị. Cần chạy lại GitHub Actions/Codemagic với source 1.2.1 để xác nhận IPA và cài bản mới để kiểm tra lỗi nhập tệp.
