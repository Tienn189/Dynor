# Dynor – trạng thái tích hợp

- Bản 1.2 (build 3): tích hợp luồng Tendies theo AirCard/Airlift từ mở tệp, nhập Thư viện hoặc tải kho online tới màn hình cài, tiến trình và lỗi cài thực tế.
- Phạm vi AirCard: iOS 18.0–27.2 beta 2. iOS 18–27.1 cho phép thử trực tiếp; riêng 27.2.0 cần chọn đúng beta 1/2 đang dùng vì upstream không có allowlist build. Không tự coi lựa chọn beta là build đã xác minh. Beta 3+/RC/chính thức, 27.2.1+ và phiên bản tương lai bị chặn.
- iOS 18–26 nhập pairing record; iOS 27 có thêm ghép nối trong Cài đặt. Kết nối ưu tiên địa chỉ mạng Wi-Fi đang hoạt động với `10.7.0.1` dự phòng, không ép địa chỉ loopback. Bản này không tự respring.
- Đã cập nhật: tài khoản ở Cài đặt dùng DynorAccountService thay cho hồ sơ cục bộ; UI trắng đen và chế độ tối; VIP bỏ qua giới hạn quảng cáo mô phỏng khi còn hạn.
- Màn hình chọn VIP đã là SwiftUI native, không còn mở Safari.
- **Chưa bật thanh toán thật**: cần API server-side tạo đơn theo phiên Supabase, trả thông tin ngân hàng/QR, webhook xử lý gói tháng 30 ngày và cơ chế chống trùng. Nút tạo đơn hiện thông báo cấu hình chưa hoàn tất.
- Không đặt service_role hoặc SEPAY_WEBHOOK_SECRET trong app.
- Chưa kiểm tra build trên macOS/Xcode trong môi trường này.
- Để phát hành qua App Store, cần kiểm tra yêu cầu StoreKit/In-App Purchase cho tính năng số.
