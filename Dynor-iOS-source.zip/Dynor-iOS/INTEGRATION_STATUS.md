# Dynor – trạng thái tích hợp

- Đã cập nhật: tài khoản ở Cài đặt dùng DynorAccountService thay cho hồ sơ cục bộ; UI trắng đen và chế độ tối; VIP bỏ qua giới hạn quảng cáo mô phỏng khi còn hạn.
- Màn hình chọn VIP đã là SwiftUI native, không còn mở Safari.
- **Chưa bật thanh toán thật**: cần API server-side tạo đơn theo phiên Supabase, trả thông tin ngân hàng/QR, webhook xử lý gói tháng 30 ngày và cơ chế chống trùng. Nút tạo đơn hiện thông báo cấu hình chưa hoàn tất.
- Không đặt service_role hoặc SEPAY_WEBHOOK_SECRET trong app.
- Chưa kiểm tra build trên macOS/Xcode trong môi trường này.
- Để phát hành qua App Store, cần kiểm tra yêu cầu StoreKit/In-App Purchase cho tính năng số.
