# Dynor — trạng thái tích hợp 1.3.0 (build 6)

- Bộ cài PosterBoard chuyển sang 3105 revision `a72617ed4c764a65d8aac1e91aca95231e72a2cb`; gỡ AirliftFFI, Pairing, VPN, Bonjour và downloader framework.
- Truy cập thiết bị được chuẩn bị khi người dùng bấm nút. iOS 18.0–18.7.1 dùng route kernel; iOS 26.0–26.6.1 và bốn build iOS 27.0 đã ghim dùng MHA-C2.
- Bundle identifier là `com.apple.mobile.MobileHouseArrest`, cần giữ khi ký enterprise theo hướng dẫn 3105. Dữ liệu/Keychain của bundle Dynor cũ không tự chuyển; cần nhập lại tệp và đăng nhập lại.
- Giữ nhập `.tendies`, gói `.dynor`, ảnh, Thư viện, Khám phá và backend tài khoản/VIP. Cài gói mã hóa vẫn kiểm tra quyền và dọn bản rõ tạm sau thao tác.
- CI không tải thư viện native từ mạng; mã C/Objective-C có trong source, nối Swift qua bridging header. Pipeline tiếp tục chạy XCTest Simulator rồi archive IPA unsigned.
- Chính sách iOS chỉ là điều kiện cho phép thử theo upstream. Chưa có kết quả build Xcode/XCTest hoặc cài wallpaper trên iPhone cho bản này; xem `VERIFICATION.md`.
- Thanh toán, quảng cáo và backend production vẫn cần cấu hình/xác nhận theo tài liệu triển khai. Không chứa chứng chỉ ký, service-role key hoặc webhook secret trong mã nguồn app.
