import SwiftUI
import AVKit
import UIKit
import UniformTypeIdentifiers

private enum OnlineConfig {
    static let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    static let key = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    static func preview(_ path: String) -> URL? {
        let trimmed = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        // The admin website stores absolute Supabase Storage URLs.
        if let url = URL(string: trimmed),
           let scheme = url.scheme?.lowercased(),
           scheme == "https" || scheme == "http" {
            return url
        }

        // Legacy records may store a path relative to dynor-previews.
        let relative = trimmed.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let encoded = relative.split(separator: "/").map { segment in
            String(segment).addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? String(segment)
        }.joined(separator: "/")
        return URL(string: "\(base.absoluteString)/storage/v1/object/public/dynor-previews/\(encoded)")
    }
}

private struct OnlineWallpaper: Identifiable, Decodable {
    let id: UUID
    let title: String
    let category: String
    let cover_path: String
    let video_path: String?
    let is_vip: Bool
}

@MainActor
private final class OnlineGalleryModel: ObservableObject {
    @Published var items: [OnlineWallpaper] = []
    @Published var favorites: Set<UUID> = []
    @Published var loading = false
    @Published var error: String?
    private let account = DynorAccountService.shared

    private func request(_ path: String, method: String = "GET", token: String? = nil, body: Data? = nil, prefer: String? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: OnlineConfig.base)?.absoluteURL else { throw GalleryFailure.message("URL không hợp lệ") }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(OnlineConfig.key, forHTTPHeaderField: "apikey")
        if let token { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body { req.httpBody = body; req.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if let prefer { req.setValue(prefer, forHTTPHeaderField: "Prefer") }
        let (data,response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "Không kết nối được Supabase"
            throw GalleryFailure.message("Máy chủ: \(text.prefix(180))")
        }
        return data
    }

    func reload() async {
        loading = true
        defer { loading = false }
        do {
            let data = try await request("rest/v1/dynor_wallpapers?select=id,title,category,cover_path,video_path,is_vip&published=eq.true&order=created_at.desc")
            items = try JSONDecoder().decode([OnlineWallpaper].self, from: data)
            error = nil
            await reloadFavorites()
        } catch { self.error = error.localizedDescription }
    }

    func reloadFavorites() async {
        guard let token = await account.galleryAccessToken() else { favorites = []; return }
        do {
            let data = try await request("rest/v1/dynor_favorites?select=wallpaper_id", token: token)
            struct Favorite: Decodable { let wallpaper_id: UUID }
            favorites = Set(try JSONDecoder().decode([Favorite].self, from: data).map(\.wallpaper_id))
        } catch { self.error = "Không đồng bộ được yêu thích: \(error.localizedDescription)" }
    }

    private func authenticatedUserID(token: String) async throws -> UUID {
        let data = try await request("auth/v1/user", token: token)
        struct AuthUser: Decodable { let id: UUID }
        return try JSONDecoder().decode(AuthUser.self, from: data).id
    }

    func toggleFavorite(_ id: UUID) async {
        guard let token = await account.galleryAccessToken() else { error = "Đăng nhập tài khoản Dynor để lưu yêu thích."; return }
        let wasFavorite = favorites.contains(id)
        do {
            let userID = try await authenticatedUserID(token: token)
            if wasFavorite {
                _ = try await request("rest/v1/dynor_favorites?wallpaper_id=eq.\(id.uuidString)&user_id=eq.\(userID.uuidString)",method:"DELETE",token:token)
                favorites.remove(id)
            } else {
                let body = try JSONSerialization.data(withJSONObject: ["wallpaper_id":id.uuidString, "user_id":userID.uuidString])
                _ = try await request("rest/v1/dynor_favorites",method:"POST",token:token,body:body,prefer:"return=minimal")
                favorites.insert(id)
            }
        } catch { self.error = "Không lưu được yêu thích: \(error.localizedDescription)" }
    }

    func download(_ item: OnlineWallpaper) async throws -> URL {
        guard let token = await account.galleryAccessToken() else { throw GalleryFailure.message("Đăng nhập Dynor trước khi tải.") }
        let body = try JSONSerialization.data(withJSONObject:["id":item.id.uuidString.lowercased()])
        let data = try await request("functions/v1/dynor-wallpaper-download",method:"POST",token:token,body:body)
        struct Signed: Decodable { let url: URL }
        let signed = try JSONDecoder().decode(Signed.self,from:data)
        guard signed.url.scheme == "https", signed.url.host == OnlineConfig.base.host else { throw GalleryFailure.message("Địa chỉ tải không an toàn") }
        let (temporary,response) = try await URLSession.shared.download(from:signed.url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw GalleryFailure.message("Không tải được file") }
        let suggested = response.suggestedFilename ?? "Dynor-Wallpaper"
        let safe = URL(fileURLWithPath:suggested).lastPathComponent
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent(safe)
        try FileManager.default.createDirectory(at:destination.deletingLastPathComponent(),withIntermediateDirectories:true)
        try FileManager.default.moveItem(at:temporary,to:destination)
        return destination
    }
}

private enum GalleryFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
}

struct OnlineGalleryView: View {
    @StateObject private var model = OnlineGalleryModel()
    @State private var selected: OnlineWallpaper?
    @State private var onlyFavorites = false
    @State private var query = ""
    @State private var category = "Tất cả"
    @Environment(\.scenePhase) private var phase
    private let columns = [GridItem(.flexible(),spacing:12),GridItem(.flexible(),spacing:12)]
    private var categories: [String] { ["Tất cả"] + Array(Set(model.items.map(\.category))).sorted() }
    private var filtered: [OnlineWallpaper] {
        model.items.filter { item in
            (category == "Tất cả" || item.category == category) &&
            (!onlyFavorites || model.favorites.contains(item.id)) &&
            (query.isEmpty || "\(item.title) \(item.category)".localizedCaseInsensitiveContains(query))
        }
    }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:17) {
                Text("THƯ VIỆN TRỰC TUYẾN").font(.caption2).tracking(2).foregroundStyle(.secondary)
                Text("Một màn hình.\nMột thế giới mới.").font(.system(size:30,weight:.bold,design:.rounded))
                ScrollView(.horizontal,showsIndicators:false) {
                    HStack { ForEach(categories,id:\.self) { value in
                        Button(value) { category = value }
                            .font(.caption.weight(.medium))
                            .padding(.horizontal,14).padding(.vertical,9)
                            .background(category == value ? Color.primary.opacity(0.14) : Color.secondary.opacity(0.08),in:Capsule())
                    }}
                }
                if model.loading && model.items.isEmpty { ProgressView("Đang đồng bộ hình nền...") }
                if let error = model.error { Text(error).font(.caption).foregroundStyle(.red) }
                if filtered.isEmpty && !model.loading {
                    ContentUnavailableView(onlyFavorites ? "Chưa có hình nền yêu thích" : "Chưa có hình nền",systemImage:onlyFavorites ? "heart" : "photo",description:Text("Kéo xuống để cập nhật danh sách từ Supabase."))
                }
                LazyVGrid(columns:columns,spacing:15) {
                    ForEach(filtered) { item in
                        ZStack(alignment:.topTrailing) {
                            Button { selected = item } label: {
                                ZStack(alignment:.bottomLeading) {
                                    AsyncImage(url:OnlineConfig.preview(item.cover_path)) { image in
                                        image.resizable().scaledToFill()
                                    } placeholder: { Rectangle().fill(Color.gray.opacity(0.2)).overlay(ProgressView()) }
                                    .frame(height:265).frame(maxWidth:.infinity).clipped()
                                    LinearGradient(colors:[.clear,.black.opacity(0.72)],startPoint:.center,endPoint:.bottom)
                                    VStack(alignment:.leading,spacing:5) {
                                        if item.video_path != nil { Label("Video",systemImage:"play.circle.fill").font(.caption2) }
                                        Text(item.title).font(.subheadline.bold()).lineLimit(2)
                                        Text(item.category + (item.is_vip ? " · VIP" : "")).font(.caption2)
                                    }.foregroundStyle(.white).padding(12)
                                }.frame(height:265).clipShape(RoundedRectangle(cornerRadius:20))
                            }.buttonStyle(.plain)
                            Button { Task { await model.toggleFavorite(item.id) } } label: {
                                Image(systemName:model.favorites.contains(item.id) ? "heart.fill":"heart")
                                    .foregroundStyle(model.favorites.contains(item.id) ? .pink : .white)
                                    .frame(width:36,height:36).background(.black.opacity(0.35),in:Circle())
                            }.padding(10)
                        }
                    }
                }
            }.padding(18)
        }
        .background(Color(uiColor:.systemGroupedBackground))
        .navigationTitle("Dynor")
        .searchable(text:$query,prompt:"Tìm hình nền")
        .toolbar { ToolbarItem(placement:.topBarTrailing) {
            Button { onlyFavorites.toggle() } label: { Image(systemName:onlyFavorites ? "heart.fill":"heart") }
                .accessibilityLabel(onlyFavorites ? "Tất cả hình nền" : "Yêu thích")
        }}
        .refreshable { await model.reload() }
        .task { await model.reload() }
        .onChange(of:phase) { _,newPhase in if newPhase == .active { Task { await model.reload() } } }
        .sheet(item:$selected) { item in OnlineWallpaperDetail(item:item,model:model) }
    }
}

private struct OnlineWallpaperDetail: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    @ObservedObject var model: OnlineGalleryModel
    @Environment(\.dismiss) private var dismiss
    @State private var showVideo = false
    @State private var downloading = false
    @State private var importedWallpaper: ImportedWallpaper?
    @State private var sharedURL: URL?
    @State private var notice: String?
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:16) {
                    ZStack {
                        AsyncImage(url: OnlineConfig.preview(item.cover_path), content: { image in
                            image.resizable().scaledToFill()
                        }, placeholder: { ProgressView() })
                        .frame(height:480).frame(maxWidth:.infinity).clipped()
                        if item.video_path != nil {
                            Button { showVideo = true } label: {
                                Image(systemName:"play.fill").font(.title).foregroundStyle(.white)
                                    .frame(width:72,height:72).background(.black.opacity(0.5),in:Circle())
                            }
                        }
                    }.clipShape(RoundedRectangle(cornerRadius:23))
                    HStack {
                        VStack(alignment:.leading) {
                            Text(item.title).font(.title2.bold())
                            Text(item.category + (item.is_vip ? " · VIP" : "")).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button { Task { await model.toggleFavorite(item.id) } } label: {
                            Image(systemName:model.favorites.contains(item.id) ? "heart.fill":"heart").font(.title2)
                        }
                    }
                    Button {
                        downloading = true
                        Task {
                            do {
                                let downloadedURL = try await model.download(item)
                                let ext = downloadedURL.pathExtension.lowercased()
                                if ext == "tendies" || UTType(filenameExtension: ext)?.conforms(to: .image) == true {
                                    defer { try? FileManager.default.removeItem(at: downloadedURL.deletingLastPathComponent()) }
                                    let imported = await store.importWallpapers(urls: [downloadedURL])
                                    if let wallpaper = imported.first {
                                        store.message = nil
                                        importedWallpaper = wallpaper
                                    } else {
                                        notice = store.message ?? "Chưa nhập được hình nền đã tải."
                                        store.message = nil
                                    }
                                } else {
                                    // Other catalog attachments retain their export flow.
                                    sharedURL = downloadedURL
                                }
                            } catch { notice = error.localizedDescription }
                            downloading = false
                        }
                    } label: {
                        HStack { if downloading { ProgressView() } else { Image(systemName:"arrow.down.circle") }; Text(downloading ? "Đang tải và nhập..." : "Tải và mở trong Dynor") }
                            .frame(maxWidth:.infinity).padding(15)
                    }.buttonStyle(.borderedProminent).disabled(downloading)
                    Text("Ảnh và gói Tendies được thêm vào Thư viện rồi mở trong Dynor. Với gói Tendies, chọn Cài hình nền ở màn hình tiếp theo. Các định dạng khác mở bảng chia sẻ. Nội dung VIP cần tài khoản VIP còn hiệu lực.")
                        .font(.caption).foregroundStyle(.secondary)
                }.padding(18)
            }
            .navigationTitle("Xem trước").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement:.topBarTrailing) { Button("Xong") { dismiss() }.disabled(downloading) } }
            .interactiveDismissDisabled(downloading)
            .sheet(isPresented:$showVideo) {
                if let path=item.video_path, let url=OnlineConfig.preview(path) { OnlineVideoView(url:url) }
            }
            .sheet(item: $importedWallpaper) { wallpaper in
                LibraryPreview(item: wallpaper).environmentObject(store)
            }
            .sheet(item: Binding(get: { sharedURL.map { SharedFile(url: $0) } }, set: { file in
                if file == nil, let url = sharedURL {
                    try? FileManager.default.removeItem(at: url.deletingLastPathComponent())
                }
                sharedURL = file?.url
            })) { file in
                OnlineShareSheet(url: file.url)
            }
            .onChange(of: store.selectedTab) { _, tab in
                if tab != .discover { dismiss() }
            }
            .alert("Dynor",isPresented:Binding(get:{notice != nil},set:{if !$0 { notice=nil }})) {
                Button("OK",role:.cancel) { notice=nil }
            } message: { Text(notice ?? "") }
        }
    }
}
private struct SharedFile: Identifiable { let url: URL; var id: String { url.path } }
private struct OnlineShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
private struct OnlineVideoView: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    var body: some View {
        NavigationStack {
            Group { if let player { VideoPlayer(player:player) } else { ProgressView() } }
                .background(.black)
                .navigationTitle("Video xem trước")
                .toolbar { ToolbarItem(placement:.topBarTrailing) { Button("Xong") { dismiss() } } }
                .onAppear { let p=AVPlayer(url:url);player=p;p.play() }
                .onDisappear { player?.pause();player=nil }
        }
    }
}
