import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var activeSheet: SettingsSheet?
    @StateObject private var account = DynorAccountService.shared

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    SettingsHeader(eyebrow: "CÁ NHÂN HÓA TRẢI NGHIỆM", title: "Theo cách bạn thích.", subtitle: "Một không gian mang chất riêng của bạn.")
                    accountCard
                    appearanceCard
                    vipCard
                    informationCard
                    Text("DYNOR · BẢN TRẢI NGHIỆM iOS\nĐăng nhập email an toàn · Giao diện trắng đen.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 10)
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .account: SettingsAccountSheet()
                case .vip: SettingsVIPSheet()
                case .contact: SettingsInformationSheet(title: "Thông tin liên hệ", symbol: "envelope", text: "Thông tin liên hệ của nhà phát triển chưa được cung cấp. Email, số điện thoại và liên kết hỗ trợ cần được cập nhật trước khi phát hành.")
                case .credits: SettingsCreditsSheet()
                case .privacy: SettingsInformationSheet(title: "Dữ liệu ở lại với bạn", symbol: "lock.shield", text: "Ảnh và tệp Tendies bạn nhập được sao chép vào vùng lưu trữ riêng của Dynor trên thiết bị. Tên hồ sơ trải nghiệm, ID, giao diện, yêu thích và tiến trình quảng cáo mô phỏng được lưu cục bộ.\n\nPairing record được đọc và lưu trong vùng riêng có bảo vệ của Dynor, loại khỏi bản sao lưu. Airlift sử dụng record để kết nối dịch vụ trên chính thiết bị qua LocalDevVPN; bạn có thể xóa record trong tab Pairing.\n\nBản này chưa có tài khoản được xác thực hoặc đồng bộ đám mây. Gỡ ứng dụng có thể làm mất dữ liệu cục bộ. Ảnh đã lưu vào ứng dụng Ảnh được quản lý riêng bởi iOS.")
                }
            }
        }
    }

    private var accountCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 18) {
                Text("Tài khoản").font(.headline)
                HStack(spacing: 14) {
                    SettingsAvatar()
                    VStack(alignment: .leading, spacing: 5) {
                        Text(account.email ?? store.profile?.name ?? "Chào bạn, người sáng tạo").font(.subheadline.weight(.semibold))
                        Text(account.email == nil ? "Đăng nhập để đồng bộ quyền lợi VIP." : (account.isVIP ? "Dynor VIP đang hoạt động" : "Tài khoản đã xác minh"))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                Button { activeSheet = .account } label: {
                    HStack {
                        Text(account.email == nil ? "Đăng nhập" : "Quản lý tài khoản")
                        Spacer()
                        Image(systemName: "arrow.right")
                    }
                    .font(.subheadline.weight(.semibold))
                }
                .tint(store.accentColor)
            }
        }
    }

    private var appearanceCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 19) {
                Text("Giao diện").font(.headline)
                VStack(alignment: .leading, spacing: 10) {
                    Text("Chế độ hiển thị").font(.subheadline.weight(.medium))
                    Picker("Chế độ hiển thị", selection: $store.theme) {
                        Text("Sáng").tag(ThemeMode.light)
                        Text("Tối").tag(ThemeMode.dark)
                        Text("Tự động").tag(ThemeMode.system)
                    }
                    .pickerStyle(.segmented)
                }
                Divider()
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Liquid glass").font(.subheadline.weight(.medium))
                        Text("Kính mờ thích ứng nền sáng và tối.").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Label("Bật", systemImage: "checkmark.circle.fill")
                        .font(.caption.weight(.semibold)).foregroundStyle(store.accentColor)
                }
            }
        }
    }

    private var vipCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            Image(systemName: "crown.fill").font(.system(size: 30)).foregroundStyle(Color.primary)
            Text("Mở hết cảm hứng.\nSống trọn chất riêng.").font(.title2.weight(.semibold))
            Text("Khám phá các gói Dynor VIP từ 39.000đ / tuần.")
                .font(.subheadline).foregroundStyle(.secondary)
            Button { activeSheet = .vip } label: {
                HStack {
                    Text("Khám phá VIP")
                    Spacer()
                    Image(systemName: "arrow.right")
                }
                .font(.subheadline.weight(.semibold))
                .padding(14)
                .foregroundStyle(Color(uiColor: .systemBackground))
                .background(Color.primary, in: RoundedRectangle(cornerRadius: 13))
            }
            Text("VIP chỉ được kích hoạt sau khi máy chủ xác nhận giao dịch.").font(.caption2).foregroundStyle(.secondary)
        }
        .padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 24)
                .fill(.ultraThinMaterial)
                .overlay(alignment: .topTrailing) {
                    Circle().fill(Color.primary.opacity(0.07)).frame(width: 150, height: 150).blur(radius: 40).offset(x: 30, y: -45)
                }
                .clipShape(RoundedRectangle(cornerRadius: 24))
        }
        .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(Color.primary.opacity(0.06)))
    }

    private var informationCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 3) {
                Text("Thông tin & hỗ trợ").font(.headline).padding(.bottom, 10)
                SettingsLinkRow(title: "Thông tin liên hệ", symbol: "envelope") { activeSheet = .contact }
                Divider()
                SettingsLinkRow(title: "Về Dynor & ghi công", symbol: "sparkles") { activeSheet = .credits }
                Divider()
                SettingsLinkRow(title: "Dữ liệu của bạn", symbol: "lock.shield") { activeSheet = .privacy }
            }
        }
    }
}

private enum SettingsSheet: String, Identifiable {
    case account, vip, contact, credits, privacy
    var id: String { rawValue }
}

private struct SettingsHeader: View {
    let eyebrow: String
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(eyebrow).font(.system(size: 10, weight: .medium)).tracking(2).foregroundStyle(.secondary)
            Text(title).font(.system(size: 30, weight: .semibold, design: .rounded))
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 10)
    }
}

private struct SettingsGlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        content.padding(21).frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(Color.primary.opacity(0.06)))
    }
}

private struct SettingsAvatar: View {
    var body: some View {
        Group {
            if let path = Bundle.main.path(forResource: "AppIcon", ofType: "jpg"), let image = UIImage(contentsOfFile: path) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: "person.crop.square.fill").resizable().foregroundStyle(.secondary)
            }
        }
        .frame(width: 54, height: 54)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .accessibilityLabel("Icon Dynor")
    }
}

private struct SettingsLinkRow: View {
    let title: String
    let symbol: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol).frame(width: 22).foregroundStyle(.secondary)
                Text(title)
                Spacer()
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
            }
            .font(.subheadline)
            .foregroundStyle(.primary)
            .padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

private struct SettingsAccountSheet: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var inputEmail = ""
    @State private var otp = ""
    @State private var awaitingOTP = false
    @State private var working = false
    @State private var errorText: String?

    private var validEmail: Bool {
        let value = inputEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.contains("@") && value.split(separator: "@").last?.contains(".") == true
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 14) {
                        Text("D")
                            .font(.system(size: 27, weight: .black, design: .rounded))
                            .foregroundStyle(Color(uiColor: .systemBackground))
                            .frame(width: 52, height: 52)
                            .background(Color.primary, in: RoundedRectangle(cornerRadius: 16))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Dynor").font(.title3.bold())
                            Text("Không gian của riêng bạn")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.bottom, 32)

                    VStack(alignment: .leading, spacing: 23) {
                        HStack {
                            Image(systemName: "crown.fill").font(.title2)
                            Spacer()
                            Image(systemName: "sparkle").foregroundStyle(.secondary)
                        }
                        Text("DYNOR ACCOUNT")
                            .font(.caption.weight(.bold))
                            .tracking(2.4)
                            .foregroundStyle(.secondary)
                        Text(account.email == nil ? "Chào mừng trở lại." : "Tài khoản của bạn.")
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                            .minimumScaleFactor(0.8)
                            .lineLimit(2)
                        Text(account.email == nil
                             ? "Đăng nhập bằng email để khám phá trải nghiệm Dynor của bạn."
                             : "Tài khoản Dynor của bạn đã được xác minh.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)

                        if let email = account.email {
                            VStack(alignment: .leading, spacing: 13) {
                                Text("EMAIL ĐANG ĐĂNG NHẬP")
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text(email).font(.headline).textSelection(.enabled)
                                Label(account.isVIP ? "Dynor VIP đang hoạt động" : "Tài khoản thường",
                                      systemImage: account.isVIP ? "crown.fill" : "person.crop.circle")
                                if let date = account.vipExpiresAt, account.isVIP {
                                    Text("VIP đến: \(date.formatted(date: .abbreviated, time: .shortened))")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                }
                                Button("Kiểm tra lại trạng thái VIP") {
                                    Task { await account.refreshVIP() }
                                }
                                .foregroundStyle(.primary)
                                Button("Đăng xuất", role: .destructive) {
                                    account.signOut(); awaitingOTP = false; otp = ""
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        } else {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Địa chỉ email").font(.subheadline.weight(.semibold))
                                TextField("tenban@gmail.com", text: $inputEmail)
                                    .textContentType(.emailAddress)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .padding(16)
                                    .background(Color(uiColor: .systemBackground),
                                                in: RoundedRectangle(cornerRadius: 15))
                                    .overlay(RoundedRectangle(cornerRadius: 15)
                                        .strokeBorder(Color.primary.opacity(0.10)))
                                    .disabled(awaitingOTP)
                                if awaitingOTP {
                                    Text("Mã xác minh gồm 6 chữ số")
                                        .font(.subheadline.weight(.semibold))
                                    TextField("Nhập mã OTP", text: $otp)
                                        .keyboardType(.numberPad)
                                        .textContentType(.oneTimeCode)
                                        .padding(16)
                                        .background(Color(uiColor: .systemBackground),
                                                    in: RoundedRectangle(cornerRadius: 15))
                                    Button {
                                        Task {
                                            await perform {
                                                try await account.verifyOTP(email: inputEmail, code: otp)
                                            }
                                            if account.email != nil { awaitingOTP = false }
                                        }
                                    } label: {
                                        primaryButton("Xác minh & đăng nhập")
                                    }
                                    .disabled(working || otp.count != 6)
                                    Button("Gửi lại mã") {
                                        Task { await perform { try await account.sendOTP(to: inputEmail) } }
                                    }.disabled(working)
                                    Button("Đổi email") { awaitingOTP = false; otp = "" }
                                } else {
                                    Button {
                                        Task {
                                            await perform { try await account.sendOTP(to: inputEmail) }
                                            if errorText == nil { awaitingOTP = true }
                                        }
                                    } label: {
                                        primaryButton("Nhận mã xác minh")
                                    }
                                    .disabled(working || !validEmail)
                                }
                            }
                        }
                        if working { ProgressView() }
                        if let errorText {
                            Text(errorText).font(.footnote).foregroundStyle(.red)
                        }
                        if !account.statusMessage.isEmpty {
                            Text(account.statusMessage)
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                        if account.email == nil {
                            Text("Mã OTP gồm 6 chữ số sẽ được gửi tới email của bạn.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .padding(22)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(uiColor: .secondarySystemGroupedBackground),
                                in: RoundedRectangle(cornerRadius: 26))
                    .overlay(RoundedRectangle(cornerRadius: 26)
                        .strokeBorder(Color.primary.opacity(0.09)))
                    .padding(.bottom, 24)

                    Text("DYNOR · BẢN TRẢI NGHIỆM iOS\nĐăng nhập an toàn qua Supabase")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 18)
                .padding(.top, 30)
                .padding(.bottom, 40)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Tài khoản")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }

    private func primaryButton(_ title: String) -> some View {
        HStack {
            Spacer()
            Text(title).font(.headline)
            Image(systemName: "arrow.right")
            Spacer()
        }
        .foregroundStyle(Color(uiColor: .systemBackground))
        .padding(.vertical, 17)
        .background(Color.primary, in: RoundedRectangle(cornerRadius: 17))
    }

    private func perform(_ operation: @escaping () async throws -> Void) async {
        working = true; errorText = nil
        defer { working = false }
        do { try await operation() }
        catch { errorText = error.localizedDescription }
    }
}

private struct SettingsVIPSheet: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var selected = SettingsVIPPlan.month
    @State private var order: DynorPaymentOrder?
    @State private var paymentError: String?
    @State private var busy = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Image(systemName: "crown.fill")
                        .font(.system(size: 43))
                    SettingsHeader(eyebrow: "DYNOR VIP", title: "Không giới hạn.", subtitle: "Mọi hình nền, không cần xem quảng cáo khi VIP còn hạn.")
                    ForEach(SettingsVIPPlan.allCases) { plan in
                        Button { selected = plan; order = nil; paymentError = nil } label: {
                            HStack(spacing: 14) {
                                Image(systemName: selected == plan ? "checkmark.circle.fill" : "circle")
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(plan.title).font(.headline)
                                    Text(plan.duration).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(plan.price).font(.headline)
                            }
                            .padding(18)
                            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
                            .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(selected == plan ? Color.primary : .gray.opacity(0.2)))
                        }.buttonStyle(.plain)
                    }
                    if account.isVIP {
                        Label("VIP đang hoạt động", systemImage: "checkmark.seal.fill")
                        if let date = account.vipExpiresAt { Text("Hạn: \(date.formatted())") }
                    }
                    if let order {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 14) {
                                Text("Chuyển khoản để kích hoạt VIP").font(.headline)
                                if let url = order.qrURL {
                                    AsyncImage(url: url) { image in
                                        image.resizable().scaledToFit()
                                    } placeholder: {
                                        ProgressView().frame(height: 240)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 260)
                                    .accessibilityLabel("QR thanh toán ngân hàng")
                                }
                                Text("Ngân hàng: \(order.bankName)")
                                Text("Số tài khoản: \(order.bankAccount)").textSelection(.enabled)
                                Text("Số tiền: \(order.amount.formatted())đ").font(.headline)
                                Text("Nội dung chuyển khoản:").font(.caption).foregroundStyle(.secondary)
                                Text(order.paymentCode)
                                    .font(.system(.body, design: .monospaced).weight(.bold))
                                    .textSelection(.enabled)
                                ShareLink("Chia sẻ mã thanh toán", item: order.paymentCode)
                                Text("Chỉ chuyển khoản đúng số tiền và nội dung trên. Sau khi thanh toán, chọn Kiểm tra VIP.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if let paymentError { Text(paymentError).font(.caption).foregroundStyle(.red) }
                    if order == nil {
                        Button { Task { await createOrder() } } label: {
                            HStack {
                                Spacer()
                                if busy { ProgressView().tint(.white) }
                                Text("Tạo đơn trong Dynor").font(.headline)
                                Spacer()
                            }
                            .padding(.vertical, 17)
                            .foregroundStyle(Color(uiColor: .systemBackground))
                            .background(Color.primary, in: RoundedRectangle(cornerRadius: 18))
                        }
                        .disabled(busy || account.email == nil || selected == .lifetime)
                    }
                    if selected == .lifetime {
                        Text("Gói vĩnh viễn chưa được hỗ trợ trên máy chủ. Không chuyển tiền cho gói này.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if account.email == nil {
                        Text("Đăng nhập tài khoản Dynor trước khi tạo đơn.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Button("Kiểm tra lại VIP") { Task { await account.refreshVIP() } }
                        .foregroundStyle(.primary)
                }
                .padding(22)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Dynor VIP")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
        .tint(.primary)
    }

    private func createOrder() async {
        busy = true
        paymentError = nil
        defer { busy = false }
        do {
            order = try await account.createVIPOrder(plan: selected.rawValue)
        } catch {
            order = nil
            paymentError = error.localizedDescription
        }
    }
}

private enum SettingsVIPPlan: String, CaseIterable, Identifiable {
    case week, month, lifetime
    var id: String { rawValue }
    var title: String { switch self { case .week: return "Thẻ tuần"; case .month: return "Thẻ tháng"; case .lifetime: return "Vĩnh viễn" } }
    var price: String { switch self { case .week: return "39.000đ"; case .month: return "59.000đ"; case .lifetime: return "99.000đ" } }
    var duration: String { switch self { case .week: return "7 ngày cảm hứng"; case .month: return "30 ngày khám phá"; case .lifetime: return "Một lần chọn, mãi mãi" } }
}

private struct SettingsInformationSheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let symbol: String
    let text: String
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Image(systemName: symbol).font(.system(size: 36)).foregroundStyle(.secondary)
                    Text(title).font(.title.weight(.semibold))
                    Text(text).font(.body).foregroundStyle(.secondary).lineSpacing(5)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

private struct SettingsCreditsSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    SettingsAvatar()
                    Text("Dynor").font(.largeTitle.weight(.bold))
                    Text("Một màn hình. Một thế giới mới.").font(.title3)
                    Text("Ứng dụng iOS viết bằng SwiftUI theo yêu cầu của bạn. Icon sử dụng ảnh bạn cung cấp. Hình nền trưng bày: Unsplash.")
                        .foregroundStyle(.secondary)
                    Divider()
                    Text("Nguồn tham khảo kỹ thuật").font(.headline)
                    Link("Mak5er / AirCard-iOS ↗", destination: URL(string: "https://github.com/Mak5er/AirCard-iOS")!)
                    Text("Dynor tích hợp AirliftFFI, pairing handshake và engine Tendies được điều chỉnh từ AirCard-iOS (MIT). Thông tin nguồn, phiên bản và giấy phép nằm trong thư mục ThirdParty của mã nguồn Dynor.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .navigationTitle("Về Dynor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

