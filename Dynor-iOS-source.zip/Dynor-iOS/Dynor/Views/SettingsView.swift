import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var activeSheet: SettingsSheet?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    SettingsHeader(eyebrow: "CÁ NHÂN HÓA TRẢI NGHIỆM", title: "Theo cách bạn thích.", subtitle: "Một không gian mang chất riêng của bạn.")
                    accountCard
                    appearanceCard
                    vipCard
                    informationCard
                    Text("DYNOR · BẢN TRẢI NGHIỆM iOS\nĐăng nhập, quảng cáo và thanh toán thật đang chờ tích hợp.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 10)
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .account: SettingsAccountSheet()
                case .vip: SettingsVIPSheet()
                case .contact: SettingsInformationSheet(title: "Thông tin liên hệ", symbol: "envelope", text: "Thông tin liên hệ của nhà phát triển chưa được cung cấp. Email, số điện thoại và liên kết hỗ trợ cần được cập nhật trước khi phát hành.")
                case .credits: SettingsCreditsSheet()
                case .privacy: SettingsInformationSheet(title: "Dữ liệu ở lại với bạn", symbol: "lock.shield", text: "Ảnh và tệp Tendies bạn nhập được sao chép vào vùng lưu trữ riêng của Dynor trên thiết bị. Tên hồ sơ trải nghiệm, ID, giao diện, yêu thích và tiến trình quảng cáo mô phỏng được lưu cục bộ.\n\nPairing record được đọc và lưu trong vùng riêng có bảo vệ của Dynor, loại khỏi bản sao lưu. Airlift sử dụng record để kết nối dịch vụ trên chính thiết bị qua LocalDevVPN; bạn có thể xóa record trong tab Pairing.\n\nBản này chưa có tài khoản được xác thực hoặc đồng bộ đám mây. Gỡ ứng dụng có thể làm mất dữ liệu cục bộ. Ảnh đã lưu vào ứng dụng Ảnh được quản lý riêng bởi iOS.")
                }
            }
        }
    }

    private var accountCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 18) {
                Text("Tài khoản").font(.headline)
                HStack(spacing: 14) {
                    SettingsAvatar()
                    VStack(alignment: .leading, spacing: 5) {
                        Text(store.profile?.name ?? "Chào bạn, người sáng tạo").font(.subheadline.weight(.semibold))
                        Text(store.profile == nil ? "Kết nối không gian của bạn." : "Hồ sơ trải nghiệm · Chỉ trên thiết bị")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                Button { activeSheet = .account } label: {
                    HStack {
                        Text(store.profile == nil ? "Đăng nhập / Dùng thử" : "Xem hồ sơ & ID")
                        Spacer()
                        Image(systemName: "arrow.right")
                    }
                    .font(.subheadline.weight(.semibold))
                }
                .tint(store.accentColor)
            }
        }
    }

    private var appearanceCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 19) {
                Text("Giao diện").font(.headline)
                VStack(alignment: .leading, spacing: 10) {
                    Text("Màu chủ đề").font(.subheadline.weight(.medium))
                    Picker("Màu chủ đề", selection: $store.accent) {
                        Text("Vàng").tag(ThemeAccent.gold)
                        Text("Trắng").tag(ThemeAccent.white)
                    }
                    .pickerStyle(.segmented)
                }
                Divider()
                VStack(alignment: .leading, spacing: 10) {
                    Text("Chế độ hiển thị").font(.subheadline.weight(.medium))
                    Picker("Chế độ hiển thị", selection: $store.theme) {
                        Text("Sáng").tag(ThemeMode.light)
                        Text("Tối").tag(ThemeMode.dark)
                        Text("Tự động").tag(ThemeMode.system)
                    }
                    .pickerStyle(.segmented)
                }
                Divider()
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Liquid glass").font(.subheadline.weight(.medium))
                        Text("Kính mờ thích ứng nền sáng và tối.").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Label("Bật", systemImage: "checkmark.circle.fill")
                        .font(.caption.weight(.semibold)).foregroundStyle(store.accentColor)
                }
            }
        }
    }

    private var vipCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            Image(systemName: "crown.fill").font(.system(size: 30)).foregroundStyle(Color(red: 0.83, green: 0.66, blue: 0.22))
            Text("Mở hết cảm hứng.\nSống trọn chất riêng.").font(.title2.weight(.semibold))
            Text("Khám phá các gói Dynor VIP từ 39.000đ / tuần.")
                .font(.subheadline).foregroundStyle(.secondary)
            Button { activeSheet = .vip } label: {
                HStack {
                    Text("Khám phá VIP")
                    Spacer()
                    Image(systemName: "arrow.right")
                }
                .font(.subheadline.weight(.semibold))
                .padding(14)
                .foregroundStyle(Color.black.opacity(0.8))
                .background(Color(red: 0.95, green: 0.81, blue: 0.34), in: RoundedRectangle(cornerRadius: 13))
            }
            Text("Thanh toán chưa được kết nối.").font(.caption2).foregroundStyle(.secondary)
        }
        .padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 24)
                .fill(.ultraThinMaterial)
                .overlay(alignment: .topTrailing) {
                    Circle().fill(Color.yellow.opacity(0.2)).frame(width: 150, height: 150).blur(radius: 40).offset(x: 30, y: -45)
                }
                .clipShape(RoundedRectangle(cornerRadius: 24))
        }
        .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(Color.primary.opacity(0.06)))
    }

    private var informationCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 3) {
                Text("Thông tin & hỗ trợ").font(.headline).padding(.bottom, 10)
                SettingsLinkRow(title: "Thông tin liên hệ", symbol: "envelope") { activeSheet = .contact }
                Divider()
                SettingsLinkRow(title: "Về Dynor & ghi công", symbol: "sparkles") { activeSheet = .credits }
                Divider()
                SettingsLinkRow(title: "Dữ liệu của bạn", symbol: "lock.shield") { activeSheet = .privacy }
            }
        }
    }
}

private enum SettingsSheet: String, Identifiable {
    case account, vip, contact, credits, privacy
    var id: String { rawValue }
}

private struct SettingsHeader: View {
    let eyebrow: String
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(eyebrow).font(.system(size: 10, weight: .medium)).tracking(2).foregroundStyle(.secondary)
            Text(title).font(.system(size: 30, weight: .semibold, design: .rounded))
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 10)
    }
}

private struct SettingsGlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        content.padding(21).frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(Color.primary.opacity(0.06)))
    }
}

private struct SettingsAvatar: View {
    var body: some View {
        Group {
            if let path = Bundle.main.path(forResource: "AppIcon", ofType: "jpg"), let image = UIImage(contentsOfFile: path) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: "person.crop.square.fill").resizable().foregroundStyle(.secondary)
            }
        }
        .frame(width: 54, height: 54)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .accessibilityLabel("Icon Dynor")
    }
}

private struct SettingsLinkRow: View {
    let title: String
    let symbol: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol).frame(width: 22).foregroundStyle(.secondary)
                Text(title)
                Spacer()
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
            }
            .font(.subheadline)
            .foregroundStyle(.primary)
            .padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

private struct SettingsAccountSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var notice: String?
    @State private var confirmDelete = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    SettingsHeader(eyebrow: "KHÔNG GIAN CỦA BẠN", title: store.profile?.name ?? "Chào mừng đến Dynor.", subtitle: "Mang chất riêng theo bạn.")
                    if let profile = store.profile {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Label("Hồ sơ trải nghiệm cục bộ", systemImage: "person.crop.circle").font(.headline)
                                Text("Đây chưa phải tài khoản Gmail/SMS đã xác thực.").font(.caption).foregroundStyle(.secondary)
                                Text("ID RIÊNG TRÊN THIẾT BỊ").font(.caption2).tracking(1).foregroundStyle(.secondary)
                                Text(profile.id).font(.system(.footnote, design: .monospaced)).textSelection(.enabled)
                                Button {
                                    UIPasteboard.general.string = profile.id
                                    notice = "Đã sao chép ID hồ sơ trải nghiệm."
                                } label: { Label("Sao chép ID", systemImage: "doc.on.doc") }
                                .font(.subheadline)
                            }
                        }
                    }
                    SettingsGlassCard {
                        VStack(spacing: 13) {
                            Button {
                                notice = "Đăng nhập Gmail chưa được cấu hình. Cần Google OAuth, dịch vụ tài khoản và xác thực phía máy chủ trước khi đăng nhập thật."
                            } label: {
                                Label("Tiếp tục với Gmail", systemImage: "envelope.badge.shield.half.filled")
                                    .frame(maxWidth: .infinity).padding(12)
                            }
                            .buttonStyle(.bordered)
                            Button {
                                notice = "Đăng nhập bằng số điện thoại chưa được kết nối nhà cung cấp SMS. Bản này không gửi hoặc xác minh OTP."
                            } label: {
                                Label("Tiếp tục với số điện thoại", systemImage: "iphone")
                                    .frame(maxWidth: .infinity).padding(12)
                            }
                            .buttonStyle(.bordered)
                            Text("Các dịch vụ đăng nhập đang chờ tích hợp.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    if store.profile == nil {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 14) {
                                Text("Hoặc dùng thử trên thiết bị").font(.headline)
                                Text("Tạo hồ sơ trải nghiệm có ID riêng, chỉ lưu trong ứng dụng này. Không có xác thực hoặc đồng bộ tài khoản.")
                                    .font(.caption).foregroundStyle(.secondary)
                                TextField("Tên bạn muốn hiển thị", text: $name)
                                    .textContentType(.nickname)
                                    .textInputAutocapitalization(.words)
                                    .padding(13)
                                    .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12))
                                Button {
                                    let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
                                    guard !trimmed.isEmpty else { return }
                                    store.createLocalProfile(name: String(trimmed.prefix(40)))
                                    name = ""
                                } label: {
                                    Label("Tạo hồ sơ trải nghiệm", systemImage: "arrow.right")
                                        .frame(maxWidth: .infinity).padding(10)
                                }
                                .buttonStyle(.borderedProminent)
                                .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                            }
                        }
                    } else {
                        Button("Xóa hồ sơ trải nghiệm", role: .destructive) { confirmDelete = true }
                            .frame(maxWidth: .infinity).padding(.vertical, 10)
                    }
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Tài khoản")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
            .alert("Thông tin", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
            .confirmationDialog("Xóa hồ sơ trải nghiệm?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Xóa hồ sơ", role: .destructive) { store.deleteLocalProfile() }
            } message: { Text("Thư viện hình nền vẫn được giữ. ID hồ sơ hiện tại sẽ bị xóa.") }
        }
        .tint(store.accentColor)
    }
}

private struct SettingsVIPSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @State private var selected = SettingsVIPPlan.month
    @State private var showNotice = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Image(systemName: "crown.fill").font(.system(size: 40)).foregroundStyle(Color(red: 0.83, green: 0.66, blue: 0.22))
                    SettingsHeader(eyebrow: "DYNOR VIP", title: "Không giới hạn.\nChỉ có cảm hứng.", subtitle: "Chọn trải nghiệm dành cho bạn.")
                    VStack(alignment: .leading, spacing: 12) {
                        Label("Bỏ bước xem quảng cáo", systemImage: "checkmark.circle")
                        Label("Mở khóa toàn bộ hình nền", systemImage: "checkmark.circle")
                        Label("Quyền lợi sau xác nhận thanh toán", systemImage: "checkmark.circle")
                    }
                    .font(.subheadline)
                    ForEach(SettingsVIPPlan.allCases) { plan in
                        Button { selected = plan } label: {
                            HStack(spacing: 14) {
                                Image(systemName: selected == plan ? "largecircle.fill.circle" : "circle")
                                    .foregroundStyle(store.accentColor)
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(plan.title).font(.headline)
                                    Text(plan.duration).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(plan.price).font(.title3.weight(.semibold))
                            }
                            .padding(19)
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
                            .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(selected == plan ? store.accentColor : Color.primary.opacity(0.08), lineWidth: selected == plan ? 2 : 1))
                            .foregroundStyle(.primary)
                        }
                        .buttonStyle(.plain)
                        .accessibilityAddTraits(selected == plan ? .isSelected : [])
                    }
                    Label("Thanh toán chưa được kết nối", systemImage: "info.circle")
                        .font(.subheadline.weight(.medium))
                    Text("Bản trải nghiệm không thu tiền hoặc cấp VIP. Trước khi phát hành, giao dịch phải được xác minh bằng StoreKit và dịch vụ quyền lợi phía máy chủ.")
                        .font(.caption).foregroundStyle(.secondary)
                    Button { showNotice = true } label: {
                        Label("Xem thông tin thanh toán", systemImage: "lock")
                            .frame(maxWidth: .infinity).padding(12)
                    }
                    .buttonStyle(.borderedProminent)
                    Text("Giá VNĐ theo yêu cầu · Chưa áp dụng tự gia hạn")
                        .font(.caption2).foregroundStyle(.secondary).frame(maxWidth: .infinity)
                }
                .padding(22)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Nâng cấp VIP")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
            .alert("Chưa thể thanh toán", isPresented: $showNotice) {
                Button("Đã hiểu", role: .cancel) {}
            } message: { Text("Gói \(selected.title.lowercased()) có giá \(selected.price). StoreKit và sản phẩm In-App Purchase chưa được cấu hình nên không có giao dịch hoặc kích hoạt VIP nào được thực hiện.") }
        }
        .tint(store.accentColor)
    }
}

private enum SettingsVIPPlan: String, CaseIterable, Identifiable {
    case week, month, lifetime
    var id: String { rawValue }
    var title: String { switch self { case .week: return "Thẻ tuần"; case .month: return "Thẻ tháng"; case .lifetime: return "Vĩnh viễn" } }
    var price: String { switch self { case .week: return "39.000đ"; case .month: return "59.000đ"; case .lifetime: return "99.000đ" } }
    var duration: String { switch self { case .week: return "7 ngày cảm hứng"; case .month: return "30 ngày khám phá"; case .lifetime: return "Một lần chọn, mãi mãi" } }
}

private struct SettingsInformationSheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let symbol: String
    let text: String
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Image(systemName: symbol).font(.system(size: 36)).foregroundStyle(.secondary)
                    Text(title).font(.title.weight(.semibold))
                    Text(text).font(.body).foregroundStyle(.secondary).lineSpacing(5)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

private struct SettingsCreditsSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    SettingsAvatar()
                    Text("Dynor").font(.largeTitle.weight(.bold))
                    Text("Một màn hình. Một thế giới mới.").font(.title3)
                    Text("Ứng dụng iOS viết bằng SwiftUI theo yêu cầu của bạn. Icon sử dụng ảnh bạn cung cấp. Hình nền trưng bày: Unsplash.")
                        .foregroundStyle(.secondary)
                    Divider()
                    Text("Nguồn tham khảo kỹ thuật").font(.headline)
                    Link("Mak5er / AirCard-iOS ↗", destination: URL(string: "https://github.com/Mak5er/AirCard-iOS")!)
                    Text("Dynor tích hợp AirliftFFI, pairing handshake và engine Tendies được điều chỉnh từ AirCard-iOS (MIT). Thông tin nguồn, phiên bản và giấy phép nằm trong thư mục ThirdParty của mã nguồn Dynor.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .navigationTitle("Về Dynor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}
