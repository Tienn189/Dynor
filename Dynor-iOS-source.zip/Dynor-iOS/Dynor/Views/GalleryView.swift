import SwiftUI
import Combine
import UIKit

struct GalleryView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var query = ""
    @State private var category = "Tất cả"
    @State private var favoritesOnly = false
    @State private var selectedWallpaper: WallpaperItem?
    @State private var showUnlock = false
    private let categories = ["Tất cả", "Thiên nhiên", "Trừu tượng", "Tối giản", "Vũ trụ"]
    private let columns = [GridItem(.flexible(), spacing: 13), GridItem(.flexible(), spacing: 13)]
    private let refreshTimer = Timer.publish(every: 30, on: .main, in: .common).autoconnect()

    private var displayedWallpapers: [WallpaperItem] {
        WallpaperItem.samples.filter { item in
            (category == "Tất cả" || category == item.category)
                && (!favoritesOnly || store.favorites.contains(item.id))
                && (query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    || "\(item.title) \(item.category)".localizedCaseInsensitiveContains(query))
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 25) {
                introduction
                hero
                dailyAccess
                collectionHeader
                categoryPicker
                if displayedWallpapers.isEmpty {
                    ContentUnavailableView(
                        favoritesOnly ? "Chưa có hình nền yêu thích" : "Chưa tìm thấy hình nền",
                        systemImage: favoritesOnly ? "heart" : "magnifyingglass",
                        description: Text(favoritesOnly ? "Chạm trái tim trên hình nền để lưu chất riêng của bạn." : "Thử một từ khóa hoặc danh mục khác nhé.")
                    )
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 30)
                } else {
                    LazyVGrid(columns: columns, spacing: 19) {
                        ForEach(displayedWallpapers) { item in
                            wallpaperCard(item)
                        }
                    }
                }
                Text("Một chút thay đổi. Một cảm hứng mới.")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)
            .padding(.bottom, 20)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Dynor")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Tìm một chút cảm hứng…")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { favoritesOnly.toggle() }
                } label: {
                    Image(systemName: favoritesOnly ? "heart.fill" : "heart")
                        .foregroundStyle(favoritesOnly ? store.accentColor : .primary)
                }
                .accessibilityLabel(favoritesOnly ? "Xem tất cả hình nền" : "Xem hình nền yêu thích")
            }
        }
        .sheet(item: $selectedWallpaper) { item in
            GalleryWallpaperDetail(item: item)
                .environmentObject(store)
        }
        .sheet(isPresented: $showUnlock) {
            GalleryAdUnlockView().environmentObject(store)
        }
        .onReceive(refreshTimer) { _ in store.refreshDailyAccess() }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { store.refreshDailyAccess() }
        }
        .onAppear { store.refreshDailyAccess() }
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("ĐỔI HÌNH NỀN. ĐỔI CẢM HỨNG.")
                .font(.system(size: 9, weight: .semibold, design: .rounded))
                .tracking(1.6)
                .foregroundStyle(.secondary)
            HStack(alignment: .top, spacing: 8) {
                Text("Thế giới trên\nmàn hình bạn.")
                    .font(.system(size: 31, weight: .semibold, design: .rounded))
                    .tracking(-0.8)
                Image(systemName: "sparkle")
                    .font(.system(size: 25))
                    .foregroundStyle(store.accentColor)
                    .padding(.top, 7)
            }
            Text("Những hình nền được chọn lọc, dành cho chất riêng của bạn.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineSpacing(3)
        }
    }

    private var hero: some View {
        ZStack(alignment: .leading) {
            GalleryArtwork(imageName: "mountain-hero")
                .frame(height: 300)
                .clipped()
            LinearGradient(colors: [.black.opacity(0.12), .black.opacity(0.62)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 17) {
                Label("BỘ SƯU TẬP NỔI BẬT", systemImage: "sparkles")
                    .font(.system(size: 8, weight: .medium))
                    .tracking(1)
                    .padding(.horizontal, 11)
                    .padding(.vertical, 8)
                    .background(.ultraThinMaterial, in: Capsule())
                Spacer(minLength: 8)
                Text("Một màn hình.\nMột thế giới mới.")
                    .font(.system(size: 29, weight: .semibold, design: .rounded))
                    .tracking(-0.8)
                    .lineSpacing(3)
                Text("Mang vẻ đẹp thiên nhiên đến gần hơn.")
                    .font(.caption2)
                    .foregroundStyle(.white.opacity(0.85))
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        category = "Thiên nhiên"
                        favoritesOnly = false
                        query = ""
                    }
                } label: {
                    HStack(spacing: 14) {
                        Text("Khám phá bộ sưu tập")
                        Image(systemName: "arrow.right")
                    }
                    .font(.caption.weight(.medium))
                    .padding(.horizontal, 15)
                    .padding(.vertical, 12)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                    .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(.white.opacity(0.28), lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
            .foregroundStyle(.white)
            .padding(23)
        }
        .frame(height: 300)
        .clipShape(RoundedRectangle(cornerRadius: 25))
    }

    private var dailyAccess: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: store.isUnlocked ? "lock.open.fill" : "lock.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(store.accentColor)
                    .frame(width: 38, height: 38)
                    .background(store.accentColor.opacity(0.14), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 5) {
                    Text(store.isUnlocked ? "Cả thế giới đã mở." : "Mở khóa cả thế giới.")
                        .font(.headline)
                    Text(store.isUnlocked ? "Lưu mọi hình nền đến 00:00 giờ Việt Nam." : "Xem 5 quảng cáo để lưu mọi hình nền trong hôm nay.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            HStack(spacing: 9) {
                GalleryAdDots(count: store.adsWatched, accent: store.accentColor, foreground: store.accent == .white ? Color(uiColor: .systemBackground) : .black.opacity(0.8))
                Spacer(minLength: 10)
                Button {
                    showUnlock = true
                } label: {
                    Label(store.isUnlocked ? "Đã mở khóa" : "Xem · \(store.adsWatched)/5", systemImage: store.isUnlocked ? "checkmark" : "play.fill")
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 11)
                        .background(store.accentColor, in: RoundedRectangle(cornerRadius: 11))
                        .foregroundStyle(store.accent == .white ? Color(uiColor: .systemBackground) : Color.black.opacity(0.8))
                }
                .buttonStyle(.plain)
            }
            Label("Bản trải nghiệm · Quảng cáo mô phỏng", systemImage: "info.circle")
                .font(.system(size: 9))
                .foregroundStyle(.secondary)
        }
        .padding(19)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 23))
        .overlay(RoundedRectangle(cornerRadius: 23).strokeBorder(store.accentColor.opacity(0.25), lineWidth: 1))
    }

    private var collectionHeader: some View {
        HStack(spacing: 8) {
            Text(favoritesOnly ? "Cảm hứng đã lưu" : "Chọn một cảm hứng")
                .font(.headline)
            Text("\(displayedWallpapers.count)")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(.quaternary, in: Capsule())
            Spacer()
        }
    }

    private var categoryPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 7) {
                ForEach(categories, id: \.self) { value in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) { category = value }
                    } label: {
                        Text(value)
                            .font(.caption.weight(category == value ? .semibold : .regular))
                            .foregroundStyle(category == value ? Color.primary : Color.secondary)
                            .fixedSize(horizontal: true, vertical: true)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 9)
                            .background(category == value ? store.accentColor.opacity(0.23) : Color.clear, in: Capsule())
                            .overlay(Capsule().strokeBorder(category == value ? store.accentColor.opacity(0.4) : Color.primary.opacity(0.08), lineWidth: 1))
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(category == value ? .isSelected : [])
                }
            }
            // Keep the antialiased capsule edges inside the scroll viewport.
            .padding(.horizontal, 1)
            .padding(.vertical, 2)
        }
    }

    private func wallpaperCard(_ item: WallpaperItem) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .topTrailing) {
                Button {
                    selectedWallpaper = item
                } label: {
                    ZStack(alignment: .bottomLeading) {
                        GalleryArtwork(imageName: item.imageName)
                            .frame(height: 242)
                            .clipped()
                        LinearGradient(colors: [.clear, .black.opacity(0.65)], startPoint: .center, endPoint: .bottom)
                        HStack(alignment: .bottom, spacing: 5) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.title).font(.system(size: 13, weight: .semibold, design: .rounded))
                                Text(item.category).font(.system(size: 9)).foregroundStyle(.white.opacity(0.75))
                            }
                            Spacer(minLength: 0)
                            Image(systemName: store.isUnlocked ? "square.and.arrow.down" : "lock")
                                .font(.system(size: 11))
                        }
                        .foregroundStyle(.white)
                        .padding(13)
                    }
                    .frame(height: 242)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .contentShape(RoundedRectangle(cornerRadius: 18))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Xem hình nền \(item.title)")

                Button {
                    store.toggleFavorite(item.id)
                } label: {
                    Image(systemName: store.favorites.contains(item.id) ? "heart.fill" : "heart")
                        .font(.system(size: 13))
                        .foregroundStyle(store.favorites.contains(item.id) ? store.accentColor : .white)
                        .frame(width: 32, height: 32)
                        .background(.ultraThinMaterial, in: Circle())
                        .overlay(Circle().strokeBorder(.white.opacity(0.25), lineWidth: 0.7))
                }
                .buttonStyle(.plain)
                .padding(10)
                .accessibilityLabel(store.favorites.contains(item.id) ? "Bỏ yêu thích \(item.title)" : "Yêu thích \(item.title)")
            }
            HStack {
                Label("Dynor Collection", systemImage: "photo")
                Spacer(minLength: 2)
                Text("JPG")
            }
            .font(.system(size: 8))
            .foregroundStyle(.secondary)
            .padding(.horizontal, 3)
        }
    }
}

private struct GalleryArtwork: View {
    let imageName: String
    var body: some View {
        GeometryReader { proxy in
            if let image = wallpaperImage(named: imageName) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .clipped()
            } else {
                LinearGradient(colors: [.gray.opacity(0.2), .gray.opacity(0.5)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .overlay(Image(systemName: "photo").font(.largeTitle).foregroundStyle(.secondary))
            }
        }
        .accessibilityHidden(true)
    }
}

private struct GalleryAdDots: View {
    let count: Int
    let accent: Color
    let foreground: Color
    var body: some View {
        HStack(spacing: 6) {
            ForEach(0..<5, id: \.self) { index in
                ZStack {
                    Circle().fill(index < count ? accent : accent.opacity(0.09))
                    Circle().strokeBorder(accent.opacity(index < count ? 0.9 : 0.3), style: StrokeStyle(lineWidth: 1, dash: index < count ? [] : [2, 2]))
                    if index < count {
                        Image(systemName: "checkmark").font(.system(size: 9, weight: .bold)).foregroundStyle(foreground)
                    } else {
                        Text("\(index + 1)").font(.system(size: 9)).foregroundStyle(.secondary)
                    }
                }
                .frame(width: 25, height: 25)
                .accessibilityLabel("Lượt \(index + 1) \(index < count ? "đã hoàn tất" : "chưa hoàn tất")")
            }
        }
    }
}

private struct GalleryWallpaperDetail: View {
    let item: WallpaperItem
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @State private var showUnlock = false
    @State private var isSaving = false
    @State private var notice: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    GalleryArtwork(imageName: item.imageName)
                        .frame(height: 420)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                    HStack {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("DYNOR COLLECTION").font(.system(size: 9, weight: .medium)).tracking(1.3).foregroundStyle(.secondary)
                            Text(item.title).font(.system(size: 28, weight: .semibold, design: .rounded))
                            Text(item.category).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button { store.toggleFavorite(item.id) } label: {
                            Image(systemName: store.favorites.contains(item.id) ? "heart.fill" : "heart")
                                .font(.title3)
                                .foregroundStyle(store.accentColor)
                                .frame(width: 45, height: 45)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                        .accessibilityLabel(store.favorites.contains(item.id) ? "Bỏ yêu thích" : "Lưu yêu thích")
                    }
                    if let image = wallpaperImage(named: item.imageName) {
                        HStack {
                            Label("\(Int(image.size.width * image.scale)) × \(Int(image.size.height * image.scale))", systemImage: "arrow.up.left.and.arrow.down.right")
                            Spacer()
                            Text("JPG")
                        }
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    }
                    Button {
                        if store.isUnlocked {
                            isSaving = true
                            Task { @MainActor in
                                await store.saveToPhotos(item)
                                notice = store.message
                                store.message = nil
                                isSaving = false
                            }
                        } else {
                            showUnlock = true
                        }
                    } label: {
                        HStack(spacing: 9) {
                            if isSaving { ProgressView().tint(store.accent == .white ? Color(uiColor: .systemBackground) : .black) }
                            else { Image(systemName: store.isUnlocked ? "square.and.arrow.down" : "lock") }
                            Text(store.isUnlocked ? "Lưu vào Ảnh" : "Mở khóa để lưu hình nền")
                        }
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(17)
                        .background(store.accentColor, in: RoundedRectangle(cornerRadius: 15))
                        .foregroundStyle(store.accent == .white ? Color(uiColor: .systemBackground) : Color.black.opacity(0.8))
                    }
                    .buttonStyle(.plain)
                    .disabled(isSaving)
                    Label("Sau khi lưu: mở Ảnh → Chia sẻ → Dùng làm hình nền. iOS yêu cầu bạn tự xác nhận việc đặt hình nền.", systemImage: "info.circle")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineSpacing(4)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Xem trước")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
            .sheet(isPresented: $showUnlock) { GalleryAdUnlockView().environmentObject(store) }
            .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: {
                Text(notice ?? "")
            }
        }
    }
}

private struct GalleryAdUnlockView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @State private var isPlaying = false
    @State private var sessionID = UUID()
    @State private var startDay = ""
    @State private var activeSeconds: Double = 0
    @State private var outcome = ""

    private var remaining: Int { max(0, Int(ceil(4 - activeSeconds))) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Image(systemName: store.isUnlocked ? "lock.open.fill" : "play.rectangle.fill")
                        .font(.system(size: 27))
                        .foregroundStyle(store.accentColor)
                        .frame(width: 60, height: 60)
                        .background(store.accentColor.opacity(0.15), in: RoundedRectangle(cornerRadius: 19))
                    Text(store.isUnlocked ? "Cảm hứng không giới hạn." : "5 lần xem.\nCả ngày cảm hứng.")
                        .font(.system(size: 29, weight: .semibold, design: .rounded))
                        .tracking(-0.6)
                    Text("Xem đủ 5 lượt để lưu tất cả hình nền trưng bày đến 00:00 theo giờ Việt Nam. Tiến trình bắt đầu lại vào ngày hôm sau.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineSpacing(4)
                    GalleryAdDots(count: store.adsWatched, accent: store.accentColor, foreground: store.accent == .white ? Color(uiColor: .systemBackground) : .black.opacity(0.8))
                    if isPlaying {
                        VStack(spacing: 18) {
                            Text("QUẢNG CÁO MÔ PHỎNG · \(min(5, store.adsWatched + 1))/5")
                                .font(.system(size: 9, weight: .semibold)).tracking(1)
                            Image(systemName: "sparkles").font(.system(size: 42)).foregroundStyle(store.accentColor)
                            Text("Để màn hình kể chuyện bạn.")
                                .font(.system(size: 20, weight: .medium, design: .rounded))
                            ProgressView(value: min(activeSeconds / 4, 1)).tint(store.accentColor)
                            Text(scenePhase == .active ? "Còn \(remaining) giây · Đóng sớm sẽ không tính lượt" : "Đang tạm dừng")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                        .padding(23)
                        .frame(maxWidth: .infinity)
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 23))
                    }
                    if !outcome.isEmpty {
                        Text(outcome)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Label("Đây là quảng cáo mô phỏng để thử luồng ứng dụng. Chưa kết nối mạng quảng cáo, không tạo doanh thu. Quyền mở khóa chỉ lưu trên thiết bị này.", systemImage: "info.circle")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineSpacing(4)
                        .padding(16)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.quaternary, in: RoundedRectangle(cornerRadius: 16))
                    Button {
                        store.refreshDailyAccess()
                        if store.isUnlocked {
                            dismiss()
                        } else {
                            outcome = ""
                            activeSeconds = 0
                            startDay = store.currentDayKey
                            isPlaying = true
                            sessionID = UUID()
                        }
                    } label: {
                        HStack(spacing: 10) {
                            if isPlaying { ProgressView().tint(store.accent == .white ? Color(uiColor: .systemBackground) : .black) }
                            else { Image(systemName: store.isUnlocked ? "checkmark" : "play.fill") }
                            Text(isPlaying ? "Đang xem mô phỏng…" : store.isUnlocked ? "Đã mở khóa · Khám phá ngay" : "Xem mô phỏng \(min(5, store.adsWatched + 1))/5")
                        }
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(16)
                        .background(store.accentColor, in: RoundedRectangle(cornerRadius: 15))
                        .foregroundStyle(store.accent == .white ? Color(uiColor: .systemBackground) : Color.black.opacity(0.8))
                    }
                    .buttonStyle(.plain)
                    .disabled(isPlaying)
                }
                .padding(24)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Mở khóa hôm nay")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() } } }
            .task(id: sessionID) { await countVisibleSeconds() }
            .onAppear { store.refreshDailyAccess() }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { store.refreshDailyAccess() }
            }
            .onDisappear { isPlaying = false }
        }
    }

    @MainActor
    private func countVisibleSeconds() async {
        guard isPlaying else { return }
        // Fixed small visible increments avoid counting the long suspended interval
        // when iOS returns this task from the background.
        while activeSeconds < 4 {
            do { try await Task.sleep(nanoseconds: 100_000_000) }
            catch { return }
            guard !Task.isCancelled, isPlaying else { return }
            if scenePhase == .active { activeSeconds = min(4, activeSeconds + 0.1) }
        }
        guard !Task.isCancelled, isPlaying else { return }
        let credited = store.recordDemoAd(startDay: startDay)
        if !credited { store.message = nil } // The ad sheet shows its own day-reset notice.
        isPlaying = false
        outcome = credited
            ? (store.isUnlocked ? "Đã mở khóa tất cả hình nền đến 00:00 hôm nay." : "Đã ghi nhận lượt xem. Còn \(5 - store.adsWatched) lượt nữa.")
            : "Đã sang ngày mới. Tiến trình hôm nay đã được đặt lại."
    }
}
