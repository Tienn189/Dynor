import SwiftUI

/// Monochrome action button. Only fixes foreground/background contrast;
/// existing layout, labels and navigation remain unchanged.
struct DynorContrastButtonStyle: ButtonStyle {
    @Environment(\.colorScheme) private var colorScheme

    func makeBody(configuration: Configuration) -> some View {
        let dark = colorScheme == .dark
        let foreground: Color = dark ? .black : .white
        let background: Color = dark ? .white : .black

        return configuration.label
            .fontWeight(.semibold)
            .foregroundColor(foreground)
            .tint(foreground)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 13)
            .background(background, in: RoundedRectangle(cornerRadius: 16))
            .contentShape(RoundedRectangle(cornerRadius: 16))
            .opacity(configuration.isPressed ? 0.78 : 1)
    }
}
