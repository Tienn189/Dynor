import SwiftUI
import UniformTypeIdentifiers

@MainActor
struct PairingView: View {
    @EnvironmentObject private var store: DynorStore
    @StateObject private var controller = PairingController.shared
    @State private var showImporter = false
    @State private var importing = false
    @State private var notice: String?

    private var supportsOnDevicePairing: Bool {
        ProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 27
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("KẾT NỐI KHÔNG GIAN CỦA BẠN")
                            .font(.system(size: 10, weight: .medium)).tracking(1.6).foregroundStyle(.secondary)
                        Text("Pairing & Airlift").font(.system(size: 31, weight: .semibold, design: .rounded))
                        Text("Ghép nối thiết bị để cài hình nền Tendies.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 12)

                    PairingGlassCard {
                        VStack(alignment: .leading, spacing: 20) {
                            HStack(alignment: .top) {
                                Label("Pairing thiết bị", systemImage: "link").font(.headline)
                                Spacer(minLength: 8)
                                PairingStatus(text: controller.running ? "Đang ghép nối" : (store.pairingRecord == nil ? "Chưa có file" : "Đã lưu file"))
                            }
                            if supportsOnDevicePairing {
                                PairingStep(number: "01", title: "Ghép nối ngay trên iPhone", detail: "Bấm Ghép nối, rồi mở Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép nối với Dynor. Nhập mã PIN khi được yêu cầu.")
                                if controller.running {
                                    VStack(alignment: .leading, spacing: 12) {
                                        HStack(spacing: 10) {
                                            ProgressView()
                                            Text(controller.pairingStatus).font(.subheadline)
                                        }
                                        if let pin = controller.pairingPIN {
                                            Text(pin).font(.system(size: 36, weight: .semibold, design: .monospaced))
                                                .textSelection(.enabled)
                                                .accessibilityLabel("Mã PIN ghép nối: \(pin)")
                                        }
                                        Button("Dừng ghép nối", role: .destructive) { controller.cancel() }
                                    }
                                    .padding(14)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(store.accentColor.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                                } else {
                                    Button {
                                        Task { await pairOnDevice() }
                                    } label: {
                                        Label("Ghép nối iPhone này", systemImage: "link")
                                            .frame(maxWidth: .infinity).padding(9)
                                    }
                                    .buttonStyle(DynorContrastButtonStyle())
                                    .disabled(importing || store.isInstallingWallpaper || store.isImportingPairing)
                                }
                                Divider()
                            }
                            PairingStep(number: supportsOnDevicePairing ? "02" : "01", title: "Nhập file pairing", detail: supportsOnDevicePairing ? "Bạn cũng có thể nhập file có sẵn từ SideStore, AltStore, LiveContainer hoặc máy tính." : "iOS dưới 27 sử dụng file pairing từ SideStore, AltStore, LiveContainer, Jitterbug hoặc máy tính. Chọn .mobiledevicepairing, .plist hoặc .mobilepair.")
                            if let record = store.pairingRecord {
                                VStack(alignment: .leading, spacing: 8) {
                                    Label(record.displayName, systemImage: "doc.badge.checkmark")
                                        .font(.subheadline.weight(.medium)).lineLimit(3)
                                    Text("Đã lưu trên thiết bị · \(record.addedAt.formatted(date: .abbreviated, time: .shortened))")
                                        .font(.caption).foregroundStyle(.secondary)
                                    Text("Kết nối sẽ được xác thực khi cài hình nền.")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                .padding(14)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12))
                            }
                            Button { showImporter = true } label: {
                                HStack {
                                    if importing { ProgressView().padding(.trailing, 4) }
                                    Label(store.pairingRecord == nil ? "Nhập file pairing" : "Nhập file pairing khác", systemImage: "square.and.arrow.down")
                                }
                                .frame(maxWidth: .infinity).padding(9)
                            }
                            .buttonStyle(DynorContrastButtonStyle())
                            .disabled(importing || controller.running || store.isInstallingWallpaper || store.isImportingPairing)
                            if store.pairingRecord != nil {
                                Button("Xóa file pairing", role: .destructive) {
                                    store.removePairingRecord()
                                    if store.pairingRecord == nil { PairingController.clearHostIdentity() }
                                }
                                .font(.subheadline)
                                .disabled(importing || controller.running || store.isInstallingWallpaper || store.isImportingPairing)
                            }
                        }
                    }

                    PairingGlassCard {
                        VStack(alignment: .leading, spacing: 18) {
                            Label("Cài hình nền Tendies", systemImage: "photo.on.rectangle.angled").font(.headline)
                            PairingStep(number: "1", title: "Bật LocalDevVPN", detail: "Bật cấu hình loopback LocalDevVPN hoặc WireGuard để Airlift có thể truy cập dịch vụ trên thiết bị (10.7.0.1 hoặc 127.0.0.1).")
                            Divider()
                            PairingStep(number: "2", title: "Mở Thư viện", detail: "Nhập file .tendies, chọn hình nền rồi bấm Cài hình nền. Giữ ứng dụng mở đến khi quá trình hoàn tất.")
                            Divider()
                            PairingDetailRow(title: "Pairing record", value: store.pairingRecord == nil ? "Chưa có" : "Đã lưu cục bộ")
                            PairingDetailRow(title: "Thư viện Tendies", value: "\(store.library.filter { $0.kind == .tendies }.count) tệp")
                            Text(TendiesInstaller.supportWarning ?? "Dynor cho phép cài Tendies trên iOS 18–27.1. Khả năng cài phụ thuộc phiên bản, file pairing và kết nối thiết bị. iOS 27.2 được tạm chặn vì chưa phân biệt chắc chắn bản beta đã vá.")
                                .font(.caption).foregroundStyle(.secondary)
                            Link(destination: URL(string: "https://github.com/Mak5er/AirCard-iOS")!) {
                                Label("Hướng dẫn kết nối AirCard-iOS", systemImage: "arrow.up.right.square")
                                    .font(.subheadline.weight(.semibold))
                            }
                        }
                    }
                    Text("File pairing chứa thông tin xác thực. Dynor lưu bản sao trong vùng riêng của ứng dụng để kết nối; bạn có thể xóa ở trên.")
                        .font(.caption2).foregroundStyle(.secondary)
                        .padding(.bottom, 10)
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Pairing")
            .navigationBarTitleDisplayMode(.inline)
            // File providers can assign different UTIs to plist/unknown extensions.
            // Let Files select any item; the import service validates its contents.
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    importing = true
                    Task {
                        await store.importPairingRecord(url: url)
                        importing = false
                    }
                case .failure(let error):
                    notice = "Chưa nhập được file: \(error.localizedDescription)"
                }
            }
            .alert("Pairing", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }
        .tint(store.accentColor)
    }

    @MainActor
    private func pairOnDevice() async {
        guard !importing, !store.isInstallingWallpaper, !store.isImportingPairing else { return }
        do {
            let url = try await controller.startAndWait()
            defer { try? FileManager.default.removeItem(at: url) }
            importing = true
            await store.importPairingRecord(url: url)
            importing = false
        } catch is CancellationError {
            // The user explicitly stopped this pairing session.
        } catch {
            notice = error.localizedDescription
        }
    }
}

private struct PairingGlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        content.padding(21).frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(Color.primary.opacity(0.06)))
    }
}

private struct PairingStatus: View {
    let text: String
    var body: some View {
        HStack(spacing: 5) {
            Circle().fill(.secondary).frame(width: 5, height: 5)
            Text(text)
        }
        .font(.system(size: 10, weight: .medium))
        .foregroundStyle(.secondary)
        .padding(.horizontal, 9).padding(.vertical, 6)
        .background(Color(uiColor: .tertiarySystemFill), in: Capsule())
    }
}

private struct PairingStep: View {
    @EnvironmentObject private var store: DynorStore
    let number: String
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Text(number).font(.caption.weight(.semibold))
                .frame(width: 30, height: 30)
                .background(store.accentColor.opacity(0.2), in: Circle())
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(detail).font(.caption).foregroundStyle(.secondary).lineSpacing(3)
            }
        }
    }
}

private struct PairingDetailRow: View {
    let title: String
    let value: String
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
        }
        .font(.caption)
    }
}
