import SwiftUI
import UIKit
import UniformTypeIdentifiers

@MainActor
struct LibraryView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var importing = false
    @State private var pickerIsVisible = false
    @State private var readingFiles = false
    @State private var importResultMessage: String?
    @State private var selecting = false
    @State private var selected = Set<UUID>()
    @State private var confirmDelete = false
    @State private var preview: ImportedWallpaper?
    @State private var category = "Tất cả"
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]
    private var visible: [ImportedWallpaper] {
        store.library.filter { category == "Tất cả" || ($0.kind.isTendies ? category == "Tendies" : category == "Ảnh") }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 7) {
                    Text("LƯU GIỮ CHẤT RIÊNG").font(.caption2.weight(.semibold)).tracking(2).foregroundStyle(.secondary)
                    Text("Thư viện của tôi").font(.largeTitle.bold())
                    Text("Ảnh và Tendies của bạn, lưu ngay trên iPhone.").font(.subheadline).foregroundStyle(.secondary)
                }
                Label("Chọn ảnh, tệp .tendies hoặc gói mã hóa .dynor. Nội dung mỗi tệp tối đa 50 MB. File gốc của bạn không bị thay đổi.", systemImage: "lock.shield")
                    .font(.caption).foregroundStyle(.secondary).padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
                Picker("Loại tệp", selection: $category) {
                    ForEach(["Tất cả", "Ảnh", "Tendies"], id: \.self) { Text($0).tag($0) }
                }.pickerStyle(.segmented)
                HStack {
                    Text("\(visible.count) tệp").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    if selecting {
                        Button(selected.isSuperset(of: Set(visible.map(\.id))) && !visible.isEmpty ? "Bỏ chọn" : "Chọn tất cả") {
                            let ids = Set(visible.map(\.id))
                            if selected.isSuperset(of: ids) { selected.subtract(ids) } else { selected.formUnion(ids) }
                        }.font(.caption)
                    }
                    Button(selecting ? "Xong" : "Chọn nhiều") {
                        selecting.toggle(); selected.removeAll()
                    }.font(.caption).disabled(store.library.isEmpty || store.isInstallingWallpaper)
                }
                if visible.isEmpty {
                    ContentUnavailableView {
                        Label("Bộ sưu tập bắt đầu từ bạn", systemImage: "square.and.arrow.down")
                    } description: {
                        Text("Nhập ảnh, tệp .tendies hoặc gói mã hóa .dynor từ ứng dụng Tệp. Sau khi nhập, mở gói để cài hình nền.")
                    } actions: {
                        Button("Nhập ảnh / Tendies", action: showImportPicker)
                            .buttonStyle(.borderedProminent)
                            .disabled(readingFiles || store.isImporting || store.isInstallingWallpaper)
                    }.padding(.vertical, 35)
                } else {
                    LazyVGrid(columns: columns, spacing: 18) {
                        ForEach(visible) { item in
                            Button {
                                if selecting {
                                    if selected.contains(item.id) { selected.remove(item.id) } else { selected.insert(item.id) }
                                } else { preview = item }
                            } label: {
                                VStack(alignment: .leading, spacing: 9) {
                                    ZStack(alignment: .topTrailing) {
                                        LibraryArtwork(item: item).frame(height: 245).clipped()
                                            .clipShape(RoundedRectangle(cornerRadius: 20))
                                        if selecting {
                                            Image(systemName: selected.contains(item.id) ? "checkmark.circle.fill" : "circle")
                                                .font(.title2).symbolRenderingMode(.palette)
                                                .foregroundStyle(selected.contains(item.id) ? store.accentColor : .white, .ultraThinMaterial)
                                                .padding(11)
                                        }
                                    }
                                    Text(item.displayName).font(.caption.weight(.medium)).lineLimit(1).foregroundStyle(.primary)
                                    Text(item.kind == .encryptedTendies ? "Dynor · Gói mã hóa" : item.kind.isTendies ? "Tendies · Cài hình nền" : ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                                        .font(.caption2).foregroundStyle(.secondary)
                                }
                            }.buttonStyle(.plain).disabled(readingFiles)
                        }
                    }
                }
                if selecting && !selected.isEmpty {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label("Xóa \(selected.count) tệp đã chọn", systemImage: "trash")
                            .frame(maxWidth: .infinity).padding(8)
                    }.buttonStyle(.bordered).disabled(store.isInstallingWallpaper)
                }
            }.padding(20)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Thư viện").navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(action: showImportPicker) {
            if readingFiles { ProgressView() } else { Image(systemName: "plus") }
        }.disabled(readingFiles || store.isImporting || store.isInstallingWallpaper)
            .accessibilityLabel("Nhập ảnh hoặc Tendies") } }
        .sheet(isPresented: $importing, onDismiss: {
            pickerIsVisible = false
            presentImportResult()
        }) {
            WallpaperDocumentPicker(onPick: { urls in
                // Retain and process the selection immediately. Import must not
                // depend on the order of UIKit and SwiftUI dismissal callbacks.
                importing = false
                importPickedDocuments(urls)
            }, onCancel: {
                importing = false
            })
        }
        .overlay {
            if readingFiles {
                ProgressView("Đang nhập tệp…")
                    .padding(24).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
            }
        }
        .confirmationDialog("Xóa \(selected.count) tệp khỏi Dynor?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Xóa \(selected.count) tệp", role: .destructive) {
                store.removeImported(ids: selected); selected.removeAll(); selecting = false
            }
            Button("Giữ lại", role: .cancel) {}
        } message: { Text("Tệp gốc bên ngoài Dynor vẫn được giữ lại.") }
        .sheet(item: $preview) { LibraryPreview(item: $0).environmentObject(store) }
        .onAppear { presentRequestedWallpaper() }
        .onChange(of: store.pendingLibraryPreview) { _, _ in presentRequestedWallpaper() }
    }

    private func showImportPicker() {
        guard !readingFiles, !store.isImporting, !store.isInstallingWallpaper else { return }
        pickerIsVisible = true
        importing = true
    }

    private func importPickedDocuments(_ urls: [URL]) {
        guard !urls.isEmpty, !readingFiles else { return }
        readingFiles = true
        Task { @MainActor in
            defer {
                readingFiles = false
                presentImportResult()
            }
            let imported = await store.importWallpapers(urls: urls)
            let message = store.message
            store.message = nil
            if urls.count == 1, let item = imported.first {
                store.openInLibrary(item)
            } else {
                importResultMessage = message ?? "Chưa nhập được tệp đã chọn. Hãy thử lại."
            }
        }
    }

    private func presentImportResult() {
        guard !pickerIsVisible, !importing, !readingFiles else { return }
        if let message = importResultMessage {
            importResultMessage = nil
            store.message = message
        }
        presentRequestedWallpaper()
    }

    private func presentRequestedWallpaper() {
        guard !pickerIsVisible, !importing, !readingFiles,
              store.selectedTab == .library, let id = store.pendingLibraryPreview,
              let item = store.library.first(where: { $0.id == id }) else { return }
        category = item.kind.isTendies ? "Tendies" : "Ảnh"
        selecting = false
        selected.removeAll()
        preview = item
        store.pendingLibraryPreview = nil
    }
}

private struct LibraryArtwork: View {
    @EnvironmentObject private var store: DynorStore
    let item: ImportedWallpaper
    var body: some View {
        GeometryReader { geometry in
            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                Image(uiImage: image).resizable().scaledToFill().frame(width: geometry.size.width, height: geometry.size.height)
            } else {
                ZStack {
                    LinearGradient(colors: [.init(red: 0.35, green: 0.48, blue: 0.43), .init(red: 0.7, green: 0.7, blue: 0.46)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    VStack(spacing: 20) {
                        Image(systemName: item.kind == .encryptedTendies ? "lock.shield" : "square.3.layers.3d").font(.system(size: 42, weight: .ultraLight))
                        Text(item.kind == .encryptedTendies ? "DYNOR" : "TENDIES").font(.caption.weight(.medium)).tracking(4)
                    }.foregroundStyle(.white)
                }
            }
        }
    }
}

@MainActor
struct LibraryPreview: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    let item: ImportedWallpaper
    @State private var saving = false
    @State private var notice: String?
    @State private var installing = false
    @State private var installProgress = 0.0
    @State private var installLog: [String] = []
    @State private var installed = false
    @State private var preparing = false
    @State private var accessReady = false
    private var busy: Bool { installing || preparing }
    private var compatibility: TendiesCompatibility.Assessment { TendiesCompatibility.current }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    LibraryArtwork(item: item).frame(height: 400).clipped().clipShape(RoundedRectangle(cornerRadius: 24))
                    Text(item.displayName).font(.title2.bold())
                    Text(item.kind.isTendies ? "Chuẩn bị quyền truy cập, sau đó cài gói hình nền. Khi hoàn tất, khởi động lại iPhone rồi mở Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập." : "Lưu ảnh vào Ảnh, sau đó chọn Chia sẻ → Dùng làm hình nền.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    if item.kind == .encryptedTendies {
                        Label("Đăng nhập Dynor và kết nối Internet mỗi lần cài gói mã hóa. Gói VIP cần tài khoản VIP còn hiệu lực. Dynor không xuất tệp đã giải mã.", systemImage: "lock.shield")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if item.kind.isTendies {
                        tendiesControls
                    }
                    if item.kind == .image {
                        Button {
                            saving = true
                            Task {
                                await store.saveImportedToPhotos(item)
                                notice = store.message
                                store.message = nil
                                saving = false
                            }
                        } label: {
                            Label(saving ? "Đang lưu…" : "Lưu vào Ảnh", systemImage: "photo.badge.arrow.down")
                                .frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(.borderedProminent).disabled(saving)
                        ShareLink(item: store.fileURL(for: item)) {
                            Label("Chia sẻ ảnh gốc", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(.bordered).disabled(busy)
                    }
                }.padding(20)
            }.toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() }.disabled(busy) } }
            .interactiveDismissDisabled(busy)
            .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }
    }

    @ViewBuilder
    private var tendiesControls: some View {
        if let warning = compatibility.warning {
            Label(warning, systemImage: "info.circle")
                .font(.caption).foregroundStyle(.secondary)
        } else {
            Label(compatibility.detail, systemImage: "iphone")
                .font(.caption).foregroundStyle(.secondary)
            if ProcessInfo.processInfo.operatingSystemVersion.majorVersion == 18 {
                Text("Bước chuẩn bị trên iOS 18 có thể làm Dynor đóng hoặc khởi động lại. Mỗi lần mở lại ứng dụng cần chuẩn bị lại quyền truy cập.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            if ProcessInfo.processInfo.operatingSystemVersion.majorVersion == 27 {
                Text("Trên iOS 27, hãy thêm và áp dụng một hình nền Bộ sưu tập của Apple trong Cài đặt → Hình nền trước khi chuẩn bị cài gói.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        if preparing {
            ProgressView("Đang chuẩn bị quyền truy cập…")
                .font(.caption)
        }
        Button(action: prepareWallpaperAccess) {
            Label(preparing ? "Đang chuẩn bị…" : accessReady ? "Chuẩn bị lại quyền truy cập" : "Chuẩn bị cài hình nền", systemImage: "lock.open")
                .frame(maxWidth: .infinity).padding(8)
        }
        .buttonStyle(.bordered)
        .disabled(busy || store.isInstallingWallpaper || !compatibility.canAttemptInstall)
        if accessReady {
            Label("Đã sẵn sàng cài hình nền trong phiên này.", systemImage: "checkmark.circle")
                .font(.caption).foregroundStyle(.secondary)
        }
        if installing {
            ProgressView(value: installProgress)
            Text("Đang cài… Giữ Dynor mở cho đến khi hoàn tất.")
                .font(.caption).foregroundStyle(.secondary)
        }
        Button(action: installTendies) {
            Label(installing ? "Đang cài hình nền…" : installed ? "Cài lại hình nền" : "Cài hình nền", systemImage: "iphone.gen3")
                .frame(maxWidth: .infinity).padding(8)
        }
        .buttonStyle(.borderedProminent)
        .disabled(busy || store.isInstallingWallpaper || !accessReady || !compatibility.canAttemptInstall)
        if !installLog.isEmpty {
            DisclosureGroup("Chi tiết cài đặt") {
                Text(installLog.joined(separator: "\n"))
                    .font(.caption2.monospaced())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
            }.font(.caption)
        }
    }

    private func appendInstallLog(_ line: String) {
        installLog.append(line)
        if installLog.count > 100 { installLog.removeFirst(installLog.count - 100) }
    }

    private func prepareWallpaperAccess() {
        guard compatibility.canAttemptInstall, !busy, !store.isInstallingWallpaper else { return }
        preparing = true
        accessReady = false
        store.isInstallingWallpaper = true
        installLog = []
        let previousIdleSetting = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        Task { @MainActor in
            defer {
                preparing = false
                store.isInstallingWallpaper = false
                UIApplication.shared.isIdleTimerDisabled = previousIdleSetting
            }
            do {
                try await TendiesInstaller.shared.prepareAccess(log: { line in
                    Task { @MainActor in appendInstallLog(line) }
                })
                accessReady = true
            } catch {
                notice = "Chưa chuẩn bị được quyền truy cập: \(error.localizedDescription)"
            }
        }
    }

    private func installTendies() {
        guard compatibility.canAttemptInstall, accessReady, !busy, !store.isInstallingWallpaper else { return }
        installing = true
        store.isInstallingWallpaper = true
        installed = false
        installProgress = 0
        let previousIdleSetting = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        Task { @MainActor in
            defer {
                installing = false
                store.isInstallingWallpaper = false
                UIApplication.shared.isIdleTimerDisabled = previousIdleSetting
            }
            do {
                let count = try await TendiesInstaller.shared.install(
                    archiveURL: store.fileURL(for: item),
                    log: { line in Task { @MainActor in appendInstallLog(line) } },
                    progress: { value in Task { @MainActor in installProgress = value } }
                )
                installed = true
                notice = "Đã cài \(count) mẫu hình nền. Khởi động lại iPhone rồi mở Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập để chọn."
            } catch {
                accessReady = false
                notice = "Chưa hoàn tất cài hình nền: \(error.localizedDescription)"
            }
        }
    }
}
