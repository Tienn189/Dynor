import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct LibraryView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var importing = false
    @State private var readingFiles = false
    @State private var selecting = false
    @State private var selected = Set<UUID>()
    @State private var confirmDelete = false
    @State private var preview: ImportedWallpaper?
    @State private var category = "Tất cả"
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]
    private var visible: [ImportedWallpaper] {
        store.library.filter { category == "Tất cả" || ($0.kind == .tendies ? category == "Tendies" : category == "Ảnh") }
    }
    // Providers may advertise .tendies as ZIP or generic data. Validate after selection.
    private var importTypes: [UTType] { [.item] }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 7) {
                    Text("LƯU GIỮ CHẤT RIÊNG").font(.caption2.weight(.semibold)).tracking(2).foregroundStyle(.secondary)
                    Text("Thư viện của tôi").font(.largeTitle.bold())
                    Text("Ảnh và Tendies của bạn, lưu ngay trên iPhone.").font(.subheadline).foregroundStyle(.secondary)
                }
                Label("Chọn nhiều ảnh hoặc tệp .tendies. Mỗi tệp tối đa 50 MB. File gốc của bạn không bị thay đổi.", systemImage: "lock.shield")
                    .font(.caption).foregroundStyle(.secondary).padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
                Picker("Loại tệp", selection: $category) {
                    ForEach(["Tất cả", "Ảnh", "Tendies"], id: \.self) { Text($0).tag($0) }
                }.pickerStyle(.segmented)
                HStack {
                    Text("\(visible.count) tệp").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    if selecting {
                        Button(selected.isSuperset(of: Set(visible.map(\.id))) && !visible.isEmpty ? "Bỏ chọn" : "Chọn tất cả") {
                            let ids = Set(visible.map(\.id))
                            if selected.isSuperset(of: ids) { selected.subtract(ids) } else { selected.formUnion(ids) }
                        }.font(.caption)
                    }
                    Button(selecting ? "Xong" : "Chọn nhiều") {
                        selecting.toggle(); selected.removeAll()
                    }.font(.caption).disabled(store.library.isEmpty)
                }
                if visible.isEmpty {
                    ContentUnavailableView {
                        Label("Bộ sưu tập bắt đầu từ bạn", systemImage: "square.and.arrow.down")
                    } description: {
                        Text("Nhập ảnh hoặc tệp Tendies từ ứng dụng Tệp. Sau khi nhập, mở tệp Tendies để cài hình nền bằng Airlift.")
                    } actions: {
                        Button("Import hình nền") { importing = true }.buttonStyle(DynorContrastButtonStyle())
                    }.padding(.vertical, 35)
                } else {
                    LazyVGrid(columns: columns, spacing: 18) {
                        ForEach(visible) { item in
                            Button {
                                if selecting {
                                    if selected.contains(item.id) { selected.remove(item.id) } else { selected.insert(item.id) }
                                } else { preview = item }
                            } label: {
                                VStack(alignment: .leading, spacing: 9) {
                                    ZStack(alignment: .topTrailing) {
                                        LibraryArtwork(item: item).frame(height: 245).clipped()
                                            .clipShape(RoundedRectangle(cornerRadius: 20))
                                        if selecting {
                                            Image(systemName: selected.contains(item.id) ? "checkmark.circle.fill" : "circle")
                                                .font(.title2).symbolRenderingMode(.palette)
                                                .foregroundStyle(selected.contains(item.id) ? store.accentColor : .white, .ultraThinMaterial)
                                                .padding(11)
                                        }
                                    }
                                    Text(item.displayName).font(.caption.weight(.medium)).lineLimit(1).foregroundStyle(.primary)
                                    Text(item.kind == .tendies ? "Tendies · Cài hình nền" : ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                                        .font(.caption2).foregroundStyle(.secondary)
                                }
                            }.buttonStyle(.plain)
                        }
                    }
                }
                if selecting && !selected.isEmpty {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label("Xóa \(selected.count) tệp đã chọn", systemImage: "trash")
                            .frame(maxWidth: .infinity).padding(8)
                    }.buttonStyle(.bordered)
                }
            }.padding(20)
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Thư viện").navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { importing = true } label: {
            if readingFiles { ProgressView() } else { Image(systemName: "plus") }
        }.disabled(readingFiles).accessibilityLabel("Import nhiều hình nền") } }
        .fileImporter(isPresented: $importing, allowedContentTypes: importTypes, allowsMultipleSelection: true) { result in
            switch result {
            case .success(let urls):
                readingFiles = true
                Task {
                    await store.importWallpapers(urls: urls)
                    readingFiles = false
                }
            case .failure(let error): store.message = "Chưa nhập được tệp: \(error.localizedDescription)"
            }
        }
        .confirmationDialog("Xóa \(selected.count) tệp khỏi Dynor?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Xóa \(selected.count) tệp", role: .destructive) {
                store.removeImported(ids: selected); selected.removeAll(); selecting = false
            }
            Button("Giữ lại", role: .cancel) {}
        } message: { Text("Tệp gốc bên ngoài Dynor vẫn được giữ lại.") }
        .sheet(item: $preview) { LibraryPreview(item: $0).environmentObject(store) }
    }
}

private struct LibraryArtwork: View {
    @EnvironmentObject private var store: DynorStore
    let item: ImportedWallpaper
    var body: some View {
        GeometryReader { geometry in
            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                Image(uiImage: image).resizable().scaledToFill().frame(width: geometry.size.width, height: geometry.size.height)
            } else {
                ZStack {
                    LinearGradient(colors: [.init(red: 0.35, green: 0.48, blue: 0.43), .init(red: 0.7, green: 0.7, blue: 0.46)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    VStack(spacing: 20) {
                        Image(systemName: "square.3.layers.3d").font(.system(size: 42, weight: .ultraLight))
                        Text("TENDIES").font(.caption.weight(.medium)).tracking(4)
                    }.foregroundStyle(.white)
                }
            }
        }
    }
}

@MainActor
private struct LibraryPreview: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    let item: ImportedWallpaper
    @State private var saving = false
    @State private var notice: String?
    @State private var installing = false
    @State private var installProgress = 0.0
    @State private var installLog: [String] = []
    @State private var installed = false
    @ObservedObject private var pairingController = PairingController.shared
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    LibraryArtwork(item: item).frame(height: 400).clipped().clipShape(RoundedRectangle(cornerRadius: 24))
                    Text(item.displayName).font(.title2.bold())
                    Text(item.kind == .tendies ? "Bật LocalDevVPN và mở khóa iPhone trước khi cài. Sau khi cài, nhấn giữ màn hình khóa → Thêm hình nền để chọn hình nền mới." : "Lưu ảnh vào Ảnh, sau đó chọn Chia sẻ → Dùng làm hình nền.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    if item.kind == .tendies {
                        tendiesControls
                    }
                    if item.kind == .image {
                        Button {
                            saving = true
                            Task {
                                await store.saveImportedToPhotos(item)
                                notice = store.message
                                store.message = nil
                                saving = false
                            }
                        } label: {
                            Label(saving ? "Đang lưu…" : "Lưu vào Ảnh", systemImage: "photo.badge.arrow.down")
                                .frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(DynorContrastButtonStyle()).disabled(saving)
                    }
                    ShareLink(item: store.fileURL(for: item)) {
                        Label("Chia sẻ tệp gốc", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(8)
                    }.buttonStyle(.bordered).disabled(installing)
                }.padding(20)
            }.toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() }.disabled(installing) } }
            .interactiveDismissDisabled(installing)
            .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }
    }

    @ViewBuilder
    private var tendiesControls: some View {
        if let warning = TendiesInstaller.supportWarning {
            Label(warning, systemImage: "info.circle")
                .font(.caption).foregroundStyle(.secondary)
        } else if pairingController.running {
            Label("Hãy hoàn tất ghép nối trước khi cài hình nền.", systemImage: "link")
                .font(.caption).foregroundStyle(.secondary)
        } else if store.pairingRecord == nil {
            Label("Nhập file pairing hoặc ghép nối ở tab Pairing trước khi cài.", systemImage: "link")
                .font(.caption).foregroundStyle(.secondary)
        }
        if installing {
            ProgressView(value: installProgress)
            Text("Đang cài… Giữ Dynor mở và không ngắt VPN.")
                .font(.caption).foregroundStyle(.secondary)
        }
        Button {
            installTendies()
        } label: {
            Label(installing ? "Đang cài hình nền…" : installed ? "Cài lại hình nền" : "Cài hình nền", systemImage: "iphone.gen3")
                .frame(maxWidth: .infinity).padding(8)
        }
        .buttonStyle(DynorContrastButtonStyle())
        .disabled(installing || store.isInstallingWallpaper || pairingController.running || store.isImportingPairing || store.pairingRecord == nil || TendiesInstaller.supportWarning != nil)
        if !installLog.isEmpty {
            DisclosureGroup("Chi tiết cài đặt") {
                Text(installLog.joined(separator: "\n"))
                    .font(.caption2.monospaced())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
            }.font(.caption)
        }
    }

    private func installTendies() {
        guard !installing, !store.isInstallingWallpaper, !pairingController.running, !store.isImportingPairing, let pairingURL = store.pairingRecordURL else { return }
        installing = true
        store.isInstallingWallpaper = true
        installed = false
        installProgress = 0
        installLog = []
        let previousIdleSetting = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        Task { @MainActor in
            defer {
                installing = false
                store.isInstallingWallpaper = false
                UIApplication.shared.isIdleTimerDisabled = previousIdleSetting
            }
            do {
                let count = try await TendiesInstaller.shared.install(
                    archiveURL: store.fileURL(for: item), pairingURL: pairingURL,
                    log: { line in
                        Task { @MainActor in
                            installLog.append(line)
                            if installLog.count > 100 { installLog.removeFirst(installLog.count - 100) }
                        }
                    },
                    progress: { value in Task { @MainActor in installProgress = value } }
                )
                installed = true
                notice = "Đã cài \(count) mẫu hình nền. Nhấn giữ màn hình khóa → Thêm hình nền để chọn. Nếu chưa thấy, khởi động lại iPhone rồi kiểm tra lại."
            } catch {
                notice = "Chưa hoàn tất cài hình nền: \(error.localizedDescription)"
            }
        }
    }
}
