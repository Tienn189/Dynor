import SwiftUI
import UIKit
import Combine
import Photos
import UniformTypeIdentifiers

struct WallpaperItem: Identifiable {
    let id: String
    let title: String
    let category: String
    let imageName: String

    static let samples: [WallpaperItem] = [
        .init(id: "dune", title: "Golden Silence", category: "Thiên nhiên", imageName: "dune"),
        .init(id: "alpine", title: "Alpine Dreams", category: "Thiên nhiên", imageName: "alpine"),
        .init(id: "liquid", title: "Liquid Flow", category: "Trừu tượng", imageName: "liquid"),
        .init(id: "forest", title: "Into the Green", category: "Thiên nhiên", imageName: "forest"),
        .init(id: "space", title: "Stardust", category: "Vũ trụ", imageName: "space"),
        .init(id: "ocean", title: "Ocean Therapy", category: "Thiên nhiên", imageName: "ocean"),
        .init(id: "minimal", title: "Soft Horizon", category: "Tối giản", imageName: "minimal"),
        .init(id: "sunset", title: "Last Light", category: "Thiên nhiên", imageName: "sunset"),
        .init(id: "coast", title: "Coastal Escape", category: "Thiên nhiên", imageName: "coast"),
        .init(id: "peak", title: "Above the Clouds", category: "Thiên nhiên", imageName: "mountain-hero")
    ]
}

func wallpaperImage(named name: String) -> UIImage? {
    guard let path = Bundle.main.path(forResource: name, ofType: "jpg") else { return nil }
    return UIImage(contentsOfFile: path)
}

enum ThemeMode: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var colorScheme: ColorScheme? {
        switch self { case .system: return nil; case .light: return .light; case .dark: return .dark }
    }
}

enum ThemeAccent: String, CaseIterable { case gold, white }
struct LocalProfile: Codable, Equatable { let id: String; let name: String }
enum ImportedKind: String, Codable { case image, tendies }
struct ImportedWallpaper: Codable, Identifiable {
    let id: UUID
    let displayName: String
    let storedFilename: String
    let kind: ImportedKind
    let addedAt: Date
    let byteCount: Int64
}

struct ImportedPairingRecord: Codable {
    let displayName: String
    let addedAt: Date
    let storedFilename: String
}

@MainActor
final class DynorStore: ObservableObject {
    @Published var theme: ThemeMode { didSet { defaults.set(theme.rawValue, forKey: "theme") } }
    @Published var accent: ThemeAccent { didSet { defaults.set(accent.rawValue, forKey: "accent") } }
    @Published var favorites: Set<String> { didSet { defaults.set(Array(favorites), forKey: "favorites") } }
    @Published private(set) var profile: LocalProfile?
    @Published private(set) var library: [ImportedWallpaper] = []
    @Published private(set) var pairingRecord: ImportedPairingRecord?
    @Published private(set) var isImporting = false
    @Published private(set) var isImportingPairing = false
    @Published var isInstallingWallpaper = false
    @Published var message: String?
    @Published private var dailyDay: String
    @Published private var dailyCount: Int

    private let defaults: UserDefaults
    private let root: URL
    private var libraryDirectory: URL { root.appendingPathComponent("Library", isDirectory: true) }
    private var indexURL: URL { root.appendingPathComponent("library.json") }
    private var pairingDirectory: URL { root.appendingPathComponent("Pairing", isDirectory: true) }
    private var pairingIndexURL: URL { root.appendingPathComponent("pairing.json") }
    var pairingRecordURL: URL? {
        pairingRecord.map { pairingDirectory.appendingPathComponent($0.storedFilename) }
    }
    var accentColor: Color { accent == .gold ? Color(red: 0.82, green: 0.64, blue: 0.16) : Color.primary }
    var currentDayKey: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Asia/Ho_Chi_Minh")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
    var adsWatched: Int { dailyDay == currentDayKey ? min(5, max(0, dailyCount)) : 0 }
    var isUnlocked: Bool { adsWatched >= 5 }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        theme = ThemeMode(rawValue: defaults.string(forKey: "theme") ?? "system") ?? .system
        accent = ThemeAccent(rawValue: defaults.string(forKey: "accent") ?? "gold") ?? .gold
        favorites = Set(defaults.stringArray(forKey: "favorites") ?? [])
        dailyDay = defaults.string(forKey: "dailyDay") ?? ""
        dailyCount = min(5, max(0, defaults.integer(forKey: "dailyCount")))
        if let data = defaults.data(forKey: "profile") { profile = try? JSONDecoder().decode(LocalProfile.self, from: data) }
        root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Dynor", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: libraryDirectory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: indexURL.path) {
                library = try JSONDecoder().decode([ImportedWallpaper].self, from: Data(contentsOf: indexURL))
            }
            try FileManager.default.createDirectory(at: pairingDirectory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: pairingIndexURL.path) {
                let record = try JSONDecoder().decode(ImportedPairingRecord.self, from: Data(contentsOf: pairingIndexURL))
                if FileManager.default.fileExists(atPath: pairingDirectory.appendingPathComponent(record.storedFilename).path) {
                    pairingRecord = record
                }
            }
        } catch {
            message = "Không thể mở thư viện cục bộ: \(error.localizedDescription)"
        }
        refreshDailyAccess()
    }

    func refreshDailyAccess() {
        if dailyDay != currentDayKey {
            dailyDay = currentDayKey
            dailyCount = 0
            defaults.set(dailyDay, forKey: "dailyDay")
            defaults.set(0, forKey: "dailyCount")
        }
        objectWillChange.send()
    }

    @discardableResult
    func recordDemoAd(startDay: String) -> Bool {
        refreshDailyAccess()
        guard startDay == currentDayKey else {
            message = "Đã sang ngày mới theo giờ Việt Nam. Hãy bắt đầu lại tiến trình hôm nay."
            return false
        }
        dailyCount = min(5, dailyCount + 1)
        defaults.set(dailyCount, forKey: "dailyCount")
        return true
    }

    func toggleFavorite(_ id: String) {
        if favorites.contains(id) { favorites.remove(id) } else { favorites.insert(id) }
    }

    func createLocalProfile(name: String) {
        let cleanName = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(40))
        guard !cleanName.isEmpty else { return }
        let next = LocalProfile(id: profile?.id ?? "DYN-" + UUID().uuidString, name: cleanName)
        do {
            defaults.set(try JSONEncoder().encode(next), forKey: "profile")
            profile = next
        } catch { message = error.localizedDescription }
    }

    func deleteLocalProfile() {
        defaults.removeObject(forKey: "profile")
        profile = nil
    }

    func fileURL(for item: ImportedWallpaper) -> URL {
        libraryDirectory.appendingPathComponent(item.storedFilename)
    }

    func importWallpapers(urls: [URL]) async {
        guard !isImporting else { message = "Dynor đang nhập tệp. Hãy chờ hoàn tất."; return }
        isImporting = true
        defer { isImporting = false }
        var added: [ImportedWallpaper] = []
        var duplicates = 0
        var failures: [String] = []
        for url in urls {
            do {
                let staged = try await Task.detached(priority: .userInitiated) {
                    try DocumentImportService.stage(url, maximumBytes: DocumentImportService.wallpaperLimit)
                }.value
                defer { staged.remove() }
                let ext = staged.pathExtension
                let isTendies = ext == "tendies"
                guard isTendies || UTType(filenameExtension: ext)?.conforms(to: .image) == true else {
                    throw DocumentImportError.unsupportedWallpaper
                }
                if library.contains(where: { $0.displayName == staged.displayName && $0.byteCount == staged.byteCount }) ||
                    added.contains(where: { $0.displayName == staged.displayName && $0.byteCount == staged.byteCount }) {
                    duplicates += 1
                    continue
                }
                if !isTendies && UIImage(contentsOfFile: staged.url.path) == nil {
                    throw DocumentImportError.invalidImage
                }
                let id = UUID()
                let record = ImportedWallpaper(id: id, displayName: staged.displayName,
                    storedFilename: id.uuidString + "." + ext, kind: isTendies ? .tendies : .image,
                    addedAt: Date(), byteCount: staged.byteCount)
                try FileManager.default.copyItem(at: staged.url, to: fileURL(for: record))
                added.append(record)
            } catch { failures.append("\(url.lastPathComponent): \(error.localizedDescription)") }
        }
        do {
            let next = Array(added.reversed()) + library
            try JSONEncoder().encode(next).write(to: indexURL, options: .atomic)
            library = next
            var summary = "Đã nhập \(added.count) tệp."
            if duplicates > 0 { summary += " Bỏ qua \(duplicates) tệp trùng tên và kích thước." }
            if !failures.isEmpty { summary += "\n" + failures.joined(separator: "\n") }
            message = summary
        } catch {
            for item in added { try? FileManager.default.removeItem(at: fileURL(for: item)) }
            message = "Chưa lưu được thư viện: \(error.localizedDescription)"
        }
    }

    @discardableResult
    func importPairingRecord(url: URL) async -> Bool {
        guard !isInstallingWallpaper else { message = "Hãy chờ cài hình nền hoàn tất trước khi đổi pairing record."; return false }
        guard !isImportingPairing else { return false }
        isImportingPairing = true
        defer { isImportingPairing = false }
        do {
            guard DocumentImportService.pairingExtensions.contains(url.pathExtension.lowercased()) else {
                message = "Hãy chọn tệp .mobiledevicepairing, .plist hoặc .mobilepair."
                return false
            }
            let staged = try await Task.detached(priority: .userInitiated) {
                let staged = try DocumentImportService.stage(url, maximumBytes: DocumentImportService.pairingLimit)
                do { try DocumentImportService.validatePairing(at: staged.url) }
                catch { staged.remove(); throw error }
                return staged
            }.value
            defer { staged.remove() }
            let record = ImportedPairingRecord(displayName: staged.displayName, addedAt: Date(), storedFilename: UUID().uuidString + ".plist")
            let destination = pairingDirectory.appendingPathComponent(record.storedFilename)
            let previousURL = pairingRecordURL
            do {
                try FileManager.default.copyItem(at: staged.url, to: destination)
                try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: destination.path)
                try JSONEncoder().encode(record).write(to: pairingIndexURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            } catch {
                try? FileManager.default.removeItem(at: destination)
                throw error
            }
            pairingRecord = record
            if let previousURL { try? FileManager.default.removeItem(at: previousURL) }
            // Pairing credentials are device-specific; do not migrate them via backups.
            var excluded = URLResourceValues()
            excluded.isExcludedFromBackup = true
            var directory = pairingDirectory
            try? directory.setResourceValues(excluded)
            message = "Đã nhập pairing record. Bật LocalDevVPN trước khi cài hình nền."
            return true
        } catch {
            message = "Chưa nhập được pairing record: \(error.localizedDescription)"
            return false
        }
    }

    func removePairingRecord() {
        guard !isInstallingWallpaper else { message = "Hãy chờ cài hình nền hoàn tất trước khi xóa pairing record."; return }
        do {
            if FileManager.default.fileExists(atPath: pairingIndexURL.path) {
                try FileManager.default.removeItem(at: pairingIndexURL)
            }
            let previousURL = pairingRecordURL
            pairingRecord = nil
            if let previousURL { try FileManager.default.removeItem(at: previousURL) }
        } catch { message = "Chưa xóa được pairing record: \(error.localizedDescription)" }
    }

    func removeImported(ids: Set<UUID>) {
        guard !ids.isEmpty else { return }
        let removed = library.filter { ids.contains($0.id) }
        let kept = library.filter { !ids.contains($0.id) }
        do {
            // Commit the visible index before reclaiming the corresponding files.
            try JSONEncoder().encode(kept).write(to: indexURL, options: .atomic)
            library = kept
            var failedCleanup = 0
            for item in removed {
                do { try FileManager.default.removeItem(at: fileURL(for: item)) }
                catch { failedCleanup += 1 }
            }
            message = "Đã xóa \(removed.count) tệp khỏi thư viện." + (failedCleanup > 0 ? " Có tệp chưa dọn được trên bộ nhớ." : "")
        } catch { message = "Chưa xóa được thư viện: \(error.localizedDescription)" }
    }

    func saveToPhotos(_ item: WallpaperItem) async {
        refreshDailyAccess()
        guard isUnlocked else { message = "Xem đủ 5 quảng cáo mô phỏng để lưu hình nền trong hôm nay."; return }
        guard let image = wallpaperImage(named: item.imageName) else { message = "Không tìm thấy ảnh trong ứng dụng."; return }
        await saveImage(image)
    }

    func saveImportedToPhotos(_ item: ImportedWallpaper) async {
        guard item.kind == .image, let image = UIImage(contentsOfFile: fileURL(for: item).path) else {
            message = "Tệp Tendies dùng nút Cài hình nền; không thể lưu trực tiếp như ảnh."; return
        }
        await saveImage(image)
    }

    private func saveImage(_ image: UIImage) async {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else {
            message = "Hãy cho phép Dynor thêm ảnh trong Cài đặt → Quyền riêng tư → Ảnh."
            return
        }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAsset(from: image)
            }
            message = "Đã lưu vào Ảnh. Mở Ảnh → Chia sẻ → Dùng làm hình nền để cài."
        } catch { message = "Chưa lưu được ảnh: \(error.localizedDescription)" }
    }
}
