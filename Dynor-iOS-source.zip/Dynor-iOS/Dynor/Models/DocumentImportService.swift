import Foundation

enum DocumentImportError: LocalizedError {
    case notAFile
    case empty
    case tooLarge(Int)
    case unsupportedWallpaper
    case invalidImage
    case invalidPairing

    var errorDescription: String? {
        switch self {
        case .notAFile: return "Hãy chọn một tệp, không phải thư mục."
        case .empty: return "Tệp trống hoặc chưa tải được từ iCloud. Hãy tải tệp trong ứng dụng Tệp rồi thử lại."
        case .tooLarge(let limit): return "Tệp vượt quá giới hạn \(limit / 1024 / 1024) MB."
        case .unsupportedWallpaper: return "Chỉ nhập ảnh hoặc tệp có đuôi .tendies."
        case .invalidImage: return "Không đọc được nội dung ảnh."
        case .invalidPairing: return "Pairing record phải là tệp plist XML hoặc binary chứa một dictionary không rỗng."
        }
    }
}

struct StagedDocument {
    let url: URL
    let displayName: String
    let byteCount: Int64
    let pathExtension: String

    func remove() { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
}

/// Document providers can advertise `.tendies` as ZIP or as a dynamic UTI.
/// Pick any document and validate the extension/content after obtaining access.
enum DocumentImportService {
    static let pairingExtensions: Set<String> = ["plist", "mobiledevicepairing", "mobilepair"]
    static let wallpaperLimit = 50 * 1024 * 1024
    static let pairingLimit = 5 * 1024 * 1024

    /// Run away from the main actor: coordination may wait for iCloud to download.
    static func stage(_ source: URL, maximumBytes: Int) throws -> StagedDocument {
        let hasAccess = source.startAccessingSecurityScopedResource()
        defer { if hasAccess { source.stopAccessingSecurityScopedResource() } }

        if (try? source.resourceValues(forKeys: [.isUbiquitousItemKey]).isUbiquitousItem) == true {
            try FileManager.default.startDownloadingUbiquitousItem(at: source)
        }

        var coordinationError: NSError?
        var result: Result<StagedDocument, Error>?
        // Coordinated reads materialize cloud/provider documents before checking size.
        NSFileCoordinator().coordinate(readingItemAt: source, options: [], error: &coordinationError) { readableURL in
            result = Result { try copyReadableFile(readableURL, displayName: source.lastPathComponent, maximumBytes: maximumBytes) }
        }
        if let coordinationError { throw coordinationError }
        guard let result else { throw CocoaError(.fileReadUnknown) }
        return try result.get()
    }

    static func validatePairing(at url: URL) throws {
        let data = try Data(contentsOf: url)
        let value = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)
        guard let dictionary = value as? [String: Any], !dictionary.isEmpty else {
            throw DocumentImportError.invalidPairing
        }
        // Protocol-specific credential validation belongs to the pairing engine.
        // Remote pairing plists do not share all USB pairing-record keys.
    }

    private static func copyReadableFile(_ source: URL, displayName: String, maximumBytes: Int) throws -> StagedDocument {
        let attributes = try source.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard attributes.isRegularFile == true else { throw DocumentImportError.notAFile }
        if let size = attributes.fileSize, size > maximumBytes { throw DocumentImportError.tooLarge(maximumBytes) }

        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("DynorImport-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let ext = URL(fileURLWithPath: displayName).pathExtension.lowercased()
        let destination = directory.appendingPathComponent("document").appendingPathExtension(ext)
        do {
            guard FileManager.default.createFile(atPath: destination.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
            let input = try FileHandle(forReadingFrom: source)
            defer { try? input.close() }
            let output = try FileHandle(forWritingTo: destination)
            defer { try? output.close() }
            var count = 0
            while let chunk = try input.read(upToCount: 64 * 1024), !chunk.isEmpty {
                count += chunk.count
                guard count <= maximumBytes else { throw DocumentImportError.tooLarge(maximumBytes) }
                try output.write(contentsOf: chunk)
            }
            guard count > 0 else { throw DocumentImportError.empty }
            return StagedDocument(url: destination, displayName: displayName, byteCount: Int64(count), pathExtension: ext)
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw error
        }
    }
}
