// Network discovery adapted from Mak5er/AirCard-iOS (MIT).
// See ThirdParty/AirCard/LICENSE and provenance.json.
import Foundation
import Darwin
import AirliftFFI

/// Airlift must connect through a device interface or VPN gateway. A direct
/// loopback connection can invalidate remotepairingdeviced's connection policy.
enum TendiesTargetHosts {
    struct Interface {
        let name: String
        let ipv4: String
        var isUp = true
        var isLoopback = false
    }

    private struct ConfigurationError: LocalizedError {
        var errorDescription: String? {
            "Không cấu hình được kết nối thiết bị. Hãy mở lại Dynor và thử lại."
        }
    }

    /// Pure policy kept separate from interface discovery for regression tests.
    /// Prefer Wi-Fi, then other active device interfaces, then LocalDevVPN.
    static func candidates(from interfaces: [Interface]) -> [String] {
        let active = interfaces.filter {
            $0.isUp && !$0.isLoopback && !isTunnel($0.name) && validAddress($0.ipv4)
        }
        let ordered = active.filter { $0.name == "en0" } + active.filter { $0.name != "en0" }
        var seen = Set<String>()
        return (ordered.map(\.ipv4) + ["10.7.0.1"]).filter { seen.insert($0).inserted }
    }

    /// Called on the serialized installation queue before starting native work.
    /// Airlift copies each string during these synchronous configuration calls.
    static func configure() throws {
        let hosts = candidates(from: interfaces())
        let owned = hosts.map { strdup($0) }
        defer { owned.forEach { free($0) } }
        guard owned.allSatisfy({ $0 != nil }) else { throw ConfigurationError() }
        let pointers: [UnsafePointer<CChar>?] = owned.map { pointer in
            pointer.map { UnsafePointer($0) }
        }
        guard al_set_target_host(pointers[0]) == 0 else { throw ConfigurationError() }
        let result = pointers.withUnsafeBufferPointer {
            al_set_target_hosts($0.baseAddress, $0.count)
        }
        guard result == 0 else { throw ConfigurationError() }
    }

    private static func isTunnel(_ name: String) -> Bool {
        ["utun", "ipsec", "tap", "tun", "ppp", "lo"].contains { name.hasPrefix($0) }
    }

    private static func validAddress(_ address: String) -> Bool {
        let parts = address.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4 else { return false }
        let octets = parts.compactMap { UInt8($0) }
        guard octets.count == 4 else { return false }
        return octets[0] > 0 && octets[0] != 127 && octets[0] < 224
    }

    private static func interfaces() -> [Interface] {
        var first: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&first) == 0, let head = first else { return [] }
        defer { freeifaddrs(head) }
        var result: [Interface] = []
        var current: UnsafeMutablePointer<ifaddrs>? = head
        while let entry = current {
            defer { current = entry.pointee.ifa_next }
            guard let address = entry.pointee.ifa_addr,
                  address.pointee.sa_family == sa_family_t(AF_INET) else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            guard getnameinfo(address, socklen_t(MemoryLayout<sockaddr_in>.size),
                              &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 else { continue }
            let flags = entry.pointee.ifa_flags
            result.append(Interface(name: String(cString: entry.pointee.ifa_name),
                                    ipv4: String(cString: host),
                                    isUp: flags & UInt32(IFF_UP) != 0,
                                    isLoopback: flags & UInt32(IFF_LOOPBACK) != 0))
        }
        return result
    }
}
