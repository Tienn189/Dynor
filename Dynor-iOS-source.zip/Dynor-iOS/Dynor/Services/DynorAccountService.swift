import Foundation
import Security

@MainActor
final class DynorAccountService: ObservableObject {
    static let shared = DynorAccountService()
    @Published private(set) var email: String?
    @Published private(set) var vipExpiresAt: Date?
    @Published private(set) var isVIP = false
    @Published private(set) var statusMessage = ""

    private let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    private let publicKey = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    private let tokenKey = "dynor.supabase.accessToken"
    private let refreshKey = "dynor.supabase.refreshToken"
    private var accessToken: String?
    private var refreshToken: String?

    private init() {
        accessToken = Self.readSecret(tokenKey)
        refreshToken = Self.readSecret(refreshKey)
        if accessToken != nil { Task { await restoreSession() } }
    }

    private func request(path: String, method: String = "POST", body: [String: Any]? = nil, bearer: String? = nil) async throws -> Any {
        let parts = path.split(separator: "?", maxSplits: 1).map(String.init)
        var url = base.appendingPathComponent(parts[0])
        if parts.count > 1, var components = URLComponents(url: url, resolvingAgainstBaseURL: false) {
            components.percentEncodedQuery = parts[1]
            if let built = components.url { url = built }
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(publicKey, forHTTPHeaderField: "apikey")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let bearer { req.setValue("Bearer \(bearer)", forHTTPHeaderField: "Authorization") }
        if let body { req.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await URLSession.shared.data(for: req)
        let object = (try? JSONSerialization.jsonObject(with: data)) ?? [:]
        guard let http = response as? HTTPURLResponse else { throw AuthError.message("Không có phản hồi từ máy chủ") }
        guard (200..<300).contains(http.statusCode) else {
            let detail = (object as? [String: Any])?["msg"] as? String
                ?? (object as? [String: Any])?["error_description"] as? String
                ?? (object as? [String: Any])?["message"] as? String
                ?? "HTTP \(http.statusCode)"
            throw AuthError.message(detail)
        }
        return object
    }

    func sendOTP(to rawEmail: String) async throws {
        let value = rawEmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard value.contains("@"), value.contains(".") else { throw AuthError.message("Email không hợp lệ") }
        _ = try await request(path: "auth/v1/otp", body: ["email": value, "create_user": true])
        statusMessage = "Đã gửi mã OTP tới \(value)"
    }

    func verifyOTP(email rawEmail: String, code: String) async throws {
        let value = rawEmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard code.count == 6, code.allSatisfy({ $0.isNumber }) else { throw AuthError.message("Nhập đủ 6 chữ số OTP") }
        let object = try await request(path: "auth/v1/verify", body: ["email": value, "token": code, "type": "email"])
        guard let dict = object as? [String: Any], let access = dict["access_token"] as? String,
              let refresh = dict["refresh_token"] as? String else { throw AuthError.message("Không nhận được phiên đăng nhập") }
        saveTokens(access: access, refresh: refresh)
        self.email = (dict["user"] as? [String: Any])?["email"] as? String ?? value
        statusMessage = "Đăng nhập thành công"
        await refreshVIP()
    }

    private func saveTokens(access: String, refresh: String) {
        accessToken = access
        refreshToken = refresh
        Self.saveSecret(access, key: tokenKey)
        Self.saveSecret(refresh, key: refreshKey)
    }

    func restoreSession() async {
        guard let token = accessToken else { return }
        do {
            let user = try await request(path: "auth/v1/user", method: "GET", bearer: token) as? [String: Any]
            email = user?["email"] as? String
            await refreshVIP()
        } catch {
            guard let refresh = refreshToken else { signOut(); return }
            do {
                let result = try await request(path: "auth/v1/token?grant_type=refresh_token", body: ["refresh_token": refresh]) as? [String: Any]
                guard let result, let access = result["access_token"] as? String,
                      let newRefresh = result["refresh_token"] as? String else { throw AuthError.message("Không thể làm mới phiên") }
                saveTokens(access: access, refresh: newRefresh)
                let user = try await request(path: "auth/v1/user", method: "GET", bearer: access) as? [String: Any]
                email = user?["email"] as? String
                await refreshVIP()
            } catch { signOut() }
        }
    }

    func refreshVIP() async {
        guard let token = accessToken else { isVIP = false; return }
        do {
            let user = try await request(path: "auth/v1/user", method: "GET", bearer: token) as? [String: Any]
            guard let userID = user?["id"] as? String else { return }
            let path = "rest/v1/dynor_vip?user_id=eq.\(userID)&select=vip_expires_at&limit=1"
            let result = try await request(path: path, method: "GET", bearer: token)
            let rows = result as? [[String: Any]] ?? []
            if let raw = rows.first?["vip_expires_at"] as? String {
                let parser = ISO8601DateFormatter()
                parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
                let date = parser.date(from: raw) ?? ISO8601DateFormatter().date(from: raw)
                vipExpiresAt = date
                isVIP = date.map { $0 > Date() } ?? false
            } else { vipExpiresAt = nil; isVIP = false }
            statusMessage = isVIP ? "VIP đang hoạt động" : "Chưa có VIP đang hoạt động"
        } catch {
            isVIP = false
            statusMessage = "Chưa kiểm tra được VIP: \(error.localizedDescription)"
        }
    }

    func signOut() {
        email = nil; accessToken = nil; refreshToken = nil; isVIP = false; vipExpiresAt = nil
        Self.deleteSecret(tokenKey); Self.deleteSecret(refreshKey)
        statusMessage = "Đã đăng xuất"
    }

    private enum AuthError: LocalizedError {
        case message(String)
        var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
    }
    private static func saveSecret(_ value: String, key: String) {
        deleteSecret(key)
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrAccount as String: key,
                                    kSecValueData as String: Data(value.utf8),
                                    kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        SecItemAdd(query as CFDictionary, nil)
    }
    private static func readSecret(_ key: String) -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrAccount as String: key,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var output: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &output) == errSecSuccess,
              let data = output as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    private static func deleteSecret(_ key: String) {
        SecItemDelete([kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: key] as CFDictionary)
    }
}
