// Support ranges and build IDs adapted from YangJiiii/3105 SupportPolicy.swift.
// GPL-3.0; pinned source and notices: ThirdParty/3105.
import Foundation
import Darwin

enum TendiesCompatibility {
    struct Assessment {
        let warning: String?
        let detail: String
        var canAttemptInstall: Bool { warning == nil }
    }

    static let verifiedIOS27Builds = ["24A5355q", "24A5370h", "24A5380h", "24A5390f"]
    static let summary = "Theo 3105: iOS 18.0–18.7.1, 26.0–26.6.1 và iOS 27 beta 1–4 theo mã build. Cài trực tiếp qua PosterBoard."

    static var currentBuild: String {
        var size: size_t = 0
        guard sysctlbyname("kern.osversion", nil, &size, nil, 0) == 0, size > 0 else { return "Unknown" }
        var value = [CChar](repeating: 0, count: size)
        guard sysctlbyname("kern.osversion", &value, &size, nil, 0) == 0 else { return "Unknown" }
        return String(cString: value)
    }

    static var current: Assessment {
        assess(version: ProcessInfo.processInfo.operatingSystemVersion, build: currentBuild)
    }

    static func assess(version: OperatingSystemVersion, build: String = "Unknown") -> Assessment {
        let major = version.majorVersion
        let minor = version.minorVersion
        let patch = version.patchVersion
        let validNumbers = minor >= 0 && patch >= 0
        let supported: Bool
        switch major {
        case 18: supported = validNumbers && (minor < 7 || (minor == 7 && patch <= 1))
        case 26: supported = validNumbers && (minor < 6 || (minor == 6 && patch <= 1))
        case 27: supported = minor == 0 && patch == 0 && verifiedIOS27Builds.contains(build)
        default: supported = false
        }
        guard supported else {
            let warning = "iOS \(major).\(minor).\(patch) (\(build)) nằm ngoài phạm vi cài hình nền của 3105. \(summary)"
            return Assessment(warning: warning, detail: warning)
        }
        let detail = major == 18
            ? "Nhấn Chuẩn bị cài hình nền để cấp quyền bằng cơ chế của 3105. Bước này có thể làm ứng dụng hoặc thiết bị khởi động lại."
            : "Nhấn Chuẩn bị cài hình nền để truy cập PosterBoard. Cần bản Dynor ký bằng chứng chỉ doanh nghiệp và giữ nguyên định danh cài đặt."
        return Assessment(warning: nil, detail: detail)
    }
}
