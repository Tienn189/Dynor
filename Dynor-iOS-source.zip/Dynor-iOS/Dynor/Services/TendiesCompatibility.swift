import Foundation

/// Eligibility for attempting an Airlift write, not proof that a particular
/// wallpaper or iOS beta has been tested on a physical device.
enum TendiesCompatibility {
    /// Upstream does not publish build IDs for the last working betas. A user
    /// report is explicit and never presented as an automatically verified build.
    enum Release: String, CaseIterable, Identifiable, Hashable {
        case unknown, beta1, beta2, beta3OrLater, stable
        var id: Self { self }
        var label: String {
            switch self {
            case .unknown: return "Chưa xác định bản beta"
            case .beta1: return "Tôi đang dùng iOS 27.2 beta 1"
            case .beta2: return "Tôi đang dùng iOS 27.2 beta 2"
            case .beta3OrLater: return "iOS 27.2 beta 3 trở lên / RC"
            case .stable: return "iOS 27.2 chính thức"
            }
        }
    }

    struct Assessment {
        let warning: String?
        let detail: String
        let canPairOnDevice: Bool
        let requiresBetaConfirmation: Bool
        var canAttemptInstall: Bool { warning == nil }
    }

    static let summary = "Theo AirCard: iOS 18.0–27.2 beta 2. iOS 18–26.x nhập file pairing; iOS 27 có thể ghép nối trong Cài đặt. iOS 27.2 beta 3 trở lên đã bị vá."

    static var current: Assessment {
        assess(version: ProcessInfo.processInfo.operatingSystemVersion)
    }

    static func assess(version: OperatingSystemVersion, release: Release = .unknown) -> Assessment {
        let canPairOnDevice = version.majorVersion >= 27
        let requiresBetaConfirmation = version.majorVersion == 27 && version.minorVersion == 2
        let warning: String?
        if version.majorVersion < 18 {
            warning = "Cài Tendies bằng Airlift yêu cầu iOS 18 trở lên. Bạn vẫn có thể nhập và chia sẻ tệp."
        } else if version.majorVersion > 27 || (version.majorVersion == 27 && version.minorVersion > 2) {
            warning = "Phiên bản này nằm ngoài phạm vi AirCard hỗ trợ. Airlift đã bị vá từ iOS 27.2 beta 3 nên Dynor không thực hiện cài Tendies."
        } else if requiresBetaConfirmation {
            // Beta 1/2 are 27.2.0; never let a report enable 27.2.1 or later.
            if version.patchVersion != 0 || release == .beta3OrLater || release == .stable {
                warning = "Airlift đã bị vá từ iOS 27.2 beta 3. Bản chính thức, RC và các bản mới hơn không cài được Tendies bằng phương thức này."
            } else if release == .unknown {
                warning = "iOS chỉ báo phiên bản 27.2, không cho biết thứ tự beta. Chọn đúng bản đang cài trong Cài đặt → Cài đặt chung → Giới thiệu; chỉ beta 1 hoặc beta 2 nằm trong phạm vi AirCard hỗ trợ."
            } else {
                warning = nil
            }
        } else {
            warning = nil
        }

        let detail: String
        if let warning {
            detail = warning
        } else if requiresBetaConfirmation {
            detail = "Cho phép thử cài theo bản beta bạn xác nhận. AirCard công bố iOS 27.2 beta 1–2 còn hoạt động; Dynor chưa tự xác minh được build này. Có thể ghép nối trong Cài đặt hoặc nhập file pairing."
        } else if canPairOnDevice {
            detail = "Được phép thử cài trên iOS 27.0–27.1 theo phạm vi AirCard. Có thể ghép nối trong Cài đặt hoặc nhập file pairing. Dynor chưa kiểm chứng riêng từng developer/public beta trên thiết bị."
        } else {
            detail = "Được phép thử cài trên iOS 18–26.x bằng file pairing của chính thiết bị. Bật LocalDevVPN, cho phép Mạng cục bộ và giữ iPhone mở khóa khi cài. Kết quả còn phụ thuộc bản iOS và gói Tendies."
        }
        return Assessment(warning: warning, detail: detail, canPairOnDevice: canPairOnDevice,
                          requiresBetaConfirmation: requiresBetaConfirmation)
    }
}
