import Foundation
import zlib

/// Parse untrusted ZIP metadata, extract with strict output limits, and verify
/// every file checksum before wallpaper descriptors can reach the native engine.
enum TendiesArchiveValidator {
    struct Entry: Equatable {
        let path: String
        let isDirectory: Bool
        let uncompressedSize: Int64
        let crc32: UInt32
        let compressedOffset: Int
        let compressedSize: Int
        let method: UInt16

        // Airlift deliberately omits macOS ZIP metadata during extraction.
        var isMetadata: Bool { path.contains("__MACOSX") || path.hasSuffix(".DS_Store") }
    }

    static func validateBeforeExtraction(at archiveURL: URL) throws -> [Entry] {
        let size = try archiveURL.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size >= 22, size <= 50 * 1024 * 1024 else {
            throw invalid("Tệp Tendies rỗng hoặc vượt quá 50 MB.")
        }
        let data = try Data(contentsOf: archiveURL, options: .mappedIfSafe)
        guard data.count == size else { throw invalid("Tệp Tendies đã thay đổi trong khi đọc.") }
        let reader = ZIPReader(data: data)
        let earliest = max(0, data.count - 65_557)
        var eocd: Int?
        for offset in stride(from: data.count - 22, through: earliest, by: -1) {
            if try reader.u32(offset) == 0x06054b50,
               offset + 22 + Int(try reader.u16(offset + 20)) == data.count {
                eocd = offset
                break
            }
        }
        guard let end = eocd,
              try reader.u16(end + 4) == 0,
              try reader.u16(end + 6) == 0 else {
            throw invalid("Tendies phải là tệp ZIP hợp lệ trên một phần lưu trữ.")
        }
        let count = Int(try reader.u16(end + 10))
        let directorySize = Int(try reader.u32(end + 12))
        let directoryStart = Int(try reader.u32(end + 16))
        guard count > 0, count <= 10_000,
              try reader.u16(end + 8) == UInt16(count),
              directorySize != Int(UInt32.max), directoryStart != Int(UInt32.max),
              directoryStart + directorySize == end else {
            throw invalid("ZIP64, ZIP nhiều phần hoặc tệp có quá nhiều mục chưa được hỗ trợ.")
        }

        var entries: [Entry] = []
        var names = Set<String>()
        var ranges: [Range<Int>] = []
        var expandedBytes: Int64 = 0
        var cursor = directoryStart
        for _ in 0..<count {
            guard try reader.u32(cursor) == 0x02014b50 else { throw invalid("Danh mục ZIP bị hỏng.") }
            let flags = try reader.u16(cursor + 8)
            let method = try reader.u16(cursor + 10)
            let crc = try reader.u32(cursor + 16)
            let compressedSize = Int(try reader.u32(cursor + 20))
            let expandedSize = Int64(try reader.u32(cursor + 24))
            let nameLength = Int(try reader.u16(cursor + 28))
            let extraLength = Int(try reader.u16(cursor + 30))
            let commentLength = Int(try reader.u16(cursor + 32))
            let disk = try reader.u16(cursor + 34)
            let attributes = try reader.u32(cursor + 38)
            let localOffset = Int(try reader.u32(cursor + 42))
            let next = cursor + 46 + nameLength + extraLength + commentLength
            guard next <= end, nameLength > 0, nameLength <= 1024, disk == 0,
                  flags & 0x41 == 0, method == 0 || method == 8,
                  expandedSize <= 128 * 1024 * 1024,
                  compressedSize != Int(UInt32.max), localOffset != Int(UInt32.max) else {
                throw invalid("Tendies chứa mục ZIP không được hỗ trợ, được mã hóa hoặc quá lớn.")
            }
            let nameBytes = try reader.bytes(cursor + 46, count: nameLength)
            guard let name = String(data: nameBytes, encoding: .utf8) else {
                throw invalid("Tên mục trong Tendies không phải UTF-8 hợp lệ.")
            }
            let directory = name.hasSuffix("/")
            let path = directory ? String(name.dropLast()) : name
            let components = path.split(separator: "/", omittingEmptySubsequences: false)
            guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\\"),
                  !path.contains(":"), !path.contains("\0"), components.count <= 40,
                  components.allSatisfy({ !$0.isEmpty && $0 != "." && $0 != ".." }),
                  names.insert(path.precomposedStringWithCanonicalMapping.lowercased()).inserted else {
                throw invalid("Tendies chứa đường dẫn không an toàn hoặc mục trùng tên.")
            }
            let unixType = (attributes >> 16) & 0xf000
            guard unixType == 0 || unixType == (directory ? 0x4000 : 0x8000),
                  directory || attributes & 0x10 == 0,
                  !directory || expandedSize == 0 else {
                throw invalid("Tendies không được chứa liên kết tượng trưng hoặc tệp đặc biệt.")
            }
            expandedBytes += expandedSize
            guard expandedBytes <= 512 * 1024 * 1024 else {
                throw invalid("Nội dung Tendies sau giải nén vượt quá 512 MB.")
            }

            guard localOffset < directoryStart,
                  try reader.u32(localOffset) == 0x04034b50,
                  try reader.u16(localOffset + 6) == flags,
                  try reader.u16(localOffset + 8) == method else {
                throw invalid("Thông tin mục ZIP không nhất quán.")
            }
            let localNameLength = Int(try reader.u16(localOffset + 26))
            let localExtraLength = Int(try reader.u16(localOffset + 28))
            let payload = localOffset + 30 + localNameLength + localExtraLength
            guard localNameLength == nameLength,
                  try reader.bytes(localOffset + 30, count: localNameLength) == nameBytes,
                  payload + compressedSize <= directoryStart else {
                throw invalid("Dữ liệu mục ZIP vượt ra ngoài tệp hoặc sai tên.")
            }
            if flags & 8 == 0 {
                guard try reader.u32(localOffset + 14) == crc,
                      try reader.u32(localOffset + 18) == UInt32(compressedSize),
                      try reader.u32(localOffset + 22) == UInt32(expandedSize) else {
                    throw invalid("Kích thước hoặc mã kiểm tra ZIP không nhất quán.")
                }
            }
            if method == 0 && Int64(compressedSize) != expandedSize {
                throw invalid("Kích thước mục ZIP không nén không hợp lệ.")
            }
            ranges.append(localOffset..<(payload + compressedSize))
            entries.append(Entry(path: path, isDirectory: directory, uncompressedSize: expandedSize,
                                 crc32: crc, compressedOffset: payload, compressedSize: compressedSize, method: method))
            cursor = next
        }
        guard cursor == end else { throw invalid("Danh mục ZIP chứa dữ liệu dư hoặc bị thiếu.") }
        let sortedRanges = ranges.sorted { $0.lowerBound < $1.lowerBound }
        for index in 1..<sortedRanges.count where sortedRanges[index].lowerBound < sortedRanges[index - 1].upperBound {
            throw invalid("Các mục dữ liệu ZIP bị chồng lấn.")
        }
        // Reject file/directory collisions such as a regular file `a` and `a/b`.
        let regularPaths = Set(entries.filter { !$0.isDirectory }.map { $0.path.precomposedStringWithCanonicalMapping.lowercased() })
        for entry in entries {
            var parent = (entry.path as NSString).deletingLastPathComponent
            while !parent.isEmpty {
                guard !regularPaths.contains(parent.precomposedStringWithCanonicalMapping.lowercased()) else {
                    throw invalid("Đường dẫn tệp và thư mục trong ZIP bị xung đột.")
                }
                parent = (parent as NSString).deletingLastPathComponent
            }
        }
        return entries
    }

    /// Use a bounded inflater instead of the upstream extractor's unchecked
    /// io::copy. A dishonest ZIP size cannot expand beyond its declared limit.
    static func extract(at archiveURL: URL, to directory: URL, entries: [Entry]) throws {
        let refreshed = try validateBeforeExtraction(at: archiveURL)
        guard refreshed == entries else { throw invalid("Tendies đã thay đổi trước khi giải nén.") }
        let data = try Data(contentsOf: archiveURL, options: .mappedIfSafe)
        guard data.count <= 50 * 1024 * 1024 else { throw invalid("Tendies vượt quá 50 MB.") }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let values = try directory.resourceValues(forKeys: [.isSymbolicLinkKey, .isDirectoryKey])
        guard values.isSymbolicLink != true, values.isDirectory == true,
              try FileManager.default.contentsOfDirectory(atPath: directory.path).isEmpty else {
            throw invalid("Thư mục giải nén phải rỗng và không được là liên kết.")
        }
        for entry in entries where !entry.isMetadata {
            let destination = directory.appendingPathComponent(entry.path)
            if entry.isDirectory {
                try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
                continue
            }
            guard entry.compressedOffset >= 0,
                  entry.compressedOffset + entry.compressedSize <= data.count else {
                throw invalid("Dữ liệu ZIP bị cắt ngắn trước khi giải nén.")
            }
            try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            guard FileManager.default.createFile(atPath: destination.path, contents: nil, attributes: [.posixPermissions: 0o600]) else {
                throw invalid("Không tạo được tệp Tendies sau giải nén.")
            }
            let output = try FileHandle(forWritingTo: destination)
            do {
                if entry.method == 0 {
                    let bytes = data.subdata(in: entry.compressedOffset..<(entry.compressedOffset + entry.compressedSize))
                    guard Int64(bytes.count) == entry.uncompressedSize else { throw invalid("Sai kích thước ZIP không nén.") }
                    try output.write(contentsOf: bytes)
                } else {
                    try inflateEntry(entry, from: data, into: output)
                }
                try output.close()
                guard try checksum(destination) == entry.crc32 else {
                    throw invalid("Tệp Tendies giải nén có mã kiểm tra không đúng: \(entry.path)")
                }
            } catch {
                try? output.close()
                try? FileManager.default.removeItem(at: destination)
                throw error
            }
        }
    }

    private static func inflateEntry(_ entry: Entry, from data: Data, into output: FileHandle) throws {
        var state = z_stream()
        let initialized = inflateInit2_(&state, -MAX_WBITS, ZLIB_VERSION, Int32(MemoryLayout<z_stream>.size))
        guard initialized == Z_OK else { throw invalid("Không khởi tạo được bộ giải nén Tendies.") }
        defer { inflateEnd(&state) }
        try data.withUnsafeBytes { (input: UnsafeRawBufferPointer) in
            guard let address = input.baseAddress else { throw invalid("ZIP không có dữ liệu nén.") }
            state.next_in = UnsafeMutablePointer<Bytef>(mutating: address.assumingMemoryBound(to: Bytef.self).advanced(by: entry.compressedOffset))
            state.avail_in = uInt(entry.compressedSize)
            let chunkSize = 64 * 1024
            var buffer = [UInt8](repeating: 0, count: chunkSize)
            var expanded: Int64 = 0
            while true {
                let inputBefore = state.avail_in
                let result: (Int32, Int) = buffer.withUnsafeMutableBufferPointer { bytes in
                    state.next_out = bytes.baseAddress
                    state.avail_out = uInt(chunkSize)
                    let status = inflate(&state, Z_NO_FLUSH)
                    return (status, chunkSize - Int(state.avail_out))
                }
                expanded += Int64(result.1)
                guard expanded <= entry.uncompressedSize, expanded <= 128 * 1024 * 1024 else {
                    throw invalid("Nội dung ZIP nở vượt quá kích thước đã khai báo.")
                }
                if result.1 > 0 { try output.write(contentsOf: Data(buffer.prefix(result.1))) }
                if result.0 == Z_STREAM_END {
                    guard expanded == entry.uncompressedSize, state.avail_in == 0 else {
                        throw invalid("Dữ liệu DEFLATE bị thiếu hoặc chứa dữ liệu dư.")
                    }
                    break
                }
                guard result.0 == Z_OK, result.1 > 0 || state.avail_in < inputBefore else {
                    throw invalid("Dữ liệu DEFLATE bị hỏng hoặc bị cắt ngắn.")
                }
            }
        }
    }

    static func validateExtraction(at directory: URL, entries: [Entry]) throws {
        let base = directory.resolvingSymlinksInPath().standardizedFileURL.path + "/"
        let expected = Dictionary(uniqueKeysWithValues: entries.filter { !$0.isMetadata }.map { ($0.path, $0) })
        for entry in expected.values {
            let file = directory.appendingPathComponent(entry.path)
            let values = try file.resourceValues(forKeys: [.isSymbolicLinkKey, .isRegularFileKey, .isDirectoryKey, .fileSizeKey])
            guard file.resolvingSymlinksInPath().standardizedFileURL.path.hasPrefix(base),
                  values.isSymbolicLink != true else {
                throw invalid("Kết quả giải nén có đường dẫn không an toàn.")
            }
            if entry.isDirectory {
                guard values.isDirectory == true else { throw invalid("Giải nén Tendies thiếu thư mục.") }
            } else {
                guard values.isRegularFile == true, Int64(values.fileSize ?? -1) == entry.uncompressedSize,
                      try checksum(file) == entry.crc32 else {
                    throw invalid("Tendies bị hỏng hoặc chưa giải nén đầy đủ: \(entry.path)")
                }
            }
        }
        guard let enumerator = FileManager.default.enumerator(at: directory,
            includingPropertiesForKeys: [.isSymbolicLinkKey, .isRegularFileKey, .isDirectoryKey]) else {
            throw invalid("Không đọc được nội dung Tendies đã giải nén.")
        }
        while let file = enumerator.nextObject() as? URL {
            let values = try file.resourceValues(forKeys: [.isSymbolicLinkKey, .isRegularFileKey, .isDirectoryKey])
            guard values.isSymbolicLink != true,
                  file.resolvingSymlinksInPath().standardizedFileURL.path.hasPrefix(base) else {
                throw invalid("Kết quả giải nén có liên kết tượng trưng.")
            }
            if values.isRegularFile == true {
                let relative = String(file.standardizedFileURL.path.dropFirst(directory.standardizedFileURL.path.count + 1))
                guard expected[relative]?.isDirectory == false else {
                    throw invalid("Kết quả giải nén chứa tệp không có trong danh mục ZIP.")
                }
            } else if values.isDirectory != true {
                throw invalid("Kết quả giải nén chứa tệp đặc biệt.")
            }
        }
    }

    private static let crcTable: [UInt32] = (0..<256).map { value in
        var crc = UInt32(value)
        for _ in 0..<8 { crc = crc & 1 == 1 ? (crc >> 1) ^ 0xedb88320 : crc >> 1 }
        return crc
    }

    private static func checksum(_ url: URL) throws -> UInt32 {
        guard let stream = InputStream(url: url) else { throw invalid("Không đọc được tệp đã giải nén.") }
        stream.open()
        defer { stream.close() }
        let chunkSize = 64 * 1024
        var buffer = [UInt8](repeating: 0, count: chunkSize)
        var crc = UInt32.max
        while true {
            let read = stream.read(&buffer, maxLength: chunkSize)
            guard read >= 0 else { throw stream.streamError ?? invalid("Đọc tệp Tendies bị gián đoạn.") }
            if read == 0 { break }
            for byte in buffer.prefix(read) { crc = (crc >> 8) ^ crcTable[Int((crc ^ UInt32(byte)) & 0xff)] }
        }
        return crc ^ UInt32.max
    }

    private static func invalid(_ text: String) -> NSError {
        NSError(domain: "Dynor.TendiesArchive", code: 1, userInfo: [NSLocalizedDescriptionKey: text])
    }

    private struct ZIPReader {
        let data: Data
        func bytes(_ offset: Int, count: Int) throws -> Data {
            guard offset >= 0, count >= 0, offset <= data.count, count <= data.count - offset else {
                throw invalid("ZIP bị cắt ngắn hoặc có kích thước không hợp lệ.")
            }
            return data.subdata(in: offset..<(offset + count))
        }
        func u16(_ offset: Int) throws -> UInt16 {
            let chunk = try bytes(offset, count: 2)
            return UInt16(chunk[0]) | UInt16(chunk[1]) << 8
        }
        func u32(_ offset: Int) throws -> UInt32 {
            let chunk = try bytes(offset, count: 4)
            return UInt32(chunk[0]) | UInt32(chunk[1]) << 8 | UInt32(chunk[2]) << 16 | UInt32(chunk[3]) << 24
        }
    }
}
