// Wallpaper-scoped adapter for YangJiiii/3105 MHA-C2 and iOS 18 kernel access.
// GPL-3.0; see ThirdParty/3105 for pinned originals and attribution.
import Foundation
import Darwin

struct PosterBoardAccessError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

enum PosterBoardAccess {
    private static let stateLock = NSLock()
    private static let operationLock = NSLock()
    private static var preparedContainer: URL?
    private static var kernelAttempted = false
    private static var kernelEstablished = false
    static let requiredBundleIdentifier = "com.apple.mobile.MobileHouseArrest"

    static var isReady: Bool {
        stateLock.lock()
        defer { stateLock.unlock() }
        return preparedContainer != nil
    }

    /// Only call after the user presses the preparation button, on a worker queue.
    /// Never run the kernel operation automatically at launch or during import.
    static func prepare(log: @escaping (String) -> Void) throws -> URL {
        operationLock.lock()
        defer { operationLock.unlock() }
        if let warning = TendiesCompatibility.current.warning {
            throw PosterBoardAccessError(message: warning)
        }
#if targetEnvironment(simulator) || !arch(arm64)
        throw PosterBoardAccessError(message: "Cần iPhone hoặc iPad thật thuộc phiên bản iOS được hỗ trợ. Simulator chỉ dùng kiểm tra giao diện và xử lý gói.")
#else
        guard Bundle.main.bundleIdentifier == requiredBundleIdentifier else {
            throw PosterBoardAccessError(message: "Định danh bản cài không phù hợp cơ chế 3105. Build và ký lại Dynor với định danh com.apple.mobile.MobileHouseArrest bằng chứng chỉ doanh nghiệp.")
        }
        if let container = currentContainer() { return container }
        log("Đang tìm và cấp quyền truy cập PosterBoard…")
        let version = ProcessInfo.processInfo.operatingSystemVersion
        if version.majorVersion >= 26, let container = lookupMCM() {
            remember(container)
            log("Đã mở container PosterBoard qua MHA-C2.")
            return container
        }
        if version.majorVersion == 18 {
            if !kernelEstablished {
                guard !kernelAttempted else {
                    throw PosterBoardAccessError(message: "Lần chuẩn bị quyền trước chưa thành công. Đóng và mở lại Dynor trước khi thử lại.")
                }
                kernelAttempted = true
                log("Đang chuẩn bị quyền iOS 18 theo 3105; giữ Dynor mở. Bước này có thể mất 10–30 giây.")
                let result = kexploit_opa334()
                guard result == 0 else {
                    throw PosterBoardAccessError(message: "Chưa cấp được quyền iOS 18 (mã \(result)). Đóng và mở lại Dynor trước khi thử lại.")
                }
                kernelEstablished = true
                let process = proc_self()
                guard process != 0 else {
                    throw PosterBoardAccessError(message: "Không tìm thấy tiến trình Dynor sau khi chuẩn bị quyền. Đóng và mở lại ứng dụng.")
                }
                let sandboxResult = sandbox_escape(process)
                log(sandboxResult == 0 ? "Đã cấp quyền truy cập hệ thống tệp." : "Đã chuẩn bị quyền kernel; đang kiểm tra quyền PosterBoard thực tế.")
            }
            if let container = lookupMCM() ?? lookupMetadata() {
                remember(container)
                log("Đã tìm thấy PosterBoard. Dynor sẽ kiểm tra quyền ghi trước khi cài.")
                return container
            }
        }
        throw PosterBoardAccessError(message: "Chưa truy cập được PosterBoard. Kiểm tra bản iOS được hỗ trợ và cài Dynor bằng chứng chỉ doanh nghiệp với định danh gốc; SideStore, AltStore và LiveContainer không thuộc luồng cài của 3105.")
#endif
    }

    /// The installer must probe destination descriptor directories before writes.
    static func resolveContainer() throws -> URL {
        stateLock.lock()
        defer { stateLock.unlock() }
        guard let container = preparedContainer,
              validContainer(container),
              FileManager.default.fileExists(atPath: container.path) else {
            preparedContainer = nil
            throw PosterBoardAccessError(message: "Hãy nhấn Chuẩn bị cài hình nền trước khi cài hình nền.")
        }
        return container
    }

    private static func currentContainer() -> URL? {
        stateLock.lock()
        defer { stateLock.unlock() }
        if let container = preparedContainer,
           validContainer(container), FileManager.default.fileExists(atPath: container.path) {
            return container
        }
        preparedContainer = nil
        return nil
    }

    static func invalidate() {
        stateLock.lock()
        defer { stateLock.unlock() }
        preparedContainer = nil
    }

    private static func remember(_ container: URL) {
        stateLock.lock()
        defer { stateLock.unlock() }
        preparedContainer = container
    }

    static func validContainer(_ url: URL) -> Bool {
        guard url.isFileURL else { return false }
        var path = url.standardizedFileURL.path
        if path.hasPrefix("/private/") { path = String(path.dropFirst(8)) }
        let parent = "/var/mobile/Containers/Data/Application/"
        guard path.hasPrefix(parent) else { return false }
        let suffix = String(path.dropFirst(parent.count))
        return !suffix.contains("/") && UUID(uuidString: suffix) != nil
    }

    private static func lookupMCM() -> URL? {
        var error: NSString?
        guard let path = MCMActivateContainerPath(2, "com.apple.PosterBoard", false, &error) else { return nil }
        let container = URL(fileURLWithPath: path, isDirectory: true)
        return validContainer(container) ? container : nil
    }

    /// iOS 18 fallback from 3105: identify PosterBoard by device metadata.
    /// Metadata reads are bounded to 1 MiB.
    private static func lookupMetadata() -> URL? {
        let root = "/var/mobile/Containers/Data/Application"
        let paths: [String]
        if let names = try? FileManager.default.contentsOfDirectory(atPath: root), !names.isEmpty {
            paths = names.map { root + "/" + $0 }
        } else {
            var path = root.utf8CString.map { Int8($0) }
            guard let result = bad_query_list(&path, 2_000_000) else { return nil }
            defer { free(result) }
            paths = String(cString: result).split(separator: "\n").map(String.init)
        }
        for path in paths {
            let container = URL(fileURLWithPath: path, isDirectory: true)
            guard validContainer(container) else { continue }
            let metadata = container.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist")
            guard let file = fopen(metadata.path, "rb") else { continue }
            let capacity = 1_048_577
            var buffer = [UInt8](repeating: 0, count: capacity)
            let count = buffer.withUnsafeMutableBytes { bytes in
                fread(bytes.baseAddress, 1, capacity, file)
            }
            fclose(file)
            guard count > 0, count <= 1_048_576,
                  let dictionary = try? PropertyListSerialization.propertyList(from: Data(buffer.prefix(count)), options: [], format: nil) as? [String: Any],
                  dictionary["MCMMetadataIdentifier"] as? String == "com.apple.PosterBoard" else { continue }
            return container
        }
        return nil
    }
}
