import Foundation
import Combine
import Network
import AirliftFFI

// Adapted from Mak5er/AirCard-iOS (MIT). See ThirdParty/AirCard/LICENSE.
// Native host runs are serialized: the upstream FFI has no cancellation handle.
@MainActor
final class PairingController: ObservableObject {
    static let shared = PairingController()

    @Published private(set) var running = false
    @Published private(set) var pairingStatus = "Chưa ghép nối"
    @Published private(set) var pairingPIN: String?

    private let localNetwork = LocalNetworkAuthorization()
    private let keepAlive = KeepAlive()
    private var service: NetService?
    private var listenerPort: UInt16?
    private var cancellationConnection: NWConnection?
    private var cancelled = false
    private var workerActive = false
    private var continuation: CheckedContinuation<URL, Error>?
    private static let identityKey = "dynor.pairing.hostAltIRK"

    enum PairingError: LocalizedError {
        case unavailable, busy, localNetworkDenied, emptyRecord, failed(String)
        var errorDescription: String? {
            switch self {
            case .unavailable: return "Ghép nối ngay trên thiết bị cần iOS 27 trở lên. Hãy nhập file pairing trên iOS thấp hơn."
            case .busy: return "Phiên ghép nối trước vẫn đang dừng. Hãy đợi hoặc mở lại ứng dụng."
            case .localNetworkDenied: return "Chưa có quyền Mạng cục bộ. Mở Cài đặt → Dynor → Mạng cục bộ rồi thử lại."
            case .emptyRecord: return "Thiết bị chưa tạo được file pairing. Hãy xác nhận mã PIN trong Cài đặt rồi thử lại."
            case .failed(let reason): return reason
            }
        }
    }

    static func clearHostIdentity() {
        UserDefaults.standard.removeObject(forKey: identityKey)
    }

    /// Returns a temporary record only after the native handshake completes.
    /// The caller imports it into protected storage and deletes this temporary file.
    func startAndWait() async throws -> URL {
        guard ProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 27 else { throw PairingError.unavailable }
        guard !running, !workerActive else { throw PairingError.busy }
        running = true
        cancelled = false
        pairingPIN = nil
        pairingStatus = "Đang xin quyền Mạng cục bộ…"
        let authorized = await localNetwork.request()
        guard !cancelled else { running = false; throw CancellationError() }
        guard authorized else { running = false; pairingStatus = "Chưa có quyền Mạng cục bộ"; throw PairingError.localNetworkDenied }
        return try await withCheckedThrowingContinuation { continuation in
            self.continuation = continuation
            keepAlive.startAudio()
            runHost()
        }
    }

    func cancel() {
        guard running else { return }
        cancelled = true
        stopAdvertising()
        keepAlive.stopAll()
        pairingPIN = nil
        pairingStatus = workerActive ? "Đang dừng phiên ghép nối…" : "Đã hủy ghép nối"
        // If Rust is waiting in accept(), a local connection followed by EOF
        // releases it. Do not start another worker while one is still unwinding.
        if let port = listenerPort, let endpointPort = NWEndpoint.Port(rawValue: port) {
            let connection = NWConnection(host: "127.0.0.1", port: endpointPort, using: .tcp)
            cancellationConnection = connection
            connection.stateUpdateHandler = { [weak connection] state in
                if case .ready = state { connection?.cancel() }
            }
            connection.start(queue: .global(qos: .utility))
        }
    }

    private func runHost() {
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent("Dynor-pairing-\(UUID().uuidString).plist")
        workerActive = true
        pairingStatus = "Đang khởi động dịch vụ ghép nối…"
        let altIRK = UserDefaults.standard.string(forKey: Self.identityKey) ?? ""
        let context = Unmanaged.passRetained(self).toOpaque()
        DispatchQueue.global(qos: .userInitiated).async {
            var result = ALPairResult()
            let code = destination.path.withCString { path in
                altIRK.withCString { identity in
                    al_pairing_run_host("0.0.0.0", 0, "Dynor", "Mac17,7", path, identity,
                                        dynorPairReady, dynorPairPIN, context, &result)
                }
            }
            let failure = result.error.map { String(cString: $0) } ?? "Không ghép nối được (mã \(code))."
            let identity = result.host_alt_irk_hex.map { String(cString: $0) } ?? ""
            al_pairing_result_free(&result)
            DispatchQueue.main.async {
                let controller = Unmanaged<PairingController>.fromOpaque(context).takeRetainedValue()
                controller.finish(code: code, failure: failure, identity: identity, destination: destination)
            }
        }
    }

    private func finish(code: Int32, failure: String, identity: String, destination: URL) {
        stopAdvertising()
        keepAlive.stopAll()
        cancellationConnection?.stateUpdateHandler = nil
        cancellationConnection?.cancel()
        cancellationConnection = nil
        listenerPort = nil
        workerActive = false
        running = false
        pairingPIN = nil
        let waiter = continuation
        continuation = nil
        if cancelled {
            try? FileManager.default.removeItem(at: destination)
            pairingStatus = "Đã hủy ghép nối"
            waiter?.resume(throwing: CancellationError())
            return
        }
        guard code == 0 else {
            try? FileManager.default.removeItem(at: destination)
            pairingStatus = "Ghép nối chưa thành công"
            waiter?.resume(throwing: PairingError.failed(failure))
            return
        }
        guard let bytes = try? Data(contentsOf: destination), !bytes.isEmpty,
              (try? PropertyListSerialization.propertyList(from: bytes, format: nil)) is [String: Any] else {
            try? FileManager.default.removeItem(at: destination)
            pairingStatus = "Chưa nhận được file pairing"
            waiter?.resume(throwing: PairingError.emptyRecord)
            return
        }
        if !identity.isEmpty { UserDefaults.standard.set(identity, forKey: Self.identityKey) }
        try? FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: destination.path)
        pairingStatus = "Ghép nối thành công"
        waiter?.resume(returning: destination)
    }

    fileprivate func advertise(serviceID: String, port: UInt16, txt: [String: Data]) {
        listenerPort = port
        guard !cancelled else { cancel(); return }
        stopAdvertising()
        let service = NetService(domain: "", type: "_remotepairing-pairable-host._tcp.", name: serviceID, port: Int32(port))
        service.setTXTRecord(NetService.data(fromTXTRecord: txt))
        service.publish()
        self.service = service
        pairingStatus = "Mở Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép nối với Dynor."
    }

    fileprivate func showPIN(_ pin: String) {
        guard !cancelled else { return }
        pairingPIN = pin
        pairingStatus = "Nhập mã PIN này trong Cài đặt để chấp nhận ghép nối với Dynor."
    }

    private func stopAdvertising() { service?.stop(); service = nil }
}

private let dynorPairReady: ALPairReadyCb = { context, serviceID, port, keys, values, count in
    guard let context, let serviceID else { return }
    let controller = Unmanaged<PairingController>.fromOpaque(context).takeUnretainedValue()
    let identifier = String(cString: serviceID)
    var txt: [String: Data] = [:]
    if let keys, let values {
        for index in 0..<Int(count) {
            if let key = keys[index], let value = values[index] {
                txt[String(cString: key)] = Data(String(cString: value).utf8)
            }
        }
    }
    DispatchQueue.main.async { controller.advertise(serviceID: identifier, port: port, txt: txt) }
}

private let dynorPairPIN: ALPairPinCb = { pin, context in
    guard let context, let pin else { return }
    let controller = Unmanaged<PairingController>.fromOpaque(context).takeUnretainedValue()
    let value = String(cString: pin)
    DispatchQueue.main.async { controller.showPIN(value) }
}
