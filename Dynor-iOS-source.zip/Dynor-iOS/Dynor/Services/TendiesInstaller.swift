// Adapted from Mak5er/AirCard-iOS TendiesEngine (MIT).
// Upstream: 40640c4d827aeab8d798285b57d24fcf6be070d0; see ThirdParty/AirCard/LICENSE.
import Foundation
import AirliftFFI

private struct TendiesInstallError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

private final class TendiesLogSink {
    let receive: (String) -> Void
    init(_ receive: @escaping (String) -> Void) { self.receive = receive }
}

/// Serializes installations. FFI calls and archive processing run on a worker queue.
/// A native write already in progress cannot be cancelled safely; keep the UI open.
actor TendiesInstaller {
    static let shared = TendiesInstaller()
    private var installing = false
    private static let queue = DispatchQueue(label: "com.dynor.tendies.install", qos: .userInitiated)

    static var supportWarning: String? {
        TendiesCompatibility.current.warning
    }

    static func supportWarning(for version: OperatingSystemVersion, release: TendiesCompatibility.Release = .unknown) -> String? {
        TendiesCompatibility.assess(version: version, release: release).warning
    }

    /// Returns the number of descriptors whose writes and cache refresh completed.
    /// Completion does not imply that iOS has selected the new Lock Screen wallpaper.
    func install(archiveURL: URL, pairingURL: URL,
                 release: TendiesCompatibility.Release = .unknown,
                 log: @escaping (String) -> Void,
                 progress: @escaping (Double) -> Void) async throws -> Int {
        try Task.checkCancellation()
        guard !installing else { throw TendiesInstallError(text: "Một lượt cài hình nền đang chạy. Hãy đợi hoàn tất.") }
        let version = ProcessInfo.processInfo.operatingSystemVersion
        if let warning = Self.supportWarning(for: version, release: release) {
            throw TendiesInstallError(text: warning)
        }
        if version.majorVersion == 27 && version.minorVersion == 2 {
            log("Bản beta do người dùng xác nhận (chưa xác minh build): \(release.label)")
        }
        installing = true
        defer { installing = false }
        return try await withCheckedThrowingContinuation { continuation in
            Self.queue.async {
                do {
                    continuation.resume(returning: try Self.performInstall(
                        archiveURL: archiveURL, pairingURL: pairingURL, log: log, progress: progress))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }

    private static func performInstall(archiveURL: URL, pairingURL: URL,
                                       log: @escaping (String) -> Void,
                                       progress: @escaping (Double) -> Void) throws -> Int {
        guard FileManager.default.fileExists(atPath: pairingURL.path) else {
            throw TendiesInstallError(text: "Chưa có pairing record. Nhập hoặc ghép nối trong mục Pairing trước.")
        }
        log("Hệ thống: \(ProcessInfo.processInfo.operatingSystemVersionString)")
        log("Đang kiểm tra tệp Tendies…")
        progress(0.02)
        let work = FileManager.default.temporaryDirectory.appendingPathComponent("dynor-install-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: work) }
        // Snapshot both inputs: another open-in/import action may replace active pairing.
        let stagedArchive = work.appendingPathComponent("source.tendies")
        let stagedPairing = work.appendingPathComponent("pairing.plist")
        try FileManager.default.copyItem(at: archiveURL, to: stagedArchive)
        try FileManager.default.copyItem(at: pairingURL, to: stagedPairing)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: stagedPairing.path)
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: stagedArchive)
        let stage = work.appendingPathComponent("extracted", isDirectory: true)
        try FileManager.default.createDirectory(at: stage, withIntermediateDirectories: true)
        try TendiesArchiveValidator.extract(at: stagedArchive, to: stage, entries: entries)
        let descriptors = TendiesDescriptorCatalog.findDescriptorsWithExtensions(in: stage, defaultExt: "com.apple.WallpaperKit.CollectionsPoster")
        guard !descriptors.isEmpty else {
            throw TendiesInstallError(text: "Tệp không chứa cấu hình hình nền PosterBoard hợp lệ.")
        }
        for descriptor in descriptors {
            guard TendiesDescriptorCatalog.validExtension(descriptor.ext) else {
                throw TendiesInstallError(text: "Tendies chứa mã phần mở rộng hình nền không hợp lệ.")
            }
        }
        log("Đã tìm thấy \(descriptors.count) cấu hình. Đang kết nối thiết bị…")
        progress(0.1)
        try TendiesTargetHosts.configure()
        let sink = TendiesLogSink(log)
        let context = Unmanaged.passUnretained(sink).toOpaque()
        // Retain the sink for the entire synchronous native operation, including callbacks.
        return try withExtendedLifetime(sink) {
            let container = try detectContainer(pairingPath: stagedPairing.path, context: context)
            guard validContainer(container) else {
                throw TendiesInstallError(text: "Thiết bị trả về đường dẫn PosterBoard không hợp lệ; đã dừng cài.")
            }
            var installed = 0
            do {
                for descriptor in descriptors {
                    log("Đang ghi cấu hình \(installed + 1)/\(descriptors.count)…")
                    try TendiesDescriptorCatalog.updatePlistIdentifiers(in: descriptor.url, randomizedID: Int.random(in: 10000...99999))
                    let identifier = UUID().uuidString.uppercased()
                    let base = container + "/Library/Application Support/PRBPosterExtensionDataStore/61/Extensions/"
                    let extensionIDs = TendiesDescriptorCatalog.destinationExtensions(for: descriptor.ext)
                    var successes = 0
                    var lastFailure: Error?
                    for extensionID in extensionIDs {
                        do {
                            try inject(folder: descriptor.url, parent: base + extensionID + "/descriptors",
                                       name: identifier, pairingPath: stagedPairing.path, context: context)
                            successes += 1
                        } catch {
                            lastFailure = error
                            log("Không ghi được biến thể \(extensionID): \(error.localizedDescription)")
                        }
                    }
                    guard successes > 0 else {
                        throw lastFailure ?? TendiesInstallError(text: "Không ghi được cấu hình hình nền.")
                    }
                    installed += 1
                    progress(0.15 + 0.7 * Double(installed) / Double(descriptors.count))
                }
                log("Đang cập nhật tùy chọn PosterBoard…")
                try refreshPreferences(container: container, pairingPath: stagedPairing.path, context: context, log: log)
                progress(1)
                log("Đã ghi \(installed) cấu hình. Mở tùy chỉnh Màn hình khóa để chọn hình nền mới; nếu chưa xuất hiện, khởi động lại thiết bị.")
                return installed
            } catch {
                if installed > 0 {
                    throw TendiesInstallError(text: "Đã ghi \(installed)/\(descriptors.count) cấu hình nhưng chưa hoàn tất: \(error.localizedDescription)")
                }
                throw error
            }
        }
    }

    private static let nativeLog: ALLogCallback = { context, message in
        guard let context = context, let message = message else { return }
        Unmanaged<TendiesLogSink>.fromOpaque(context).takeUnretainedValue().receive(String(cString: message))
    }

    private static func validContainer(_ path: String) -> Bool {
        let normalized = path.hasPrefix("/private/") ? String(path.dropFirst(8)) : path
        let parent = "/var/mobile/Containers/Data/Application/"
        guard normalized.hasPrefix(parent) else { return false }
        let suffix = String(normalized.dropFirst(parent.count))
        return UUID(uuidString: suffix) != nil && !suffix.contains("/")
    }

    private static func nativeFailure(_ pointer: UnsafeMutablePointer<CChar>?, fallback: String) -> TendiesInstallError {
        let detail = pointer.map { String(cString: $0) } ?? fallback
        return TendiesInstallError(text: detail)
    }

    private static func detectContainer(pairingPath: String, context: UnsafeMutableRawPointer) throws -> String {
        var output: UnsafeMutablePointer<CChar>?
        var error: UnsafeMutablePointer<CChar>?
        defer { if let output = output { al_string_free(output) }; if let error = error { al_string_free(error) } }
        let result = pairingPath.withCString { pairing in
            "com.apple.PosterBoard".withCString { bundle in
                al_find_app_container(pairing, bundle, nativeLog, context, &output, &error)
            }
        }
        guard result == 0, let output = output else {
            let detail = nativeFailure(error, fallback: "Không tìm thấy PosterBoard.").localizedDescription
            throw TendiesInstallError(text: "Chưa kết nối được PosterBoard. Bật LocalDevVPN và mở khóa iPhone. \(detail)")
        }
        var container = String(cString: output)
        if container.hasSuffix("/") { container.removeLast() }
        return container
    }

    private static func inject(folder: URL, parent: String, name: String,
                               pairingPath: String, context: UnsafeMutableRawPointer) throws {
        var error: UnsafeMutablePointer<CChar>?
        defer { if let error = error { al_string_free(error) } }
        let result = pairingPath.withCString { pair in
            folder.path.withCString { source in
                parent.withCString { destination in
                    name.withCString { targetName in
                        al_exploit_inject_folder(pair, source, destination, targetName, nativeLog, context, &error)
                    }
                }
            }
        }
        guard result == 0 else { throw nativeFailure(error, fallback: "Ghi cấu hình thất bại (mã \(result)).") }
    }

    private static func writePreferences(source: URL, target: String,
                                         pairingPath: String, context: UnsafeMutableRawPointer) throws {
        var error: UnsafeMutablePointer<CChar>?
        defer { if let error = error { al_string_free(error) } }
        let result = pairingPath.withCString { pair in
            source.path.withCString { sourcePath in
                target.withCString { destination in
                    al_exploit_write_dir(pair, sourcePath, destination, nativeLog, context, &error)
                }
            }
        }
        guard result == 0 else { throw nativeFailure(error, fallback: "Cập nhật PosterBoard thất bại (mã \(result)).") }
    }

    private static func refreshPreferences(container: String, pairingPath: String,
                                           context: UnsafeMutableRawPointer, log: (String) -> Void) throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("dynor-poster-prefs-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let preferences: [String: Any] = [
            "PBF_RESET_FILE_PROTECTIONS": true,
            "PBF_LOCALE_DID_CHANGE": true,
            "PersistedPosterContainerBundleIdentifiers": [
                "com.apple.Posters.CollectionsPosterApp", "com.apple.WallpaperKit.CollectionsPoster",
                "com.apple.MercuryPoster", "com.apple.Posters.MercuryPosterApp",
                "com.apple.PhotosUIPrivate.PhotosPosterProvider"
            ],
            "CompletedPosterBundleIdentifierMigrations": [
                "com.apple.Posters.UnityPosterApp.ExtragalacticPoster",
                "com.apple.Posters.WeatherPosterApp.WeatherPoster",
                "com.apple.Posters.UnityPosterApp.Unity2025Poster",
                "com.apple.Posters.UnityPosterApp.UnityPosterExtension",
                "com.apple.Posters.UnityPosterApp.RhizomePoster",
                "com.apple.Posters.KaleidoscopePosterApp.KaleidoscopePoster"
            ]
        ]
        let data = try PropertyListSerialization.data(fromPropertyList: preferences, format: .binary, options: 0)
        try data.write(to: directory.appendingPathComponent("com.apple.PosterBoard.unprotectedUserDefaults.plist"), options: .atomic)
        try writePreferences(source: directory, target: container + "/Library/Preferences", pairingPath: pairingPath, context: context)
        do {
            try writePreferences(source: directory, target: "/var/mobile/Library/Preferences", pairingPath: pairingPath, context: context)
        } catch {
            // Main PosterBoard preferences succeeded; the global copy is an upstream compatibility fallback.
            log("Tùy chọn PosterBoard đã ghi; bản sao tùy chọn toàn cục chưa ghi được: \(error.localizedDescription)")
        }
    }
}
