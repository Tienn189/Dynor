// Adapted from Mak5er/AirCard-iOS TendiesEngine (MIT).
// Upstream: 40640c4d827aeab8d798285b57d24fcf6be070d0; see ThirdParty/AirCard/LICENSE.
import Foundation
import AirliftFFI

private struct TendiesInstallError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

private final class TendiesLogSink {
    let receive: (String) -> Void
    init(_ receive: @escaping (String) -> Void) { self.receive = receive }
}

/// Serializes installations. FFI calls and archive processing run on a worker queue.
/// A native write already in progress cannot be cancelled safely; keep the UI open.
actor TendiesInstaller {
    static let shared = TendiesInstaller()
    private var installing = false
    private static let queue = DispatchQueue(label: "com.dynor.tendies.install", qos: .userInitiated)

    static var supportWarning: String? {
        supportWarning(for: ProcessInfo.processInfo.operatingSystemVersion)
    }

    static func supportWarning(for version: OperatingSystemVersion) -> String? {
        guard version.majorVersion >= 18 else {
            return "Cài Tendies bằng Airlift yêu cầu iOS 18 trở lên. Bạn vẫn có thể nhập và chia sẻ tệp."
        }
        // Upstream reports 27.2 beta 3+ patched. Without an exact beta build allowlist,
        // refuse all 27.2 builds, including final releases, rather than claim support.
        if version.majorVersion > 27 || (version.majorVersion == 27 && version.minorVersion >= 2) {
            return "Airlift đã bị vá từ iOS 27.2 beta 3. Dynor chưa xác minh bản iOS này nên không thực hiện cài Tendies."
        }
        return nil
    }

    /// Returns the number of descriptors whose writes and cache refresh completed.
    /// Completion does not imply that iOS has selected the new Lock Screen wallpaper.
    func install(archiveURL: URL, pairingURL: URL,
                 log: @escaping (String) -> Void,
                 progress: @escaping (Double) -> Void) async throws -> Int {
        try Task.checkCancellation()
        guard !installing else { throw TendiesInstallError(text: "Một lượt cài hình nền đang chạy. Hãy đợi hoàn tất.") }
        if let warning = Self.supportWarning { throw TendiesInstallError(text: warning) }
        installing = true
        defer { installing = false }
        return try await withCheckedThrowingContinuation { continuation in
            Self.queue.async {
                do {
                    continuation.resume(returning: try Self.performInstall(
                        archiveURL: archiveURL, pairingURL: pairingURL, log: log, progress: progress))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }

    private static func performInstall(archiveURL: URL, pairingURL: URL,
                                       log: @escaping (String) -> Void,
                                       progress: @escaping (Double) -> Void) throws -> Int {
        guard FileManager.default.fileExists(atPath: pairingURL.path) else {
            throw TendiesInstallError(text: "Chưa có pairing record. Nhập hoặc ghép nối trong mục Pairing trước.")
        }
        log("Đang kiểm tra tệp Tendies…")
        progress(0.02)
        let work = FileManager.default.temporaryDirectory.appendingPathComponent("dynor-install-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: work) }
        // Snapshot both inputs: another open-in/import action may replace active pairing.
        let stagedArchive = work.appendingPathComponent("source.tendies")
        let stagedPairing = work.appendingPathComponent("pairing.plist")
        try FileManager.default.copyItem(at: archiveURL, to: stagedArchive)
        try FileManager.default.copyItem(at: pairingURL, to: stagedPairing)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: stagedPairing.path)
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: stagedArchive)
        let stage = work.appendingPathComponent("extracted", isDirectory: true)
        try FileManager.default.createDirectory(at: stage, withIntermediateDirectories: true)
        try TendiesArchiveValidator.extract(at: stagedArchive, to: stage, entries: entries)
        let descriptors = findDescriptorsWithExtensions(in: stage, defaultExt: "com.apple.WallpaperKit.CollectionsPoster")
        guard !descriptors.isEmpty else {
            throw TendiesInstallError(text: "Tệp không chứa cấu hình hình nền PosterBoard hợp lệ.")
        }
        for descriptor in descriptors {
            guard validExtension(descriptor.ext) else {
                throw TendiesInstallError(text: "Tendies chứa mã phần mở rộng hình nền không hợp lệ.")
            }
        }
        log("Đã tìm thấy \(descriptors.count) cấu hình. Đang kết nối thiết bị…")
        progress(0.1)
        configureTargetHosts()
        let sink = TendiesLogSink(log)
        let context = Unmanaged.passUnretained(sink).toOpaque()
        // Retain the sink for the entire synchronous native operation, including callbacks.
        return try withExtendedLifetime(sink) {
            let container = try detectContainer(pairingPath: stagedPairing.path, context: context)
            guard validContainer(container) else {
                throw TendiesInstallError(text: "Thiết bị trả về đường dẫn PosterBoard không hợp lệ; đã dừng cài.")
            }
            var installed = 0
            do {
                for descriptor in descriptors {
                    log("Đang ghi cấu hình \(installed + 1)/\(descriptors.count)…")
                    try updatePlistIdentifiers(in: descriptor.url, randomizedID: Int.random(in: 10000...99999))
                    let identifier = UUID().uuidString.uppercased()
                    let base = container + "/Library/Application Support/PRBPosterExtensionDataStore/61/Extensions/"
                    var extensionIDs = [descriptor.ext]
                    if descriptor.ext == "com.apple.WallpaperKit.CollectionsPoster" {
                        extensionIDs.append("com.apple.Posters.CollectionsPosterApp")
                    } else if descriptor.ext == "com.apple.MercuryPoster" {
                        extensionIDs.append("com.apple.Posters.MercuryPosterApp")
                    }
                    var successes = 0
                    var lastFailure: Error?
                    for extensionID in extensionIDs {
                        do {
                            try inject(folder: descriptor.url, parent: base + extensionID + "/descriptors",
                                       name: identifier, pairingPath: stagedPairing.path, context: context)
                            successes += 1
                        } catch {
                            lastFailure = error
                            log("Không ghi được biến thể \(extensionID): \(error.localizedDescription)")
                        }
                    }
                    guard successes > 0 else {
                        throw lastFailure ?? TendiesInstallError(text: "Không ghi được cấu hình hình nền.")
                    }
                    installed += 1
                    progress(0.15 + 0.7 * Double(installed) / Double(descriptors.count))
                }
                log("Đang cập nhật tùy chọn PosterBoard…")
                try refreshPreferences(container: container, pairingPath: stagedPairing.path, context: context, log: log)
                progress(1)
                log("Đã ghi \(installed) cấu hình. Mở tùy chỉnh Màn hình khóa để chọn hình nền mới; nếu chưa xuất hiện, khởi động lại thiết bị.")
                return installed
            } catch {
                if installed > 0 {
                    throw TendiesInstallError(text: "Đã ghi \(installed)/\(descriptors.count) cấu hình nhưng chưa hoàn tất: \(error.localizedDescription)")
                }
                throw error
            }
        }
    }

    private static let nativeLog: ALLogCallback = { context, message in
        guard let context = context, let message = message else { return }
        Unmanaged<TendiesLogSink>.fromOpaque(context).takeUnretainedValue().receive(String(cString: message))
    }

    private static func configureTargetHosts() {
        "10.7.0.1".withCString { first in
            "127.0.0.1".withCString { second in
                _ = al_set_target_host(first)
                let hosts: [UnsafePointer<CChar>?] = [first, second]
                hosts.withUnsafeBufferPointer { buffer in
                    _ = al_set_target_hosts(buffer.baseAddress, buffer.count)
                }
            }
        }
    }

    private static func validContainer(_ path: String) -> Bool {
        let normalized = path.hasPrefix("/private/") ? String(path.dropFirst(8)) : path
        let parent = "/var/mobile/Containers/Data/Application/"
        guard normalized.hasPrefix(parent) else { return false }
        let suffix = String(normalized.dropFirst(parent.count))
        return UUID(uuidString: suffix) != nil && !suffix.contains("/")
    }

    private static func validExtension(_ identifier: String) -> Bool {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
        return identifier.hasPrefix("com.apple.") && identifier.contains("Poster") &&
            identifier.count <= 200 && !identifier.contains("..") &&
            identifier.unicodeScalars.allSatisfy { allowed.contains($0) }
    }

    private static func nativeFailure(_ pointer: UnsafeMutablePointer<CChar>?, fallback: String) -> TendiesInstallError {
        let detail = pointer.map { String(cString: $0) } ?? fallback
        return TendiesInstallError(text: detail)
    }

    private static func detectContainer(pairingPath: String, context: UnsafeMutableRawPointer) throws -> String {
        var output: UnsafeMutablePointer<CChar>?
        var error: UnsafeMutablePointer<CChar>?
        defer { if let output = output { al_string_free(output) }; if let error = error { al_string_free(error) } }
        let result = pairingPath.withCString { pairing in
            "com.apple.PosterBoard".withCString { bundle in
                al_find_app_container(pairing, bundle, nativeLog, context, &output, &error)
            }
        }
        guard result == 0, let output = output else {
            let detail = nativeFailure(error, fallback: "Không tìm thấy PosterBoard.").localizedDescription
            throw TendiesInstallError(text: "Chưa kết nối được PosterBoard. Bật LocalDevVPN và mở khóa iPhone. \(detail)")
        }
        var container = String(cString: output)
        if container.hasSuffix("/") { container.removeLast() }
        return container
    }

    private static func inject(folder: URL, parent: String, name: String,
                               pairingPath: String, context: UnsafeMutableRawPointer) throws {
        var error: UnsafeMutablePointer<CChar>?
        defer { if let error = error { al_string_free(error) } }
        let result = pairingPath.withCString { pair in
            folder.path.withCString { source in
                parent.withCString { destination in
                    name.withCString { targetName in
                        al_exploit_inject_folder(pair, source, destination, targetName, nativeLog, context, &error)
                    }
                }
            }
        }
        guard result == 0 else { throw nativeFailure(error, fallback: "Ghi cấu hình thất bại (mã \(result)).") }
    }

    private static func writePreferences(source: URL, target: String,
                                         pairingPath: String, context: UnsafeMutableRawPointer) throws {
        var error: UnsafeMutablePointer<CChar>?
        defer { if let error = error { al_string_free(error) } }
        let result = pairingPath.withCString { pair in
            source.path.withCString { sourcePath in
                target.withCString { destination in
                    al_exploit_write_dir(pair, sourcePath, destination, nativeLog, context, &error)
                }
            }
        }
        guard result == 0 else { throw nativeFailure(error, fallback: "Cập nhật PosterBoard thất bại (mã \(result)).") }
    }

    private static func refreshPreferences(container: String, pairingPath: String,
                                           context: UnsafeMutableRawPointer, log: (String) -> Void) throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("dynor-poster-prefs-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let preferences: [String: Any] = [
            "PBF_RESET_FILE_PROTECTIONS": true,
            "PBF_LOCALE_DID_CHANGE": true,
            "PersistedPosterContainerBundleIdentifiers": [
                "com.apple.Posters.CollectionsPosterApp", "com.apple.WallpaperKit.CollectionsPoster",
                "com.apple.MercuryPoster", "com.apple.Posters.MercuryPosterApp",
                "com.apple.PhotosUIPrivate.PhotosPosterProvider"
            ],
            "CompletedPosterBundleIdentifierMigrations": [
                "com.apple.Posters.UnityPosterApp.ExtragalacticPoster",
                "com.apple.Posters.WeatherPosterApp.WeatherPoster",
                "com.apple.Posters.UnityPosterApp.Unity2025Poster",
                "com.apple.Posters.UnityPosterApp.UnityPosterExtension",
                "com.apple.Posters.UnityPosterApp.RhizomePoster",
                "com.apple.Posters.KaleidoscopePosterApp.KaleidoscopePoster"
            ]
        ]
        let data = try PropertyListSerialization.data(fromPropertyList: preferences, format: .binary, options: 0)
        try data.write(to: directory.appendingPathComponent("com.apple.PosterBoard.unprotectedUserDefaults.plist"), options: .atomic)
        try writePreferences(source: directory, target: container + "/Library/Preferences", pairingPath: pairingPath, context: context)
        do {
            try writePreferences(source: directory, target: "/var/mobile/Library/Preferences", pairingPath: pairingPath, context: context)
        } catch {
            // Main PosterBoard preferences succeeded; the global copy is an upstream compatibility fallback.
            log("Tùy chọn PosterBoard đã ghi; bản sao tùy chọn toàn cục chưa ghi được: \(error.localizedDescription)")
        }
    }
    // MARK: - Plist Identifier Randomization (Matches Nugget implementation)

    private static func updatePlistIdentifiers(in folderURL: URL, randomizedID: Int) throws {
        // If suggestion metadata exists, the descriptor is pre-packaged with matching
        // descriptorIdentifier and wallpaper identifiers (e.g. 7400.DYNAMIC <-> 7400).
        // Randomizing only Wallpaper.plist desynchronizes PosterKit's suggestion lookup!
        let suggestionMetadataURL = folderURL.appendingPathComponent("com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist")
        if FileManager.default.fileExists(atPath: suggestionMetadataURL.path) {
            return
        }

        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(
            at: folderURL,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else { return }

        while let fileURL = enumerator.nextObject() as? URL {
            let fileName = fileURL.lastPathComponent

            if fileName == "com.apple.posterkit.provider.descriptor.identifier" {
                // IMPORTANT: ONLY randomize if the file content is a pure integer!
                // For extensions like Mercury, Unity, Kaleidoscope, descriptor identifiers are
                // required string symbols (e.g. "v6x.colorA", "Unity2025")!
                // Overwriting them breaks extension lookup!
                if let content = try? String(contentsOf: fileURL, encoding: .utf8),
                   let _ = Int(content.trimmingCharacters(in: .whitespacesAndNewlines)) {
                    try Data("\(randomizedID)".utf8).write(to: fileURL, options: .atomic)
                }
            } else if fileName == "com.apple.posterkit.provider.contents.userInfo" {
                if let data = try? Data(contentsOf: fileURL),
                   var plist = (try? PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil)) as? [String: Any],
                   plist["wallpaperRepresentingIdentifier"] != nil {
                    plist["wallpaperRepresentingIdentifier"] = randomizedID
                    let updated = try PropertyListSerialization.data(fromPropertyList: plist, format: .binary, options: 0)
                    try updated.write(to: fileURL, options: .atomic)
                }
            } else if fileName.hasSuffix("Wallpaper.plist") {
                if let data = try? Data(contentsOf: fileURL),
                   var plist = (try? PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil)) as? [String: Any] {
                    plist["identifier"] = randomizedID
                    let updated = try PropertyListSerialization.data(fromPropertyList: plist, format: .binary, options: 0)
                    try updated.write(to: fileURL, options: .atomic)
                }
            }
        }
    }

    // MARK: - Find Descriptors With Targeted Extensions

    private static func isDescriptorFolder(_ url: URL) -> Bool {
        let fm = FileManager.default
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else { return false }
        let name = url.lastPathComponent
        if name.hasPrefix(".") || name == "__MACOSX" { return false }

        // Must not be the container root or Library itself
        let ignoredNames: Set<String> = [
            "container", "library", "application support", "prbposterextensiondatastore",
            "extensions", "descriptors", "ordered-descriptors",
            "mercury-descriptors", "mercurydescriptors", "video-descriptors", "videodescriptors"
        ]
        if ignoredNames.contains(name.lowercased()) {
            return false
        }

        func hasFileContents(_ directory: URL) -> Bool {
            guard let files = fm.enumerator(at: directory, includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey], options: [.skipsHiddenFiles]) else { return false }
            while let file = files.nextObject() as? URL {
                if let values = try? file.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
                   values.isRegularFile == true, (values.fileSize ?? 0) > 0 { return true }
            }
            return false
        }
        let versions = url.appendingPathComponent("versions", isDirectory: true)
        if (try? versions.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true,
           hasFileContents(versions) { return true }
        for marker in ["providerInfo.plist", "com.apple.posterkit.provider.descriptor.identifier", "Wallpaper.plist"] {
            let file = url.appendingPathComponent(marker)
            if let values = try? file.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
               values.isRegularFile == true, (values.fileSize ?? 0) > 0 { return true }
        }
        if url.pathExtension.lowercased() == "wallpaper", hasFileContents(url) { return true }

        return false
    }

    private static func determineExtension(for folderURL: URL, defaultExt: String) -> String {
        let pathLower = folderURL.path.lowercased()

        // 1. Check path components for .../Extensions/<bundleID>/descriptors/<desc>
        let components = folderURL.pathComponents
        for i in 0..<components.count {
            if components[i].lowercased() == "extensions", i + 1 < components.count {
                let cand = components[i + 1]
                if cand.contains(".") {
                    return cand
                }
            }
            if components[i].lowercased() == "descriptors", i > 0 {
                let cand = components[i - 1]
                if cand.contains(".") && !cand.lowercased().contains("store") {
                    return cand
                }
            }
        }

        // 2. Check metadata inside suggestionMetadata.plist if present
        let metadataURL = folderURL.appendingPathComponent("com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist")
        if let data = try? Data(contentsOf: metadataURL),
           let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
           let objects = plist["$objects"] as? [Any] {
            for obj in objects {
                if let str = obj as? String {
                    if str.hasPrefix("com.apple.") && str.contains("Poster") {
                        return str
                    }
                }
            }
        }

        // 3. Check descriptor identifier content (e.g. "v6x.colorA" or "v5..." -> Mercury)
        let descIdURL = folderURL.appendingPathComponent("com.apple.posterkit.provider.descriptor.identifier")
        if let descId = try? String(contentsOf: descIdURL, encoding: .utf8) {
            let trimmed = descId.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.hasPrefix("v6") || trimmed.hasPrefix("v5") || trimmed.hasPrefix("v4") || trimmed.contains(".color") {
                return "com.apple.MercuryPoster"
            }
        }

        // 4. Path string hints
        if pathLower.contains("mercury") {
            return "com.apple.MercuryPoster"
        }
        if pathLower.contains("video") || pathLower.contains("photo") {
            return "com.apple.PhotosUIPrivate.PhotosPosterProvider"
        }
        if pathLower.contains("collection") || pathLower.contains("wallpaperkit") {
            return "com.apple.WallpaperKit.CollectionsPoster"
        }
        if pathLower.contains("kaleidoscope") {
            return "com.apple.Posters.KaleidoscopePosterApp.KaleidoscopePoster"
        }
        if pathLower.contains("unity") {
            return "com.apple.Posters.UnityPosterApp.UnityPosterExtension"
        }

        return defaultExt
    }

    private static func findDescriptorsWithExtensions(in rootURL: URL, defaultExt: String) -> [(ext: String, url: URL)] {
        let fileManager = FileManager.default
        var results: [(ext: String, url: URL)] = []

        if isDescriptorFolder(rootURL) {
            let ext = determineExtension(for: rootURL, defaultExt: defaultExt)
            return [(ext: ext, url: rootURL)]
        }

        // Recursive traversal to discover all descriptor directories
        guard let enumerator = fileManager.enumerator(
            at: rootURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return [] }

        while let itemURL = enumerator.nextObject() as? URL {
            var isDir: ObjCBool = false
            guard fileManager.fileExists(atPath: itemURL.path, isDirectory: &isDir), isDir.boolValue else { continue }
            if itemURL.lastPathComponent.hasPrefix(".") || itemURL.lastPathComponent == "__MACOSX" {
                enumerator.skipDescendants()
                continue
            }

            if isDescriptorFolder(itemURL) {
                let ext = determineExtension(for: itemURL, defaultExt: defaultExt)
                results.append((ext: ext, url: itemURL))
                enumerator.skipDescendants() // Do not look for nested descriptors inside a descriptor folder
            }
        }

        return results.sorted { $0.url.path < $1.url.path }
    }
}
