import Foundation
import Darwin

private struct TendiesInstallError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

/// Access preparation and writes share one worker queue. Never start a kernel
/// attempt automatically; the separate preparation button is the explicit opt-in.
actor TendiesInstaller {
    static let shared = TendiesInstaller()
    private var busy = false
    private static let queue = DispatchQueue(label: "com.dynor.posterboard.install", qos: .userInitiated)

    func prepareAccess(log: @escaping (String) -> Void) async throws {
        try beginOperation()
        defer { busy = false }
        try Task.checkCancellation()
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            Self.queue.async {
                do {
                    _ = try PosterBoardAccess.prepare(log: log)
                    continuation.resume()
                } catch { continuation.resume(throwing: error) }
            }
        }
    }

    /// Returns successfully committed descriptors, not an active Lock Screen.
    func install(archiveURL: URL, log: @escaping (String) -> Void,
                 progress: @escaping (Double) -> Void) async throws -> Int {
        try beginOperation()
        defer { busy = false }
        try Task.checkCancellation()
        guard PosterBoardAccess.isReady else {
            throw TendiesInstallError(text: "Hãy bấm Chuẩn bị cài hình nền trước khi cài.")
        }
        var decrypted: PreparedEncryptedTendies?
        if archiveURL.pathExtension.lowercased() == "dynor" {
            log("Đang xác minh quyền và mở gói mã hóa…")
            decrypted = try await EncryptedTendiesService.shared.prepareForInstallation(archiveURL)
        }
        defer { decrypted?.remove() }
        let installArchive = decrypted?.url ?? archiveURL
        try Task.checkCancellation()
        return try await withCheckedThrowingContinuation { continuation in
            Self.queue.async {
                do {
                    continuation.resume(returning: try Self.performInstall(
                        archiveURL: installArchive, log: log, progress: progress))
                } catch { continuation.resume(throwing: error) }
            }
        }
    }

    private func beginOperation() throws {
        guard !busy else {
            throw TendiesInstallError(text: "Một thao tác hình nền đang chạy. Hãy đợi hoàn tất.")
        }
        if let warning = TendiesCompatibility.current.warning {
            throw TendiesInstallError(text: warning)
        }
        busy = true
    }

    private static func performInstall(archiveURL: URL, log: (String) -> Void,
                                       progress: (Double) -> Void) throws -> Int {
        log("Hệ thống: \(ProcessInfo.processInfo.operatingSystemVersionString) (\(TendiesCompatibility.currentBuild))")
        log("Đang kiểm tra gói Tendies…")
        progress(0.02)
        let manager = FileManager.default
        let work = try TendiesInstallWorkspace.create()
        defer { try? manager.removeItem(at: work) }
        let stagedArchive = work.appendingPathComponent("source.tendies")
        try manager.copyItem(at: archiveURL, to: stagedArchive)
        try manager.setAttributes([.protectionKey: FileProtectionType.complete, .posixPermissions: 0o600], ofItemAtPath: stagedArchive.path)
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: stagedArchive)
        let stage = work.appendingPathComponent("extracted", isDirectory: true)
        try TendiesArchiveValidator.extract(at: stagedArchive, to: stage, entries: entries)
        let payload = try TendiesPackageInspector.inspectExtractedPackage(at: stage)
        progress(0.25)
        log("Đã kiểm tra \(payload.descriptors.count) cấu hình. Đang kiểm tra quyền ghi PosterBoard…")

        // Resolve afresh after validation. Never use a fixed generation (e.g. 61)
        // or create a guessed system path when the store is unavailable.
        let container = try PosterBoardAccess.resolveContainer()
        let layout: WallpaperPosterLayout
        do {
            layout = try WallpaperLayoutScanner.scan(
                containerURL: container,
                rootValidator: { $0.standardizedFileURL == container.standardizedFileURL })
            try probeRequiredExtensions(Set(payload.descriptors.map(\.extensionIdentifier)), layout: layout)
        } catch {
            PosterBoardAccess.invalidate()
            throw error
        }
        let backupRoot = try journalRoot()
        // A terminated app may leave a preparing receipt. Recover only its
        // journaled UUIDs; do not reset other tools' or Apple's wallpapers.
        for receipt in WallpaperInstaller.receipts(in: backupRoot) where receipt.status == .preparing {
            log("Đang thu hồi lượt cài bị gián đoạn…")
            try WallpaperInstaller.restore(receipt: receipt, containerURL: container,
                rootValidator: { $0.standardizedFileURL == container.standardizedFileURL })
        }
        progress(0.4)
        log("Đang cài vào kho PosterBoard thế hệ \(layout.generation)…")
        let receipt = try WallpaperInstaller.install(payload: payload, layout: layout, backupRoot: backupRoot)
        progress(1)
        let count = receipt.installedDescriptors.count
        log("Đã ghi và lưu nhật ký \(count) cấu hình. Khởi động lại iPhone, sau đó mở Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập.")
        return count
    }

    /// Based on 3105 WallpaperAccessProbe: test actual create/open/remove access
    /// for every extension in the payload before committing any descriptor.
    private static func probeRequiredExtensions(_ identifiers: Set<String>, layout: WallpaperPosterLayout) throws {
        for identifier in identifiers.sorted() {
            guard let directory = layout.extensionDescriptorDirectories[identifier] else {
                throw WallpaperLabError.unsupportedPosterLayout
            }
            let probe = directory.appendingPathComponent(".dynor-wallpaper-probe-" + UUID().uuidString, isDirectory: true)
            guard mkdir(probe.path, 0o700) == 0 else { throw WallpaperLabError.accessDenied }
            let descriptor = open(probe.path, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW)
            if descriptor >= 0 { close(descriptor) }
            let removed = rmdir(probe.path) == 0
            if !removed { try? FileManager.default.removeItem(at: probe) }
            guard descriptor >= 0, removed else { throw WallpaperLabError.accessDenied }
        }
    }

    private static func journalRoot() throws -> URL {
        let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Dynor/WallpaperReceipts", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true,
            attributes: [.posixPermissions: 0o700, .protectionKey: FileProtectionType.complete])
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        var protectedRoot = root
        try protectedRoot.setResourceValues(values)
        return root
    }
}
