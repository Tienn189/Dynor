import SwiftUI

@main
@MainActor
struct DynorApp: App {
    @StateObject private var store = DynorStore()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .onOpenURL { url in
                    Task {
                        if DocumentImportService.pairingExtensions.contains(url.pathExtension.lowercased()) {
                            await store.importPairingRecord(url: url)
                        } else {
                            await store.importWallpapers(urls: [url])
                        }
                    }
                }
                .tint(store.accentColor)
                .preferredColorScheme(store.theme.colorScheme)
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active { store.refreshDailyAccess(); Task { await DynorAccountService.shared.restoreSession() } }
                }
                .task {
                    while !Task.isCancelled {
                        do { try await Task.sleep(for: .seconds(20)) }
                        catch { return }
                        store.refreshDailyAccess()
                    }
                }
        }
    }
}

private struct RootView: View {
    @EnvironmentObject private var store: DynorStore
    var body: some View {
        TabView {
            NavigationStack { GalleryView() }
                .tabItem { Label("Khám phá", systemImage: "square.grid.2x2") }
            NavigationStack { LibraryView() }
                .tabItem { Label("Thư viện", systemImage: "square.stack") }
            PairingView()
                .tabItem { Label("Pairing", systemImage: "link") }
            SettingsView()
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
        }
        .alert("Dynor", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
            Button("Đã hiểu", role: .cancel) { store.message = nil }
        } message: { Text(store.message ?? "") }
    }
}
