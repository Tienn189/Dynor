import XCTest
import UniformTypeIdentifiers
@testable import Dynor

final class WallpaperDocumentTypesTests: XCTestCase {
    func testPickerAcceptsDynorAirCardAndEveryResolvedTendiesType() {
        let identifiers = Set(WallpaperDocumentTypes.pickerTypes.map(\.identifier))
        XCTAssertTrue(identifiers.contains("com.dynor.tendies"))
        XCTAssertTrue(identifiers.contains("com.aircard.tendies"))
        for type in UTType.types(tag: "tendies", tagClass: .filenameExtension, conformingTo: nil) {
            XCTAssertTrue(identifiers.contains(type.identifier))
        }
        XCTAssertEqual(identifiers.count, WallpaperDocumentTypes.pickerTypes.count)
    }

    func testPickerKeepsProviderFallbackTypes() {
        let identifiers = Set(WallpaperDocumentTypes.pickerTypes.map(\.identifier))
        for type in [UTType.zip, .archive, .data, .item, .image] {
            XCTAssertTrue(identifiers.contains(type.identifier))
        }
    }

    func testPairingPickerAcceptsKnownTypesAndEveryDocumentFallback() {
        let types = PairingDocumentTypes.pickerTypes
        let identifiers = Set(types.map(\.identifier))
        XCTAssertEqual(identifiers.count, types.count)
        XCTAssertTrue(identifiers.contains("com.dynor.mobiledevicepairing"))
        for type in [UTType.propertyList, .xml, .data, .item] {
            XCTAssertTrue(identifiers.contains(type.identifier))
        }
        for ext in DocumentImportService.pairingExtensions {
            for type in UTType.types(tag: ext, tagClass: .filenameExtension, conformingTo: nil) {
                XCTAssertTrue(identifiers.contains(type.identifier))
            }
        }
    }

    func testAppRegistersOpenInForBothTendiesIdentifiers() throws {
        let info = try XCTUnwrap(Bundle(for: DynorStore.self).infoDictionary)
        let documents = try XCTUnwrap(info["CFBundleDocumentTypes"] as? [[String: Any]])
        let wallpaper = try XCTUnwrap(documents.first {
            ($0["LSItemContentTypes"] as? [String])?.contains("com.dynor.tendies") == true
        })
        XCTAssertEqual(wallpaper["CFBundleTypeRole"] as? String, "Viewer")
        XCTAssertTrue((wallpaper["LSItemContentTypes"] as? [String])?.contains("com.aircard.tendies") == true)
    }
}
