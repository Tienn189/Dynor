import Foundation
import XCTest
@testable import Dynor

/// Exercises the disk transaction with a temporary PosterBoard store, never a
/// device container or the access/exploit bridge.
final class PosterBoardWallpaperTests: XCTestCase {
    private let manager = FileManager.default
    private var temporary: URL!

    override func setUpWithError() throws {
        temporary = manager.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try manager.createDirectory(at: temporary, withIntermediateDirectories: true)
    }

    override func tearDownWithError() throws {
        if let temporary { try manager.removeItem(at: temporary) }
    }

    func testScannerUsesHighestUsableNumericGeneration() throws {
        let container = try directory("PosterBoard")
        _ = try descriptorDirectory(container: container, generation: "9")
        let newest = try descriptorDirectory(container: container, generation: "72")
        // A newer generation that has not initialized any extensions is skipped.
        _ = try directory(store(in: container).appendingPathComponent("73"))
        _ = try descriptorDirectory(container: container, generation: "future")

        let layout = try scan(container)

        XCTAssertEqual(layout.generation, "72")
        XCTAssertEqual(layout.extensionDescriptorDirectories[WallpaperPosterLayout.collectionsExtension]?.path, newest.path)
        XCTAssertTrue(layout.supportsCollections)
        XCTAssertFalse(layout.supportsVideo)
    }

    func testScannerRejectsUntrustedRootMissingStoreAndLinkedDescriptorDirectory() throws {
        let container = try directory("PosterBoard")
        XCTAssertThrowsError(try WallpaperLayoutScanner.scan(containerURL: container, rootValidator: { _ in false })) {
            XCTAssertEqual($0 as? WallpaperLabError, .unsafeContainerRoot)
        }
        XCTAssertThrowsError(try scan(container)) {
            XCTAssertEqual($0 as? WallpaperLabError, .posterStoreUnavailable)
        }

        let descriptors = try descriptorDirectory(container: container, generation: "72")
        try manager.removeItem(at: descriptors)
        let outside = try directory("Outside")
        try manager.createSymbolicLink(at: descriptors, withDestinationURL: outside)

        XCTAssertThrowsError(try scan(container)) {
            XCTAssertEqual($0 as? WallpaperLabError, .symbolicLinkUnsupported)
        }
        XCTAssertTrue(try manager.contentsOfDirectory(atPath: outside.path).isEmpty)
    }

    func testInspectorRecognizesOrderedVideoMercuryAndContainerPackages() throws {
        let package = try directory("Package")
        _ = try descriptor(at: package.appendingPathComponent("OrderedDescriptors/01"))
        _ = try descriptor(at: package.appendingPathComponent("OrderedDescriptors/02"))
        _ = try descriptor(at: package.appendingPathComponent("VideoDescriptors/video"))
        _ = try descriptor(at: package.appendingPathComponent("MercuryDescriptors/mercury"))
        let packedContainer = try directory(package.appendingPathComponent("Container"))
        let containerDescriptors = try descriptorDirectory(container: packedContainer, generation: "61")
        _ = try descriptor(at: containerDescriptors.appendingPathComponent("packed"))

        let payload = try TendiesPackageInspector.inspectExtractedPackage(at: package)

        XCTAssertEqual(payload.descriptors.count, 5)
        XCTAssertEqual(payload.descriptors.filter(\.isOrdered).map { $0.directoryURL.lastPathComponent }, ["01", "02"])
        XCTAssertEqual(payload.descriptors.filter { $0.extensionIdentifier == WallpaperPosterLayout.collectionsExtension }.count, 3)
        XCTAssertEqual(payload.descriptors.filter { $0.extensionIdentifier == WallpaperPosterLayout.photosExtension }.count, 1)
        XCTAssertEqual(payload.descriptors.filter { $0.extensionIdentifier == WallpaperPosterLayout.mercuryExtension }.count, 1)
        XCTAssertEqual(payload.fileCount, 15)
        XCTAssertGreaterThan(payload.totalBytes, 0)
    }

    func testInspectorRejectsSymbolicLinkInDescriptorTree() throws {
        let package = try directory("Package")
        let source = try descriptor(at: package.appendingPathComponent("Descriptors/custom"))
        let outside = temporary.appendingPathComponent("outside.txt")
        try Data("outside".utf8).write(to: outside)
        try manager.createSymbolicLink(at: source.appendingPathComponent("linked.txt"), withDestinationURL: outside)

        XCTAssertThrowsError(try TendiesPackageInspector.inspectExtractedPackage(at: package)) {
            XCTAssertEqual($0 as? WallpaperLabError, .symbolicLinkUnsupported)
        }
    }

    func testInstallRewritesIdentifiersAndJournalsWithoutChangingExistingWallpaper() throws {
        let container = try directory("PosterBoard")
        let destination = try descriptorDirectory(container: container, generation: "72")
        let original = try descriptor(at: destination.appendingPathComponent("AppleOriginal"))
        let originalData = try Data(contentsOf: original.appendingPathComponent("Wallpaper.plist"))
        let package = try directory("Package")
        let source = try descriptor(at: package.appendingPathComponent("Descriptors/custom"))
        let payload = try TendiesPackageInspector.inspectExtractedPackage(at: package)
        let backups = temporary.appendingPathComponent("Receipts")

        let receipt = try WallpaperInstaller.install(payload: payload, layout: scan(container), backupRoot: backups)

        XCTAssertEqual(receipt.status, .installed)
        XCTAssertEqual(receipt.installedDescriptors.count, 1)
        XCTAssertEqual(receipt.originalDescriptorNames[WallpaperPosterLayout.collectionsExtension], ["AppleOriginal"])
        let installed = try XCTUnwrap(receipt.installedDescriptors.first)
        XCTAssertNotNil(UUID(uuidString: installed.directoryName))
        let installedDirectory = destination.appendingPathComponent(installed.directoryName)
        let identifierText = try String(contentsOf: installedDirectory.appendingPathComponent("com.apple.posterkit.provider.descriptor.identifier"), encoding: .utf8)
        let identifier = try XCTUnwrap(Int(identifierText))
        XCTAssertGreaterThanOrEqual(identifier, 10_000)
        XCTAssertEqual(try plist(at: installedDirectory.appendingPathComponent("Wallpaper.plist"))["identifier"] as? Int, identifier)
        XCTAssertEqual(try plist(at: installedDirectory.appendingPathComponent("Wallpaper.plist"))["title"] as? String, "Fixture")
        XCTAssertEqual(try plist(at: installedDirectory.appendingPathComponent("com.apple.posterkit.provider.contents.userInfo"))["wallpaperRepresentingIdentifier"] as? Int, identifier)
        XCTAssertEqual(try Data(contentsOf: original.appendingPathComponent("Wallpaper.plist")), originalData)
        XCTAssertEqual(try String(contentsOf: source.appendingPathComponent("com.apple.posterkit.provider.descriptor.identifier"), encoding: .utf8), "42")
        XCTAssertEqual(WallpaperInstaller.receipts(in: backups), [receipt])
        XCTAssertEqual(Set(try manager.contentsOfDirectory(atPath: destination.path)), Set(["AppleOriginal", installed.directoryName]))
    }

    func testFailedLaterDescriptorRollsBackEarlierWritesAndPreservesOriginal() throws {
        let container = try directory("PosterBoard")
        let destination = try descriptorDirectory(container: container, generation: "72")
        _ = try descriptor(at: destination.appendingPathComponent("AppleOriginal"))
        let package = try directory("Package")
        _ = try descriptor(at: package.appendingPathComponent("Descriptors/custom"))
        _ = try descriptor(at: package.appendingPathComponent("VideoDescriptors/custom"))
        let inspected = try TendiesPackageInspector.inspectExtractedPackage(at: package)
        let collection = try XCTUnwrap(inspected.descriptors.first { $0.extensionIdentifier == WallpaperPosterLayout.collectionsExtension })
        let video = try XCTUnwrap(inspected.descriptors.first { $0.extensionIdentifier == WallpaperPosterLayout.photosExtension })
        let payload = TendiesPayload(descriptors: [collection, video], totalBytes: inspected.totalBytes, fileCount: inspected.fileCount)
        let backups = temporary.appendingPathComponent("Receipts")

        XCTAssertThrowsError(try WallpaperInstaller.install(payload: payload, layout: scan(container), backupRoot: backups)) {
            XCTAssertEqual($0 as? WallpaperLabError, .unsupportedPosterLayout)
        }

        XCTAssertEqual(try manager.contentsOfDirectory(atPath: destination.path), ["AppleOriginal"])
        let journal = try XCTUnwrap(WallpaperInstaller.receipts(in: backups).first)
        XCTAssertEqual(journal.status, .rolledBack)
        XCTAssertEqual(journal.installedDescriptors.count, 1)
        XCTAssertEqual(try plist(at: destination.appendingPathComponent("AppleOriginal/Wallpaper.plist"))["identifier"] as? Int, 42)
    }

    func testFailedRollbackRemainsRecoverableAndLaterRestorePreservesOriginal() throws {
        let container = try directory("PosterBoard")
        let destination = try descriptorDirectory(container: container, generation: "72")
        _ = try descriptor(at: destination.appendingPathComponent("AppleOriginal"))
        let package = try directory("Package")
        _ = try descriptor(at: package.appendingPathComponent("Descriptors/custom"))
        _ = try descriptor(at: package.appendingPathComponent("VideoDescriptors/custom"))
        let inspected = try TendiesPackageInspector.inspectExtractedPackage(at: package)
        let collection = try XCTUnwrap(inspected.descriptors.first { $0.extensionIdentifier == WallpaperPosterLayout.collectionsExtension })
        let video = try XCTUnwrap(inspected.descriptors.first { $0.extensionIdentifier == WallpaperPosterLayout.photosExtension })
        let payload = TendiesPayload(descriptors: [collection, video], totalBytes: inspected.totalBytes, fileCount: inspected.fileCount)
        let backups = temporary.appendingPathComponent("Receipts")
        let deniedCleanup = RollbackDenyingFileManager(descriptorDirectory: destination)

        XCTAssertThrowsError(try WallpaperInstaller.install(payload: payload, layout: scan(container), backupRoot: backups, fileManager: deniedCleanup)) {
            XCTAssertEqual($0 as? WallpaperLabError, .unsupportedPosterLayout)
        }

        let journal = try XCTUnwrap(WallpaperInstaller.receipts(in: backups).first)
        XCTAssertEqual(journal.status, .preparing)
        let leftover = try XCTUnwrap(journal.installedDescriptors.first)
        XCTAssertTrue(manager.fileExists(atPath: destination.appendingPathComponent(leftover.directoryName).path))

        // On a subsequent attempt, real filesystem access can finish the cleanup
        // from the journal rather than losing track of the partial installation.
        try WallpaperInstaller.restore(receipt: journal, containerURL: container, rootValidator: { $0 == container }, fileManager: manager)

        XCTAssertEqual(try manager.contentsOfDirectory(atPath: destination.path), ["AppleOriginal"])
        XCTAssertEqual(try plist(at: destination.appendingPathComponent("AppleOriginal/Wallpaper.plist"))["identifier"] as? Int, 42)
        XCTAssertEqual(WallpaperInstaller.receipts(in: backups).first?.status, .restored)
    }

    func testRestoreRemovesOnlyDescriptorsFromItsReceipt() throws {
        let container = try directory("PosterBoard")
        let destination = try descriptorDirectory(container: container, generation: "72")
        _ = try descriptor(at: destination.appendingPathComponent("AppleOriginal"))
        let package = try directory("Package")
        _ = try descriptor(at: package.appendingPathComponent("Descriptors/custom"))
        let payload = try TendiesPackageInspector.inspectExtractedPackage(at: package)
        let backups = temporary.appendingPathComponent("Receipts")
        let first = try WallpaperInstaller.install(payload: payload, layout: scan(container), backupRoot: backups)
        let second = try WallpaperInstaller.install(payload: payload, layout: scan(container), backupRoot: backups)

        try WallpaperInstaller.restore(receipt: first, containerURL: container, rootValidator: { $0 == container })

        let otherDescriptor = try XCTUnwrap(second.installedDescriptors.first)
        XCTAssertEqual(Set(try manager.contentsOfDirectory(atPath: destination.path)), Set(["AppleOriginal", otherDescriptor.directoryName]))
        XCTAssertEqual(WallpaperInstaller.receipts(in: backups).first { $0.id == first.id }?.status, .restored)
        XCTAssertEqual(WallpaperInstaller.receipts(in: backups).first { $0.id == second.id }?.status, .installed)
    }

    private func scan(_ container: URL) throws -> WallpaperPosterLayout {
        try WallpaperLayoutScanner.scan(containerURL: container, rootValidator: { $0 == container.standardizedFileURL })
    }

    private func store(in container: URL) -> URL {
        container.appendingPathComponent(WallpaperLayoutScanner.storeRelativePath, isDirectory: true)
    }

    private func descriptorDirectory(container: URL, generation: String) throws -> URL {
        try directory(store(in: container).appendingPathComponent("\(generation)/Extensions/\(WallpaperPosterLayout.collectionsExtension)/descriptors"))
    }

    @discardableResult
    private func directory(_ relative: String) throws -> URL {
        try directory(temporary.appendingPathComponent(relative, isDirectory: true))
    }

    @discardableResult
    private func directory(_ url: URL) throws -> URL {
        try manager.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    @discardableResult
    private func descriptor(at url: URL) throws -> URL {
        try directory(url)
        try PropertyListSerialization.data(fromPropertyList: ["identifier": 42, "title": "Fixture"], format: .binary, options: 0)
            .write(to: url.appendingPathComponent("Wallpaper.plist"))
        try PropertyListSerialization.data(fromPropertyList: ["wallpaperRepresentingIdentifier": 42], format: .binary, options: 0)
            .write(to: url.appendingPathComponent("com.apple.posterkit.provider.contents.userInfo"))
        try Data("42".utf8).write(to: url.appendingPathComponent("com.apple.posterkit.provider.descriptor.identifier"))
        return url
    }

    private func plist(at url: URL) throws -> [String: Any] {
        try XCTUnwrap(PropertyListSerialization.propertyList(from: Data(contentsOf: url), options: [], format: nil) as? [String: Any])
    }
}

private final class RollbackDenyingFileManager: FileManager, @unchecked Sendable {
    private let descriptorDirectoryPath: String

    init(descriptorDirectory: URL) {
        descriptorDirectoryPath = descriptorDirectory.standardizedFileURL.path
        super.init()
    }

    override func removeItem(at url: URL) throws {
        if url.deletingLastPathComponent().standardizedFileURL.path == descriptorDirectoryPath,
           UUID(uuidString: url.lastPathComponent) != nil {
            throw CocoaError(.fileWriteNoPermission)
        }
        try super.removeItem(at: url)
    }
}
