import Foundation
import XCTest
@testable import Dynor

final class TendiesInstallerCompatibilityTests: XCTestCase {
    private func supported(_ major: Int, _ minor: Int, _ patch: Int, build: String = "Unknown") -> Bool {
        TendiesCompatibility.assess(version: .init(majorVersion: major, minorVersion: minor, patchVersion: patch), build: build).canAttemptInstall
    }

    func testSupportedRangeBoundaries() {
        for (major, minor, patch) in [(18, 0, 0), (18, 6, 9), (18, 7, 1), (26, 0, 0), (26, 5, 9), (26, 6, 1)] {
            XCTAssertTrue(supported(major, minor, patch))
        }
        for (major, minor, patch) in [(17, 7, 1), (18, 7, 2), (18, 8, 0), (19, 0, 0), (26, 6, 2), (26, 7, 0), (27, 1, 0), (28, 0, 0)] {
            XCTAssertFalse(supported(major, minor, patch))
        }
    }

    func testIOS27RequiresExactVerifiedBuildAndVersion() {
        for build in ["24A5355q", "24A5370h", "24A5380h", "24A5390f"] {
            XCTAssertTrue(supported(27, 0, 0, build: build))
            XCTAssertFalse(supported(27, 0, 1, build: build))
            XCTAssertFalse(supported(27, 1, 0, build: build))
        }
        for build in ["Unknown", "", "24A5390F", "24A9999z", "24A5390f "] {
            XCTAssertFalse(supported(27, 0, 0, build: build))
        }
    }

    func testNegativeVersionComponentsAreRejected() {
        XCTAssertFalse(supported(18, -1, 0))
        XCTAssertFalse(supported(26, 0, -1))
    }

    func testContainerValidationRequiresExactUUIDRoot() {
        let root = "/var/mobile/Containers/Data/Application/" + UUID().uuidString
        XCTAssertTrue(PosterBoardAccess.validContainer(URL(fileURLWithPath: root)))
        XCTAssertTrue(PosterBoardAccess.validContainer(URL(fileURLWithPath: "/private" + root)))
        for path in ["/", root + "/Library", "/var/mobile/Containers/Data/Application/no-uuid", "/tmp/" + UUID().uuidString] {
            XCTAssertFalse(PosterBoardAccess.validContainer(URL(fileURLWithPath: path)))
        }
    }
}
