import Foundation
import XCTest
@testable import Dynor

final class TendiesInstallerCompatibilityTests: XCTestCase {
    func testDocumentedSupportedVersionsPassCompatibilityGate() {
        for (major, minor) in [(18, 0), (26, 0), (27, 0), (27, 1)] {
            let version = OperatingSystemVersion(majorVersion: major, minorVersion: minor, patchVersion: 0)
            XCTAssertNil(TendiesInstaller.supportWarning(for: version), "iOS \(major).\(minor)")
        }
    }

    func testSystemBelowFrameworkMinimumIsBlocked() {
        let version = OperatingSystemVersion(majorVersion: 17, minorVersion: 7, patchVersion: 0)
        XCTAssertNotNil(TendiesInstaller.supportWarning(for: version))
    }

    func testPatchedAndUnknownFutureVersionsAreBlocked() {
        for (major, minor) in [(27, 2), (27, 3), (28, 0)] {
            let version = OperatingSystemVersion(majorVersion: major, minorVersion: minor, patchVersion: 0)
            XCTAssertNotNil(TendiesInstaller.supportWarning(for: version), "iOS \(major).\(minor)")
        }
    }
}
