import Foundation
import XCTest
@testable import Dynor

final class TendiesInstallerCompatibilityTests: XCTestCase {
    func testDocumentedSupportedVersionsPassCompatibilityGate() {
        for (major, minor) in [(18, 0), (18, 7), (26, 0), (26, 1), (26, 6), (27, 0), (27, 1)] {
            let version = OperatingSystemVersion(majorVersion: major, minorVersion: minor, patchVersion: 0)
            XCTAssertNil(TendiesInstaller.supportWarning(for: version), "iOS \(major).\(minor)")
        }
    }

    func testSystemBelowFrameworkMinimumIsBlocked() {
        let version = OperatingSystemVersion(majorVersion: 17, minorVersion: 7, patchVersion: 0)
        XCTAssertNotNil(TendiesInstaller.supportWarning(for: version))
    }

    func testPatchedAndUnknownFutureVersionsAreBlocked() {
        for (major, minor) in [(27, 2), (27, 3), (28, 0)] {
            let version = OperatingSystemVersion(majorVersion: major, minorVersion: minor, patchVersion: 0)
            XCTAssertNotNil(TendiesInstaller.supportWarning(for: version), "iOS \(major).\(minor)")
        }
    }

    func testLastWorkingBetasRequireExplicitReleaseReport() {
        let version = OperatingSystemVersion(majorVersion: 27, minorVersion: 2, patchVersion: 0)
        XCTAssertNotNil(TendiesInstaller.supportWarning(for: version))
        for release in [TendiesCompatibility.Release.beta1, .beta2] {
            XCTAssertNil(TendiesInstaller.supportWarning(for: version, release: release))
            let assessment = TendiesCompatibility.assess(version: version, release: release)
            XCTAssertTrue(assessment.canAttemptInstall)
            XCTAssertTrue(assessment.requiresBetaConfirmation)
            XCTAssertTrue(assessment.canPairOnDevice)
        }
        for release in [TendiesCompatibility.Release.unknown, .beta3OrLater, .stable] {
            XCTAssertNotNil(TendiesInstaller.supportWarning(for: version, release: release))
        }
    }

    func testBetaReportCannotEnablePatchedPointReleaseOrFutureIOS() {
        for (major, minor, patch) in [(27, 2, 1), (27, 3, 0), (28, 0, 0)] {
            let version = OperatingSystemVersion(majorVersion: major, minorVersion: minor, patchVersion: patch)
            for release in TendiesCompatibility.Release.allCases {
                XCTAssertFalse(TendiesCompatibility.assess(version: version, release: release).canAttemptInstall)
            }
        }
    }

    func testPairingEligibilityIsSeparateFromInstallEligibility() {
        let ios26 = OperatingSystemVersion(majorVersion: 26, minorVersion: 0, patchVersion: 0)
        let ios27 = OperatingSystemVersion(majorVersion: 27, minorVersion: 0, patchVersion: 0)
        let patched = OperatingSystemVersion(majorVersion: 27, minorVersion: 2, patchVersion: 0)
        XCTAssertFalse(TendiesCompatibility.assess(version: ios26).canPairOnDevice)
        XCTAssertTrue(TendiesCompatibility.assess(version: ios27).canPairOnDevice)
        XCTAssertTrue(TendiesCompatibility.assess(version: patched, release: .beta3OrLater).canPairOnDevice)
        XCTAssertFalse(TendiesCompatibility.assess(version: patched, release: .beta3OrLater).canAttemptInstall)
    }
}
