import Foundation
import XCTest
@testable import Dynor

final class TendiesArchiveValidatorTests: XCTestCase {
    private var temporary: URL!

    override func setUpWithError() throws {
        temporary = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: temporary, withIntermediateDirectories: true)
    }

    override func tearDownWithError() throws {
        try FileManager.default.removeItem(at: temporary)
    }

    func testStoredArchiveAndExtractedChecksum() throws {
        let archive = try writeArchive([Fixture(name: "descriptor/Wallpaper.plist")])
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: archive)
        XCTAssertEqual(entries.count, 1)
        let extracted = temporary.appendingPathComponent("extracted", isDirectory: true)
        try FileManager.default.createDirectory(at: extracted.appendingPathComponent("descriptor"), withIntermediateDirectories: true)
        let file = extracted.appendingPathComponent("descriptor/Wallpaper.plist")
        try Data("abc".utf8).write(to: file)
        XCTAssertNoThrow(try TendiesArchiveValidator.validateExtraction(at: extracted, entries: entries))
        try Data("abd".utf8).write(to: file)
        XCTAssertThrowsError(try TendiesArchiveValidator.validateExtraction(at: extracted, entries: entries))
    }

    func testTraversalAbsoluteAndWindowsPathsAreRejected() throws {
        for name in ["../Wallpaper.plist", "/Wallpaper.plist", "a/../../Wallpaper.plist", "a\\Wallpaper.plist", "C:/Wallpaper.plist", "a/./b", "a//b"] {
            let archive = try writeArchive([Fixture(name: name)])
            XCTAssertThrowsError(try TendiesArchiveValidator.validateBeforeExtraction(at: archive), name)
        }
    }

    func testSymlinkAndCaseInsensitiveCollisionsAreRejected() throws {
        let symlink = try writeArchive([Fixture(name: "link", attributes: 0xa1ff0000)])
        XCTAssertThrowsError(try TendiesArchiveValidator.validateBeforeExtraction(at: symlink))
        let duplicate = try writeArchive([Fixture(name: "a.plist"), Fixture(name: "A.plist")])
        XCTAssertThrowsError(try TendiesArchiveValidator.validateBeforeExtraction(at: duplicate))
        let collision = try writeArchive([Fixture(name: "folder"), Fixture(name: "folder/a.plist")])
        XCTAssertThrowsError(try TendiesArchiveValidator.validateBeforeExtraction(at: collision))
    }

    func testLocalHeaderNameMismatchAndTruncatedDataAreRejected() throws {
        let mismatch = try writeArchive([Fixture(name: "a.plist", localName: "b.plist")])
        XCTAssertThrowsError(try TendiesArchiveValidator.validateBeforeExtraction(at: mismatch))
        let archive = try writeArchive([Fixture(name: "a.plist")])
        var data = try Data(contentsOf: archive)
        data.removeLast(10)
        try data.write(to: archive)
        XCTAssertThrowsError(try TendiesArchiveValidator.validateBeforeExtraction(at: archive))
    }

    func testExpandedSizeLimitAndEncryptionAreRejected() throws {
        let oversized = try writeArchive([Fixture(name: "a", method: 8, expandedSize: 129 * 1024 * 1024)])
        XCTAssertThrowsError(try TendiesArchiveValidator.validateBeforeExtraction(at: oversized))
        let encrypted = try writeArchive([Fixture(name: "a", flags: 1)])
        XCTAssertThrowsError(try TendiesArchiveValidator.validateBeforeExtraction(at: encrypted))
    }

    func testMissingAndUnlistedExtractedFilesAreRejected() throws {
        let archive = try writeArchive([Fixture(name: "a.plist")])
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: archive)
        let extracted = temporary.appendingPathComponent("extracted")
        try FileManager.default.createDirectory(at: extracted, withIntermediateDirectories: true)
        XCTAssertThrowsError(try TendiesArchiveValidator.validateExtraction(at: extracted, entries: entries))
        try Data("abc".utf8).write(to: extracted.appendingPathComponent("a.plist"))
        try Data().write(to: extracted.appendingPathComponent("extra"))
        XCTAssertThrowsError(try TendiesArchiveValidator.validateExtraction(at: extracted, entries: entries))
    }

    func testBoundedDeflateExtractionAndDishonestSize() throws {
        // Raw DEFLATE stream for "abc".
        let compressed = Data([0x4b, 0x4c, 0x4a, 0x06, 0x00])
        let valid = try writeArchive([Fixture(name: "a.plist", method: 8, payload: compressed)])
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: valid)
        let destination = temporary.appendingPathComponent("valid")
        try TendiesArchiveValidator.extract(at: valid, to: destination, entries: entries)
        XCTAssertEqual(try Data(contentsOf: destination.appendingPathComponent("a.plist")), Data("abc".utf8))
        let dishonest = try writeArchive([Fixture(name: "a.plist", method: 8, expandedSize: 2, payload: compressed)])
        let dishonestEntries = try TendiesArchiveValidator.validateBeforeExtraction(at: dishonest)
        let rejected = temporary.appendingPathComponent("rejected")
        XCTAssertThrowsError(try TendiesArchiveValidator.extract(at: dishonest, to: rejected, entries: dishonestEntries))
        XCTAssertFalse(FileManager.default.fileExists(atPath: rejected.appendingPathComponent("a.plist").path))
    }

    private struct Fixture {
        let name: String
        var attributes: UInt32 = 0
        var localName: String? = nil
        var method: UInt16 = 0
        var flags: UInt16 = 0
        var expandedSize: UInt32 = 3
        var payload: Data? = nil
    }

    private func writeArchive(_ fixtures: [Fixture]) throws -> URL {
        var data = Data()
        var central = Data()
        for fixture in fixtures {
            let offset = UInt32(data.count)
            let name = Data(fixture.name.utf8)
            let localName = Data((fixture.localName ?? fixture.name).utf8)
            let payload = fixture.payload ?? Data("abc".utf8)
            append(UInt32(0x04034b50), to: &data)
            append(UInt16(20), to: &data)
            append(fixture.flags, to: &data)
            append(fixture.method, to: &data)
            append(UInt32(0), to: &data) // DOS time/date
            append(UInt32(0x352441c2), to: &data) // CRC32("abc")
            append(UInt32(payload.count), to: &data)
            append(fixture.expandedSize, to: &data)
            append(UInt16(localName.count), to: &data)
            append(UInt16(0), to: &data)
            data.append(localName)
            data.append(payload)

            append(UInt32(0x02014b50), to: &central)
            append(UInt16(0x0314), to: &central)
            append(UInt16(20), to: &central)
            append(fixture.flags, to: &central)
            append(fixture.method, to: &central)
            append(UInt32(0), to: &central)
            append(UInt32(0x352441c2), to: &central)
            append(UInt32(payload.count), to: &central)
            append(fixture.expandedSize, to: &central)
            append(UInt16(name.count), to: &central)
            append(UInt16(0), to: &central) // Extra length
            append(UInt16(0), to: &central) // Comment length
            append(UInt16(0), to: &central) // Disk
            append(UInt16(0), to: &central) // Internal attributes
            append(fixture.attributes, to: &central)
            append(offset, to: &central)
            central.append(name)
        }
        let centralOffset = UInt32(data.count)
        data.append(central)
        append(UInt32(0x06054b50), to: &data)
        append(UInt16(0), to: &data)
        append(UInt16(0), to: &data)
        append(UInt16(fixtures.count), to: &data)
        append(UInt16(fixtures.count), to: &data)
        append(UInt32(central.count), to: &data)
        append(centralOffset, to: &data)
        append(UInt16(0), to: &data)
        let url = temporary.appendingPathComponent(UUID().uuidString + ".tendies")
        try data.write(to: url)
        return url
    }

    private func append<T: FixedWidthInteger>(_ value: T, to data: inout Data) {
        var little = value.littleEndian
        withUnsafeBytes(of: &little) { data.append(contentsOf: $0) }
    }
}
