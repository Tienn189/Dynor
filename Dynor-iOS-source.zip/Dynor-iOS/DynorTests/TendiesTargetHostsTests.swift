import XCTest
@testable import Dynor

final class TendiesTargetHostsTests: XCTestCase {
    func testWiFiPrecedesOtherInterfacesWithGatewayFallback() {
        let interfaces: [TendiesTargetHosts.Interface] = [
            .init(name: "pdp_ip0", ipv4: "10.20.30.40"),
            .init(name: "en0", ipv4: "192.168.1.25"),
            .init(name: "en1", ipv4: "192.168.1.25")
        ]
        XCTAssertEqual(TendiesTargetHosts.candidates(from: interfaces),
                       ["192.168.1.25", "10.20.30.40", "10.7.0.1"])
    }

    func testLoopbackAndTunnelInterfacesCannotBecomeNativeTargets() {
        let interfaces: [TendiesTargetHosts.Interface] = [
            .init(name: "lo0", ipv4: "127.0.0.1"),
            .init(name: "en0", ipv4: "127.10.1.1"),
            .init(name: "en1", ipv4: "192.168.1.2", isLoopback: true),
            .init(name: "utun4", ipv4: "10.8.0.2"),
            .init(name: "ipsec0", ipv4: "10.9.0.2"),
            .init(name: "ppp0", ipv4: "10.10.0.2"),
            .init(name: "tap0", ipv4: "10.11.0.2")
        ]
        XCTAssertEqual(TendiesTargetHosts.candidates(from: interfaces), ["10.7.0.1"])
    }

    func testUnavailableOrInvalidInterfacesLeaveGatewayFallback() {
        let interfaces: [TendiesTargetHosts.Interface] = [
            .init(name: "en0", ipv4: "192.168.1.2", isUp: false),
            .init(name: "en1", ipv4: "0.0.0.0"),
            .init(name: "en2", ipv4: "224.0.0.1"),
            .init(name: "en3", ipv4: "255.255.255.255"),
            .init(name: "en4", ipv4: "300.1.1.1"),
            .init(name: "en5", ipv4: "::1")
        ]
        XCTAssertEqual(TendiesTargetHosts.candidates(from: interfaces), ["10.7.0.1"])
        XCTAssertEqual(TendiesTargetHosts.candidates(from: []), ["10.7.0.1"])
    }

    func testGatewayIsNeverDuplicated() {
        XCTAssertEqual(TendiesTargetHosts.candidates(from: [
            .init(name: "en0", ipv4: "10.7.0.1"),
            .init(name: "en1", ipv4: "10.7.0.1")
        ]), ["10.7.0.1"])
    }
}
