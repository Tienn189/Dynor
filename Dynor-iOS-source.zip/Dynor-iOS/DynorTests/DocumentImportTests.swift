import XCTest
@testable import Dynor

final class DocumentImportTests: XCTestCase {
    private var directory: URL!

    override func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }

    override func tearDownWithError() throws {
        try FileManager.default.removeItem(at: directory)
    }

    func testTendiesCopyPreservesArchiveAndOriginalFilename() throws {
        let source = directory.appendingPathComponent("Batman.TENDIES")
        let bytes = Data([0x50, 0x4b, 0x03, 0x04, 0x01, 0xff, 0x00])
        try bytes.write(to: source)
        let document = try DocumentImportService.stage(source, maximumBytes: 100)
        defer { document.remove() }
        XCTAssertEqual(document.displayName, "Batman.TENDIES")
        XCTAssertEqual(document.pathExtension, "tendies")
        XCTAssertEqual(document.byteCount, Int64(bytes.count))
        XCTAssertEqual(try Data(contentsOf: document.url), bytes)
        XCTAssertEqual(try Data(contentsOf: source), bytes)
        XCTAssertNotEqual(document.url, source)
    }

    func testRejectsDirectoryAndEmptyFile() throws {
        XCTAssertThrowsError(try DocumentImportService.stage(directory, maximumBytes: 100))
        let empty = directory.appendingPathComponent("empty.tendies")
        try Data().write(to: empty)
        XCTAssertThrowsError(try DocumentImportService.stage(empty, maximumBytes: 100))
    }

    func testRejectsOversizeFileAndAcceptsExactLimit() throws {
        let source = directory.appendingPathComponent("full.tendies")
        try Data(repeating: 1, count: 129).write(to: source)
        XCTAssertThrowsError(try DocumentImportService.stage(source, maximumBytes: 128))
        let document = try DocumentImportService.stage(source, maximumBytes: 129)
        defer { document.remove() }
        XCTAssertEqual(document.byteCount, 129)
    }

    func testAcceptsBothLegacyXMLAndRemoteBinaryPairingRecords() throws {
        let records: [([String: Any], PropertyListSerialization.PropertyListFormat)] = [
            (["HostID": "host", "SystemBUID": "system", "HostCertificate": Data([1, 2, 3])], .xml),
            (["identifier": "remote", "public_key": Data(repeating: 1, count: 32), "private_key": Data(repeating: 2, count: 32)], .binary)
        ]
        for (record, format) in records {
            let source = directory.appendingPathComponent("pairingFile.plist")
            try PropertyListSerialization.data(fromPropertyList: record, format: format, options: 0).write(to: source)
            XCTAssertNoThrow(try DocumentImportService.validatePairing(at: source))
        }
    }

    func testRejectsMalformedOrNonDictionaryPairingFiles() throws {
        let source = directory.appendingPathComponent("pairingFile.plist")
        let values: [Any] = [[:], ["not", "a", "record"], "not a record"]
        for value in values {
            try PropertyListSerialization.data(fromPropertyList: value, format: .binary, options: 0).write(to: source)
            XCTAssertThrowsError(try DocumentImportService.validatePairing(at: source))
        }
        try Data("corrupted plist".utf8).write(to: source)
        XCTAssertThrowsError(try DocumentImportService.validatePairing(at: source))
    }
}
