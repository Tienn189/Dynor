# Dynor in-app payment setup

The SwiftUI screen creates payment orders using the authenticated Supabase Edge Function `dynor-create-order`, displays bank transfer details and VietQR, and lets users refresh their VIP status. It never accepts a client-side claim of payment.

1. Deploy `Supabase/dynor-create-order/index.ts` as an Edge Function named `dynor-create-order`. Ensure the function is protected by valid Supabase user JWTs. It also explicitly verifies the user token.
2. Configure server secrets `SEPAY_RECEIVER_ACCOUNT` (full MB receiving account) and optionally `VIETQR_BANK_CODE=MB`. Keep service-role keys and bank account secrets out of iOS code. Confirm the receiver account is correct before accepting payments.
3. The existing SePay webhook must securely match the payment code, transfer direction, bank account, and exact amount, then call the atomic settlement RPC. The `dynor_settle_payment` RPC must use `duration_days` (7 for week, 30 for month) and must prevent duplicate transaction credit. **Do not enable month payments until this has been verified.**
4. The server returns a VietQR URL; verify QR bank name, recipient, amount, and content with a bank app before accepting real transfers.
5. The screen refreshes VIP on demand. To update automatically, implement polling or realtime subscription to `dynor_vip` for the signed-in user.
6. The `lifetime` plan is deliberately disabled; it needs an explicit backend entitlement model.
7. If distributing on the App Store, digital VIP features generally require Apple In-App Purchase rather than external bank transfer. Check applicable Apple rules.

No live payments or iOS build tests have been performed as part of this change.
