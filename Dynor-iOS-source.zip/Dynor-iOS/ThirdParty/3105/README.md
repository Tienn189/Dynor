# 3105 integration

Pinned upstream: [YangJiiii/3105](https://github.com/YangJiiii/3105/tree/a72617ed4c764a65d8aac1e91aca95231e72a2cb), revision `a72617ed4c764a65d8aac1e91aca95231e72a2cb`.

`upstream/` preserves the original files used for the wallpaper integration. `provenance.json` lists their SHA-256 hashes. Original 3105 portions are GPL-3.0; retain `LICENSE` and `THIRD_PARTY_NOTICES.md`, including the notices for upstream components whose terms differ.

Dynor adaptations:

- `Dynor/Native/exploit/`: MCM retained lease and container activation bridge plus filesystem enumeration fallback from 3105.
- `Dynor/Native/kexploit/`: kernel and sandbox support sources, with simulator/architecture compilation guards added to the Objective-C implementation files. No kernel operation runs in Simulator.
- `PosterBoardAccess.swift`: wallpaper-scoped access wrapper. Preparation is user initiated and serialized. iOS 18 uses the upstream kernel/sandbox preparation and metadata fallback; iOS 26/27 uses MHA-C2 directly. The native offset table rejects iOS 26.1 and newer, so Dynor never invokes this kernel chain on those versions.
- `TendiesCompatibility.swift`: keeps Dynor's minimum iOS 18; applies upstream's 18.7.1/26.6.1 boundaries and exact iOS 27 beta build allowlist.
- `Services/PosterBoard/`: wallpaper layout/package inspection and transactional descriptor installation adapted from upstream. Dynor retains its own stricter archive size limits and protected workspace. Unused global custom-wallpaper reset code is omitted. A failed rollback keeps its receipt recoverable instead of claiming cleanup succeeded; interrupted preparing receipts are restored before the next install.

Build with bundle identifier `com.apple.mobile.MobileHouseArrest` and the native bridging header. Upstream requires enterprise signing for its MHA-C2 installation path. A different bundle identifier is rejected at runtime; changing it also changes the app container, so the former Dynor installation's local data is not migrated automatically.

The wrapper never treats successful kernel setup or a readable MCM container as proof that a wallpaper write is permitted: the installer must probe the actual destination descriptor directories before applying a package. Actual device access has not been verified in this Linux workspace.
