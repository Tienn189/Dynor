# Retained AirCard source attribution

Source: https://github.com/Mak5er/AirCard-iOS/tree/40640c4d827aeab8d798285b57d24fcf6be070d0
License: MIT (see LICENSE).

Dynor retains adapted native copy-based document picker behavior, Tendies UTI compatibility and descriptor helpers/tests from AirCard. Dynor changes include coordinated imports, archive preflight/CRC checks, protected staging, provider name/extension preservation and discovery scoped to the archive.

Version 1.3.0 removes the AirliftFFI framework, pairing host, pairing-record import, local-network discovery and Rust dependency downloader. No Airlift binary or Cargo dependencies are used by this version. The replacement direct PosterBoard engine comes from 3105; see ../3105/ for its separate GPL-3.0 license and provenance.
