# AirCard integration

Source: https://github.com/Mak5er/AirCard-iOS/tree/40640c4d827aeab8d798285b57d24fcf6be070d0
License: MIT (see LICENSE).

Dynor adapts the pairing host, local-network authorization, background audio,
PosterBoard descriptor discovery/randomization and installation flow. The bundled
AirliftFFI.xcframework is the upstream prebuilt static Rust framework, arm64 for
iOS and Simulator. Its git blob hashes were verified against the source tree;
SHA-256 checksums are recorded in provenance.json. Cargo.lock records upstream
Rust dependencies. To rebuild the framework, check out that revision and follow
upstream build-ios.sh and its third-party license requirements.

Changes in Dynor include coordinated document imports, protected pairing storage,
serialized operations, archive preflight and CRC checks, native errors/progress,
descriptor discovery scoped to the archive, bidirectional legacy/modern extension
aliases, and active non-loopback interface discovery with a LocalDevVPN gateway
fallback. Files and online downloads open Dynor's installation preview directly.
Dynor also adapts AirCard's native copy-based document picker, accepts its Tendies
UTI alongside Dynor's type, and enumerates all registered types for the extension.

Upstream advertises iOS 18.0 through 27.2 beta 2 and reports the method patched
from 27.2 beta 3. Dynor allows attempts on 18.0–27.1; 27.2.0 additionally requires
the user to identify beta 1 or beta 2 in the release picker. No upstream build ID
allowlist is available, so this is a user report, not automatic build validation.
Beta 3+, RC, stable 27.2, 27.2.1+, and future versions remain blocked. Imported
pairing is used on iOS 18–26; on-device Settings pairing is also available on 27.
Individual developer/public betas and physical-device installs have not been
verified in this Linux workspace. See ../../VERIFICATION.md.

Dynor does not automatically respring the device.
No upstream branding or unrelated Wallet/passcode features are included.
