# AirCard integration

Source: https://github.com/Mak5er/AirCard-iOS/tree/40640c4d827aeab8d798285b57d24fcf6be070d0
License: MIT (see LICENSE).

Dynor adapts the pairing host, local-network authorization, background audio,
PosterBoard descriptor discovery/randomization and installation flow. The bundled
AirliftFFI.xcframework is the upstream prebuilt static Rust framework, arm64 for
iOS and Simulator. Its git blob hashes were verified against the source tree;
SHA-256 checksums are recorded in provenance.json. Cargo.lock records upstream
Rust dependencies. To rebuild the framework, check out that revision and follow
upstream build-ios.sh and its third-party license requirements.

Changes in Dynor include coordinated document imports, protected pairing storage,
serialized operations, archive preflight and CRC checks, native errors/progress,
and conservative version gating. Dynor does not automatically respring the device.
No upstream branding or unrelated Wallet/passcode features are included.
