# Dynor V5 source patch

## Modified directly
- `Dynor/Views/DynorDesign.swift`: rebuilt shared header with compact icon, accent strip, grouped surface, better typography; no large solid-color hero.
- `Dynor/Views/OnlineGalleryView.swift`: new header copy, language-aware search/sections and contrast-aware accent controls.
- `Dynor/Models/DynorStore.swift`: computed black/white foreground based on selected accent brightness, including custom colors.
- `Dynor/Views/SettingsView.swift`: accent-aware VIP, account and other primary buttons, more honest language note.
- `Dynor/DynorApp.swift`: apply chosen locale to SwiftUI environment; translate root alert acknowledgement.
- `Dynor/Resources/en.lproj/Localizable.strings`, `zh-Hans.lproj/Localizable.strings`: added English and Simplified Chinese translations for common UI text keys.
- `project.yml`: include language bundles as resources.

## Verification
- Swift source syntax parsing: PASS (`swiftc -frontend -parse` on modified Swift files).
- Bundled worse_query dependency hashes: PASS (`scripts/verify_dependencies.py`).
- Full iOS build / runtime test: NOT performed (requires macOS/Xcode).

## Still outstanding
- Full translation of all text including dynamic/technical errors, account/VIP flows, and server-sourced content; the added tables cover only common static keys.
- Verify actual wallpaper installation and PosterBoard refresh on a real iPhone; not changed in this UI-only patch.
- Verify custom theme color in every view and native iOS modal. System UI and third-party content may retain their own colors.
