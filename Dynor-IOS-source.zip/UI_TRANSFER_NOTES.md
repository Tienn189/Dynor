Source base: file 1 (Dynor-New-Editorial-UI-source(1).zip).
UI copied from file 2 (Dynor-IOS-source(20261118-100707).zip): DynorApp.swift and all Dynor/Views/*.swift.
All other files, services, models, project settings, and resources remain from file 1.
No Xcode build or device verification performed.
