Bragio temporary VIP badge fallback. Backend dynor_wallpapers.is_vip must be set true for the Bragio record; backend Edge Function still controls download. No Xcode build performed.
