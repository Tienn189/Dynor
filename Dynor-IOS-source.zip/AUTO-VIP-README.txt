Dynor automatic VIP recognition fix

- OnlineGalleryView.swift: removed the Bragio title-based VIP exception.
- All wallpapers use Supabase is_vip for the yellow crown before Download.
- Admin/index.html: accepts .dynor and .tendies file uploads.
- Admin already uploads the file to dynor-downloads and inserts file_path, file_name and is_vip in one record. Keep the VIP checkbox selected when publishing VIP wallpapers.
- Uploading directly to Storage does NOT create a matching dynor_wallpapers row or determine VIP status. Use Admin publishing workflow.
- Existing rows with NULL file_path need repair; no automatic filename guessing is safe.
- Existing Edge Function dynor-wallpaper-download must enforce VIP entitlements on the server and validate file_path before createSignedUrl.
- No Xcode or device build performed.
