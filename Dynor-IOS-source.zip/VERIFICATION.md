# Kiểm chứng Dynor 1.3.0 / build 6

Bản source được chỉnh sửa trên Linux. **Chưa chạy xcodebuild, chưa chạy XCTest,
chưa tạo IPA bằng Xcode và chưa xác nhận cài wallpaper trên iPhone iOS 26.6.**
Không có chứng chỉ/provisioning profile hoặc thiết bị iOS trong phiên làm việc.

## Đã chạy

| Kiểm tra | Kết quả |
| --- | --- |
| `python3 scripts/verify_dependencies.py` | Qua: 6 SHA-256 native source/license/readme khớp commit pin |
| `python3 -m unittest discover -s scripts -p 'test_*.py' -v` | Qua: 7 test kiểm tra entitlement/provisioning, sai Bundle ID, profile hết hạn, entitlement thiếu/giả |
| `node --test Supabase/tests/encrypted-packages.test.mjs Tools/DynorVault/tests/crypto.test.mjs` | Qua: cả 2 tệp test backend/Vault có sẵn |
| Parse Swift bằng tree-sitter-swift | Qua: 26 tệp, không lỗi cú pháp; đây không phải Swift compiler/type checking |
| Parse YAML project/GitHub Actions/Codemagic, Python AST, JSON, entitlement plist | Qua |
| `bash -n scripts/build_ipa.sh` | Qua |
| Kiểm tra Bundle ID và dependency trong project.yml | com.dynor.wallpapers; không còn AirliftFFI |

Tool parser cú pháp chỉ dùng khi chỉnh sửa, không phải dependency của app/build.
Native `worse_query` và `pathleak` giữ nguyên byte upstream; wrapper chỉ phục vụ
PosterBoard. Tự tìm container vẫn có thể thất bại nếu API hint hoặc pathleak của
upstream bị hệ thống chặn. Lỗi được báo, không trả receipt thành công.

## XCTest đã bổ sung/cập nhật, chưa thực thi

- 12 test giao dịch filesystem: rollback khi provider thứ hai thiếu, giữ descriptor
  cũ/preferences khác, alias provider thực sự tồn tại, version datastore dạng số,
  SHA-256 đúng digest mẫu, thay đổi cùng kích thước ở cuối tệp lớn, đường dẫn ẩn,
  lỗi không đọc được thư mục, symlink, gói rỗng và lỗi yêu cầu nạp lại.
- Kiểm tra container hint chỉ là UUID con trực tiếp trong root được phép, từ chối
  traversal/root lạ; Simulator không vào closure ghi thiết bị.
- Kiểm tra phạm vi phiên bản gồm iOS 26.6 và chặn ngoài phạm vi upstream.
- Giữ test ZIP/CRC/giới hạn giải nén, descriptor identifiers, nhập tệp, định dạng
  tài liệu và giải mã `.dynor` có sẵn.

`scripts/build_ipa.sh` và hai pipeline macOS chạy test trên Simulator trước
archive. Cần kiểm tra log/xcresult của lần chạy thực tế; cấu hình CI chưa được
thực thi từ phiên chỉnh sửa này.

## Xác minh trên iPhone mục tiêu

1. Ghi lại mẫu iPhone, iOS đầy đủ và số build tại Cài đặt → Cài đặt chung → Giới thiệu.
2. Build/ký theo BUILD_IPA.md. Giữ Bundle ID; App Group phải nằm trong cả chữ ký
   và provisioning profile. Chạy `verify_signed_app.py` với `.app` đã ký.
3. Cài và xác nhận phiên bản 1.3.0 (6). Không cài app hỗ trợ; không bật VPN/pairing.
4. Mở Cài đặt → Hình nền → Thêm hình nền mới; trở lại Dynor, tab PosterBoard
   kiểm tra chữ ký; nhập `.tendies` mẫu đã biết hoạt động trên cùng bản iOS.
5. Cài, lưu log: backend, xác minh danh tính container, provider thực tế, số
   descriptor và số tệp đã đọc lại. Không lấy thông báo ghi đúng làm kết quả cuối.
6. Mở bộ chọn của iOS, kiểm tra mẫu thật sự xuất hiện và chọn làm màn hình khóa.
   Nếu chưa có, khởi động lại iPhone rồi kiểm tra. Chỉ đánh dấu cài thành công khi
   mẫu hiển thị đúng; thử khóa/mở máy và kiểm tra animation nếu gói có animation.
7. Thử chữ ký thiếu App Group, gói hỏng/không descriptor/provider không có: phải
   báo lỗi, không báo đã cài. Thử lại sau lỗi, xác nhận hình nền cũ còn nguyên.
8. Lặp lại riêng trên các bản iOS khác cần hỗ trợ. Không suy rộng từ một thiết bị
   hoặc từ kết quả build sang toàn bộ phiên bản trong phạm vi upstream.

Nếu đã ghi đủ tệp nhưng iOS không nạp mẫu, cần log và gói mẫu để tiếp tục chẩn
đoán. Source này không có kênh đọc trạng thái wallpaper đang được chọn của iOS,
vì vậy thông báo chỉ xác nhận phần ghi/đọc lại mà app thực sự kiểm chứng được.

## Bổ sung GitHub Actions ký IPA

Đã thêm `scripts/sign_ipa.py`, 11 test preflight và tùy chọn `sign_ipa` khi chạy
workflow thủ công. Tổng 18 test Python ký/profile (11 mới + 7 có sẵn) đã qua.
YAML, phạm vi secrets chỉ cho chạy thủ công, Bash và Python nhúng đã kiểm tra
cú pháp. Secrets được cấp riêng cho bước kiểm tra/ký, không dùng trong push/PR.
Chưa chạy ký thật: cần macOS runner cùng cert/private key và profile của người dùng.
Script chỉ xuất signed artifact sau khi codesign/profile/App Group được xác minh;
nó không tạo quyền App Group thay Apple Developer và không xác nhận cài wallpaper.
