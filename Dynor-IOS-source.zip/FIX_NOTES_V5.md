# Dynor V5 — focused patch
- Installed wallpaper library: thumbnail previews when the descriptor contains a supported static image, preview sheet, multiselect deletion.
- Theme: VIP sheet now uses the active accent color instead of forcing primary tint.
- Identifier handling: for descriptor identifiers with a numeric prefix, preserve suffix and update matching values in suggestion metadata rather than skipping ID remapping altogether.
- The last change is an experimental mitigation for repeated wallpaper installs, not a verified fix on iOS. Other provider-specific identifiers or PosterBoard caches may still prevent a second wallpaper from appearing.
- iOS does not expose a public API for enumerating every wallpaper installed in the system; this library shows Dynor-managed entries only.
- Full English/Chinese localization and a complete redesign of login/payment screens are not included in this patch.
- Swift parser check passed; no macOS/Xcode iOS build was run.
