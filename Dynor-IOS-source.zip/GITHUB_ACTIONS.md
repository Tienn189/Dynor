# Tạo IPA bằng GitHub Actions

Giữ cách build bằng GitHub Actions cũ được, nhưng YAML trong ZIP gốc gọi
`prepare_airlift.py`/`test_prepare_airlift.py`: hai script này đã bỏ cùng Airlift.
Vì vậy cần thay YAML bằng bản cập nhật cùng tên workflow, không dùng nguyên YAML cũ.
Với cơ chế
PosterBoard trực tiếp, phần cần thêm là ký bằng chứng chỉ và provisioning profile
có App Group. Bản workflow đi kèm giữ tên **Build Dynor native IPA**, bổ sung
lựa chọn `sign_ipa` khi bấm Run workflow, không buộc chạy cơ chế cài cũ.

## Đưa source lên GitHub

Cách đơn giản: giải nén ZIP rồi đưa **nội dung bên trong Dynor-iOS/** lên gốc repo,
kể cả `.github/workflows/build-ipa.yml`, `project.yml`, `Dynor/`, `DynorTests/`,
`scripts/` và `ThirdParty/`. Không đặt nguyên thư mục Dynor-iOS lồng thêm một cấp.

Nếu repo hiện chỉ chứa ZIP: thay file gốc `Dynor-iOS-source.zip` bằng ZIP mới và
đặt riêng workflow mới tại `.github/workflows/build-ipa.yml` ngoài ZIP.
GitHub không tự đọc workflow nằm bên trong ZIP. Source đã giải nén ở gốc sẽ được
ưu tiên hơn ZIP: nếu repo có source cũ, phải cập nhật source đó hoặc xóa bản cũ.

## Chỉ build unsigned như workflow cũ

Vào **Actions → Build Dynor native IPA → Run workflow** và bỏ chọn `sign_ipa`.
Lấy `Dynor-unsigned.ipa` trong artifact **Dynor-native-unsigned-IPA**. Push/PR
vẫn chỉ chạy build unsigned và XCTest, không sử dụng signing secrets.

Bản unsigned chưa có chữ ký cấp quyền App Group. Nếu ký bên ngoài, cần cert/profile
cấp đúng quyền đó; chỉ bật hoặc chèn entitlement trong phần mềm ký chưa đủ.

## Xuất IPA được ký ngay trên Actions

Bạn cần có chứng chỉ Apple Development/Distribution kèm private key (`.p12`)
và profile Development/Ad Hoc (hoặc Enterprise hợp lệ) cùng team/certificate.
Profile phải cho phép:

- Bundle ID `com.dynor.wallpapers`.
- App Group `group.3fae94347e97b250.4` mặc định.
- Thiết bị iPhone đích có trong danh sách UDID nếu dùng Development/Ad Hoc.

Nhóm ký phải có quyền sử dụng chính Bundle ID này. Bật App Groups cho App ID,
gán group rồi tạo/tải lại profile. App Group khai báo trong source đã có sẵn tại
`Dynor/Dynor.entitlements` và `project.yml`; GitHub không tự tạo được quyền Apple
hay chứng chỉ/private key thay cho chủ tài khoản.

Trong repo mở **Settings → Secrets and variables → Actions → New repository secret**:

| Secret | Nội dung |
| --- | --- |
| `DYNOR_CERTIFICATE_P12_BASE64` | Base64 của file `.p12`, gồm cả private key |
| `DYNOR_CERTIFICATE_PASSWORD` | Mật khẩu `.p12`; để trống nếu file không có mật khẩu |
| `DYNOR_PROVISION_PROFILE_BASE64` | Base64 của file `.mobileprovision` có App Group |

Đừng đưa file `.p12`/private key hay mật khẩu vào source/repo. Dùng chức năng
GitHub Secrets để runner nhận chúng khi bước ký được yêu cầu.

Có thể chuyển file sang Base64 ngay trên máy. Trên Mac:

```bash
base64 -i certificate.p12 | pbcopy
base64 -i Dynor.mobileprovision | pbcopy
```

Chạy từng lệnh và dán nội dung clipboard vào secret tương ứng. Trên PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("C:\path\certificate.p12")) | Set-Clipboard
[Convert]::ToBase64String([IO.File]::ReadAllBytes("C:\path\Dynor.mobileprovision")) | Set-Clipboard
```

Sau đó **Run workflow → giữ chọn `sign_ipa`**. Thiếu secrets sẽ báo lỗi ngay,
không giả vờ tạo IPA được ký. Sau XCTest/archive, runner tạo keychain tạm, nhập
chứng chỉ, kiểm tra profile/group/certificate và danh sách thiết bị được profile cho phép,
nhúng profile và ký app.
Chỉ sau khi xác minh chữ ký/profile mới đóng gói **Dynor-signed.ipa** và upload
artifact **Dynor-native-signed-IPA**. Keychain và bản sao thông tin ký được dọn
khi script kết thúc. Bước này chưa được thực thi với chứng chỉ thật trong phiên
chỉnh sửa source.

Cài IPA signed bằng phương thức cài phù hợp cho thiết bị. Nếu iOS yêu cầu thì
bật Developer Mode cho build Development. Công cụ ký lại sau đó có thể thay đổi
entitlements: không ký lại bằng profile thiếu App Group.

Nếu App Group của bạn có tên khác, sửa `DYNOR_APP_GROUP_IDENTIFIER` trong
`project.yml` để khớp group có thật trong profile, cập nhật source rồi chạy lại.
Không đổi Bundle ID theo yêu cầu của Dynor.

## Nếu giữ nguyên YAML cũ

Có thể giữ YAML cũ nếu nó đã chạy đúng `scripts/build_ipa.sh` từ source mới.
Để thêm ký, sau bước build và trước upload signed artifact, dùng:

```yaml
- name: Sign IPA with App Group
  env:
    DYNOR_CERTIFICATE_P12_BASE64: ${{ secrets.DYNOR_CERTIFICATE_P12_BASE64 }}
    DYNOR_CERTIFICATE_PASSWORD: ${{ secrets.DYNOR_CERTIFICATE_PASSWORD }}
    DYNOR_PROVISION_PROFILE_BASE64: ${{ secrets.DYNOR_PROVISION_PROFILE_BASE64 }}
  run: python3 "$SOURCE_DIR/scripts/sign_ipa.py"

- uses: actions/upload-artifact@v4
  with:
    name: Dynor-native-signed-IPA
    path: ${{ env.SOURCE_DIR }}/build/ipa/Dynor-signed.ipa
    if-no-files-found: error
```

`SOURCE_DIR` phải là thư mục source đã được workflow xác định. Chỉ chạy bước ký
trên nhánh bạn tin cậy khi chủ động yêu cầu; bản workflow đi kèm chỉ dùng secrets
khi chạy thủ công với `sign_ipa=true`.

## Kết quả build và kết quả cài hình nền

Artifact IPA/chữ ký đúng chưa chứng minh PosterBoard đã nạp wallpaper trên iOS
26.6. Xem VERIFICATION.md để thử thật. Log và XCTest ở artifact
**Dynor-native-build-evidence**; source này được chuẩn bị trên Linux, chưa có
lần chạy Xcode/GitHub Actions hay ký bằng cert/profile thật trong phiên chỉnh sửa.

Tham khảo chính thức:
[GitHub: ký ứng dụng trên runner macOS](https://docs.github.com/en/actions/how-tos/deploy/deploy-to-third-party-platforms/sign-xcode-applications),
[Apple: bật capabilities](https://developer.apple.com/help/account/identifiers/enable-app-capabilities),
[Apple: tạo Ad Hoc provisioning profile](https://developer.apple.com/help/account/provisioning-profiles/create-an-ad-hoc-provisioning-profile/).
