# Third-party notices

The PosterBoard integration includes GPL-3.0-or-later worse_query code. When
redistributing the combined application, comply with GPLv3 and provide its
corresponding source and license, including these integration changes. The root
LICENSE is the GPLv3 text; it does not remove existing third-party notices.

- forcequitOS/worse_query: GPL-3.0-or-later, pinned revision and pristine native
  source hashes in ThirdParty/WorseQuery/provenance.json.
- nxtcoreee3/Worse-Poster and contributors: GPL-3.0, workflow reference and
  license in ThirdParty/WorsePoster.
- Mak5er/AirCard-iOS: MIT, retained descriptor discovery/identifier logic and
  archive-import influences, see ThirdParty/AirCard. Airlift is no longer used.
- Original Dynor source, branding and icon: supplied by the user.
- Sample photo sources: Dynor/Resources/Wallpapers/sources.json.

No signing identity, certificate, provisioning profile, account token or
private pairing record is supplied in this source package.
