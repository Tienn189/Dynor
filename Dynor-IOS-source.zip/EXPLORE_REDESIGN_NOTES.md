# Explore layout redesign

- New compact Dynor wordmark with language menu (VI/EN/中文) and favorites action.
- Large editorial Wallpapers title, small section eyebrow and descriptive copy.
- Landscape Featured carousel positioned before search; uses only existing published Supabase records.
- Glass search field, filter menu, icon-led horizontal categories, and Latest masonry grid.
- No wallpaper assets from the reference image have been added.
- Accent kept restrained in Explore; neutral glass controls and dark text.
- Existing detail, favorites, download and backend flows preserved.

Validation: Swift syntax parser passed for OnlineGalleryView.swift. Full iOS build and on-device UI tests unavailable in this environment.
