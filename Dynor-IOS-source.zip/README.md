# Dynor 1.3.0 (build 6) — PosterBoard trực tiếp

Giữ Bundle ID **com.dynor.wallpapers**, bố cục SwiftUI, Khám phá, Thư viện,
Cài đặt, tài khoản và gói mã hóa. Tab Pairing được thay bằng PosterBoard tại
cùng vị trí. Cơ chế Airlift, pairing, LocalDevVPN và binary Rust đã được bỏ.

Bản này dùng luồng descriptor của [Worse Poster](https://github.com/nxtcoreee3/Worse-Poster)
và source [worse_query](https://github.com/forcequitOS/worse_query) đi kèm. Không
cần ứng dụng hỗ trợ, pairing record hoặc VPN khi cài hình nền. **IPA phải được
ký với App Group thực sự được provisioning profile cho phép**; build unsigned
hoặc tự thêm entitlement không tạo ra quyền này.

## Build IPA

Trên Mac có full Xcode 16+, XcodeGen và iPhone Simulator iOS 18+:

```bash
brew install xcodegen
cd Dynor-iOS
bash scripts/build_ipa.sh
```

Đầu ra: `build/ipa/Dynor-unsigned.ipa`. Script chạy XCTest rồi archive; dừng
khi lỗi. Muốn chỉ archive: thêm `--skip-tests` (không được coi là đã test).
Xem [GITHUB_ACTIONS.md](GITHUB_ACTIONS.md) để build/ký ngay bằng Actions và
[BUILD_IPA.md](BUILD_IPA.md) để cấu hình App Group, ký IPA với đúng Team,
kiểm tra chữ ký và build bằng GitHub Actions/Codemagic. Toàn bộ native source
đã kèm trong ZIP, không có bước tải Airlift hoặc dependencies Rust.

## Cài .tendies trên iPhone

1. Ký với App ID `com.dynor.wallpapers` và App Group riêng mặc định
   `group.com.dynor.wallpapers`. Cài app, kiểm tra tab PosterBoard.
2. Mở **Cài đặt iOS → Hình nền → Thêm hình nền mới** một lần để khởi tạo kho.
3. Nhập `.tendies` qua **Thư viện → +**, **Mở bằng Dynor** từ Tệp, hoặc tải từ
   Khám phá. Mở mẫu rồi bấm **Cài hình nền**. Giữ Dynor phía trước và máy mở khóa.
4. Dynor kiểm tra ZIP/CRC/descriptor, xác minh container là `com.apple.PosterBoard`,
   chọn provider thực sự có trên máy và ghi descriptor vào thư mục UUID mới.
   Dynor đọc lại toàn bộ tập tệp, đối chiếu SHA-256 trước khi báo đã ghi.
5. Bấm **Mở bộ chọn hình nền**, hoặc tự mở trong Cài đặt, tìm mẫu và chọn làm
   màn hình khóa. Nếu mẫu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại.

**Đã ghi và đọc lại đúng dữ liệu không đồng nghĩa iOS đã nạp hoặc chọn mẫu.**
App báo đúng giới hạn này; không tự báo “cài thành công”, tự chọn hình nền hay
gây respring. Khi có lỗi giữa chừng, app thu hồi các descriptor mới của lượt
cài; nếu không thu hồi hết, thông báo nêu rõ dữ liệu có thể còn một phần.
Tùy chọn PosterBoard được hợp nhất, giữ các giá trị khác. Nếu cờ yêu cầu nạp
lại không ghi được, log hướng dẫn khởi động lại; không đánh đồng với lỗi ghi tệp.

## Phiên bản iOS

- Backend upstream công bố **26.0–26.7.2 / 27.2**; **26.6 nằm trong phạm vi này**.
  Dynor cho phép thử trên 26.0–26.7.2 và 27.0–27.2.0, vẫn kiểm tra quyền truy cập
  thực tế mỗi lượt. Không tự suy ra 27.2.1 hoặc 27.3 beta hoạt động từ README fork.
- App vẫn chạy từ iOS 18 để dùng thư viện/ảnh/tài khoản; cài trực tiếp bị chặn
  ngoài phạm vi backend. Không giữ cơ chế cài cũ làm fallback.
- Đây là phạm vi công bố upstream, **chưa phải xác nhận Dynor đã cài hình nền
  thành công trên iPhone iOS 26.6**. Môi trường chỉnh sửa là Linux, không có Xcode
  hoặc iPhone; xem [VERIFICATION.md](VERIFICATION.md) cho bằng chứng và phần chưa test.

Lần đầu tự tìm container có thể mất vài phút. Nếu không tìm thấy, mở bộ chọn
hình nền của iOS rồi thử lại. Container gợi ý/cached luôn được xác minh danh tính
trước khi ghi. Không tạo provider giả khi gói yêu cầu provider không có trên máy.

## Các chức năng giữ lại

Ảnh thường vẫn lưu vào Photos và chia sẻ theo giao diện hiện tại. `.tendies`
và `.dynor` vẫn không có chức năng xuất gói trong app. `.dynor` được giải mã
trong vùng lưu trữ riêng sau khi server cấp quyền, rồi đi qua cùng installer.
Xem [ENCRYPTED_TENDIES_SETUP.md](ENCRYPTED_TENDIES_SETUP.md),
[WALLPAPER_ONLINE_SETUP.md](WALLPAPER_ONLINE_SETUP.md) và [PAYMENT_SETUP.md](PAYMENT_SETUP.md).

## Nguồn

Worse Poster `05db4788ca4df0b0dc33ba132b318f853728ee80`; worse_query
`d1540e20cd82b974d891e0551ced6d6aeb570ac2`. Ở revision tham khảo, README fork
nhắc worse_query nhưng mã backend vẫn là bad_query cũ; vì vậy Dynor dùng source
kế nhiệm đúng từ forcequitOS. Native được giữ nguyên và xác minh hash trước
khi sinh project. Xem [NOTICE.md](NOTICE.md), `ThirdParty/` và `LICENSE`.
