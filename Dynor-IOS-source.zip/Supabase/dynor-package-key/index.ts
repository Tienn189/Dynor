import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { createPackageHandler } from '../_shared/package-handlers.mjs';

Deno.serve(createPackageHandler('key', { createClient, env: (name: string) => Deno.env.get(name) }));
