-- Run once in Supabase SQL Editor. Does not modify existing VIP/payment tables.
create table if not exists public.dynor_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
create table if not exists public.dynor_wallpapers (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  category text not null default 'Khác',
  cover_path text not null,
  video_path text,
  file_path text not null,
  file_name text not null,
  is_vip boolean not null default false,
  published boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.dynor_favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  wallpaper_id uuid not null references public.dynor_wallpapers(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, wallpaper_id)
);
create index if not exists dynor_wallpapers_feed_idx on public.dynor_wallpapers (published, created_at desc);

alter table public.dynor_admins enable row level security;
alter table public.dynor_wallpapers enable row level security;
alter table public.dynor_favorites enable row level security;

create or replace function public.dynor_is_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.dynor_admins where user_id = (select auth.uid()));
$$;
revoke all on function public.dynor_is_admin() from public;
grant execute on function public.dynor_is_admin() to authenticated;

create policy "Admin reads own status" on public.dynor_admins for select to authenticated using (user_id = (select auth.uid()));
create policy "Published or admin read" on public.dynor_wallpapers for select to anon, authenticated using (published or (select public.dynor_is_admin()));
create policy "Admin inserts wallpapers" on public.dynor_wallpapers for insert to authenticated with check ((select public.dynor_is_admin()));
create policy "Admin updates wallpapers" on public.dynor_wallpapers for update to authenticated using ((select public.dynor_is_admin())) with check ((select public.dynor_is_admin()));
create policy "Admin deletes wallpapers" on public.dynor_wallpapers for delete to authenticated using ((select public.dynor_is_admin()));
create policy "Users read own favorites" on public.dynor_favorites for select to authenticated using (user_id = (select auth.uid()));
create policy "Users add own favorites" on public.dynor_favorites for insert to authenticated with check (user_id = (select auth.uid()) and exists(select 1 from public.dynor_wallpapers w where w.id = wallpaper_id and w.published));
create policy "Users remove own favorites" on public.dynor_favorites for delete to authenticated using (user_id = (select auth.uid()));

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('dynor-previews','dynor-previews',true,52428800,array['image/jpeg','image/png','image/webp','video/mp4']),
 ('dynor-downloads','dynor-downloads',false,104857600,null)
on conflict(id) do nothing;

create policy "Public reads previews" on storage.objects for select to anon, authenticated using (bucket_id = 'dynor-previews');
create policy "Admin uploads previews and files" on storage.objects for insert to authenticated with check (bucket_id in ('dynor-previews','dynor-downloads') and (select public.dynor_is_admin()));
create policy "Admin updates previews and files" on storage.objects for update to authenticated using (bucket_id in ('dynor-previews','dynor-downloads') and (select public.dynor_is_admin())) with check (bucket_id in ('dynor-previews','dynor-downloads') and (select public.dynor_is_admin()));
create policy "Admin removes previews and files" on storage.objects for delete to authenticated using (bucket_id in ('dynor-previews','dynor-downloads') and (select public.dynor_is_admin()));
-- Downloads are private; signed URLs are issued only by the Edge Function.

-- IMPORTANT: Replace UUID below with YOUR auth.users.id (not your email).
-- insert into public.dynor_admins(user_id) values ('YOUR-USER-UUID');
