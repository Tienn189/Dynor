-- Run after wallpaper_online.sql in the same Supabase project.
-- Only Edge Functions with the service-role credential may access these tables.
-- User JWTs, including administrator JWTs, never receive table access to keys.
begin;

create table if not exists public.dynor_encrypted_packages (
  package_id uuid primary key,
  sha256 text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  -- AES-GCM at rest: nonce (12) || encrypted CEK (32) || tag (16).
  -- 60 bytes have an exact 80-character, unpadded standard Base64 encoding.
  wrapped_key text not null check (wrapped_key ~ '^[A-Za-z0-9+/]{80}$'),
  original_name text not null check (
    char_length(original_name) between 1 and 255
    and lower(right(original_name, 8)) = '.tendies'
    and position('/' in original_name) = 0
    and position(chr(92) in original_name) = 0
    and original_name !~ '[[:cntrl:]]'
  ),
  requires_vip boolean not null default true,
  active boolean not null default true,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table public.dynor_encrypted_packages enable row level security;
revoke all on table public.dynor_encrypted_packages
  from public, anon, authenticated, service_role;
grant select, insert on table public.dynor_encrypted_packages to service_role;
-- Registration uses INSERT, never UPSERT. A package ID cannot replace an old key.
-- The service may revoke/reactivate a package, but cannot rewrite its identity,
-- content hash, key, or access policy. Owner SQL remains available for operations.
grant update (active) on table public.dynor_encrypted_packages to service_role;

create table if not exists public.dynor_package_key_rate_limits (
  user_id uuid primary key references auth.users(id) on delete cascade,
  window_started_at timestamptz not null,
  request_count integer not null check (request_count between 1 and 31)
);

alter table public.dynor_package_key_rate_limits enable row level security;
revoke all on table public.dynor_package_key_rate_limits
  from public, anon, authenticated, service_role;

-- One INSERT ... ON CONFLICT serializes concurrent requests for the same user.
-- Requests beyond the limit saturate at 31 and remain denied until the window
-- expires. Request counters therefore cannot overflow or reset under contention.
create or replace function public.dynor_consume_package_key_limit(p_user_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_now timestamptz := clock_timestamp();
  v_count integer;
begin
  if p_user_id is null then
    return false;
  end if;

  insert into public.dynor_package_key_rate_limits as quota
    (user_id, window_started_at, request_count)
  values
    (p_user_id, v_now, 1)
  on conflict (user_id) do update
  set window_started_at = case
        when quota.window_started_at <= v_now - interval '60 seconds'
          then v_now
        else quota.window_started_at
      end,
      request_count = case
        when quota.window_started_at <= v_now - interval '60 seconds'
          then 1
        else least(quota.request_count + 1, 31)
      end
  returning request_count into v_count;

  return v_count <= 30;
end;
$$;

revoke all on function public.dynor_consume_package_key_limit(uuid)
  from public, anon, authenticated, service_role;
grant execute on function public.dynor_consume_package_key_limit(uuid)
  to service_role;

comment on table public.dynor_encrypted_packages is
  'Server-only encrypted content keys; DYNOR_PACKAGE_KEK is held in Edge Function secrets.';
comment on function public.dynor_consume_package_key_limit(uuid) is
  'Service-only atomic fixed-window limit: 30 key-release attempts per user per 60 seconds.';

-- Owner SQL can revoke a package without deleting its audit or encryption record:
-- update public.dynor_encrypted_packages set active = false
-- where package_id = '00000000-0000-0000-0000-000000000000';

commit;
