// WebCrypto wire format shared by the Deno endpoints and Node interoperability tests.
// No content key, KEK, service-role token, or private device key belongs in this file.
export const PACKAGE_MAGIC = new TextEncoder().encode('DYNORT01');
export const KEY_WRAP_INFO = new TextEncoder().encode('DynorContentKey/v1');

export class PackageInputError extends Error {}

export function packageID(value) {
  if (typeof value !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value)) {
    throw new PackageInputError('Invalid package_id');
  }
  return value;
}

export function contentHash(value) {
  if (typeof value !== 'string' || !/^[0-9a-f]{64}$/.test(value)) {
    throw new PackageInputError('Invalid sha256');
  }
  return value;
}

export function originalName(value) {
  if (typeof value !== 'string' || value.length < 9 || [...value].length > 255 ||
      /[\x00-\x1f\x7f/\\]/.test(value) || value.trim() !== value || !/\.tendies$/i.test(value)) {
    throw new PackageInputError('Invalid original_name');
  }
  return value;
}

export function base64(bytes) {
  // All callers encode small keys/nonces, never the wallpaper itself.
  return btoa(String.fromCharCode(...new Uint8Array(bytes)));
}

export function decodeBase64(value, length, label = 'key') {
  if (typeof value !== 'string' || value.length !== 4 * Math.ceil(length / 3) ||
      !/^[A-Za-z0-9+/]+={0,2}$/.test(value)) {
    throw new PackageInputError(`Invalid ${label}`);
  }
  let bytes;
  try { bytes = Uint8Array.from(atob(value), c => c.charCodeAt(0)); }
  catch { throw new PackageInputError(`Invalid ${label}`); }
  if (bytes.length !== length || base64(bytes) !== value) {
    throw new PackageInputError(`Invalid ${label}`);
  }
  return bytes;
}

export function packageHeader(id) {
  const header = new Uint8Array(24);
  header.set(PACKAGE_MAGIC);
  const hex = packageID(id).replaceAll('-', '');
  for (let i = 0; i < 16; i++) header[8 + i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return header;
}

function combined(iv, encrypted) {
  const result = new Uint8Array(iv.length + encrypted.byteLength);
  result.set(iv);
  result.set(new Uint8Array(encrypted), iv.length);
  return result;
}

export async function importKEK(value) {
  const bytes = decodeBase64(value, 32, 'DYNOR_PACKAGE_KEK');
  try { return await crypto.subtle.importKey('raw', bytes, 'AES-GCM', false, ['encrypt', 'decrypt']); }
  finally { bytes.fill(0); }
}

export async function wrapAtRest(rawKey, kek, id) {
  if (!(rawKey instanceof Uint8Array) || rawKey.byteLength !== 32) throw new PackageInputError('Invalid content key');
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: nonce, additionalData: packageHeader(id), tagLength: 128 }, kek, rawKey,
  );
  return base64(combined(nonce, encrypted));
}

export async function unwrapAtRest(wrapped, kek, id) {
  const body = decodeBase64(wrapped, 60, 'stored key');
  const rawKey = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: body.subarray(0, 12), additionalData: packageHeader(id), tagLength: 128 },
    kek, body.subarray(12),
  );
  if (rawKey.byteLength !== 32) throw new Error('Invalid stored key length');
  return new Uint8Array(rawKey);
}

export async function recipientPublicKey(encoded) {
  const raw = decodeBase64(encoded, 65, 'public_key');
  if (raw[0] !== 4) throw new PackageInputError('Invalid public_key');
  try {
    return await crypto.subtle.importKey('raw', raw, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  } catch { throw new PackageInputError('Invalid public_key'); }
}

export async function wrapForRecipient(rawKey, recipient, id) {
  if (!(rawKey instanceof Uint8Array) || rawKey.byteLength !== 32) throw new PackageInputError('Invalid content key');
  const ephemeral = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const shared = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: recipient }, ephemeral.privateKey, 256));
  const salt = crypto.getRandomValues(new Uint8Array(16));
  let wrappingKey;
  try {
    const material = await crypto.subtle.importKey('raw', shared, 'HKDF', false, ['deriveKey']);
    wrappingKey = await crypto.subtle.deriveKey(
      { name: 'HKDF', hash: 'SHA-256', salt, info: KEY_WRAP_INFO }, material,
      { name: 'AES-GCM', length: 256 }, false, ['encrypt'],
    );
  } finally { shared.fill(0); }
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: nonce, additionalData: packageHeader(id), tagLength: 128 }, wrappingKey, rawKey,
  );
  return {
    ephemeral_public_key: base64(await crypto.subtle.exportKey('raw', ephemeral.publicKey)),
    salt: base64(salt),
    wrapped_key: base64(combined(nonce, ciphertext)),
  };
}
