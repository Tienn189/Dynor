import test from 'node:test';
import assert from 'node:assert/strict';
import { createECDH, createDecipheriv, createHash, hkdfSync, randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import {
  packageHeader, packageID, contentHash, originalName, base64, decodeBase64,
  importKEK, wrapAtRest, unwrapAtRest, recipientPublicKey, wrapForRecipient,
} from '../_shared/package-crypto.mjs';
import { createPackageHandler } from '../_shared/package-handlers.mjs';

const ID = '29abc356-4854-4d22-8dbb-a232a411a057';
const OTHER_ID = '93b9af25-eccc-417d-b04c-a3788aef5382';
const HASH = 'ab'.repeat(32);
const USER_ID = '563456bf-d0a8-4b8b-bcb4-529e92db7326';
const CEK = new Uint8Array(randomBytes(32));
const KEK = base64(randomBytes(32));
const ENV = { SUPABASE_URL: 'https://project.invalid', SUPABASE_ANON_KEY: 'test-anon', SUPABASE_SERVICE_ROLE_KEY: 'test-service', DYNOR_PACKAGE_KEK: KEK };

function clientRecipient() {
  const ec = createECDH('prime256v1');
  ec.generateKeys();
  return {
    public_key: ec.getPublicKey().toString('base64'),
    unwrap(response, id = ID) {
      const secret = ec.computeSecret(Buffer.from(response.ephemeral_public_key, 'base64'));
      const wrapping = hkdfSync('sha256', secret, Buffer.from(response.salt, 'base64'), Buffer.from('DynorContentKey/v1'), 32);
      const combined = Buffer.from(response.wrapped_key, 'base64');
      assert.equal(combined.length, 60);
      const decrypt = createDecipheriv('aes-256-gcm', wrapping, combined.subarray(0, 12));
      decrypt.setAAD(packageHeader(id));
      decrypt.setAuthTag(combined.subarray(-16));
      return Buffer.concat([decrypt.update(combined.subarray(12, -16)), decrypt.final()]);
    },
  };
}

function fakeDependencies(overrides = {}) {
  const state = {
    user: { id: USER_ID }, admin: { user_id: USER_ID },
    allowed: true, record: null, vip: null, inserts: [], reads: [], rpcCalls: [],
    ...overrides,
  };
  const db = {
    from(table) {
      state.reads.push(table);
      return {
        select() { return this; }, eq() { return this; },
        async maybeSingle() {
          if (state.throwDatabase) throw new Error('internal: SECRET_DO_NOT_RETURN');
          const key = { dynor_admins: 'admin', dynor_encrypted_packages: 'record', dynor_vip: 'vip' }[table];
          return { data: state[key], error: state[`${key}Error`] ?? null };
        },
        async insert(row) { state.inserts.push(row); return { error: state.insertError ?? null }; },
      };
    },
    async rpc(name, args) { state.rpcCalls.push([name, args]); return { data: state.allowed, error: state.rpcError ?? null }; },
  };
  const createClient = (_url, key) => key === ENV.SUPABASE_SERVICE_ROLE_KEY ? db : {
    auth: { async getUser() { return { data: { user: state.user }, error: state.authError ?? null }; } },
  };
  return { state, createClient, env: key => (state.env ?? ENV)[key], now: () => Date.parse('2026-11-16T00:00:00Z') };
}

function request(body, extra = {}) {
  const headers = { authorization: 'Bearer valid-test-jwt', 'content-type': 'application/json', ...extra.headers };
  return new Request('https://server.invalid/functions/v1/dynor-package-key', {
    method: 'POST', ...extra, headers,
    body: typeof body === 'string' ? body : JSON.stringify(body),
  });
}

async function registeredRecord() {
  const kek = await importKEK(KEK);
  return {
    package_id: ID, sha256: HASH, wrapped_key: await wrapAtRest(CEK, kek, ID),
    requires_vip: false, active: true,
  };
}

const registration = () => ({ package_id: ID, sha256: HASH, key_base64: base64(CEK), original_name: 'My Wallpaper.tendies', requires_vip: true });

test('binary header agrees with fixed magic and UUID network byte order', () => {
  assert.equal(Buffer.from(packageHeader(ID)).toString('hex'), '44594e4f5254303129abc35648544d228dbba232a411a057');
});

test('validators reject ambiguous identifiers, invalid filenames and noncanonical Base64', async () => {
  assert.throws(() => packageID(ID.toUpperCase()));
  assert.throws(() => packageID('../wallpaper'));
  assert.throws(() => contentHash('AB'.repeat(32)));
  for (const name of ['../wallpaper.tendies', 'folder\\file.tendies', 'file.tendies\n', '.tendies', 'file.zip']) assert.throws(() => originalName(name));
  assert.equal(originalName('Mẫu hình nền.TENDIES'), 'Mẫu hình nền.TENDIES');
  assert.throws(() => decodeBase64(' '.repeat(44), 32));
  assert.throws(() => decodeBase64('A'.repeat(42) + 'B=', 32)); // 43rd sextet has discarded nonzero bits.
  assert.throws(() => decodeBase64(base64(CEK).replace(/=$/, ''), 32));
  await assert.rejects(recipientPublicKey(base64(new Uint8Array(65))));
  const invalidPoint = new Uint8Array(65); invalidPoint[0] = 4;
  await assert.rejects(recipientPublicKey(base64(invalidPoint)));
});

test('at-rest encryption authenticates package ID and rejects ciphertext tampering', async () => {
  const kek = await importKEK(KEK);
  const wrapped = await wrapAtRest(CEK, kek, ID);
  assert.deepEqual(await unwrapAtRest(wrapped, kek, ID), CEK);
  assert.notEqual(wrapped, base64(CEK));
  await assert.rejects(unwrapAtRest(wrapped, kek, OTHER_ID));
  const tampered = decodeBase64(wrapped, 60); tampered[22] ^= 1;
  await assert.rejects(unwrapAtRest(base64(tampered), kek, ID));
  await assert.rejects(unwrapAtRest(wrapped, await importKEK(base64(randomBytes(32))), ID));
});

test('recipient wrap interoperates with independent Node ECDH/HKDF/AES implementation', async () => {
  const recipient = clientRecipient();
  const response = await wrapForRecipient(CEK, await recipientPublicKey(recipient.public_key), ID);
  assert.deepEqual(recipient.unwrap(response), Buffer.from(CEK));
  assert.throws(() => recipient.unwrap(response, OTHER_ID));
  assert.throws(() => clientRecipient().unwrap(response));
  const tampered = Buffer.from(response.wrapped_key, 'base64'); tampered[20] ^= 1;
  assert.throws(() => recipient.unwrap({ ...response, wrapped_key: tampered.toString('base64') }));
  assert.deepEqual(Object.keys(response).sort(), ['ephemeral_public_key', 'salt', 'wrapped_key']);
});

test('only authenticated admins can register; success stores wrapped key and returns no key', async () => {
  for (const overrides of [{ user: null }, { admin: null }]) {
    const deps = fakeDependencies(overrides);
    const response = await createPackageHandler('register', deps)(request(registration()));
    assert.equal(response.status, overrides.user === null ? 401 : 403);
    assert.equal(deps.state.inserts.length, 0);
  }
  const deps = fakeDependencies();
  const response = await createPackageHandler('register', deps)(request(registration()));
  assert.equal(response.status, 201);
  assert.deepEqual(await response.json(), { package_id: ID, sha256: HASH });
  assert.equal(deps.state.inserts.length, 1);
  const stored = deps.state.inserts[0];
  assert.equal(stored.created_by, USER_ID);
  assert.equal(stored.requires_vip, true);
  assert.notEqual(stored.wrapped_key, base64(CEK));
  assert.deepEqual(await unwrapAtRest(stored.wrapped_key, await importKEK(KEK), ID), CEK);
  assert.equal(stored.key_base64, undefined);
});

test('duplicate registration fails instead of overwriting an existing key', async () => {
  const deps = fakeDependencies({ insertError: { code: '23505', message: 'secret details' } });
  const response = await createPackageHandler('register', deps)(request(registration()));
  assert.equal(response.status, 409);
  assert.doesNotMatch(await response.text(), /secret details/);
});

test('key release enforces login, package status/hash and successful rate check', async () => {
  const recipient = clientRecipient();
  const body = { package_id: ID, sha256: HASH, public_key: recipient.public_key };
  const record = await registeredRecord();
  for (const [overrides, status] of [
    [{ user: null, record }, 401],
    [{ record: null }, 404],
    [{ record: { ...record, active: false } }, 404],
    [{ record: { ...record, sha256: 'cd'.repeat(32) } }, 404],
    [{ record, allowed: false }, 429],
    [{ record, rpcError: { message: 'unavailable' } }, 503],
  ]) {
    const deps = fakeDependencies(overrides);
    const response = await createPackageHandler('key', deps)(request(body));
    assert.equal(response.status, status);
    const result = await response.json();
    assert.equal(result.wrapped_key, undefined);
    if (status === 429) {
      assert.equal(response.headers.get('retry-after'), '60');
      assert.equal(deps.state.reads.includes('dynor_encrypted_packages'), false);
    }
  }
  const deps = fakeDependencies({ record });
  const response = await createPackageHandler('key', deps)(request(body));
  assert.equal(response.status, 200);
  assert.equal(response.headers.get('cache-control'), 'no-store');
  assert.deepEqual(recipient.unwrap(await response.json()), Buffer.from(CEK));
  assert.deepEqual(deps.state.rpcCalls, [['dynor_consume_package_key_limit', { p_user_id: USER_ID }]]);
});

test('VIP gate rejects absent/expired membership, permits lifetime and future expiry, fails closed on lookup errors', async () => {
  const recipient = clientRecipient();
  const body = { package_id: ID, sha256: HASH, public_key: recipient.public_key };
  const record = { ...await registeredRecord(), requires_vip: true };
  for (const [vip, status, vipError] of [
    [null, 403],
    [{ plan_id: 'monthly', vip_expires_at: '2026-11-15T23:59:59Z' }, 403],
    [{ plan_id: 'monthly', vip_expires_at: 'invalid-date' }, 403],
    [{ plan_id: 'lifetime', vip_expires_at: null }, 200],
    [{ plan_id: 'monthly', vip_expires_at: '2027-01-01T00:00:00Z' }, 200],
    [null, 503, { message: 'database unavailable' }],
  ]) {
    const deps = fakeDependencies({ record, vip, vipError });
    const response = await createPackageHandler('key', deps)(request(body));
    assert.equal(response.status, status);
    if (status === 200) assert.deepEqual(recipient.unwrap(await response.json()), Buffer.from(CEK));
  }
});

test('bounded request reader rejects oversized bodies, JSON arrays and wrong media type', async () => {
  const invalid = [
    [request(' '.repeat(4097)), 413],
    [request('{}', { headers: { 'content-length': '5000' } }), 413],
    [request('[]'), 400],
    [request('{'), 400],
    [request('{}', { headers: { 'content-type': 'text/plain' } }), 415],
  ];
  for (const [req, status] of invalid) {
    const deps = fakeDependencies();
    const response = await createPackageHandler('register', deps)(req);
    assert.equal(response.status, status);
    assert.equal(deps.state.inserts.length, 0);
  }
});

test('preflight works without credentials; non-POST methods expose no server data', async () => {
  const deps = fakeDependencies({ env: {} });
  const handler = createPackageHandler('register', deps);
  const preflight = await handler(new Request('https://server.invalid', { method: 'OPTIONS' }));
  assert.equal(preflight.status, 204);
  assert.match(preflight.headers.get('access-control-allow-headers'), /authorization/);
  assert.equal((await handler(new Request('https://server.invalid'))).status, 405);
  assert.equal((await handler(request(registration()))).status, 503);
});

test('unexpected server/crypto errors do not disclose request data or secrets', async () => {
  const deps = fakeDependencies({ throwDatabase: true });
  const response = await createPackageHandler('register', deps)(request(registration()));
  assert.equal(response.status, 503);
  assert.deepEqual(await response.json(), { error: 'Package service unavailable' });
  const brokenKEK = fakeDependencies({ env: { ...ENV, DYNOR_PACKAGE_KEK: 'invalid' } });
  assert.equal((await createPackageHandler('register', brokenKEK)(request(registration()))).status, 503);
});

test('browser package survives admin registration and authorized recipient release, while substitution and tampering fail', async () => {
  // The delivered ZIP keeps the browser tool beside Supabase. During development
  // its independent Site checkout can be selected without copying production data.
  const vaultRoot = process.env.DYNOR_VAULT_ROOT
    ? pathToFileURL(process.env.DYNOR_VAULT_ROOT.replace(/\/$/, '') + '/')
    : new URL('../../Tools/DynorVault/', import.meta.url);
  const { encryptTendies } = await import(new URL('dist/crypto.mjs', vaultRoot));
  const vector = JSON.parse(await readFile(new URL('tests/interop-v1.json', vaultRoot), 'utf8'));
  const plaintext = new Uint8Array(Buffer.from(vector.plaintext_base64, 'base64'));
  const encrypted = await encryptTendies(plaintext);
  const deps = fakeDependencies();
  const register = createPackageHandler('register', deps);
  const registrationResponse = await register(request({
    package_id: encrypted.packageId, sha256: encrypted.sha256,
    key_base64: base64(encrypted.keyBytes), original_name: 'Interop.tendies', requires_vip: true,
  }));
  assert.equal(registrationResponse.status, 201);
  assert.deepEqual(await registrationResponse.json(), { package_id: encrypted.packageId, sha256: encrypted.sha256 });
  deps.state.record = { ...deps.state.inserts[0], active: true };
  assert.equal(deps.state.record.key_base64, undefined);
  assert.notEqual(deps.state.record.wrapped_key, base64(encrypted.keyBytes));
  // The browser does not retain a plaintext content key after registration.
  encrypted.keyBytes.fill(0);

  const recipient = clientRecipient();
  const body = { package_id: encrypted.packageId, sha256: encrypted.sha256, public_key: recipient.public_key };
  const release = createPackageHandler('key', deps);
  assert.equal((await release(request(body))).status, 403); // No active VIP yet.
  deps.state.vip = { plan_id: 'lifetime', vip_expires_at: null };
  const releaseResponse = await release(request(body));
  assert.equal(releaseResponse.status, 200);
  const wrapped = await releaseResponse.json();
  const contentKey = recipient.unwrap(wrapped, encrypted.packageId);
  assert.throws(() => clientRecipient().unwrap(wrapped, encrypted.packageId));
  assert.equal(createHash('sha256').update(encrypted.bytes).digest('hex'), encrypted.sha256);

  function decryptPayload(bytes) {
    const decrypt = createDecipheriv('aes-256-gcm', contentKey, bytes.subarray(24, 36));
    decrypt.setAAD(bytes.subarray(0, 24));
    decrypt.setAuthTag(bytes.subarray(-16));
    return Buffer.concat([decrypt.update(bytes.subarray(36, -16)), decrypt.final()]);
  }
  assert.deepEqual(decryptPayload(encrypted.bytes), Buffer.from(plaintext));
  for (const position of [8, 24, 36, encrypted.bytes.length - 1]) {
    const tampered = new Uint8Array(encrypted.bytes);
    tampered[position] ^= 1;
    assert.throws(() => decryptPayload(tampered));
    const changedHash = createHash('sha256').update(tampered).digest('hex');
    assert.equal((await release(request({ ...body, sha256: changedHash }))).status, 404);
  }
  deps.state.record.active = false;
  assert.equal((await release(request(body))).status, 404);
  contentKey.fill(0);
});
