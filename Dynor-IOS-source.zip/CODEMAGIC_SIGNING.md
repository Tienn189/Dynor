# Ký IPA Dynor trên Codemagic

Source đã khai báo Bundle ID `com.dynor.wallpapers` và App Group `group.3fae94347e97b250.4`.

1. Trong Apple Developer, bật App Groups cho App ID `com.dynor.wallpapers` và gán `group.3fae94347e97b250.4`. Tạo lại provisioning profile tương ứng.
2. Trong Codemagic, thêm ba biến môi trường **Secret** cho workflow `dynor-ios-unsigned`:
   - `DYNOR_CERTIFICATE_P12_BASE64`: nội dung file .p12 mã hóa base64 (một dòng).
   - `DYNOR_CERTIFICATE_PASSWORD`: mật khẩu của file .p12.
   - `DYNOR_PROVISION_PROFILE_BASE64`: provisioning profile mã hóa base64 (một dòng).
3. Chạy workflow. Nếu đủ ba biến, bước ký sẽ tạo `Dynor-signed.ipa` và script sẽ kiểm tra chữ ký, provisioning profile và App Group. Nếu không có biến nào, workflow chỉ tạo `Dynor-unsigned.ipa`. Nếu thiếu một phần biến, build báo lỗi thay vì xuất IPA ký sai.

**Quan trọng:** Không đưa chứng chỉ, mật khẩu hoặc provisioning profile vào ZIP/repository. Chỉ thay đổi source không thể cấp quyền App Group của Apple hoặc đảm bảo cơ chế PosterBoard hoạt động trên thiết bị.
