# Worse Poster reference

Repository: https://github.com/nxtcoreee3/Worse-Poster
Revision: 05db4788ca4df0b0dc33ba132b318f853728ee80
License: GPL-3.0 (see LICENSE).

Dynor follows the PosterBoard descriptor installation workflow in
Pocket Poster/Controllers/{PosterBoardManager,SymHandler}.swift: discover the
PosterBoard container, add descriptors under its versioned extension store,
then let the user select the wallpaper in iOS. No upstream UI/assets are copied.

At this revision, README refers to worse_query but Exploit/bad_query.c still
contains the older backend. Dynor uses the successor's pinned original source
from forcequitOS/worse_query instead (see ../WorseQuery). It does not copy
legacy .Trash fallback, broad collection deletion, or forced respring.

Dynor changes: actual signed App Group checks, verified container identity,
existing-provider selection, bounded archive/CRC validation, SHA-256 read-back,
rollback of new descriptors, preservation of unrelated preferences and explicit
separation of verified writes from wallpaper selection.
