# Historical AirCard attribution

Parts of Dynor's Tendies archive/descriptor processing were adapted from
[Mak5er/AirCard-iOS](https://github.com/Mak5er/AirCard-iOS/tree/40640c4d827aeab8d798285b57d24fcf6be070d0),
revision `40640c4d827aeab8d798285b57d24fcf6be070d0`, under the MIT license.
See LICENSE for the original notice.

The AirliftFFI framework, pairing/VPN transport, downloader and Rust dependencies
have been removed. `provenance.json` is a historical record of the former binary
pins, not an active build dependency. Dynor now compiles the vendored worse_query
Objective-C helpers from source. See ../WorseQuery/README.md.
