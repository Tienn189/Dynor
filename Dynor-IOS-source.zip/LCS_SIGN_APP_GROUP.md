# LCSsign App Group test (iOS 26.6)

- Bundle ID remains `com.dynor.wallpapers`.
- Xcode build configuration now requests `group.3fae94347e97b250.4`, a group listed in the supplied provisioning profile.
- At runtime Dynor **requires this exact group in the signed entitlements** and checks that iOS grants access to its container. A profile entry alone does not prove entitlement activation.
- Sign the new IPA with LCSsign and inspect the signed app entitlements. If LCSsign strips/changes the group, installation is blocked with an accurate error.
- IMPORTANT: this group may be shared with Camlo or other apps. Upstream `worse_query` temporarily changes the App Group's Library/Caches directory. Back up data, avoid concurrent use with other apps sharing the group, and do not treat this as production-safe until tested. Prefer a dedicated group under your control for distribution.
- No iPhone runtime test or Xcode build was possible in this Linux environment. A successful installation is **not** guaranteed.
