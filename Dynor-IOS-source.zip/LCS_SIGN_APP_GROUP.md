# Dynor / LCSsign App Group audit

The XcodeGen source (`project.yml`) requests `group.3fae94347e97b250.4`. The entitlements plist uses `$(DYNOR_APP_GROUP_IDENTIFIER)` and `Info.plist` uses `DynorAppGroupIdentifier` from the same setting. Bundle ID remains `com.dynor.wallpapers`.

**Important:** The provisioning profile listing an App Group does not prove the final IPA signature grants it. After building and signing with LCSsign, on macOS run:

```sh
python3 scripts/check_signed_ipa.py /path/to/Dynor-LC-signed.ipa
```

If the tool reports a missing group, fix signing settings in LCSsign or obtain a suitable profile. Do not bypass runtime entitlement checks. If it passes but the iPhone still shows the old group, ensure the newest IPA was installed and inspect its Info.plist. Passing the audit does not prove worse_query can write to PosterBoard. Sharing an App Group with another app can expose shared container data; use an app-specific group where possible.
