# Dynor "Aurora Noir" – thiết kế lại toàn bộ giao diện

Ngôn ngữ thiết kế mới: nền mực đậm (sáng: ivory ấm), ánh sáng aurora pha màu nhấn của người dùng,
bề mặt kính mờ viền gradient, tiêu đề serif sang trọng, nút gradient có bóng sáng, thanh tab nổi.

## File giao diện đã viết lại
- `Views/DynorDesign.swift` – hệ thiết kế mới (AuroraBackground, dynorGlass, DynorHeader, DynorChip,
  DynorPrimaryButtonStyle, GlassIconButton, VIPBadge, StatTile, SelectionMark…). `DynorHero` giữ lại để tương thích.
- `DynorApp.swift` – thanh tab nổi dạng kính, pill trượt (matchedGeometryEffect), haptic.
- `Views/OnlineGalleryView.swift` – Khám phá: header, tìm kiếm, chip danh mục, carousel "Nổi bật" parallax,
  lưới poster 2 cột so le, nút Yêu thích trên header, trang chi tiết toàn màn hình.
- `Views/LibraryView.swift` – Bộ sưu tập: thống kê, thẻ nhập nét đứt, lưới poster, chọn nhiều, trang xem trước
  dạng khung iPhone (Sleep / Locked / Unlock) + khối cài đặt.
- `Views/InstalledWallpapersView.swift`, `ActivityHistoryView.swift` (timeline), `ThemeColorPickerView.swift`,
  `PosterBoardView.swift`, `SettingsView.swift` (hồ sơ, banner VIP vàng, giao diện, thiết bị…).

## Giữ nguyên 100%
Tải/nhập tệp, cài PosterBoard, worse_query, tài khoản, thanh toán VIP, mã hóa .dynor, nhật ký, signing/CI.
`GalleryView.swift` (không còn dùng) không đổi.

## Lưu ý
Chưa build được trong môi trường Linux (không có Xcode). Hãy build bằng Codemagic/GitHub Actions và gửi lại
lỗi compiler (nếu có) để chỉnh. Yêu cầu iOS 18+ (dùng Color.mix, scrollTransition, contentMargins).
