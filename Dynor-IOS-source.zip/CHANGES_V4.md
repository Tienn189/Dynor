# Dynor V4 — changes and limitations

- Default accent is blue; replaced oversized colored hero with compact text header.
- Removed the collection's top install shortcut and Settings' redundant Tendies install tool.
- Theme color picker now has presets and a custom ColorPicker, saved locally.
- Settings includes a language choice (Vietnamese, English, Simplified Chinese). Main navigation and selected headings are translated; some detailed screens and technical messages remain Vietnamese.
- Added Installed tab: only descriptor folders created and tracked by Dynor, not the full iOS wallpaper collection. Supports multi-select deletion and a scoped reset in Settings.
- Writer now records verified descriptor directories and uses a much larger randomized numeric identifier space for packages without suggestion metadata. This reduces collisions but does not guarantee iOS will display subsequent installs without a reload; the PosterBoard caching behavior must be tested on device.
- Existing install backend and App Group unchanged. No Xcode build or device verification was performed.
- If installing a second wallpaper still fails, capture the per-install log and check whether its provider metadata has fixed suggestion IDs. Do not reset system wallpapers blindly.
