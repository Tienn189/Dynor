# Chẩn đoán App Group V2

Mở Dynor → PosterBoard → Kiểm tra lại chữ ký. Báo cáo sẽ hiển thị Bundle ID, phiên bản iOS, App Group cấu hình, nhóm từ entitlement runtime, tình trạng containerURL và kiểm tra ghi/đọc file tạm. Dùng nút **Chia sẻ báo cáo chẩn đoán** để gửi kết quả. Không gửi chứng chỉ .p12.

Nếu Container URL = NIL mặc dù entitlement có nhóm, cần kiểm tra chữ ký/provisioning profile và Application Identifier thực tế. Đổi chuỗi App Group trong Swift không thể tự cấp quyền iOS. Nếu container URL có nhưng ghi/đọc lỗi, báo cáo ghi rõ domain/code của NSError. Không có bước nào ở đây thay đổi dữ liệu PosterBoard.

Chưa build bằng Xcode và chưa xác nhận cài hình nền trên iPhone.
