import Foundation
import Darwin

enum DocumentImportError: LocalizedError {
    case notAFile
    case empty
    case tooLarge(Int)
    case unsupportedWallpaper
    case invalidImage

    var errorDescription: String? {
        switch self {
        case .notAFile: return "Hãy chọn một tệp, không phải thư mục."
        case .empty: return "Tệp trống hoặc chưa tải được từ iCloud. Hãy tải tệp trong ứng dụng Tệp rồi thử lại."
        case .tooLarge(let limit): return "Tệp vượt quá giới hạn \(limit / 1024 / 1024) MB."
        case .unsupportedWallpaper: return "Chỉ nhập ảnh, tệp .tendies hoặc gói mã hóa .dynor."
        case .invalidImage: return "Không đọc được nội dung ảnh."
        }
    }
}

struct StagedDocument {
    let url: URL
    let displayName: String
    let byteCount: Int64
    let pathExtension: String

    func remove() { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
}

/// Document providers can advertise `.tendies` as ZIP or as a dynamic UTI.
/// Pick any document and validate the extension/content after obtaining access.
enum DocumentImportService {
    static let wallpaperLimit = 50 * 1024 * 1024
    // Header (24), nonce (12) and GCM tag (16) surround at most 50 MiB of Tendies.
    static let encryptedWallpaperLimit = wallpaperLimit + 52

    /// Run away from the main actor: coordination may wait for iCloud to download.
    static func stage(_ source: URL, maximumBytes: Int) throws -> StagedDocument {
        guard source.isFileURL else { throw DocumentImportError.notAFile }
        let hasAccess = source.startAccessingSecurityScopedResource()
        defer { if hasAccess { source.stopAccessingSecurityScopedResource() } }

        let metadata = try? source.resourceValues(forKeys: [.nameKey, .isUbiquitousItemKey])
        if metadata?.isUbiquitousItem == true {
            try FileManager.default.startDownloadingUbiquitousItem(at: source)
        }
        let displayName = preferredFilename(sourceURL: source, providerName: metadata?.name)

        var coordinationError: NSError?
        var result: Result<StagedDocument, Error>?
        // Coordinated reads materialize cloud/provider documents before checking size.
        NSFileCoordinator().coordinate(readingItemAt: source, options: [], error: &coordinationError) { readableURL in
            result = Result { try copyReadableFile(readableURL, displayName: displayName, maximumBytes: maximumBytes) }
        }
        if let coordinationError {
            if case .success(let staged)? = result { staged.remove() }
            throw coordinationError
        }
        guard let result else { throw CocoaError(.fileReadUnknown) }
        return try result.get()
    }

    /// Provider names can restore an extension missing from an opaque URL, but
    /// some providers expose a display name with the extension hidden instead.
    static func preferredFilename(sourceURL: URL, providerName: String?) -> String {
        let sourceName = sourceURL.lastPathComponent
        guard let providerName, !providerName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return sourceName
        }
        if URL(fileURLWithPath: providerName).pathExtension.isEmpty && !sourceURL.pathExtension.isEmpty {
            return sourceName
        }
        return providerName
    }

    private static func copyReadableFile(_ source: URL, displayName: String, maximumBytes: Int) throws -> StagedDocument {
        // Some Files providers omit URLResourceValues.isRegularFile even after
        // materializing a document. Inspect the opened file, not optional provider
        // metadata, and keep rejecting directories, sockets and other special files.
        let input = try FileHandle(forReadingFrom: source)
        defer { try? input.close() }
        var attributes = stat()
        guard fstat(input.fileDescriptor, &attributes) == 0 else {
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
        }
        guard attributes.st_mode & mode_t(S_IFMT) == mode_t(S_IFREG) else {
            throw DocumentImportError.notAFile
        }
        if attributes.st_size > Int64(maximumBytes) { throw DocumentImportError.tooLarge(maximumBytes) }

        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("DynorImport-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let ext = URL(fileURLWithPath: displayName).pathExtension.lowercased()
        // Provider URLs may lack an extension; avoid a trailing dot in the staged filename.
        var destination = directory.appendingPathComponent("document")
        if !ext.isEmpty { destination = destination.appendingPathExtension(ext) }
        do {
            guard FileManager.default.createFile(atPath: destination.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
            let output = try FileHandle(forWritingTo: destination)
            defer { try? output.close() }
            var count = 0
            while let chunk = try input.read(upToCount: 64 * 1024), !chunk.isEmpty {
                count += chunk.count
                guard count <= maximumBytes else { throw DocumentImportError.tooLarge(maximumBytes) }
                try output.write(contentsOf: chunk)
            }
            guard count > 0 else { throw DocumentImportError.empty }
            return StagedDocument(url: destination, displayName: displayName, byteCount: Int64(count), pathExtension: ext)
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw error
        }
    }
}
