import SwiftUI
import UIKit
import Combine
import Photos
import UniformTypeIdentifiers

struct WallpaperItem: Identifiable {
    let id: String
    let title: String
    let category: String
    let imageName: String

    static let samples: [WallpaperItem] = [
        .init(id: "dune", title: "Golden Silence", category: "Thiên nhiên", imageName: "dune"),
        .init(id: "alpine", title: "Alpine Dreams", category: "Thiên nhiên", imageName: "alpine"),
        .init(id: "liquid", title: "Liquid Flow", category: "Trừu tượng", imageName: "liquid"),
        .init(id: "forest", title: "Into the Green", category: "Thiên nhiên", imageName: "forest"),
        .init(id: "space", title: "Stardust", category: "Vũ trụ", imageName: "space"),
        .init(id: "ocean", title: "Ocean Therapy", category: "Thiên nhiên", imageName: "ocean"),
        .init(id: "minimal", title: "Soft Horizon", category: "Tối giản", imageName: "minimal"),
        .init(id: "sunset", title: "Last Light", category: "Thiên nhiên", imageName: "sunset"),
        .init(id: "coast", title: "Coastal Escape", category: "Thiên nhiên", imageName: "coast"),
        .init(id: "peak", title: "Above the Clouds", category: "Thiên nhiên", imageName: "mountain-hero")
    ]
}

func wallpaperImage(named name: String) -> UIImage? {
    guard let path = Bundle.main.path(forResource: name, ofType: "jpg") else { return nil }
    return UIImage(contentsOfFile: path)
}

enum ThemeMode: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var colorScheme: ColorScheme? {
        switch self { case .system: return nil; case .light: return .light; case .dark: return .dark }
    }
}

enum ThemeAccent: String, CaseIterable, Identifiable {
    case yellow, orange, blue, mint, purple, pink, red, custom
    var id: String { rawValue }
    var title: String {
        switch self {
        case .yellow: return "Vàng"
        case .orange: return "Cam"
        case .blue: return "Xanh dương"
        case .mint: return "Xanh ngọc"
        case .purple: return "Tím"
        case .pink: return "Hồng"
        case .red: return "Đỏ"
        case .custom: return "Tự chọn"
        }
    }
    var color: Color {
        switch self {
        case .yellow: return Color(red: 1, green: 0.78, blue: 0.12)
        case .orange: return Color(red: 1, green: 0.52, blue: 0.18)
        case .blue: return Color(red: 0.25, green: 0.58, blue: 1)
        case .mint: return Color(red: 0.16, green: 0.80, blue: 0.67)
        case .purple: return Color(red: 0.64, green: 0.43, blue: 0.97)
        case .pink: return Color(red: 0.98, green: 0.39, blue: 0.65)
        case .red: return Color(red: 0.95, green: 0.33, blue: 0.29)
        case .custom: return Color(hex: UserDefaults.standard.string(forKey: "dynor.customAccent") ?? "#3478F6")
        }
    }
}
struct LocalProfile: Codable, Equatable { let id: String; let name: String }
enum DynorTab: Hashable { case discover, library, installed, settings }
enum ImportedKind: String, Codable {
    case image, tendies, encryptedTendies
    var isTendies: Bool { self == .tendies || self == .encryptedTendies }
}
struct ImportedWallpaper: Codable, Identifiable {
    let id: UUID
    let displayName: String
    let storedFilename: String
    let kind: ImportedKind
    let addedAt: Date
    let byteCount: Int64
}

@MainActor
final class DynorStore: ObservableObject {
    @Published var theme: ThemeMode { didSet { defaults.set(theme.rawValue, forKey: "theme") } }
    @Published var accent: ThemeAccent { didSet { defaults.set(accent.rawValue, forKey: "accent") } }
    @Published var customAccentHex: String {
        didSet { defaults.set(customAccentHex, forKey: "dynor.customAccent") }
    }
    @Published var appLanguage: String {
        didSet { defaults.set(appLanguage, forKey: "dynor.language") }
    }
    @Published var favorites: Set<String> { didSet { defaults.set(Array(favorites), forKey: "favorites") } }
    @Published private(set) var profile: LocalProfile?
    @Published private(set) var library: [ImportedWallpaper] = []
    @Published private(set) var isImporting = false
    @Published var selectedTab: DynorTab = .discover
    @Published var pendingLibraryPreview: UUID?
    @Published var isInstallingWallpaper = false
    @Published var message: String?
    @Published private var dailyDay: String
    @Published private var dailyCount: Int

    private let defaults: UserDefaults
    private let root: URL
    private var libraryDirectory: URL { root.appendingPathComponent("Library", isDirectory: true) }
    private var indexURL: URL { root.appendingPathComponent("library.json") }
    var accentColor: Color { accent == .custom ? Color(hex: customAccentHex) : accent.color }
    /// Contrasting foreground for solid accent surfaces, including custom colors.
    var accentTextColor: Color {
        let ui = UIColor(accentColor)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard ui.getRed(&r, green: &g, blue: &b, alpha: &a) else { return .white }
        let brightness = 0.2126 * r + 0.7152 * g + 0.0722 * b
        return brightness > 0.59 ? .black : .white
    }
    var currentDayKey: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Asia/Ho_Chi_Minh")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
    var adsWatched: Int { dailyDay == currentDayKey ? min(5, max(0, dailyCount)) : 0 }
    var isUnlocked: Bool { DynorAccountService.shared.isVIP || adsWatched >= 5 }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        theme = ThemeMode(rawValue: defaults.string(forKey: "theme") ?? "system") ?? .system
        accent = ThemeAccent(rawValue: defaults.string(forKey: "accent") ?? "blue") ?? .blue
        customAccentHex = defaults.string(forKey: "dynor.customAccent") ?? "#3478F6"
        appLanguage = defaults.string(forKey: "dynor.language") ?? "vi"
        favorites = Set(defaults.stringArray(forKey: "favorites") ?? [])
        dailyDay = defaults.string(forKey: "dailyDay") ?? ""
        dailyCount = min(5, max(0, defaults.integer(forKey: "dailyCount")))
        if let data = defaults.data(forKey: "profile") { profile = try? JSONDecoder().decode(LocalProfile.self, from: data) }
        root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Dynor", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: libraryDirectory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: indexURL.path) {
                library = try JSONDecoder().decode([ImportedWallpaper].self, from: Data(contentsOf: indexURL))
            }
        } catch {
            message = "Không thể mở thư viện cục bộ: \(error.localizedDescription)"
        }
        // The direct PosterBoard backend no longer uses device credentials.
        // Remove only the previous connection data inside Dynor's own storage.
        defaults.removeObject(forKey: "dynor.pairing.hostAltIRK")
        for relativePath in ["Pairing", "pairing.json"] {
            let legacyURL = root.appendingPathComponent(relativePath)
            do {
                if FileManager.default.fileExists(atPath: legacyURL.path) {
                    try FileManager.default.removeItem(at: legacyURL)
                }
            } catch {
                message = message ?? "Chưa dọn được dữ liệu kết nối cũ: \(error.localizedDescription)"
            }
        }
        refreshDailyAccess()
    }

    func refreshDailyAccess() {
        if dailyDay != currentDayKey {
            dailyDay = currentDayKey
            dailyCount = 0
            defaults.set(dailyDay, forKey: "dailyDay")
            defaults.set(0, forKey: "dailyCount")
        }
        objectWillChange.send()
    }

    @discardableResult
    func recordDemoAd(startDay: String) -> Bool {
        refreshDailyAccess()
        guard startDay == currentDayKey else {
            message = "Đã sang ngày mới theo giờ Việt Nam. Hãy bắt đầu lại tiến trình hôm nay."
            return false
        }
        dailyCount = min(5, dailyCount + 1)
        defaults.set(dailyCount, forKey: "dailyCount")
        return true
    }

    func toggleFavorite(_ id: String) {
        if favorites.contains(id) { favorites.remove(id) } else { favorites.insert(id) }
    }

    func createLocalProfile(name: String) {
        let cleanName = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(40))
        guard !cleanName.isEmpty else { return }
        let next = LocalProfile(id: profile?.id ?? "DYN-" + UUID().uuidString, name: cleanName)
        do {
            defaults.set(try JSONEncoder().encode(next), forKey: "profile")
            profile = next
        } catch { message = error.localizedDescription }
    }

    func deleteLocalProfile() {
        defaults.removeObject(forKey: "profile")
        profile = nil
    }

    func fileURL(for item: ImportedWallpaper) -> URL {
        libraryDirectory.appendingPathComponent(item.storedFilename)
    }

    @discardableResult
    func importWallpapers(urls: [URL]) async -> [ImportedWallpaper] {
        guard !isImporting else { message = "Dynor đang nhập tệp. Hãy chờ hoàn tất."; return [] }
        isImporting = true
        defer { isImporting = false }
        var added: [ImportedWallpaper] = []
        var duplicates = 0
        var available: [ImportedWallpaper] = []
        var failures: [String] = []
        for url in urls {
            do {
                let staged = try await Task.detached(priority: .userInitiated) {
                    try DocumentImportService.stage(url, maximumBytes: DocumentImportService.encryptedWallpaperLimit)
                }.value
                defer { staged.remove() }
                let ext = staged.pathExtension
                let isEncrypted = ext == "dynor"
                let isTendies = ext == "tendies" || isEncrypted
                guard isTendies || UTType(filenameExtension: ext)?.conforms(to: .image) == true else {
                    throw DocumentImportError.unsupportedWallpaper
                }
                if !isEncrypted && staged.byteCount > Int64(DocumentImportService.wallpaperLimit) {
                    throw DocumentImportError.tooLarge(DocumentImportService.wallpaperLimit)
                }
                let encryptedHash: String?
                if isEncrypted {
                    encryptedHash = try await Task.detached(priority: .userInitiated) {
                        try EncryptedTendiesEnvelope(contentsOf: staged.url).sha256
                    }.value
                } else {
                    encryptedHash = nil
                }
                let candidates = (library + added).filter {
                    $0.displayName == staged.displayName && $0.byteCount == staged.byteCount
                }
                let existing: ImportedWallpaper?
                if let encryptedHash {
                    let directory = libraryDirectory
                    // A fresh encryption has a new package ID/key but usually
                    // the same filename and length. Reuse only identical bytes,
                    // never a different or previously revoked encrypted package.
                    existing = await Task.detached(priority: .userInitiated) {
                        candidates.first { candidate in
                            guard candidate.kind == .encryptedTendies else { return false }
                            let url = directory.appendingPathComponent(candidate.storedFilename)
                            return (try? EncryptedTendiesEnvelope(contentsOf: url).sha256) == encryptedHash
                        }
                    }.value
                } else {
                    existing = candidates.first
                }
                if let existing {
                    duplicates += 1
                    available.append(existing)
                    continue
                }
                if !isTendies && UIImage(contentsOfFile: staged.url.path) == nil {
                    throw DocumentImportError.invalidImage
                }
                let id = UUID()
                let record = ImportedWallpaper(id: id, displayName: staged.displayName,
                    storedFilename: id.uuidString + "." + ext,
                    kind: isEncrypted ? .encryptedTendies : isTendies ? .tendies : .image,
                    addedAt: Date(), byteCount: staged.byteCount)
                try FileManager.default.copyItem(at: staged.url, to: fileURL(for: record))
                added.append(record)
                available.append(record)
            } catch { failures.append("\(url.lastPathComponent): \(error.localizedDescription)") }
        }
        do {
            let next = Array(added.reversed()) + library
            try JSONEncoder().encode(next).write(to: indexURL, options: .atomic)
            library = next
            var summary = "Đã nhập \(added.count) tệp."
            if duplicates > 0 { summary += " Bỏ qua \(duplicates) tệp trùng tên và kích thước." }
            if !failures.isEmpty { summary += "\n" + failures.joined(separator: "\n") }
            message = summary
            return available
        } catch {
            for item in added { try? FileManager.default.removeItem(at: fileURL(for: item)) }
            message = "Chưa lưu được thư viện: \(error.localizedDescription)"
            return []
        }
    }

    func openInLibrary(_ item: ImportedWallpaper) {
        selectedTab = .library
        pendingLibraryPreview = item.id
    }

    func removeImported(ids: Set<UUID>) {
        guard !isInstallingWallpaper else { message = "Hãy chờ cài hình nền hoàn tất trước khi xóa tệp."; return }
        guard !ids.isEmpty else { return }
        let removed = library.filter { ids.contains($0.id) }
        let kept = library.filter { !ids.contains($0.id) }
        do {
            // Commit the visible index before reclaiming the corresponding files.
            try JSONEncoder().encode(kept).write(to: indexURL, options: .atomic)
            library = kept
            var failedCleanup = 0
            for item in removed {
                do { try FileManager.default.removeItem(at: fileURL(for: item)) }
                catch { failedCleanup += 1 }
            }
            message = "Đã xóa \(removed.count) tệp khỏi thư viện." + (failedCleanup > 0 ? " Có tệp chưa dọn được trên bộ nhớ." : "")
        } catch { message = "Chưa xóa được thư viện: \(error.localizedDescription)" }
    }

    func saveToPhotos(_ item: WallpaperItem) async {
        refreshDailyAccess()
        guard isUnlocked else { message = "Xem đủ 5 quảng cáo mô phỏng để lưu hình nền trong hôm nay."; return }
        guard let image = wallpaperImage(named: item.imageName) else { message = "Không tìm thấy ảnh trong ứng dụng."; return }
        await saveImage(image)
    }

    func saveImportedToPhotos(_ item: ImportedWallpaper) async {
        guard item.kind == .image, let image = UIImage(contentsOfFile: fileURL(for: item).path) else {
            message = "Tệp Tendies dùng nút Cài hình nền; không thể lưu trực tiếp như ảnh."; return
        }
        await saveImage(image)
    }

    private func saveImage(_ image: UIImage) async {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else {
            message = "Hãy cho phép Dynor thêm ảnh trong Cài đặt → Quyền riêng tư → Ảnh."
            return
        }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAsset(from: image)
            }
            message = "Đã lưu vào Ảnh. Mở Ảnh → Chia sẻ → Dùng làm hình nền để cài."
        } catch { message = "Chưa lưu được ảnh: \(error.localizedDescription)" }
    }
}

// A stable hexadecimal palette value shared by the theme picker and UI.
extension Color {
    init(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        guard cleaned.count == 6, let value = UInt64(cleaned, radix: 16) else {
            self = Color(red: 0.20, green: 0.47, blue: 0.96); return
        }
        self = Color(red: Double((value >> 16) & 255) / 255,
                     green: Double((value >> 8) & 255) / 255,
                     blue: Double(value & 255) / 255)
    }
}

extension DynorStore {
    func localized(_ vi: String, _ en: String, _ zh: String) -> String {
        switch appLanguage {
        case "en": return en
        case "zh", "zh-Hans": return zh
        default: return vi
        }
    }
}
