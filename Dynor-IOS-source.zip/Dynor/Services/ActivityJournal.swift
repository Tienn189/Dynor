import Foundation

struct DynorActivity: Codable, Identifiable {
    let id: UUID
    let date: Date
    let title: String
    let detail: String
    let success: Bool
}

@MainActor
final class ActivityJournal: ObservableObject {
    static let shared = ActivityJournal()
    @Published private(set) var entries: [DynorActivity] = []
    private let key = "dynor.activity.history.v1"
    private init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let items = try? JSONDecoder().decode([DynorActivity].self, from: data) { entries = items }
    }
    func add(_ title: String, detail: String, success: Bool) {
        entries.insert(DynorActivity(id: UUID(), date: Date(), title: title, detail: detail, success: success), at: 0)
        entries = Array(entries.prefix(150))
        if let data = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(data, forKey: key) }
    }
    func clear() {
        entries.removeAll()
        UserDefaults.standard.removeObject(forKey: key)
    }
}
