import Foundation
import CryptoKit

/// .dynor v1: magic(8) || package UUID(16) || GCM nonce(12) || ciphertext || tag(16).
/// The first 24 bytes are authenticated; keys are never part of the package.
struct EncryptedTendiesEnvelope {
    static let magic = Data("DYNORT01".utf8)
    static let headerSize = 24
    static let overhead = headerSize + 12 + 16
    static let maximumPlaintextBytes = 50 * 1024 * 1024
    static let maximumFileBytes = maximumPlaintextBytes + overhead

    let packageID: UUID
    let header: Data
    let sealedData: Data
    let sha256: String

    init(data: Data) throws {
        guard data.count > Self.overhead, data.count <= Self.maximumFileBytes,
              data.prefix(Self.magic.count) == Self.magic else {
            throw EncryptedTendiesError.invalidPackage
        }
        let uuid = [UInt8](data[8..<Self.headerSize])
        packageID = UUID(uuid: (uuid[0], uuid[1], uuid[2], uuid[3], uuid[4], uuid[5], uuid[6], uuid[7],
                                uuid[8], uuid[9], uuid[10], uuid[11], uuid[12], uuid[13], uuid[14], uuid[15]))
        header = Data(data.prefix(Self.headerSize))
        sealedData = Data(data.dropFirst(Self.headerSize))
        sha256 = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    init(contentsOf url: URL) throws {
        guard url.isFileURL else { throw EncryptedTendiesError.invalidPackage }
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var data = Data()
        while let chunk = try handle.read(upToCount: 64 * 1024), !chunk.isEmpty {
            guard data.count + chunk.count <= Self.maximumFileBytes else {
                throw EncryptedTendiesError.invalidPackage
            }
            data.append(chunk)
        }
        try self.init(data: data)
    }

    static func header(for packageID: UUID) -> Data {
        var uuid = packageID.uuid
        var data = magic
        withUnsafeBytes(of: &uuid) { data.append(contentsOf: $0) }
        return data
    }

    func decrypt(using key: SymmetricKey) throws -> Data {
        guard key.bitCount == 256 else { throw EncryptedTendiesError.invalidPackage }
        let plaintext: Data
        do {
            let box = try AES.GCM.SealedBox(combined: sealedData)
            plaintext = try AES.GCM.open(box, using: key, authenticating: header)
        } catch {
            throw EncryptedTendiesError.invalidPackage
        }
        guard !plaintext.isEmpty, plaintext.count <= Self.maximumPlaintextBytes,
              Self.isZIP(plaintext) else { throw EncryptedTendiesError.invalidPackage }
        // ZIP paths, expansion, CRCs and PosterBoard descriptors are still verified
        // by TendiesArchiveValidator before any native write.
        return plaintext
    }

    private static func isZIP(_ data: Data) -> Bool {
        data.starts(with: [0x50, 0x4b, 0x03, 0x04]) || data.starts(with: [0x50, 0x4b, 0x05, 0x06])
    }
}

enum EncryptedTendiesError: LocalizedError {
    case invalidPackage
    case loginRequired
    case permissionDenied
    case unavailablePackage
    case rateLimited
    case serviceUnavailable
    case invalidServerResponse
    case secureEnclaveUnavailable
    case keyStorage

    var errorDescription: String? {
        switch self {
        case .invalidPackage: return "Gói .dynor bị hỏng, bị thay đổi hoặc không đúng định dạng. Hãy tải lại từ nguồn của bạn."
        case .loginRequired: return "Đăng nhập tài khoản Dynor trong Cài đặt trước khi cài gói mã hóa."
        case .permissionDenied: return "Tài khoản chưa có quyền mở gói này. Kiểm tra quyền truy cập hoặc VIP của bạn."
        case .unavailablePackage: return "Gói mã hóa chưa được đăng ký hoặc đã ngừng cấp quyền."
        case .rateLimited: return "Bạn đã yêu cầu mở gói quá nhiều lần. Hãy chờ một phút rồi thử lại."
        case .serviceUnavailable: return "Dịch vụ cấp khóa chưa sẵn sàng. Kiểm tra kết nối mạng hoặc liên hệ quản trị Dynor."
        case .invalidServerResponse: return "Không xác minh được khóa do máy chủ trả về. Đã dừng cài đặt."
        case .secureEnclaveUnavailable: return "Thiết bị này không hỗ trợ khóa bảo vệ cần thiết để mở gói .dynor."
        case .keyStorage: return "Không truy cập được khóa bảo vệ trên thiết bị. Hãy mở khóa iPhone rồi thử lại."
        }
    }
}

/// The server wraps a content key for this installation's P-256 recipient key.
struct EncryptedTendiesKeyResponse: Decodable {
    let ephemeralPublicKey: String
    let salt: String
    let wrappedKey: String

    enum CodingKeys: String, CodingKey {
        case ephemeralPublicKey = "ephemeral_public_key"
        case salt
        case wrappedKey = "wrapped_key"
    }

    func publicKey() throws -> P256.KeyAgreement.PublicKey {
        guard let data = Data(base64Encoded: ephemeralPublicKey), data.count == 65, data.first == 4 else {
            throw EncryptedTendiesError.invalidServerResponse
        }
        do { return try P256.KeyAgreement.PublicKey(x963Representation: data) }
        catch { throw EncryptedTendiesError.invalidServerResponse }
    }

    func unwrap(sharedSecret: SharedSecret, header: Data) throws -> SymmetricKey {
        guard header.count == EncryptedTendiesEnvelope.headerSize,
              let saltData = Data(base64Encoded: salt), saltData.count == 16,
              let wrappedData = Data(base64Encoded: wrappedKey), wrappedData.count == 60 else {
            throw EncryptedTendiesError.invalidServerResponse
        }
        let wrappingKey = sharedSecret.hkdfDerivedSymmetricKey(
            using: SHA256.self, salt: saltData, sharedInfo: Data("DynorContentKey/v1".utf8), outputByteCount: 32)
        var keyBytes: Data
        do {
            keyBytes = try AES.GCM.open(AES.GCM.SealedBox(combined: wrappedData),
                                       using: wrappingKey, authenticating: header)
        } catch { throw EncryptedTendiesError.invalidServerResponse }
        defer { keyBytes.resetBytes(in: 0..<keyBytes.count) }
        guard keyBytes.count == 32 else { throw EncryptedTendiesError.invalidServerResponse }
        return SymmetricKey(data: keyBytes)
    }
}
