import Foundation
import Darwin

/// Owns the worse_query lifetime for the single container Dynor needs.
/// Call only on the installer's serialized queue: upstream temporarily replaces
/// the dedicated App Group's Caches directory while issuing each token.
enum PosterBoardAccess {
    private static let bundleIdentifier = "com.apple.PosterBoard"
    private static let cachedContainerKey = "dynor.posterboard.verifiedContainer"
    private static let roots = [
        "/var/mobile/Containers/Data/Application",
        "/var/mobile/Containers/Data/InternalDaemon"
    ]

    struct AccessError: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }

    private struct Match<Value> { let value: Value }

    @MainActor
    static func requestOpenPosterBoard() -> Bool {
        #if targetEnvironment(simulator)
        return false
        #else
        return dynor_open_posterboard()
        #endif
    }

    static var prerequisiteWarning: String? {
        #if targetEnvironment(simulator)
        return "Simulator không có PosterBoard của iPhone. Hãy cài IPA được ký với App Group hợp lệ lên thiết bị thật."
        #else
        do { _ = try configuredGroup(); return nil }
        catch { return error.localizedDescription }
        #endif
    }

    /// The closure runs while the verified PosterBoard container token is held.
    /// This verifies access and identity, not that iOS applied a wallpaper.
    static func withAccess<T>(toPosterBoard body: (URL) throws -> T,
                              log: (String) -> Void = { _ in }) throws -> T {
        #if targetEnvironment(simulator)
        throw AccessError(message: prerequisiteWarning ?? "Cần iPhone thật.")
        #else
        let group = try configuredGroup()
        guard let groupRoot = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
            throw AccessError(message: "App Group không còn truy cập được. Hãy mở lại Dynor và kiểm tra chữ ký IPA.")
        }
        // Upstream uses Library/Caches for its temporary symlink. A newly
        // provisioned group may not yet have Library, so create it beforehand.
        try FileManager.default.createDirectory(at: groupRoot.appendingPathComponent("Library"), withIntermediateDirectories: true)
        var hints = [String]()
        if let cached = UserDefaults.standard.string(forKey: cachedContainerKey) { hints.append(cached) }
        if let hint = dynor_posterboard_container_hint() { hints.append(hint) }
        var visited = Set<String>()
        var lastNativeFailure: Int64?

        func attempt(_ path: String) throws -> Match<T>? {
            guard let container = validatedContainerURL(path), visited.insert(container.path).inserted else { return nil }
            // create_dir=true bypasses lstat before a token is acquired: sandbox
            // denial cannot be mistaken for a nonexistent container.
            let handle = worse_query(container.path, group, false, true)
            guard handle >= 0 else {
                lastNativeFailure = handle
                // These failures are independent of the candidate container.
                // Stop rather than spending minutes scanning an unusable route.
                if [-1, -2, -3, -4].contains(handle) {
                    throw AccessError(message: "Không khởi tạo được quyền truy cập PosterBoard (worse_query \(handle)). Kiểm tra App Group, chữ ký IPA và phiên bản iOS; Dynor chưa ghi hình nền.")
                }
                return nil
            }
            defer { worse_query_release(handle) }
            guard try identity(at: container) == bundleIdentifier else { return nil }
            UserDefaults.standard.set(container.path, forKey: cachedContainerKey)
            log("Đã xác minh container com.apple.PosterBoard trên thiết bị.")
            return try Match(value: body(container))
        }

        for hint in hints {
            if let result = try attempt(hint) { return result.value }
        }
        UserDefaults.standard.removeObject(forKey: cachedContainerKey)
        let inode = try baselineInode()
        log("Đang tìm container PosterBoard trên thiết bị; lần đầu có thể mất vài phút (giới hạn inode \(inode)).")
        for root in roots {
            // pathleak can return /private/var paths. Normalize and reject every
            // result outside the allowlisted roots before requesting access.
            // APFS commonly reports canonical /private/var paths; try that
            // spelling first because pristine pathleak compares literal prefixes.
            for spelling in ["/private" + root, root] {
                let paths = pathleak(spelling, inode) ?? []
                for path in paths {
                    if let result = try attempt(path) { return result.value }
                }
                if !paths.isEmpty { break }
            }
        }
        let detail = lastNativeFailure.map { " " + nativeFailureDescription($0) } ?? ""
        throw AccessError(message: "Không tìm được container PosterBoard có danh tính hợp lệ. Mở Cài đặt → Hình nền một lần, giữ iPhone mở khóa rồi thử lại. Kiểm tra App Group trong chữ ký và phiên bản iOS.\(detail)")
        #endif
    }

    private static func nativeFailureDescription(_ code: Int64) -> String {
        switch code {
        case -255: return "worse_query: đường dẫn không tồn tại (-255)."
        case -1: return "worse_query: App Group không truy cập được (-1); kiểm tra provisioning profile."
        case -2: return "worse_query: API native không khả dụng trên bản iOS này (-2)."
        case -3: return "worse_query: không tạo được truy vấn container (-3)."
        case -4: return "worse_query: không chuẩn bị được thư mục cache của App Group (-4)."
        case -5: return "worse_query: hệ thống từ chối truy vấn container (-5)."
        case -6: return "worse_query: hệ thống không cấp quyền truy cập container (-6)."
        default: return "worse_query trả mã \(code); chưa có quyền truy cập hợp lệ."
        }
    }

    private static func configuredGroup() throws -> String {
        guard let group = Bundle.main.object(forInfoDictionaryKey: "DynorAppGroupIdentifier") as? String,
              group.hasPrefix("group."), group.count > 6, !group.contains("$(") else {
            throw AccessError(message: "Build chưa cấu hình DynorAppGroupIdentifier. Dùng project.yml và hướng dẫn BUILD_IPA.md đi kèm.")
        }
        guard let groups = dynor_signed_app_groups() else {
            throw AccessError(message: "Không đọc được App Groups từ chữ ký IPA. Hãy ký bằng provisioning profile có App Group dành riêng cho Dynor.")
        }
        // Some signers rewrite group IDs. Only accept a dedicated group that
        // includes this app's bundle identifier; never touch arbitrary shared
        // groups because upstream replaces the group's Caches directory.
        let ownBundle = Bundle.main.bundleIdentifier ?? "com.dynor.wallpapers"
        let selected = groups.contains(group) ? group : groups.first { identifier in
            identifier.hasPrefix("group.") && identifier.contains(ownBundle)
        }
        guard let selected else {
            throw AccessError(message: "Chữ ký IPA thiếu App Group \(group). Bật App Groups cho com.dynor.wallpapers, tạo lại provisioning profile và ký lại IPA; chỉ thêm entitlement vào source chưa đủ.")
        }
        guard let root = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: selected),
              FileManager.default.isWritableFile(atPath: root.path) else {
            throw AccessError(message: "Không truy cập được App Group \(selected) trong chữ ký hiện tại. Kiểm tra provisioning profile và cài lại IPA.")
        }
        return selected
    }

    static func validatedContainerURL(_ path: String) -> URL? {
        let normalized = path.hasPrefix("/private/var/") ? String(path.dropFirst(8)) : path
        let components = (normalized as NSString).standardizingPath
        guard roots.contains(where: { components.hasPrefix($0 + "/") }) else { return nil }
        let url = URL(fileURLWithPath: components, isDirectory: true)
        guard UUID(uuidString: url.lastPathComponent) != nil,
              roots.contains(url.deletingLastPathComponent().path),
              components == normalized else { return nil }
        return url
    }

    private static func identity(at container: URL) throws -> String? {
        let attributes = try? container.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard attributes?.isDirectory == true, attributes?.isSymbolicLink != true else { return nil }
        for filename in [".com.apple.mobile_container_manager.metadata.plist", "com.apple.mobile_container_manager.metadata.plist"] {
            let metadata = container.appendingPathComponent(filename)
            if let data = try? Data(contentsOf: metadata),
               let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
               let identifier = plist["MCMMetadataIdentifier"] as? String {
                return identifier
            }
        }
        // The original worse_query PoC identifies containers using this xattr.
        // Require a complete, valid UTF-8 value rather than a prefix match.
        var buffer = [UInt8](repeating: 0, count: 1024)
        let length = container.path.withCString { path in
            buffer.withUnsafeMutableBytes { bytes in
                getxattr(path, "com.apple.containermanager.identifier", bytes.baseAddress, bytes.count, 0, 0)
            }
        }
        guard length > 0, length < buffer.count else { return nil }
        var value = Array(buffer.prefix(length))
        if value.last == 0 { value.removeLast() }
        return String(bytes: value, encoding: .utf8)
    }

    private static func baselineInode() throws -> UInt64 {
        let fm = FileManager.default
        let baseline = fm.temporaryDirectory.appendingPathComponent("dynor-poster-inode-" + UUID().uuidString)
        try Data([0]).write(to: baseline)
        defer { try? fm.removeItem(at: baseline) }
        var info = stat()
        guard baseline.path.withCString({ lstat($0, &info) }) == 0, info.st_ino > 0 else {
            throw AccessError(message: "Không xác định được giới hạn tìm container PosterBoard.")
        }
        return UInt64(info.st_ino)
    }
}
