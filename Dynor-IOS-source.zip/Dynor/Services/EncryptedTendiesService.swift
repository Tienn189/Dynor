import Foundation
import CryptoKit
import Security

struct PreparedEncryptedTendies {
    let url: URL
    let directory: URL
    func remove() { try? FileManager.default.removeItem(at: directory) }
}

/// Private, backup-excluded working directories. No decrypted archive is placed
/// in Documents, the library, Photos, a share sheet or an export provider.
enum TendiesInstallWorkspace {
    static var root: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Dynor/InstallStaging", isDirectory: true)
    }

    static func create() throws -> URL {
        let manager = FileManager.default
        try manager.createDirectory(at: root, withIntermediateDirectories: true,
                                    attributes: [.posixPermissions: 0o700, .protectionKey: FileProtectionType.complete])
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        var protectedRoot = root
        try protectedRoot.setResourceValues(values)
        let directory = root.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try manager.createDirectory(at: directory, withIntermediateDirectories: false,
                                    attributes: [.posixPermissions: 0o700, .protectionKey: FileProtectionType.complete])
        return directory
    }

    /// Called once at process launch, before an installation can begin. A crash
    /// can skip defer; remove its private working files on the next launch.
    static func removeStale() {
        try? FileManager.default.removeItem(at: root)
        let temporary = FileManager.default.temporaryDirectory
        if let files = try? FileManager.default.contentsOfDirectory(at: temporary, includingPropertiesForKeys: nil) {
            for file in files where file.lastPathComponent.hasPrefix("dynor-install-") {
                try? FileManager.default.removeItem(at: file)
            }
        }
    }
}

private final class PackageKeySessionDelegate: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        // Never forward a key-release request or account token to a redirect.
        completionHandler(nil)
    }
}

actor EncryptedTendiesService {
    static let shared = EncryptedTendiesService()
    private let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    // Supabase's publishable key identifies the project; it is not a content key.
    private let publishableKey = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    private let markerKey = "dynor.package-recipient.install-id.v1"
    private let keyService = "com.dynor.package-recipient.v1"

    func prepareForInstallation(_ source: URL) async throws -> PreparedEncryptedTendies {
        let envelope = try EncryptedTendiesEnvelope(contentsOf: source)
        try Task.checkCancellation()
        guard let token = await DynorAccountService.shared.galleryAccessToken() else {
            throw EncryptedTendiesError.loginRequired
        }
        let privateKey = try recipientKey()
        let response = try await fetchKey(envelope: envelope, token: token,
                                          publicKey: privateKey.publicKey.x963Representation)
        try Task.checkCancellation()
        let serverKey = try response.publicKey()
        let sharedSecret: SharedSecret
        do { sharedSecret = try privateKey.sharedSecretFromKeyAgreement(with: serverKey) }
        catch { throw EncryptedTendiesError.invalidServerResponse }
        let key = try response.unwrap(sharedSecret: sharedSecret, header: envelope.header)
        var plaintext = try envelope.decrypt(using: key)
        defer { plaintext.resetBytes(in: 0..<plaintext.count) }
        try Task.checkCancellation()
        let directory = try TendiesInstallWorkspace.create()
        do {
            let output = directory.appendingPathComponent("source.tendies")
            try plaintext.write(to: output, options: [.atomic, .completeFileProtection])
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: output.path)
            try Task.checkCancellation()
            return PreparedEncryptedTendies(url: output, directory: directory)
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw error
        }
    }

    private func fetchKey(envelope: EncryptedTendiesEnvelope, token: String, publicKey: Data) async throws -> EncryptedTendiesKeyResponse {
        var request = URLRequest(url: base.appendingPathComponent("functions/v1/dynor-package-key"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
        request.setValue(publishableKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "package_id": envelope.packageID.uuidString.lowercased(),
            "sha256": envelope.sha256,
            "public_key": publicKey.base64EncodedString()
        ])
        let configuration = URLSessionConfiguration.ephemeral
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 60
        let session = URLSession(configuration: configuration, delegate: PackageKeySessionDelegate(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        let (bytes, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse else { throw EncryptedTendiesError.serviceUnavailable }
        switch http.statusCode {
        case 200: break
        case 401: throw EncryptedTendiesError.loginRequired
        case 403: throw EncryptedTendiesError.permissionDenied
        case 404: throw EncryptedTendiesError.unavailablePackage
        case 409: throw EncryptedTendiesError.invalidPackage
        case 429: throw EncryptedTendiesError.rateLimited
        default: throw EncryptedTendiesError.serviceUnavailable
        }
        var data = Data()
        for try await byte in bytes {
            guard data.count < 8192 else { throw EncryptedTendiesError.invalidServerResponse }
            data.append(byte)
        }
        do { return try JSONDecoder().decode(EncryptedTendiesKeyResponse.self, from: data) }
        catch { throw EncryptedTendiesError.invalidServerResponse }
    }

    private func recipientKey() throws -> SecureEnclave.P256.KeyAgreement.PrivateKey {
        guard SecureEnclave.isAvailable else { throw EncryptedTendiesError.secureEnclaveUnavailable }
        // Keychain items survive uninstall. An installation marker in app defaults
        // prevents reusing another installation's recipient key after reinstall.
        if let marker = UserDefaults.standard.string(forKey: markerKey) {
            var query = keyQuery(account: marker)
            query[kSecReturnData as String] = true
            query[kSecMatchLimit as String] = kSecMatchLimitOne
            var result: CFTypeRef?
            let status = SecItemCopyMatching(query as CFDictionary, &result)
            if status == errSecSuccess, let data = result as? Data {
                do { return try SecureEnclave.P256.KeyAgreement.PrivateKey(dataRepresentation: data) }
                catch { throw EncryptedTendiesError.keyStorage }
            }
            guard status == errSecItemNotFound else { throw EncryptedTendiesError.keyStorage }
        }
        var accessError: Unmanaged<CFError>?
        guard let accessControl = SecAccessControlCreateWithFlags(
            nil, kSecAttrAccessibleWhenUnlockedThisDeviceOnly, .privateKeyUsage, &accessError) else {
            throw EncryptedTendiesError.keyStorage
        }
        let key: SecureEnclave.P256.KeyAgreement.PrivateKey
        do { key = try SecureEnclave.P256.KeyAgreement.PrivateKey(accessControl: accessControl) }
        catch { throw EncryptedTendiesError.keyStorage }
        let oldKeys: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keyService,
            kSecAttrSynchronizable as String: false
        ]
        let removalStatus = SecItemDelete(oldKeys as CFDictionary)
        guard removalStatus == errSecSuccess || removalStatus == errSecItemNotFound else {
            throw EncryptedTendiesError.keyStorage
        }
        let marker = UUID().uuidString
        var query = keyQuery(account: marker)
        query[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        query[kSecValueData as String] = key.dataRepresentation
        guard SecItemAdd(query as CFDictionary, nil) == errSecSuccess else {
            throw EncryptedTendiesError.keyStorage
        }
        UserDefaults.standard.set(marker, forKey: markerKey)
        return key
    }

    private func keyQuery(account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: keyService,
         kSecAttrAccount as String: account,
         kSecAttrSynchronizable as String: false]
    }
}
