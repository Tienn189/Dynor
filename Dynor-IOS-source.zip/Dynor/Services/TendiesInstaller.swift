// PosterBoard workflow informed by nxtcoreee3/Worse-Poster (GPL-3.0).
// See ThirdParty/WorsePoster and ThirdParty/WorseQuery for pinned provenance.
import Foundation

struct TendiesInstallError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

struct TendiesInstallReceipt {
    let descriptorCount: Int
    let verifiedFileCount: Int
    let posterBoardContainer: URL
}

/// All native queries and writes share one worker. No network/pairing fallback.
actor TendiesInstaller {
    static let shared = TendiesInstaller()
    private var installing = false
    private static let queue = DispatchQueue(label: "com.dynor.posterboard.install", qos: .userInitiated)

    static func supportWarning(for version: OperatingSystemVersion) -> String? {
        TendiesCompatibility.assess(version: version).warning
    }

    func install(archiveURL: URL, log: @escaping (String) -> Void,
                 progress: @escaping (Double) -> Void) async throws -> TendiesInstallReceipt {
        try Task.checkCancellation()
        guard !installing else { throw TendiesInstallError(text: "Một lượt cài hình nền đang chạy. Hãy đợi hoàn tất.") }
        if let warning = Self.supportWarning(for: ProcessInfo.processInfo.operatingSystemVersion) {
            throw TendiesInstallError(text: warning)
        }
        installing = true
        defer { installing = false }
        var decrypted: PreparedEncryptedTendies?
        if archiveURL.pathExtension.lowercased() == "dynor" {
            log("Đang xác minh quyền và mở gói mã hóa…")
            decrypted = try await EncryptedTendiesService.shared.prepareForInstallation(archiveURL)
        }
        defer { decrypted?.remove() }
        let input = decrypted?.url ?? archiveURL
        try Task.checkCancellation()
        return try await withCheckedThrowingContinuation { continuation in
            Self.queue.async {
                do { continuation.resume(returning: try Self.performInstall(archiveURL: input, log: log, progress: progress)) }
                catch { continuation.resume(throwing: error) }
            }
        }
    }

    private static func performInstall(archiveURL: URL, log: @escaping (String) -> Void,
                                       progress: @escaping (Double) -> Void) throws -> TendiesInstallReceipt {
        log("Hệ thống: \(ProcessInfo.processInfo.operatingSystemVersionString)")
        log("Backend: worse_query · cài trực tiếp, không pairing/VPN")
        let work = try TendiesInstallWorkspace.create()
        defer { try? FileManager.default.removeItem(at: work) }
        let archive = work.appendingPathComponent("source.tendies")
        try FileManager.default.copyItem(at: archiveURL, to: archive)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete, .posixPermissions: 0o600], ofItemAtPath: archive.path)
        progress(0.02)
        log("Đang kiểm tra và giải nén Tendies…")
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: archive)
        let stage = work.appendingPathComponent("extracted", isDirectory: true)
        try TendiesArchiveValidator.extract(at: archive, to: stage, entries: entries)
        try TendiesArchiveValidator.validateExtraction(at: stage, entries: entries)
        let descriptors = TendiesDescriptorCatalog.findDescriptorsWithExtensions(in: stage, defaultExt: "com.apple.WallpaperKit.CollectionsPoster")
        guard !descriptors.isEmpty else { throw TendiesInstallError(text: "Tệp không chứa cấu hình hình nền PosterBoard hợp lệ.") }
        for descriptor in descriptors {
            guard TendiesDescriptorCatalog.validExtension(descriptor.ext) else { throw TendiesInstallError(text: "Mã phần mở rộng hình nền không hợp lệ.") }
            try TendiesDescriptorCatalog.updatePlistIdentifiers(in: descriptor.url, randomizedID: Int.random(in: 100_000_000...999_999_999))
        }
        progress(0.1)
        log("Đã tìm thấy \(descriptors.count) cấu hình. Đang xác định PosterBoard…")
        return try PosterBoardAccess.withAccess(toPosterBoard: { container in
            let writer = PosterBoardDescriptorWriter(container: container)
            let count = try writer.install(descriptors: descriptors, log: log, progress: progress)
            log("Đã đọc lại và đối chiếu \(count) tệp trong \(descriptors.count) cấu hình. Chưa xác nhận iOS đã nạp hoặc chọn hình nền.")
            progress(1)
            return TendiesInstallReceipt(descriptorCount: descriptors.count, verifiedFileCount: count, posterBoardContainer: container)
        }, log: log)
    }
}
