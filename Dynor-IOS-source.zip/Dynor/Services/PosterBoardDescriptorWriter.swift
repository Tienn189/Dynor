import Foundation
import CryptoKit

/// Caller holds verified PosterBoard access for this entire transaction.
/// Adds new UUID directories; never overwrites a user's existing descriptors.
struct PosterBoardDescriptorWriter {
    let container: URL
    private let fm = FileManager.default

    func install(descriptors: [(ext: String, url: URL)], log: (String) -> Void,
                 progress: (Double) -> Void) throws -> Int {
        guard !descriptors.isEmpty else { throw failure("Không có cấu hình để ghi.") }
        let extensions = try extensionsDirectory()
        var additions: [URL] = []
        var files = 0
        do {
            for (index, descriptor) in descriptors.enumerated() {
                guard TendiesDescriptorCatalog.validExtension(descriptor.ext) else { throw failure("Mã extension không hợp lệ.") }
                // Use a provider that actually exists on this device; writing an
                // invented provider directory can succeed without ever loading.
                let aliases = TendiesDescriptorCatalog.destinationExtensions(for: descriptor.ext)
                guard let provider = try aliases.map({ extensions.appendingPathComponent($0, isDirectory: true) }).first(where: { try isDirectory($0) }) else {
                    throw failure("Thiết bị chưa có provider \(descriptor.ext). Mở bộ chọn hình nền và thử lại; gói có thể không tương thích với bản iOS này.")
                }
                let parent = provider.appendingPathComponent("descriptors", isDirectory: true)
                try assertNoSymlinks(parent)
                try fm.createDirectory(at: parent, withIntermediateDirectories: true)
                let destination = parent.appendingPathComponent(UUID().uuidString.uppercased(), isDirectory: true)
                let expected = try Self.manifest(at: descriptor.url)
                guard !expected.isEmpty else { throw failure("Cấu hình rỗng; đã dừng cài.") }
                additions.append(destination) // include partially copied directories in rollback
                try fm.copyItem(at: descriptor.url, to: destination)
                guard try Self.manifest(at: destination) == expected else { throw failure("Đọc lại dữ liệu PosterBoard không khớp với tệp nguồn.") }
                files += expected.count
                log("Đã ghi và đối chiếu cấu hình \(index + 1)/\(descriptors.count) · \(expected.count) tệp · \(provider.lastPathComponent)")
                progress(0.15 + 0.75 * Double(index + 1) / Double(descriptors.count))
            }
        } catch {
            var rollbackFailures = 0
            for url in additions.reversed() where fm.fileExists(atPath: url.path) {
                do { try fm.removeItem(at: url) } catch { rollbackFailures += 1 }
            }
            if rollbackFailures > 0 {
                throw failure("\(error.localizedDescription) Không gỡ lại được \(rollbackFailures) thư mục vừa ghi; PosterBoard có thể còn dữ liệu của lượt cài dở.")
            }
            throw failure("\(error.localizedDescription) Đã gỡ các cấu hình mới của lượt cài này.")
        }
        // This is a reload request, not proof PosterBoard honoured it. Preserve
        // all unrelated preferences; failure is reported separately from verified writes.
        do { try requestReload(); log("Đã ghi và đọc lại cờ yêu cầu PosterBoard nạp lại bộ sưu tập.") }
        catch { log("Các cấu hình đã đối chiếu, nhưng chưa yêu cầu nạp lại được: \(error.localizedDescription). Hãy khởi động lại iPhone.") }
        return files
    }

    private func extensionsDirectory() throws -> URL {
        let store = container.appendingPathComponent("Library/Application Support/PRBPosterExtensionDataStore", isDirectory: true)
        try assertNoSymlinks(store)
        let versions = try fm.contentsOfDirectory(at: store, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            .filter { Int($0.lastPathComponent) != nil }
            .sorted { (Int($0.lastPathComponent) ?? 0) > (Int($1.lastPathComponent) ?? 0) }
        for version in versions {
            let extensions = version.appendingPathComponent("Extensions", isDirectory: true)
            if try isDirectory(extensions) { return extensions }
        }
        throw failure("PosterBoard chưa tạo kho Extensions. Mở Cài đặt → Hình nền → Thêm hình nền mới một lần rồi thử lại.")
    }

    private func isDirectory(_ url: URL) throws -> Bool {
        try assertNoSymlinks(url)
        var directory: ObjCBool = false
        return fm.fileExists(atPath: url.path, isDirectory: &directory) && directory.boolValue
    }

    private func assertNoSymlinks(_ url: URL) throws {
        let root = container.standardizedFileURL.path
        var current = url.standardizedFileURL
        guard current.path.hasPrefix(root + "/") || current.path == root else { throw failure("Đường dẫn ngoài PosterBoard.") }
        while current.path != root {
            if let values = try? current.resourceValues(forKeys: [.isSymbolicLinkKey]), values.isSymbolicLink == true {
                throw failure("Đường dẫn PosterBoard chứa liên kết tượng trưng; đã dừng.")
            }
            current.deleteLastPathComponent()
        }
    }

    private func requestReload() throws {
        let preferences = container.appendingPathComponent("Library/Preferences", isDirectory: true)
        try assertNoSymlinks(preferences)
        try fm.createDirectory(at: preferences, withIntermediateDirectories: true)
        let url = preferences.appendingPathComponent("com.apple.PosterBoard.unprotectedUserDefaults.plist")
        try assertNoSymlinks(url)
        var values: [String: Any] = [:]
        if fm.fileExists(atPath: url.path) {
            guard let dictionary = try PropertyListSerialization.propertyList(from: Data(contentsOf: url), format: nil) as? [String: Any] else { throw failure("Tùy chọn PosterBoard không phải dictionary; giữ nguyên tệp.") }
            values = dictionary
        }
        values["PBF_RESET_FILE_PROTECTIONS"] = true
        values["PBF_LOCALE_DID_CHANGE"] = true
        let data = try PropertyListSerialization.data(fromPropertyList: values, format: .binary, options: 0)
        try data.write(to: url, options: .atomic)
        guard try Data(contentsOf: url) == data else { throw failure("Chưa xác minh được cờ nạp lại.") }
    }

    /// Hash the full relative file set, not just file sizes or directory existence.
    static func manifest(at directory: URL) throws -> [String: Data] {
        let fm = FileManager.default
        var enumerationError: Error?
        guard try directory.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey]).isDirectory == true,
              try directory.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink != true,
              let enumerator = fm.enumerator(at: directory, includingPropertiesForKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey], errorHandler: { _, error in
                  enumerationError = error
                  return false
              }) else {
            throw TendiesInstallError(text: "Không đọc được thư mục cấu hình.")
        }
        var output: [String: Data] = [:]
        for case let file as URL in enumerator {
            let values = try file.resourceValues(forKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { throw TendiesInstallError(text: "Cấu hình có liên kết tượng trưng.") }
            if values.isDirectory == true { continue }
            guard values.isRegularFile == true else { throw TendiesInstallError(text: "Cấu hình có tệp đặc biệt.") }
            let relative = String(file.path.dropFirst(directory.path.count + 1))
            let input = try FileHandle(forReadingFrom: file)
            defer { try? input.close() }
            var hash = SHA256()
            while let chunk = try input.read(upToCount: 64 * 1024), !chunk.isEmpty { hash.update(data: chunk) }
            output[relative] = Data(hash.finalize())
        }
        if let error = enumerationError { throw error }
        return output
    }

    private func failure(_ text: String) -> TendiesInstallError { TendiesInstallError(text: text) }
}
