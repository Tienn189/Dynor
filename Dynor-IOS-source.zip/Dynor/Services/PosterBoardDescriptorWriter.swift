import Foundation
import CryptoKit
import UIKit

/// Caller holds verified PosterBoard access for this entire transaction.
/// Adds new UUID directories; never overwrites a user's existing descriptors.
struct PosterBoardDescriptorWriter {
    let container: URL
    private let fm = FileManager.default
    private static let ledgerKey = "dynor.posterboard.managedDescriptors.v1"

    static func installedPaths() -> [String] {
        UserDefaults.standard.stringArray(forKey: ledgerKey) ?? []
    }

    static func previewImages(paths: [String]) -> [String: UIImage] {
        var output: [String: UIImage] = [:]
        let managed = Set(installedPaths())
        _ = try? PosterBoardAccess.withAccess(toPosterBoard: { container in
            let root = container.standardizedFileURL.path
            for path in paths where managed.contains(path) {
                let directory = URL(fileURLWithPath: path).standardizedFileURL
                guard directory.path.hasPrefix(root + "/Library/Application Support/PRBPosterExtensionDataStore/"),
                      directory.deletingLastPathComponent().lastPathComponent == "descriptors",
                      UUID(uuidString: directory.lastPathComponent) != nil else { continue }
                guard let files = FileManager.default.enumerator(at: directory,
                    includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey, .isSymbolicLinkKey]) else { continue }
                var inspected = 0
                for case let url as URL in files {
                    inspected += 1
                    if inspected > 300 { break }
                    guard ["png", "jpg", "jpeg", "heic"].contains(url.pathExtension.lowercased()),
                          let attributes = try? url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey, .isSymbolicLinkKey]),
                          attributes.isRegularFile == true, attributes.isSymbolicLink != true,
                          (attributes.fileSize ?? 0) <= 12_000_000,
                          let data = try? Data(contentsOf: url),
                          let image = UIImage(data: data) else { continue }
                    output[path] = image
                    break
                }
            }
        })
        return output
    }

    static func removeManaged(paths: [String], log: (String) -> Void = { _ in }) throws -> Int {
        var removed = 0
        try PosterBoardAccess.withAccess(toPosterBoard: { container in
            let known = Set(installedPaths())
            let root = container.standardizedFileURL.path
            for path in paths where known.contains(path) {
                let url = URL(fileURLWithPath: path).standardizedFileURL
                // Only UUID descriptor folders beneath PosterBoard may be deleted.
                guard url.path.hasPrefix(root + "/Library/Application Support/PRBPosterExtensionDataStore/"),
                      url.deletingLastPathComponent().lastPathComponent == "descriptors",
                      UUID(uuidString: url.lastPathComponent) != nil else { continue }
                if FileManager.default.fileExists(atPath: url.path) {
                    try FileManager.default.removeItem(at: url)
                }
                removed += 1
                log("Đã gỡ mục Dynor: \(url.lastPathComponent)")
            }
        }, log: log)
        let removedPaths = Set(paths)
        UserDefaults.standard.set(installedPaths().filter { !removedPaths.contains($0) }, forKey: ledgerKey)
        return removed
    }


    func install(descriptors: [(ext: String, url: URL)], log: (String) -> Void,
                 progress: (Double) -> Void) throws -> Int {
        guard !descriptors.isEmpty else { throw failure("Không có cấu hình để ghi.") }
        let extensions = try extensionsDirectory()
        var additions: [URL] = []
        // Stage complete descriptors outside the live PosterBoard descriptor list.
        // This avoids exposing half-copied wallpapers while iOS refreshes thumbnails.
        let stagingRoot = container.appendingPathComponent("Library/Caches/DynorDescriptorStaging/" + UUID().uuidString, isDirectory: true)
        try assertNoSymlinks(stagingRoot)
        try fm.createDirectory(at: stagingRoot, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: stagingRoot) }
        var files = 0
        do {
            for (index, descriptor) in descriptors.enumerated() {
                guard TendiesDescriptorCatalog.validExtension(descriptor.ext) else { throw failure("Mã extension không hợp lệ.") }
                // Use a provider that actually exists on this device; writing an
                // invented provider directory can succeed without ever loading.
                let aliases = TendiesDescriptorCatalog.destinationExtensions(for: descriptor.ext)
                guard let provider = try aliases.map({ extensions.appendingPathComponent($0, isDirectory: true) }).first(where: { try isDirectory($0) }) else {
                    throw failure("Thiết bị chưa có provider \(descriptor.ext). Mở bộ chọn hình nền và thử lại; gói có thể không tương thích với bản iOS này.")
                }
                let parent = provider.appendingPathComponent("descriptors", isDirectory: true)
                try assertNoSymlinks(parent)
                try fm.createDirectory(at: parent, withIntermediateDirectories: true)
                let destination = parent.appendingPathComponent(UUID().uuidString.uppercased(), isDirectory: true)
                // The validated archive is extracted into a private workspace.
                // Take one immutable snapshot and compare it with the published copy.
                // Re-reading a coordinated source while copying caused false mismatch errors.
                let staged = stagingRoot.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try fm.copyItem(at: descriptor.url, to: staged)
                let expected = try Self.manifest(at: staged)
                guard !expected.isEmpty else { throw failure("Cấu hình sao chép rỗng; đã dừng cài.") }
                // Same-container rename publishes a complete directory in one operation.
                try fm.moveItem(at: staged, to: destination)
                additions.append(destination)
                guard try Self.manifest(at: destination) == expected else { throw failure("Đọc lại dữ liệu PosterBoard không khớp với tệp nguồn.") }
                files += expected.count
                log("Đã ghi và đối chiếu cấu hình \(index + 1)/\(descriptors.count) · \(expected.count) tệp · \(provider.lastPathComponent)")
                progress(0.15 + 0.75 * Double(index + 1) / Double(descriptors.count))
            }
        } catch {
            var rollbackFailures = 0
            for url in additions.reversed() where fm.fileExists(atPath: url.path) {
                do { try fm.removeItem(at: url) } catch { rollbackFailures += 1 }
            }
            if rollbackFailures > 0 {
                throw failure("\(error.localizedDescription) Không gỡ lại được \(rollbackFailures) thư mục vừa ghi; PosterBoard có thể còn dữ liệu của lượt cài dở.")
            }
            throw failure("\(error.localizedDescription) Đã gỡ các cấu hình mới của lượt cài này.")
        }
        // This is a reload request, not proof PosterBoard honoured it. Preserve
        // all unrelated preferences; failure is reported separately from verified writes.
        do { try requestReload(); log("Đã ghi và đọc lại cờ yêu cầu PosterBoard nạp lại bộ sưu tập.") }
        catch { log("Các cấu hình đã đối chiếu, nhưng chưa yêu cầu nạp lại được: \(error.localizedDescription). Hãy khởi động lại iPhone.") }
        // Persist only successfully verified additions. Existing system wallpapers stay untouched.
        let previous = Self.installedPaths()
        UserDefaults.standard.set(Array(Set(previous + additions.map(\.path))).sorted(), forKey: Self.ledgerKey)
        return files
    }

    private func extensionsDirectory() throws -> URL {
        let store = container.appendingPathComponent("Library/Application Support/PRBPosterExtensionDataStore", isDirectory: true)
        try assertNoSymlinks(store)
        let versions = try fm.contentsOfDirectory(at: store, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            .filter { Int($0.lastPathComponent) != nil }
            .sorted { (Int($0.lastPathComponent) ?? 0) > (Int($1.lastPathComponent) ?? 0) }
        for version in versions {
            let extensions = version.appendingPathComponent("Extensions", isDirectory: true)
            if try isDirectory(extensions) { return extensions }
        }
        throw failure("PosterBoard chưa tạo kho Extensions. Mở Cài đặt → Hình nền → Thêm hình nền mới một lần rồi thử lại.")
    }

    private func isDirectory(_ url: URL) throws -> Bool {
        try assertNoSymlinks(url)
        var directory: ObjCBool = false
        return fm.fileExists(atPath: url.path, isDirectory: &directory) && directory.boolValue
    }

    private func assertNoSymlinks(_ url: URL) throws {
        let root = container.standardizedFileURL.path
        var current = url.standardizedFileURL
        guard current.path.hasPrefix(root + "/") || current.path == root else { throw failure("Đường dẫn ngoài PosterBoard.") }
        while current.path != root {
            if let values = try? current.resourceValues(forKeys: [.isSymbolicLinkKey]), values.isSymbolicLink == true {
                throw failure("Đường dẫn PosterBoard chứa liên kết tượng trưng; đã dừng.")
            }
            current.deleteLastPathComponent()
        }
    }

    private func requestReload() throws {
        let preferences = container.appendingPathComponent("Library/Preferences", isDirectory: true)
        try assertNoSymlinks(preferences)
        try fm.createDirectory(at: preferences, withIntermediateDirectories: true)
        let url = preferences.appendingPathComponent("com.apple.PosterBoard.unprotectedUserDefaults.plist")
        try assertNoSymlinks(url)
        var values: [String: Any] = [:]
        if fm.fileExists(atPath: url.path) {
            guard let dictionary = try PropertyListSerialization.propertyList(from: Data(contentsOf: url), format: nil) as? [String: Any] else { throw failure("Tùy chọn PosterBoard không phải dictionary; giữ nguyên tệp.") }
            values = dictionary
        }
        values["PBF_RESET_FILE_PROTECTIONS"] = true
        values["PBF_LOCALE_DID_CHANGE"] = true
        let data = try PropertyListSerialization.data(fromPropertyList: values, format: .binary, options: 0)
        try data.write(to: url, options: .atomic)
        guard try Data(contentsOf: url) == data else { throw failure("Chưa xác minh được cờ nạp lại.") }
    }

    /// Hash the full relative file set, not just file sizes or directory existence.
    static func manifest(at directory: URL) throws -> [String: Data] {
        let fm = FileManager.default
        var enumerationError: Error?
        guard try directory.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey]).isDirectory == true,
              try directory.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink != true,
              let enumerator = fm.enumerator(at: directory, includingPropertiesForKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey], errorHandler: { _, error in
                  enumerationError = error
                  return false
              }) else {
            throw TendiesInstallError(text: "Không đọc được thư mục cấu hình.")
        }
        var output: [String: Data] = [:]
        for case let file as URL in enumerator {
            let values = try file.resourceValues(forKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { throw TendiesInstallError(text: "Cấu hình có liên kết tượng trưng.") }
            if values.isDirectory == true { continue }
            guard values.isRegularFile == true else { throw TendiesInstallError(text: "Cấu hình có tệp đặc biệt.") }
            let relative = String(file.path.dropFirst(directory.path.count + 1))
            let input = try FileHandle(forReadingFrom: file)
            defer { try? input.close() }
            var hash = SHA256()
            while let chunk = try input.read(upToCount: 64 * 1024), !chunk.isEmpty { hash.update(data: chunk) }
            output[relative] = Data(hash.finalize())
        }
        if let error = enumerationError { throw error }
        return output
    }

    private func failure(_ text: String) -> TendiesInstallError { TendiesInstallError(text: text) }
}
