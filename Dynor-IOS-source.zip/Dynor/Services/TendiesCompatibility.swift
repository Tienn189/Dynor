import Foundation

/// Permission to attempt the on-device backend; never a claim of device testing.
enum TendiesCompatibility {
    struct Assessment {
        let warning: String?
        let detail: String
        var canAttemptInstall: Bool { warning == nil }
    }

    static let summary = "Cài trực tiếp qua worse_query: upstream công bố iOS 26.0–26.7.2 / 27.2. Không cần pairing, VPN hay ứng dụng hỗ trợ. IPA phải được ký với App Group hợp lệ."

    static var current: Assessment { assess(version: ProcessInfo.processInfo.operatingSystemVersion) }

    static func assess(version: OperatingSystemVersion) -> Assessment {
        let supported: Bool
        switch version.majorVersion {
        case 26:
            supported = version.minorVersion < 7 || (version.minorVersion == 7 && version.patchVersion <= 2)
        case 27:
            supported = version.minorVersion < 2 || (version.minorVersion == 2 && version.patchVersion == 0)
        default:
            supported = false
        }
        let warning = supported ? nil : "Bản iOS này nằm ngoài phạm vi worse_query được tích hợp (26.0–26.7.2, 27.0–27.2.0). Bạn vẫn có thể nhập tệp; Dynor không thử ghi PosterBoard trên bản này."
        return Assessment(warning: warning,
                          detail: warning ?? "Có thể thử cài trực tiếp trên bản iOS này theo phạm vi upstream. Dynor sẽ kiểm tra App Group, quyền truy cập PosterBoard và đọc lại từng tệp đã ghi. Chưa có xác nhận Dynor chạy thành công trên thiết bị này.")
    }
}
