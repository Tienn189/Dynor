import SwiftUI

@main
@MainActor
struct DynorApp: App {
    @StateObject private var store = DynorStore()
    @Environment(\.scenePhase) private var scenePhase

    init() {
        TendiesInstallWorkspace.removeStale()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .onOpenURL { url in
                    guard !store.isInstallingWallpaper else {
                        store.message = "Hãy chờ cài hình nền hoàn tất trước khi mở tệp khác."
                        return
                    }
                    Task {
                        store.selectedTab = .library
                        let imported = await store.importWallpapers(urls: [url])
                        if let item = imported.first {
                            store.message = nil
                            store.openInLibrary(item)
                        }
                    }
                }
                .tint(store.accentColor)
                .environment(\.locale, Locale(identifier: store.appLanguage))
                .preferredColorScheme(store.theme.colorScheme)
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active { store.refreshDailyAccess(); Task { await DynorAccountService.shared.restoreSession() } }
                }
                .task {
                    while !Task.isCancelled {
                        do { try await Task.sleep(for: .seconds(20)) }
                        catch { return }
                        store.refreshDailyAccess()
                    }
                }
        }
    }
}

private struct RootView: View {
    @EnvironmentObject private var store: DynorStore
    var body: some View {
        TabView(selection: $store.selectedTab) {
            NavigationStack { OnlineGalleryView() }
                .tabItem { Label(store.localized("Khám phá", "Explore", "探索"), systemImage: "square.grid.2x2") }
                .tag(DynorTab.discover)
            NavigationStack { LibraryView() }
                .tabItem { Label(store.localized("Bộ sưu tập", "Collection", "收藏"), systemImage: "square.stack") }
                .tag(DynorTab.library)
            NavigationStack { InstalledWallpapersView() }
                .tabItem { Label(store.localized("Thư viện", "Installed", "已安装"), systemImage: "rectangle.stack") }
                .tag(DynorTab.installed)
            SettingsView()
                .tabItem { Label(store.localized("Cài đặt", "Settings", "设置"), systemImage: "gearshape") }
                .tag(DynorTab.settings)
        }
        .tint(store.accentColor)
        .toolbarBackground(.hidden, for: .tabBar)
        .alert("Dynor", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
            Button(store.localized("Đã hiểu", "OK", "确定"), role: .cancel) { store.message = nil }
        } message: { Text(store.message ?? "") }
    }
}
