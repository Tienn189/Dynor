import SwiftUI

@main
@MainActor
struct DynorApp: App {
    @StateObject private var store = DynorStore()
    @Environment(\.scenePhase) private var scenePhase

    init() {
        TendiesInstallWorkspace.removeStale()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .onOpenURL { url in
                    guard !store.isInstallingWallpaper else {
                        store.message = "Hãy chờ cài hình nền hoàn tất trước khi mở tệp khác."
                        return
                    }
                    Task {
                        store.selectedTab = .library
                        let imported = await store.importWallpapers(urls: [url])
                        if let item = imported.first {
                            store.message = nil
                            store.openInLibrary(item)
                        }
                    }
                }
                .tint(store.accentColor)
                .environment(\.locale, Locale(identifier: store.appLanguage))
                .preferredColorScheme(store.theme.colorScheme)
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active { store.refreshDailyAccess(); Task { await DynorAccountService.shared.restoreSession() } }
                }
                .task {
                    while !Task.isCancelled {
                        do { try await Task.sleep(for: .seconds(20)) }
                        catch { return }
                        store.refreshDailyAccess()
                    }
                }
        }
    }
}

private struct RootView: View {
    @EnvironmentObject private var store: DynorStore
    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $store.selectedTab) {
                NavigationStack { OnlineGalleryView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(DynorTab.discover)
                NavigationStack { LibraryView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(DynorTab.library)
                NavigationStack { InstalledWallpapersView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(DynorTab.installed)
                SettingsView()
                    .toolbar(.hidden, for: .tabBar)
                    .tag(DynorTab.settings)
            }
            DynorTabBar()
        }
        .background { AuroraBackground() }
        .alert("Dynor", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
            Button(store.localized("Đã hiểu", "OK", "确定"), role: .cancel) { store.message = nil }
        } message: { Text(store.message ?? "") }
    }
}

/// Floating glass tab bar with a sliding accent pill.
private struct DynorTabBar: View {
    @EnvironmentObject private var store: DynorStore
    @Namespace private var pill

    private struct Entry: Identifiable {
        let tab: DynorTab
        let symbol: String
        let activeSymbol: String
        let title: String
        var id: DynorTab { tab }
    }

    private var entries: [Entry] {
        [
            Entry(tab: .discover, symbol: "safari", activeSymbol: "safari.fill",
                  title: store.localized("Khám phá", "Explore", "探索")),
            Entry(tab: .library, symbol: "square.stack.3d.up", activeSymbol: "square.stack.3d.up.fill",
                  title: store.localized("Bộ sưu tập", "Collection", "收藏")),
            Entry(tab: .installed, symbol: "square.grid.2x2", activeSymbol: "square.grid.2x2.fill",
                  title: store.localized("Thư viện", "Installed", "已安装")),
            Entry(tab: .settings, symbol: "gearshape", activeSymbol: "gearshape.fill",
                  title: store.localized("Cài đặt", "Settings", "设置"))
        ]
    }

    var body: some View {
        HStack(spacing: 2) {
            ForEach(entries) { entry in
                tabButton(entry)
            }
        }
        .padding(6)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(DynorDesign.outline, lineWidth: 1))
        .shadow(color: .black.opacity(0.28), radius: 24, y: 12)
        .padding(.horizontal, 22)
        .padding(.bottom, 6)
        .sensoryFeedback(.selection, trigger: store.selectedTab)
    }

    private func tabButton(_ entry: Entry) -> some View {
        let on = store.selectedTab == entry.tab
        return Button {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.78)) { store.selectedTab = entry.tab }
        } label: {
            HStack(spacing: 7) {
                Image(systemName: on ? entry.activeSymbol : entry.symbol)
                    .font(.system(size: 17, weight: .semibold))
                if on {
                    Text(entry.title)
                        .font(.system(size: 13, weight: .semibold))
                        .lineLimit(1)
                        .fixedSize()
                }
            }
            .foregroundStyle(on ? store.accentTextColor : Color.primary.opacity(0.6))
            .padding(.horizontal, on ? 18 : 15)
            .frame(height: 46)
            .frame(maxWidth: on ? nil : CGFloat.infinity)
            .background {
                if on {
                    Capsule()
                        .fill(LinearGradient(colors: [store.accentColor.mix(with: .white, by: 0.25), store.accentColor],
                                             startPoint: .top, endPoint: .bottom))
                        .shadow(color: store.accentColor.opacity(0.5), radius: 12, y: 4)
                        .matchedGeometryEffect(id: "pill", in: pill)
                }
            }
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(entry.title)
    }
}
