import SwiftUI

@main
@MainActor
struct DynorApp: App {
    @StateObject private var store = DynorStore()
    @Environment(\.scenePhase) private var scenePhase

    init() {
        TendiesInstallWorkspace.removeStale()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .onOpenURL { url in
                    guard !store.isInstallingWallpaper else {
                        store.message = "Hãy chờ cài hình nền hoàn tất trước khi mở tệp khác."
                        return
                    }
                    Task {
                        store.selectedTab = .library
                        let imported = await store.importWallpapers(urls: [url])
                        if let item = imported.first {
                            store.message = nil
                            store.openInLibrary(item)
                        }
                    }
                }
                .tint(store.accentColor)
                .environment(\.locale, Locale(identifier: store.appLanguage))
                .preferredColorScheme(store.theme.colorScheme)
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active { store.refreshDailyAccess(); Task { await DynorAccountService.shared.restoreSession() } }
                }
                .task {
                    while !Task.isCancelled {
                        do { try await Task.sleep(for: .seconds(20)) }
                        catch { return }
                        store.refreshDailyAccess()
                    }
                }
        }
    }
}

private struct RootView: View {
    @EnvironmentObject private var store: DynorStore
    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $store.selectedTab) {
                NavigationStack { OnlineGalleryView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(DynorTab.discover)
                NavigationStack { LibraryView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(DynorTab.library)
                NavigationStack { InstalledWallpapersView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(DynorTab.installed)
                SettingsView()
                    .toolbar(.hidden, for: .tabBar)
                    .tag(DynorTab.settings)
            }
            DynorTabBar()
        }
        .background { AuroraBackground() }
        .alert("Dynor", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
            Button(store.localized("Đã hiểu", "OK", "确定"), role: .cancel) { store.message = nil }
        } message: { Text(store.message ?? "") }
    }
}

/// Floating liquid-glass tab bar: icon over caption, with a glass "lens" sliding under the active tab.
private struct DynorTabBar: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.colorScheme) private var scheme
    @Namespace private var lens

    private struct Entry: Identifiable {
        let tab: DynorTab
        let symbol: String
        let activeSymbol: String
        let title: String
        var id: DynorTab { tab }
    }

    private var entries: [Entry] {
        [
            Entry(tab: .discover, symbol: "safari", activeSymbol: "safari.fill",
                  title: store.localized("Khám phá", "Explore", "探索")),
            Entry(tab: .library, symbol: "square.stack.3d.up", activeSymbol: "square.stack.3d.up.fill",
                  title: store.localized("Bộ sưu tập", "Collection", "收藏")),
            Entry(tab: .installed, symbol: "square.grid.2x2", activeSymbol: "square.grid.2x2.fill",
                  title: store.localized("Thư viện", "Installed", "已安装")),
            Entry(tab: .settings, symbol: "gearshape", activeSymbol: "gearshape.fill",
                  title: store.localized("Cài đặt", "Settings", "设置"))
        ]
    }

    var body: some View {
        HStack(spacing: 0) {
            ForEach(entries) { entry in
                tabButton(entry)
            }
        }
        .padding(5)
        .background {
            ZStack {
                Capsule().fill(.ultraThinMaterial)
                Capsule().fill(DynorDesign.surface)
                Capsule().fill(LinearGradient(colors: [Color.white.opacity(scheme == .dark ? 0.08 : 0.4), .clear],
                                              startPoint: .top, endPoint: UnitPoint(x: 0.5, y: 0.6)))
            }
        }
        .overlay(Capsule().strokeBorder(DynorDesign.specular(scheme), lineWidth: 0.8))
        .shadow(color: .black.opacity(scheme == .dark ? 0.45 : 0.12), radius: 26, y: 12)
        .padding(.horizontal, 24)
        .padding(.bottom, 6)
        .sensoryFeedback(.selection, trigger: store.selectedTab)
    }

    private func tabButton(_ entry: Entry) -> some View {
        let on = store.selectedTab == entry.tab
        return Button {
            withAnimation(.spring(response: 0.42, dampingFraction: 0.8)) { store.selectedTab = entry.tab }
        } label: {
            VStack(spacing: 3) {
                Image(systemName: on ? entry.activeSymbol : entry.symbol)
                    .font(.system(size: 19, weight: .medium))
                    .symbolRenderingMode(.hierarchical)
                    .frame(height: 22)
                Text(entry.title)
                    .font(.system(size: 10.5, weight: on ? .semibold : .medium))
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
            }
            .foregroundStyle(on ? store.accentColor : Color.primary.opacity(0.55))
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background {
                if on {
                    ZStack {
                        Capsule().fill(Color.primary.opacity(scheme == .dark ? 0.12 : 0.07))
                        Capsule().strokeBorder(Color.white.opacity(scheme == .dark ? 0.16 : 0.6), lineWidth: 0.7)
                    }
                    .matchedGeometryEffect(id: "lens", in: lens)
                }
            }
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(entry.title)
    }
}
