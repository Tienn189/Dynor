import SwiftUI

/// Reuses the former connection-tab position and the app's material-card styling.
@MainActor
struct PosterBoardView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var notice: String?
    @State private var signingWarning: String?
    @State private var diagnosticText: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("KẾT NỐI KHÔNG GIAN CỦA BẠN")
                            .font(.system(size: 10, weight: .medium)).tracking(1.6).foregroundStyle(.secondary)
                        Text("PosterBoard").font(.system(size: 31, weight: .semibold, design: .rounded))
                        Text("Cài Tendies trực tiếp trên iPhone.").font(.subheadline).foregroundStyle(.secondary)
                    }.padding(.vertical, 12)
                    card {
                        Label("Trạng thái cài trực tiếp", systemImage: "iphone.gen3").font(.headline)
                        Text(TendiesCompatibility.summary).font(.subheadline)
                        Text(TendiesCompatibility.current.detail).font(.caption).foregroundStyle(.secondary)
                        Divider()
                        if let warning = signingWarning {
                            Label(warning, systemImage: "exclamationmark.shield").font(.caption).foregroundStyle(.secondary)
                        } else {
                            Label("App Group đã truy cập được. Quyền vào PosterBoard sẽ được kiểm tra khi cài.", systemImage: "checkmark.shield").font(.caption)
                        }
                        Button("Kiểm tra lại chữ ký") {
                            signingWarning = PosterBoardAccess.prerequisiteWarning
                            diagnosticText = PosterBoardAccess.diagnosticReport()
                        }
                        if let diagnosticText {
                            Text(diagnosticText)
                                .font(.system(size: 12, design: .monospaced))
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            ShareLink(item: diagnosticText) {
                                Label("Chia sẻ báo cáo chẩn đoán", systemImage: "square.and.arrow.up")
                            }
                        }
                            .buttonStyle(.bordered).disabled(store.isInstallingWallpaper)
                    }
                    card {
                        Label("Cài hình nền Tendies", systemImage: "photo.on.rectangle.angled").font(.headline)
                        Text("1. Mở bộ chọn hình nền của iOS một lần để khởi tạo kho PosterBoard.")
                        Button("Mở bộ chọn hình nền") { openPosterBoard() }
                            .buttonStyle(.bordered).disabled(store.isInstallingWallpaper)
                        Divider()
                        Text("2. Vào Thư viện, nhập .tendies hoặc gói .dynor, chọn mẫu và bấm Cài hình nền. Giữ iPhone mở khóa và Dynor ở phía trước.")
                        Button("Mở Thư viện") { store.selectedTab = .library }.buttonStyle(.borderedProminent)
                        Divider()
                        Text("3. Sau khi Dynor đọc lại đúng dữ liệu, mở bộ chọn hình nền để kiểm tra mẫu và chọn làm màn hình khóa. Nếu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại.")
                        Text("Đọc lại dữ liệu thành công chưa có nghĩa là iOS đã nạp hoặc áp dụng mẫu. Dynor không tự chọn hình nền thay bạn.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Link("Mã nguồn Worse Poster", destination: URL(string: "https://github.com/nxtcoreee3/Worse-Poster")!)
                        .font(.subheadline.weight(.semibold))
                }.padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("PosterBoard").navigationBarTitleDisplayMode(.inline)
            .onAppear {
                signingWarning = PosterBoardAccess.prerequisiteWarning
                diagnosticText = PosterBoardAccess.diagnosticReport()
            }
            .alert("PosterBoard", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }.tint(store.accentColor)
    }

    private func openPosterBoard() {
        if !PosterBoardAccess.requestOpenPosterBoard() {
            notice = "iOS chưa mở được PosterBoard từ Dynor. Mở Cài đặt → Hình nền → Thêm hình nền mới để tiếp tục."
        }
    }

    private func card<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 18, content: content)
            .padding(21).frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(Color.primary.opacity(0.06)))
    }
}
