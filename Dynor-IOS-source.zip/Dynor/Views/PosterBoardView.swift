import SwiftUI

@MainActor
struct PosterBoardView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var notice: String?
    private var ready: Bool { PosterBoardAccess.prerequisiteWarning == nil }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    DynorHeader(eyebrow: "Dynor · Wallpaper engine",
                                title: "PosterBoard",
                                subtitle: "Bộ sưu tập PosterBoard ngay trên iPhone.")
                    ZStack(alignment: .bottomLeading) {
                        LinearGradient(colors: [Color(red: 0.16, green: 0.13, blue: 0.40), store.accentColor.opacity(0.8), Color(red: 0.42, green: 0.74, blue: 0.75)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing)
                        RadialGradient(colors: [Color.white.opacity(0.35), .clear], center: .topTrailing, startRadius: 0, endRadius: 240)
                        VStack(alignment: .leading, spacing: 12) {
                            Image(systemName: "square.stack.3d.up.fill").font(.system(size: 34)).foregroundStyle(.white)
                            Spacer()
                            Text("POSTERBOARD")
                                .font(.system(size: 11, weight: .semibold, design: .monospaced)).tracking(2.4)
                                .foregroundStyle(.white.opacity(0.8))
                            Text(ready ? "Sẵn sàng cài đặt" : "Cần kiểm tra quyền truy cập")
                                .font(DynorDesign.display(28, weight: .bold)).foregroundStyle(.white)
                        }
                        .padding(24)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                    }
                    .frame(height: 230)
                    .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 32, style: .continuous).strokeBorder(Color.white.opacity(0.25), lineWidth: 1))
                    .shadow(color: store.accentColor.opacity(0.35), radius: 26, y: 14)

                    VStack(alignment: .leading, spacing: 15) {
                        Label("Cài hình nền", systemImage: "sparkles.rectangle.stack").font(DynorDesign.display(21))
                        Text("Nhập gói Tendies trong Thư viện, chọn mẫu rồi bấm Cài hình nền. Dynor sẽ xác minh dữ liệu và thử mở PosterBoard để bạn áp dụng.")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Button { store.selectedTab = .library } label: {
                            Label("Đến Thư viện", systemImage: "arrow.up.right")
                        }
                        .buttonStyle(DynorPrimaryButtonStyle(tint: store.accentColor, foreground: store.accentTextColor))
                        Button { if !PosterBoardAccess.requestOpenPosterBoard() { notice = "Không thể mở PosterBoard tự động. Vào Cài đặt → Hình nền → Thêm hình nền mới." } } label: {
                            Label("Mở bộ chọn hình nền", systemImage: "iphone.gen3")
                        }
                        .buttonStyle(DynorGlassButtonStyle())
                    }.dynorSurface()
                    if let warning = PosterBoardAccess.prerequisiteWarning {
                        Label(warning, systemImage: "exclamationmark.triangle.fill")
                            .font(.caption).foregroundStyle(.orange)
                            .dynorGlass(radius: 20, padding: 16)
                    }
                }.padding(20)
            }
            .scrollIndicators(.hidden)
            .background { AuroraBackground() }
            .navigationTitle("PosterBoard").navigationBarTitleDisplayMode(.inline)
            .alert("PosterBoard", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }.tint(store.accentColor)
    }
}

struct DynorSurface: ViewModifier {
    func body(content: Content) -> some View {
        content.dynorGlass(radius: 28, padding: 20)
    }
}
extension View { func dynorSurface() -> some View { modifier(DynorSurface()) } }
