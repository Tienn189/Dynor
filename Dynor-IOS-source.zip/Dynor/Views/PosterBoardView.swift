import SwiftUI

@MainActor
struct PosterBoardView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var notice: String?
    private var ready: Bool { PosterBoardAccess.prerequisiteWarning == nil }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 9) {
                        Text("Hình nền.\nTheo cách của bạn.")
                            .font(.largeTitle.weight(.bold))
                        Text("Bộ sưu tập PosterBoard ngay trên iPhone.").foregroundStyle(.secondary)
                    }.padding(.top, 14)
                    ZStack(alignment: .bottomLeading) {
                        RoundedRectangle(cornerRadius: 28, style: .continuous).fill(LinearGradient(colors: [Color(red: 0.28, green: 0.36, blue: 0.74), Color(red: 0.42, green: 0.74, blue: 0.75), Color(red: 0.78, green: 0.82, blue: 0.59)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        Circle().fill(.white.opacity(0.16)).frame(width: 220).blur(radius: 12).offset(x: 180, y: -55)
                        VStack(alignment: .leading, spacing: 12) {
                            Image(systemName: "square.stack.3d.up.fill").font(.system(size: 36)).foregroundStyle(.white)
                            Spacer()
                            Text("PosterBoard").font(.footnote.weight(.semibold)).foregroundStyle(.white.opacity(0.85))
                            Text(ready ? "Sẵn sàng cài đặt" : "Cần kiểm tra quyền truy cập")
                                .font(.title2.bold()).foregroundStyle(.white)
                        }.padding(26)
                    }.frame(height: 220).clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                    VStack(alignment: .leading, spacing: 15) {
                        Label("Cài hình nền", systemImage: "sparkles.rectangle.stack").font(.title3.bold())
                        Text("Nhập gói Tendies trong Thư viện, chọn mẫu rồi bấm Cài hình nền. Dynor sẽ xác minh dữ liệu và thử mở PosterBoard để bạn áp dụng.")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Button { store.selectedTab = .library } label: {
                            Label("Đến Thư viện", systemImage: "arrow.up.right").frame(maxWidth: .infinity).padding(9)
                        }.buttonStyle(.borderedProminent)
                        Button { if !PosterBoardAccess.requestOpenPosterBoard() { notice = "Không thể mở PosterBoard tự động. Vào Cài đặt → Hình nền → Thêm hình nền mới." } } label: {
                            Label("Mở bộ chọn hình nền", systemImage: "iphone.gen3").frame(maxWidth: .infinity).padding(7)
                        }.buttonStyle(.bordered)
                    }.dynorSurface()
                    if let warning = PosterBoardAccess.prerequisiteWarning {
                        Label(warning, systemImage: "exclamationmark.triangle.fill")
                            .font(.caption).foregroundStyle(.orange).padding(16)
                            .frame(maxWidth: .infinity, alignment: .leading).dynorSurface()
                    }
                }.padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("PosterBoard").navigationBarTitleDisplayMode(.inline)
            .alert("PosterBoard", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }.tint(store.accentColor)
    }
}

struct DynorSurface: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(.white.opacity(0.4)))
    }
}
extension View { func dynorSurface() -> some View { modifier(DynorSurface()) } }
