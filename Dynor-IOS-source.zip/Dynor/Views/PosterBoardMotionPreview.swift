import SwiftUI
import UIKit
import QuartzCore
import Foundation

private final class MotionNode: NSObject, XMLParserDelegate {
    let tag: String; let a: [String:String]; var children: [MotionNode] = []
    init(_ tag: String, _ a: [String:String] = [:]) { self.tag = tag; self.a = a }
    func all(_ tag: String) -> [MotionNode] { children.flatMap { ($0.tag == tag ? [$0] : []) + $0.all(tag) } }
    func child(_ tag: String) -> MotionNode? { children.first { $0.tag == tag } }
}
private final class MotionXML: NSObject, XMLParserDelegate {
    let root = MotionNode("root"); var stack: [MotionNode] = []
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName: String?, attributes: [String:String]) {
        let n = MotionNode(elementName, attributes); (stack.last ?? root).children.append(n); stack.append(n)
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName: String?) { _ = stack.popLast() }
}
private struct MotionScene { let node: MotionNode; let directory: URL }
private final class MotionHost: UIView {
    var scenes: [(MotionNode, CALayer, [String:CALayer])] = []; var state = ""; var canvas = CGSize(width: 390,height: 844)
    let stage = CALayer()
    override init(frame: CGRect) { super.init(frame: frame); layer.addSublayer(stage); clipsToBounds = true }
    required init?(coder: NSCoder) { fatalError() }
    override func layoutSubviews() { super.layoutSubviews(); CATransaction.begin(); CATransaction.setDisableActions(true); stage.bounds = CGRect(origin: .zero,size: canvas); stage.position = CGPoint(x: bounds.midX,y: bounds.midY); let s = min(bounds.width/canvas.width,bounds.height/canvas.height); stage.setAffineTransform(CGAffineTransform(scaleX:s,y:s)); CATransaction.commit() }
    func numbers(_ s: String?) -> [CGFloat] { (s ?? "").split(whereSeparator: { $0.isWhitespace || $0 == "," }).compactMap { Double($0).map { CGFloat($0) } } }
    func make(_ n: MotionNode, _ dir: URL, _ ids: inout [String:CALayer]) -> CALayer {
        let l = CALayer(); let b = numbers(n.a["bounds"]); if b.count == 4 { l.bounds = CGRect(x:b[0],y:b[1],width:b[2],height:b[3]) }; let p = numbers(n.a["position"]); if p.count == 2 { l.position = CGPoint(x:p[0],y:p[1]) }; let a = numbers(n.a["anchorPoint"]); if a.count == 2 { l.anchorPoint = CGPoint(x:a[0],y:a[1]) }; l.opacity = Float(n.a["opacity"] ?? "1") ?? 1; l.masksToBounds = n.a["masksToBounds"] == "1"; l.isGeometryFlipped = n.a["geometryFlipped"] == "1"; l.contentsGravity = .resize
        if let id = n.a["id"] { ids[id] = l }
        if let src = n.child("contents")?.child("CGImage")?.a["src"], !src.contains(".."), !src.hasPrefix("/"), !src.contains(":" ) { l.contents = UIImage(contentsOfFile: dir.appendingPathComponent(src).path)?.cgImage }
        for c in n.child("sublayers")?.children ?? [] where c.tag.hasSuffix("Layer") { l.addSublayer(make(c,dir,&ids)) }
        return l
    }
    func load(_ input: [MotionScene]) { stage.sublayers?.forEach { $0.removeFromSuperlayer() }; scenes = []; state = ""; for s in input { guard let root = s.node.all("CALayer").first else { continue }; var ids: [String:CALayer] = [:]; let l = make(root,s.directory,&ids); if l.bounds.width > 0 && l.bounds.height > 0 { canvas = l.bounds.size }; stage.addSublayer(l); scenes.append((s.node,l,ids)) }; setNeedsLayout() }
    func value(_ n: MotionNode?) -> NSNumber? { guard let s = n?.a["value"], let d = Double(s), d.isFinite else { return nil }; return NSNumber(value:d) }
    let allowed: Set<String> = ["position.x","position.y","opacity","transform.scale","transform.scale.x","transform.scale.y","transform.rotation.z","transform.rotation.x","transform.rotation.y"]
    func change(_ next: String) { guard next != state else { return }; let previous = state; state = next
        CATransaction.begin(); CATransaction.setDisableActions(true)
        for (doc,_,ids) in scenes { let transition = doc.all("LKStateTransition").first { $0.a["fromState"] == previous && $0.a["toState"] == next }; for n in doc.all("LKState").filter({ $0.a["name"] == next }).flatMap({ $0.all("LKStateSetValue") }) { guard let id = n.a["targetId"], let l = ids[id], let key = n.a["keyPath"], allowed.contains(key), let v = value(n.child("value")) else { continue }; let old = l.presentation()?.value(forKeyPath:key) ?? l.value(forKeyPath:key); l.removeAnimation(forKey:key); l.setValue(v,forKeyPath:key); guard let spec = transition?.all("LKStateTransitionElement").first(where: { $0.a["targetId"] == id && $0.a["key"] == key })?.child("animation"), let duration = Double(spec.a["duration"] ?? ""), duration > 0, duration <= 30 else { continue }; let anim = CABasicAnimation(keyPath:key); anim.fromValue = old; anim.toValue = v; anim.duration = duration; let timing = spec.a["timingFunction"] ?? "linear"; anim.timingFunction = CAMediaTimingFunction(name: timing == "easeInEaseOut" ? .easeInEaseOut : timing == "easeIn" ? .easeIn : timing == "easeOut" ? .easeOut : .linear); l.add(anim,forKey:key) } }
        CATransaction.commit()
    }
}
private struct MotionSurface: UIViewRepresentable {
    let scenes: [MotionScene]; let state: String
    func makeUIView(context: Context) -> MotionHost { let v = MotionHost(frame:.zero); v.load(scenes); v.change(state); return v }
    func updateUIView(_ v: MotionHost, context: Context) { v.change(state) }
}
struct PosterBoardMotionPreview: View {
    @EnvironmentObject private var store: DynorStore
    let url: URL; let encrypted: Bool
    @State private var scenes: [MotionScene] = []; @State private var workspace: URL?; @State private var state = "Sleep"; @State private var failed = false
    var body: some View { VStack(spacing:12) { if !scenes.isEmpty { MotionSurface(scenes:scenes,state:state).aspectRatio(390.0/844.0,contentMode:.fit).frame(maxHeight:420).clipShape(RoundedRectangle(cornerRadius:24)); HStack { ForEach(["Sleep","Locked","Unlock"],id:\.self) { key in Button(key) { state = key }.buttonStyle(.bordered).tint(state == key ? store.accentColor : .secondary) } }; Text(store.localized("Bản thử nghiệm hoạt ảnh CAML", "Experimental CAML preview", "CAML 动画预览测试")).font(.caption).foregroundStyle(.secondary) } else if failed { Text(store.localized("Chưa hỗ trợ hoạt ảnh này", "Animation unavailable", "暂不支持此动画")).font(.caption) } else { ProgressView() } }.task { await load() }.onDisappear { if let workspace { try? FileManager.default.removeItem(at:workspace) }; workspace = nil; scenes = [] } }
    @MainActor private func load() async { do { let prepared = encrypted ? try await EncryptedTendiesService.shared.prepareForInstallation(url) : nil; defer { prepared?.remove() }; let source = prepared?.url ?? url; let entries = try TendiesArchiveValidator.validateBeforeExtraction(at:source); let dir = try TendiesInstallWorkspace.create(); workspace = dir; try TendiesArchiveValidator.extract(at:source,to:dir,entries:entries); let paths = entries.filter { $0.path.hasSuffix("/main.caml") || $0.path.hasSuffix("/scene.caml") }.sorted { $0.path < $1.path }; var result: [MotionScene] = []; for entry in paths { let file = dir.appendingPathComponent(entry.path); guard let parser = XMLParser(contentsOf:file) else { continue }; let delegate = MotionXML(); parser.delegate = delegate; parser.shouldResolveExternalEntities = false; if parser.parse(), !delegate.root.all("LKState").isEmpty { result.append(MotionScene(node:delegate.root,directory:file.deletingLastPathComponent())) } }; guard !Task.isCancelled else { try? FileManager.default.removeItem(at:dir); return }; scenes = result; failed = result.isEmpty } catch { failed = true } }
}
