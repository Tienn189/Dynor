import SwiftUI
import UIKit
import QuartzCore
import Foundation

private final class MotionNode: NSObject, XMLParserDelegate, @unchecked Sendable {
    let tag: String; let a: [String:String]; var children: [MotionNode] = []
    init(_ tag: String, _ a: [String:String] = [:]) { self.tag = tag; self.a = a }
    func all(_ tag: String) -> [MotionNode] { children.flatMap { ($0.tag == tag ? [$0] : []) + $0.all(tag) } }
    func child(_ tag: String) -> MotionNode? { children.first { $0.tag == tag } }
}
private final class MotionXML: NSObject, XMLParserDelegate {
    let root = MotionNode("root"); var stack: [MotionNode] = []
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName: String?, attributes: [String:String]) {
        let n = MotionNode(elementName, attributes); (stack.last ?? root).children.append(n); stack.append(n)
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName: String?) { _ = stack.popLast() }
}
private struct MotionScene: Sendable { let node: MotionNode; let directory: URL }
private final class MotionHost: UIView {
    var scenes: [(MotionNode, CALayer, [String:CALayer])] = []; var state = ""; var canvas = CGSize(width: 390,height: 844)
    let stage = CALayer()
    private let images = NSCache<NSURL, UIImage>()
    private var stateNodes: [[String: [MotionNode]]] = []
    private var transitionNodes: [[String: [String: MotionNode]]] = []
    override init(frame: CGRect) { super.init(frame: frame); layer.addSublayer(stage); clipsToBounds = true; images.totalCostLimit = 96 * 1024 * 1024 }
    required init?(coder: NSCoder) { fatalError() }
    override func layoutSubviews() { super.layoutSubviews(); CATransaction.begin(); CATransaction.setDisableActions(true); stage.bounds = CGRect(origin: .zero,size: canvas); stage.position = CGPoint(x: bounds.midX,y: bounds.midY); let s = min(bounds.width/canvas.width,bounds.height/canvas.height); stage.setAffineTransform(CGAffineTransform(scaleX:s,y:s)); CATransaction.commit() }
    func numbers(_ s: String?) -> [CGFloat] { (s ?? "").split(whereSeparator: { $0.isWhitespace || $0 == "," }).compactMap { Double($0).map { CGFloat($0) } } }
    func make(_ n: MotionNode, _ dir: URL, _ ids: inout [String:CALayer]) -> CALayer {
        let l: CALayer = n.tag == "CATransformLayer" ? CATransformLayer() : CALayer(); let b = numbers(n.a["bounds"]); if b.count == 4 { l.bounds = CGRect(x:b[0],y:b[1],width:b[2],height:b[3]) }; let p = numbers(n.a["position"]); if p.count == 2 { l.position = CGPoint(x:p[0],y:p[1]) }; let a = numbers(n.a["anchorPoint"]); if a.count == 2 { l.anchorPoint = CGPoint(x:a[0],y:a[1]) }; l.opacity = Float(n.a["opacity"] ?? "1") ?? 1; l.masksToBounds = n.a["masksToBounds"] == "1"; l.isGeometryFlipped = n.a["geometryFlipped"] == "1"; l.contentsGravity = .resize
        if let id = n.a["id"] { ids[id] = l }
        l.zPosition = CGFloat(Double(n.a["zPosition"] ?? "0") ?? 0)
        l.speed = Float(n.a["speed"] ?? "1") ?? 1
        l.timeOffset = Double(n.a["timeOffset"] ?? "0") ?? 0
        l.transform = transform(n.a["transform"])
        l.sublayerTransform = transform(n.a["sublayerTransform"])
        if let src = n.child("contents")?.child("CGImage")?.a["src"] { l.contents = artwork(src, dir) }
        for spec in n.child("animations")?.children ?? [] {
            guard let key = spec.a["keyPath"], let anim = animation(spec, key, dir) else { continue }
            anim.beginTime = Double(spec.a["beginTime"] ?? "0") ?? 0
            anim.isRemovedOnCompletion = false; anim.fillMode = .both
            l.add(anim, forKey: spec.a["key"] ?? key)
        }
        for c in n.child("sublayers")?.children ?? [] where c.tag.hasSuffix("Layer") { l.addSublayer(make(c,dir,&ids)) }
        return l
    }
    func load(_ input: [MotionScene]) { stage.sublayers?.forEach { $0.removeFromSuperlayer() }; scenes = []; stateNodes = []; transitionNodes = []; state = ""; CATransaction.begin(); CATransaction.setDisableActions(true); defer { CATransaction.commit() }; for s in input { guard let root = s.node.all("CALayer").first else { continue }; var ids: [String:CALayer] = [:]; let l = make(root,s.directory,&ids); if l.bounds.width > 0 && l.bounds.height > 0 { canvas = l.bounds.size }; l.isGeometryFlipped = true; stage.addSublayer(l); scenes.append((s.node,l,ids)); var states: [String:[MotionNode]] = [:]; for n in s.node.all("LKState") { if let name = n.a["name"] { states[name, default: []].append(contentsOf: n.all("LKStateSetValue")) } }; stateNodes.append(states); var transitions: [String:[String:MotionNode]] = [:]; for t in s.node.all("LKStateTransition") { guard let from = t.a["fromState"], let to = t.a["toState"] else { continue }; for e in t.all("LKStateTransitionElement") { guard let id = e.a["targetId"], let key = e.a["key"], let spec = e.child("animation") else { continue }; transitions[from + "|" + to, default: [:]][id + "|" + key] = spec } }; transitionNodes.append(transitions) }; setNeedsLayout() }
    func value(_ n: MotionNode?) -> NSNumber? { guard let s = n?.a["value"], let d = Double(s), d.isFinite else { return nil }; return NSNumber(value:d) }
    let allowed: Set<String> = ["timeOffset","position.x","position.y","opacity","transform.scale","transform.scale.x","transform.scale.y","transform.rotation.z","transform.rotation.x","transform.rotation.y"]
    func artwork(_ src: String, _ dir: URL) -> CGImage? {
        guard !src.hasPrefix("/"), !src.contains(":") else { return nil }
        let file = dir.appendingPathComponent(src).standardizedFileURL.resolvingSymlinksInPath()
        let parent = dir.deletingLastPathComponent().standardizedFileURL.resolvingSymlinksInPath()
        guard file.path.hasPrefix(parent.path + "/") else { return nil }
        if let cached = images.object(forKey: file as NSURL) { return cached.cgImage }
        guard let image = UIImage(contentsOfFile: file.path), let cg = image.cgImage else { return nil }
        images.setObject(image, forKey: file as NSURL, cost: cg.bytesPerRow * cg.height)
        return cg
    }
    func transform(_ source: String?) -> CATransform3D {
        var t = CATransform3DIdentity
        let str = source ?? ""
        let regex = try? NSRegularExpression(pattern: "([A-Za-z]+)\\(([^)]*)\\)")
        for m in regex?.matches(in: str, range: NSRange(str.startIndex..., in: str)) ?? [] {
            guard let a = Range(m.range(at: 1), in: str), let b = Range(m.range(at: 2), in: str) else { continue }
            let raw = String(str[b]); let v = numbers(raw.replacingOccurrences(of: "deg", with: ""))
            switch String(str[a]) {
            case "rotate" where v.count == 4: t = CATransform3DRotate(t, raw.contains("deg") ? v[0] * .pi / 180 : v[0], v[1], v[2], v[3])
            case "scale" where v.count == 3: t = CATransform3DScale(t,v[0],v[1],v[2])
            case "translate" where v.count == 3: t = CATransform3DTranslate(t,v[0],v[1],v[2])
            case "perspective" where v.count == 1 && v[0] != 0: t.m34 = -1/v[0]
            default: break
            }
        }
        return t
    }
    func animation(_ spec: MotionNode, _ key: String, _ dir: URL) -> CAPropertyAnimation? {
        guard allowed.contains(key) || key == "contents", let duration = Double(spec.a["duration"] ?? ""), duration > 0, duration <= 60 else { return nil }
        let anim: CAPropertyAnimation
        if spec.a["type"] == "CAKeyframeAnimation" {
            let k = CAKeyframeAnimation(keyPath:key)
            let nodes = spec.child("values")?.children ?? []
            let vals: [Any] = nodes.compactMap { n -> Any? in
                if key == "contents", let src = n.a["src"] { return artwork(src,dir) }
                return value(n)
            }
            guard vals.count == nodes.count, !vals.isEmpty else { return nil }
            k.values = vals
            let times = spec.child("keyTimes")?.children.compactMap { value($0) } ?? []
            if times.count == vals.count { k.keyTimes = times }
            k.calculationMode = spec.a["calculationMode"] == "discrete" ? .discrete : .linear
            anim = k
        } else {
            let b = CABasicAnimation(keyPath:key); b.fromValue = value(spec.child("fromValue")); b.toValue = value(spec.child("toValue")); anim = b
        }
        anim.duration = duration
        let timing = spec.a["timingFunction"] ?? "linear"; let v = numbers(timing)
        anim.timingFunction = v.count == 4 ? CAMediaTimingFunction(controlPoints:Float(v[0]),Float(v[1]),Float(v[2]),Float(v[3])) : CAMediaTimingFunction(name: timing == "easeInEaseOut" ? .easeInEaseOut : timing == "easeIn" ? .easeIn : timing == "easeOut" ? .easeOut : .linear)
        return anim
    }
    func change(_ next: String) {
        guard next != state else { return }; let previous = state; state = next
        CATransaction.begin(); CATransaction.setDisableActions(true)
        for (index, scene) in scenes.enumerated() {
            let ids = scene.2
            let transition = transitionNodes[index][previous + "|" + next] ?? transitionNodes[index]["*|" + next] ?? [:]
            for n in stateNodes[index][next] ?? [] {
                guard let id = n.a["targetId"], let l = ids[id], let key = n.a["keyPath"], allowed.contains(key), let v = value(n.child("value")) else { continue }
                let old = l.presentation()?.value(forKeyPath:key) ?? l.value(forKeyPath:key)
                l.removeAnimation(forKey:"dynor.transition." + key); l.setValue(v,forKeyPath:key)
                guard !previous.isEmpty, let spec = transition[id + "|" + key], let anim = animation(spec,key,URL(fileURLWithPath:"/")) else { continue }
                if let basic = anim as? CABasicAnimation { basic.fromValue = old; basic.toValue = v }
                anim.isRemovedOnCompletion = true; anim.fillMode = .removed; l.add(anim,forKey:"dynor.transition." + key)
            }
        }
        CATransaction.commit()
    }

}
private struct MotionSurface: UIViewRepresentable {
    let scenes: [MotionScene]; let state: String
    func makeUIView(context: Context) -> MotionHost { let v = MotionHost(frame:.zero); v.load(scenes); v.change(state); return v }
    func updateUIView(_ v: MotionHost, context: Context) { v.change(state) }
}
struct PosterBoardMotionPreview: View {
    @EnvironmentObject private var store: DynorStore
    let url: URL; let encrypted: Bool
    @State private var scenes: [MotionScene] = []; @State private var workspace: URL?; @State private var state = "Sleep"; @State private var failed = false
    var body: some View { VStack(spacing:12) { if !scenes.isEmpty { MotionSurface(scenes:scenes,state:state).aspectRatio(390.0/844.0,contentMode:.fit).frame(maxHeight:420).clipShape(RoundedRectangle(cornerRadius:24)); HStack { ForEach(["Sleep","Locked","Unlock"],id:\.self) { key in Button(key) { state = key }.buttonStyle(.bordered).tint(state == key ? store.accentColor : .secondary) } }; Text(store.localized("Bản thử nghiệm hoạt ảnh CAML", "Experimental CAML preview", "CAML 动画预览测试")).font(.caption).foregroundStyle(.secondary) } else if failed { Text(store.localized("Chưa hỗ trợ hoạt ảnh này", "Animation unavailable", "暂不支持此动画")).font(.caption) } else { ProgressView() } }.task { await load() }.onDisappear { if let workspace { try? FileManager.default.removeItem(at:workspace) }; workspace = nil; scenes = [] } }
    private nonisolated static func parseArchive(_ source: URL) throws -> (URL, [MotionScene]) {
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: source)
        let dir = try TendiesInstallWorkspace.create()
        do {
            try TendiesArchiveValidator.extract(at: source, to: dir, entries: entries)
            var result: [MotionScene] = []
            for entry in entries.filter({ $0.path.hasSuffix("/main.caml") || $0.path.hasSuffix("/scene.caml") }).sorted(by: { $0.path < $1.path }) {
                guard let parser = XMLParser(contentsOf: dir.appendingPathComponent(entry.path)) else { continue }
                let delegate = MotionXML(); parser.delegate = delegate; parser.shouldResolveExternalEntities = false
                if parser.parse(), !delegate.root.all("LKState").isEmpty { result.append(MotionScene(node: delegate.root, directory: dir.appendingPathComponent(entry.path).deletingLastPathComponent())) }
            }
            return (dir, result)
        } catch { try? FileManager.default.removeItem(at: dir); throw error }
    }
    @MainActor private func load() async {
        do {
            let prepared = encrypted ? try await EncryptedTendiesService.shared.prepareForInstallation(url) : nil
            defer { prepared?.remove() }
            let source = prepared?.url ?? url
            let (dir, result) = try await Task.detached(priority: .userInitiated) { try Self.parseArchive(source) }.value
            guard !Task.isCancelled else { try? FileManager.default.removeItem(at: dir); return }
            workspace = dir; scenes = result; failed = result.isEmpty
        } catch { if !Task.isCancelled { failed = true } }
    }
}
