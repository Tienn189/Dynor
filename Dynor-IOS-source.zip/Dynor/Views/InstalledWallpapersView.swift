import SwiftUI
import UIKit

/// iOS does not expose a public API to enumerate all system wallpapers.
/// This screen displays descriptors successfully written by Dynor.
struct InstalledWallpapersView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var paths: [String] = []
    @State private var thumbnails: [String: UIImage] = [:]
    @State private var selected = Set<String>()
    @State private var selecting = false
    @State private var busy = false
    @State private var message: String?
    @State private var confirmDelete = false
    @State private var previewPath: String?
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                header
                countRow
                if paths.isEmpty {
                    emptyState
                } else {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(paths, id: \.self) { path in card(path) }
                    }
                }
                Label {
                    Text("Thư viện này quản lý hình nền do Dynor ghi, không bao gồm toàn bộ hình nền hệ thống iOS. Một số gói không chứa ảnh xem trước.")
                        .font(.system(size: 12)).foregroundStyle(.secondary).lineSpacing(2)
                } icon: {
                    Image(systemName: "info.circle").foregroundStyle(store.accentColor)
                }
                .dynorGlass(radius: 18, padding: 14)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
        }
        .scrollIndicators(.hidden)
        .contentMargins(.bottom, 110, for: .scrollContent)
        .background { AuroraBackground() }
        .toolbar(.hidden, for: .navigationBar)
        .overlay(alignment: .bottom) {
            deleteBar.animation(.spring(response: 0.4, dampingFraction: 0.8), value: selected.count)
        }
        .onAppear { reload() }
        .sheet(item: Binding(get: { previewPath.map { PreviewSelection(path: $0) } },
                             set: { previewPath = $0?.path })) { item in
            previewSheet(item)
        }
        .confirmationDialog("Xóa hình nền đã chọn?", isPresented: $confirmDelete) {
            Button("Xóa", role: .destructive) { deleteSelected() }
        }
        .alert("Dynor", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    // MARK: Pieces

    private var header: some View {
        DynorHeader(eyebrow: "Dynor · Installed",
                    title: store.localized("Thư viện", "Library", "资料库"),
                    subtitle: store.localized("Những hình nền bạn đã thêm vào thiết bị.",
                                              "Wallpapers you have added to this device.",
                                              "已添加到设备的壁纸。")) {
            GlassIconButton(symbol: selecting ? "checkmark" : "checklist",
                            tint: selecting ? store.accentColor : nil) {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                    selecting.toggle()
                    selected.removeAll()
                }
            }
            .disabled(paths.isEmpty || busy)
            .accessibilityLabel(store.localized("Chọn nhiều", "Select", "多选"))
        }
    }

    private var countRow: some View {
        HStack(spacing: 12) {
            StatTile(value: "\(paths.count)", label: store.localized("Hình nền đã cài", "Installed", "已安装"),
                     symbol: "iphone.gen3")
            StatTile(value: selecting ? "\(selected.count)" : "—", label: store.localized("Đang chọn", "Selected", "已选择"),
                     symbol: "checkmark.circle.fill")
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "photo.on.rectangle.angled")
                .font(.system(size: 38, weight: .light)).foregroundStyle(store.accentColor)
            Text("Chưa có hình nền").font(DynorDesign.display(22))
            Text("Các hình nền Dynor đã cài sẽ xuất hiện tại đây.")
                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button {
                store.selectedTab = .library
            } label: {
                Label(store.localized("Đến Bộ sưu tập", "Go to Collection", "前往收藏"), systemImage: "arrow.up.right")
            }
            .buttonStyle(DynorPrimaryButtonStyle(tint: store.accentColor, foreground: store.accentTextColor))
            .frame(maxWidth: 240)
            .padding(.top, 6)
        }
        .frame(maxWidth: .infinity)
        .dynorGlass(radius: 30, padding: 28)
    }

    private func card(_ path: String) -> some View {
        let isOn = selected.contains(path)
        return Button {
            if selecting {
                if isOn { selected.remove(path) } else { selected.insert(path) }
            } else { previewPath = path }
        } label: {
            Color.clear
                .aspectRatio(0.6, contentMode: .fit)
                .overlay {
                    GeometryReader { geo in
                        if let image = thumbnails[path] {
                            Image(uiImage: image).resizable().scaledToFill()
                                .frame(width: geo.size.width, height: geo.size.height)
                        } else {
                            ZStack {
                                DynorPlaceholder(symbol: "photo.artframe")
                            }
                            .frame(width: geo.size.width, height: geo.size.height)
                        }
                    }
                }
                .overlay(alignment: .bottomLeading) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Hình nền Dynor")
                            .font(DynorDesign.display(15)).foregroundStyle(.white)
                        Text(URL(fileURLWithPath: path).lastPathComponent.prefix(8))
                            .font(.system(size: 10.5, weight: .medium, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.7))
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12).padding(.bottom, 12).padding(.top, 44)
                    .background(LinearGradient(colors: [.clear, Color.black.opacity(0.72)], startPoint: .top, endPoint: .bottom))
                }
                .overlay(alignment: .topTrailing) {
                    if selecting { SelectionMark(isOn: isOn).padding(10) }
                }
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .strokeBorder(isOn ? store.accentColor : Color.white.opacity(0.12), lineWidth: isOn ? 2.5 : 1)
                )
                .shadow(color: .black.opacity(0.22), radius: 14, y: 8)
                .scaleEffect(isOn ? 0.96 : 1)
                .animation(.spring(response: 0.35, dampingFraction: 0.75), value: isOn)
        }
        .buttonStyle(DynorPressStyle(scale: 0.97))
    }

    @ViewBuilder
    private var deleteBar: some View {
        if selecting && !selected.isEmpty {
            Button(role: .destructive) { confirmDelete = true } label: {
                Label("Xóa \(selected.count) hình nền", systemImage: "trash.fill")
            }
            .buttonStyle(DynorGlassButtonStyle(destructive: true))
            .background(.ultraThinMaterial, in: Capsule())
            .disabled(busy)
            .padding(.horizontal, 36)
            .padding(.bottom, 94)
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
    }

    private func previewSheet(_ item: PreviewSelection) -> some View {
        ZStack {
            AuroraBackground()
            VStack(spacing: 20) {
                Capsule().fill(Color.primary.opacity(0.25)).frame(width: 38, height: 5).padding(.top, 10)
                Spacer(minLength: 0)
                if let image = thumbnails[item.path] {
                    Image(uiImage: image).resizable().scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 36, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 36, style: .continuous)
                            .strokeBorder(Color.white.opacity(0.35), lineWidth: 3))
                        .shadow(color: store.accentColor.opacity(0.4), radius: 40, y: 22)
                        .padding(.horizontal, 44)
                } else {
                    VStack(spacing: 12) {
                        Image(systemName: "photo").font(.system(size: 36, weight: .light)).foregroundStyle(.secondary)
                        Text("Không có ảnh xem trước").font(DynorDesign.display(20))
                        Text("Gói hình nền không chứa ảnh tĩnh có thể hiển thị.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }.padding(30)
                }
                Spacer(minLength: 0)
                Button("Đóng") { previewPath = nil }
                    .buttonStyle(DynorGlassButtonStyle())
                    .padding(.horizontal, 36).padding(.bottom, 20)
            }
        }
        .presentationCornerRadius(38)
    }

    private func reload() {
        paths = PosterBoardDescriptorWriter.installedPaths()
        let current = paths
        Task.detached(priority: .utility) {
            let loaded = PosterBoardDescriptorWriter.previewImages(paths: current)
            await MainActor.run { thumbnails = loaded }
        }
    }

    private func deleteSelected() {
        let targets = Array(selected)
        busy = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: targets) }
            await MainActor.run {
                busy = false
                switch result {
                case .success(let count): message = "Đã xóa \(count) hình nền Dynor."
                case .failure(let error): message = error.localizedDescription
                }
                reload()
                selected.removeAll()
                selecting = false
            }
        }
    }
}

private struct PreviewSelection: Identifiable {
    let path: String
    var id: String { path }
}
