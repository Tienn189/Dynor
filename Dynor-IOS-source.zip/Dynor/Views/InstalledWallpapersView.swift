import SwiftUI
import UIKit

/// iOS does not expose a public API to enumerate all system wallpapers.
/// This screen displays descriptors successfully written by Dynor.
struct InstalledWallpapersView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var paths: [String] = []
    @State private var thumbnails: [String: UIImage] = [:]
    @State private var selected = Set<String>()
    @State private var selecting = false
    @State private var busy = false
    @State private var message: String?
    @State private var confirmDelete = false
    @State private var previewPath: String?
    private let columns = [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("THƯ VIỆN CỦA BẠN")
                        .font(.caption.weight(.bold)).tracking(2)
                        .foregroundStyle(store.accentColor)
                    Text("Hình nền đã thêm")
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                    Text("Các gói hình nền đã ghi bằng Dynor")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                HStack {
                    Label("\(paths.count) hình nền", systemImage: "square.stack.3d.up")
                        .font(.subheadline.weight(.medium))
                    Spacer()
                    Button(selecting ? "Xong" : "Chọn nhiều") {
                        selecting.toggle()
                        selected.removeAll()
                    }.disabled(paths.isEmpty || busy)
                }
                if paths.isEmpty {
                    ContentUnavailableView("Chưa có hình nền", systemImage: "photo.on.rectangle",
                        description: Text("Các hình nền Dynor đã cài sẽ xuất hiện tại đây."))
                } else {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(paths, id: \.self) { path in
                            Button {
                                if selecting {
                                    if selected.contains(path) { selected.remove(path) }
                                    else { selected.insert(path) }
                                } else { previewPath = path }
                            } label: {
                                VStack(alignment: .leading, spacing: 8) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 18).fill(store.accentColor.opacity(0.09))
                                        if let image = thumbnails[path] {
                                            Image(uiImage: image).resizable().scaledToFill()
                                                .frame(maxWidth: .infinity).frame(height: 215).clipped()
                                        } else {
                                            Image(systemName: "photo.artframe")
                                                .font(.system(size: 36)).foregroundStyle(store.accentColor)
                                        }
                                        if selecting {
                                            VStack { HStack { Spacer()
                                                Image(systemName: selected.contains(path) ? "checkmark.circle.fill" : "circle")
                                                    .font(.title2).foregroundStyle(store.accentColor)
                                                    .padding(10)
                                            }; Spacer() }
                                        }
                                    }
                                    .frame(height: 215)
                                    .clipShape(RoundedRectangle(cornerRadius: 18))
                                    Text("Hình nền Dynor").font(.subheadline.weight(.semibold))
                                    Text(URL(fileURLWithPath: path).lastPathComponent.prefix(8))
                                        .font(.caption.monospaced()).foregroundStyle(.secondary)
                                }
                            }.buttonStyle(.plain)
                        }
                    }
                }
                if selecting && !selected.isEmpty {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label("Xóa \(selected.count) hình nền", systemImage: "trash")
                            .frame(maxWidth: .infinity).padding(12)
                    }.buttonStyle(.bordered).disabled(busy)
                }
                Text("Thư viện này quản lý hình nền do Dynor ghi, không bao gồm toàn bộ hình nền hệ thống iOS. Một số gói không chứa ảnh xem trước.")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding(20)
        }
        .background(DynorDesign.canvas)
        .navigationTitle("Thư viện")
        .onAppear { reload() }
        .sheet(item: Binding(get: { previewPath.map { PreviewSelection(path: $0) } },
                             set: { previewPath = $0?.path })) { item in
            NavigationStack {
                VStack(spacing: 18) {
                    Spacer()
                    if let image = thumbnails[item.path] {
                        Image(uiImage: image).resizable().scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                            .padding(.horizontal, 28)
                    } else {
                        ContentUnavailableView("Không có ảnh xem trước", systemImage: "photo",
                            description: Text("Gói hình nền không chứa ảnh tĩnh có thể hiển thị."))
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .background(DynorDesign.canvas)
                .navigationTitle("Xem trước hình nền")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) {
                    Button("Đóng") { previewPath = nil }
                } }
            }
        }
        .confirmationDialog("Xóa hình nền đã chọn?", isPresented: $confirmDelete) {
            Button("Xóa", role: .destructive) { deleteSelected() }
        }
        .alert("Dynor", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func reload() {
        paths = PosterBoardDescriptorWriter.installedPaths()
        let current = paths
        Task.detached(priority: .utility) {
            let loaded = PosterBoardDescriptorWriter.previewImages(paths: current)
            await MainActor.run { thumbnails = loaded }
        }
    }

    private func deleteSelected() {
        let targets = Array(selected)
        busy = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: targets) }
            await MainActor.run {
                busy = false
                switch result {
                case .success(let count): message = "Đã xóa \(count) hình nền Dynor."
                case .failure(let error): message = error.localizedDescription
                }
                reload()
                selected.removeAll()
                selecting = false
            }
        }
    }
}

private struct PreviewSelection: Identifiable {
    let path: String
    var id: String { path }
}
