import SwiftUI
import UIKit

/// iOS does not expose a public API to enumerate all system wallpapers.
/// This screen displays descriptors successfully written by Dynor.
struct InstalledWallpapersView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var paths: [String] = []
    @State private var thumbnails: [String: UIImage] = [:]
    @State private var selected = Set<String>()
    @State private var selecting = false
    @State private var busy = false
    @State private var message: String?
    @State private var confirmDelete = false
    @State private var previewPath: String?
    private let columns = [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                DynorHero(index: "03 / LIBRARY", title: store.localized("Thư viện", "Library", "资料库"), subtitle: store.localized("Những hình nền bạn đã thêm vào thiết bị.", "Wallpapers added to your device.", "已添加到设备的壁纸。"), symbol: "rectangle.stack")
                HStack {
                    Label(store.localized("\(paths.count) hình nền", "\(paths.count) wallpapers", "\(paths.count) 张壁纸"), systemImage: "square.stack.3d.up")
                        .font(.subheadline.weight(.medium))
                    Spacer()
                    Button(selecting ? store.localized("Xong", "Done", "完成") : store.localized("Chọn nhiều", "Select multiple", "多选")) {
                        selecting.toggle()
                        selected.removeAll()
                    }.disabled(paths.isEmpty || busy)
                }
                if paths.isEmpty {
                    ContentUnavailableView(store.localized("Chưa có hình nền", "No wallpapers yet", "暂无壁纸"), systemImage: "photo.on.rectangle",
                        description: Text(store.localized("Các hình nền Dynor đã cài sẽ xuất hiện tại đây.", "Wallpapers installed by Dynor appear here.", "Dynor 安装的壁纸将显示在这里。")))
                } else {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(paths, id: \.self) { path in
                            Button {
                                if selecting {
                                    if selected.contains(path) { selected.remove(path) }
                                    else { selected.insert(path) }
                                } else { previewPath = path }
                            } label: {
                                VStack(alignment: .leading, spacing: 6) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color(uiColor: .secondarySystemGroupedBackground))
                                        if let image = thumbnails[path] {
                                            Image(uiImage: image).resizable().scaledToFill()
                                                .frame(maxWidth: .infinity).frame(height: 215).clipped()
                                        } else {
                                            Image(systemName: "photo.artframe")
                                                .font(.system(size: 36)).foregroundStyle(.secondary)
                                        }
                                        if selecting {
                                            VStack { HStack { Spacer()
                                                Image(systemName: selected.contains(path) ? "checkmark.circle.fill" : "circle")
                                                    .font(.title2).foregroundStyle(store.accentColor)
                                                    .padding(10)
                                            }; Spacer() }
                                        }
                                    }
                                    .frame(height: 215)
                                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                                    Text(store.localized("Hình nền Dynor", "Dynor wallpaper", "Dynor 壁纸")).font(.subheadline.weight(.semibold))
                                    Text(URL(fileURLWithPath: path).lastPathComponent.prefix(8))
                                        .font(.caption.monospaced()).foregroundStyle(.secondary)
                                }
                            }.buttonStyle(.plain)
                        }
                    }
                }
                if selecting && !selected.isEmpty {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label(store.localized("Xóa \(selected.count) hình nền", "Delete \(selected.count) wallpapers", "删除 \(selected.count) 张壁纸"), systemImage: "trash")
                            .frame(maxWidth: .infinity).padding(12)
                    }.buttonStyle(.bordered).disabled(busy)
                }
                Text(store.localized("Thư viện này quản lý hình nền do Dynor ghi, không bao gồm toàn bộ hình nền hệ thống iOS. Một số gói không chứa ảnh xem trước.", "This library tracks wallpapers written by Dynor, not every iOS system wallpaper. Some packages have no preview image.", "此资料库仅管理 Dynor 写入的壁纸，并非所有 iOS 系统壁纸。部分壁纸包没有预览图。"))
                    .font(.caption).foregroundStyle(.secondary)
            }.padding(20)
        }
        .background(DynorDesign.canvas)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { reload() }
        .sheet(item: Binding(get: { previewPath.map { PreviewSelection(path: $0) } },
                             set: { previewPath = $0?.path })) { item in
            NavigationStack {
                VStack(spacing: 18) {
                    Spacer()
                    if let image = thumbnails[item.path] {
                        Image(uiImage: image).resizable().scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                            .padding(.horizontal, 28)
                    } else {
                        ContentUnavailableView("Không có ảnh xem trước", systemImage: "photo",
                            description: Text("Gói hình nền không chứa ảnh tĩnh có thể hiển thị."))
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .background(DynorDesign.canvas)
                .navigationTitle("Xem trước hình nền")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) {
                    Button("Đóng") { previewPath = nil }
                } }
            }
        }
        .confirmationDialog("Xóa hình nền đã chọn?", isPresented: $confirmDelete) {
            Button("Xóa", role: .destructive) { deleteSelected() }
        }
        .alert("Dynor", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func reload() {
        paths = PosterBoardDescriptorWriter.installedPaths()
        let current = paths
        Task.detached(priority: .utility) {
            let loaded = PosterBoardDescriptorWriter.previewImages(paths: current)
            await MainActor.run { thumbnails = loaded }
        }
    }

    private func deleteSelected() {
        let targets = Array(selected)
        busy = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: targets) }
            await MainActor.run {
                busy = false
                switch result {
                case .success(let count): message = "Đã xóa \(count) hình nền Dynor."
                case .failure(let error): message = error.localizedDescription
                }
                reload()
                selected.removeAll()
                selecting = false
            }
        }
    }
}

private struct PreviewSelection: Identifiable {
    let path: String
    var id: String { path }
}
