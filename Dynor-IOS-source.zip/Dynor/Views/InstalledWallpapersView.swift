import SwiftUI

/// Shows descriptors written by Dynor, not every wallpaper installed by iOS.
struct InstalledWallpapersView: View {
    @State private var paths: [String] = []
    @State private var selected = Set<String>()
    @State private var selecting = false
    @State private var busy = false
    @State private var message: String?
    @State private var confirmDelete = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                DynorHero(index: "03 / INSTALLED", title: "Thư viện hình nền", subtitle: "Các cấu hình Dynor đã ghi vào PosterBoard.", symbol: "square.grid.2x2.fill")
                HStack {
                    Text("\(paths.count) cấu hình").font(.subheadline).foregroundStyle(.secondary)
                    Spacer()
                    Button(selecting ? "Xong" : "Chọn nhiều") {
                        selecting.toggle()
                        selected.removeAll()
                    }.disabled(paths.isEmpty || busy)
                }
                if paths.isEmpty {
                    ContentUnavailableView("Chưa có hình nền", systemImage: "photo.on.rectangle", description: Text("Hình nền được cài từ Dynor sẽ xuất hiện ở đây sau khi ghi thành công."))
                } else {
                    LazyVStack(spacing: 10) {
                        ForEach(paths, id: \.self) { path in
                            Button {
                                if selecting {
                                    if selected.contains(path) { selected.remove(path) }
                                    else { selected.insert(path) }
                                }
                            } label: {
                                HStack(spacing: 14) {
                                    Image(systemName: "photo.artframe")
                                        .font(.title2).foregroundStyle(DynorDesign.yellow)
                                        .frame(width: 45, height: 48)
                                        .background(DynorDesign.yellow.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text("Hình nền Dynor").font(.subheadline.weight(.semibold))
                                        Text(URL(fileURLWithPath: path).lastPathComponent)
                                            .font(.caption2.monospaced()).lineLimit(1).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if selecting { Image(systemName: selected.contains(path) ? "checkmark.circle.fill" : "circle") }
                                }.padding(12)
                                    .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 16))
                            }.buttonStyle(.plain)
                        }
                    }
                }
                if selecting && !selected.isEmpty {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label("Xóa \(selected.count) cấu hình", systemImage: "trash")
                            .frame(maxWidth: .infinity).padding(10)
                    }.buttonStyle(.bordered).disabled(busy)
                }
                Text("Chỉ quản lý cấu hình Dynor đã ghi. Không truy cập hoặc xóa các hình nền khác của iOS. iOS có thể cần tải lại bộ chọn hình nền để phản ánh thay đổi.")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding(20)
        }
        .background(DynorDesign.canvas)
        .navigationTitle("Thư viện")
        .onAppear { paths = PosterBoardDescriptorWriter.installedPaths() }
        .confirmationDialog("Xóa các cấu hình đã chọn?", isPresented: $confirmDelete) {
            Button("Xóa", role: .destructive) { deleteSelected() }
        }
        .alert("Dynor", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func deleteSelected() {
        let targets = Array(selected)
        busy = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: targets) }
            await MainActor.run {
                busy = false
                switch result {
                case .success(let count): message = "Đã xóa \(count) cấu hình do Dynor quản lý."
                case .failure(let error): message = error.localizedDescription
                }
                paths = PosterBoardDescriptorWriter.installedPaths()
                selected.removeAll()
                selecting = false
            }
        }
    }
}
