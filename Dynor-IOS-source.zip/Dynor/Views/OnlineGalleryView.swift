import SwiftUI
import AVKit

private enum OnlineConfig {
    static let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    static let key = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    static func preview(_ path: String) -> URL? {
        let trimmed = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        // The admin website stores absolute Supabase Storage URLs.
        if let url = URL(string: trimmed),
           let scheme = url.scheme?.lowercased(),
           scheme == "https" || scheme == "http" {
            return url
        }

        // Legacy records may store a path relative to dynor-previews.
        let relative = trimmed.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let encoded = relative.split(separator: "/").map { segment in
            String(segment).addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? String(segment)
        }.joined(separator: "/")
        return URL(string: "\(base.absoluteString)/storage/v1/object/public/dynor-previews/\(encoded)")
    }
}

private struct OnlineWallpaper: Identifiable, Decodable {
    let id: UUID
    let title: String
    let category: String
    let cover_path: String
    let video_path: String?
    let is_vip: Bool
}

@MainActor
private final class OnlineGalleryModel: ObservableObject {
    @Published var items: [OnlineWallpaper] = []
    @Published var favorites: Set<UUID> = []
    @Published var loading = false
    @Published var error: String?
    private let account = DynorAccountService.shared

    private func request(_ path: String, method: String = "GET", token: String? = nil, body: Data? = nil, prefer: String? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: OnlineConfig.base)?.absoluteURL else { throw GalleryFailure.message("URL không hợp lệ") }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(OnlineConfig.key, forHTTPHeaderField: "apikey")
        if let token { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body { req.httpBody = body; req.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if let prefer { req.setValue(prefer, forHTTPHeaderField: "Prefer") }
        let (data,response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "Không kết nối được Supabase"
            throw GalleryFailure.message("Máy chủ: \(text.prefix(180))")
        }
        return data
    }

    func reload() async {
        loading = true
        defer { loading = false }
        do {
            let data = try await request("rest/v1/dynor_wallpapers?select=id,title,category,cover_path,video_path,is_vip&published=eq.true&order=created_at.desc")
            items = try JSONDecoder().decode([OnlineWallpaper].self, from: data)
            error = nil
            await reloadFavorites()
        } catch { self.error = error.localizedDescription }
    }

    func reloadFavorites() async {
        guard let token = await account.galleryAccessToken() else { favorites = []; return }
        do {
            let data = try await request("rest/v1/dynor_favorites?select=wallpaper_id", token: token)
            struct Favorite: Decodable { let wallpaper_id: UUID }
            favorites = Set(try JSONDecoder().decode([Favorite].self, from: data).map(\.wallpaper_id))
        } catch { self.error = "Không đồng bộ được yêu thích: \(error.localizedDescription)" }
    }

    private func authenticatedUserID(token: String) async throws -> UUID {
        let data = try await request("auth/v1/user", token: token)
        struct AuthUser: Decodable { let id: UUID }
        return try JSONDecoder().decode(AuthUser.self, from: data).id
    }

    func toggleFavorite(_ id: UUID) async {
        guard let token = await account.galleryAccessToken() else { error = "Đăng nhập tài khoản Dynor để lưu yêu thích."; return }
        let wasFavorite = favorites.contains(id)
        do {
            let userID = try await authenticatedUserID(token: token)
            if wasFavorite {
                _ = try await request("rest/v1/dynor_favorites?wallpaper_id=eq.\(id.uuidString)&user_id=eq.\(userID.uuidString)",method:"DELETE",token:token)
                favorites.remove(id)
            } else {
                let body = try JSONSerialization.data(withJSONObject: ["wallpaper_id":id.uuidString, "user_id":userID.uuidString])
                _ = try await request("rest/v1/dynor_favorites",method:"POST",token:token,body:body,prefer:"return=minimal")
                favorites.insert(id)
            }
        } catch { self.error = "Không lưu được yêu thích: \(error.localizedDescription)" }
    }

    func download(_ item: OnlineWallpaper) async throws -> URL {
        guard let token = await account.galleryAccessToken() else { throw GalleryFailure.message("Đăng nhập Dynor trước khi tải.") }
        let body = try JSONSerialization.data(withJSONObject:["id":item.id.uuidString.lowercased()])
        let data = try await request("functions/v1/dynor-wallpaper-download",method:"POST",token:token,body:body)
        struct Signed: Decodable { let url: URL }
        let signed = try JSONDecoder().decode(Signed.self,from:data)
        guard signed.url.scheme == "https", signed.url.host == OnlineConfig.base.host else { throw GalleryFailure.message("Địa chỉ tải không an toàn") }
        let (temporary,response) = try await URLSession.shared.download(from:signed.url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw GalleryFailure.message("Không tải được file") }
        let suggested = response.suggestedFilename ?? "Dynor-Wallpaper"
        let safe = URL(fileURLWithPath:suggested).lastPathComponent
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent(safe)
        try FileManager.default.createDirectory(at:destination.deletingLastPathComponent(),withIntermediateDirectories:true)
        try FileManager.default.moveItem(at:temporary,to:destination)
        return destination
    }
}

private enum GalleryFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
}

struct OnlineGalleryView: View {
    @EnvironmentObject private var store: DynorStore
    @StateObject private var model = OnlineGalleryModel()
    @State private var selected: OnlineWallpaper?
    @State private var onlyFavorites = false
    @State private var query = ""
    @State private var category = "Tất cả"
    @State private var featuredPage = 0
    @Environment(\.scenePhase) private var phase
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]
    private var categories: [String] { ["Tất cả"] + Array(Set(model.items.map(\.category))).sorted() }
    private var filtered: [OnlineWallpaper] {
        model.items.filter { item in
            (category == "Tất cả" || item.category == category) &&
            (!onlyFavorites || model.favorites.contains(item.id)) &&
            (query.isEmpty || "\(item.title) \(item.category)".localizedCaseInsensitiveContains(query))
        }
    }
    private var showFeatured: Bool { category == "Tất cả" && query.isEmpty && !onlyFavorites && !model.items.isEmpty }
    private var featured: [OnlineWallpaper] { Array(model.items.prefix(6)) }
    private var leftColumn: [OnlineWallpaper] { filtered.enumerated().filter { $0.offset % 2 == 0 }.map(\.element) }
    private var rightColumn: [OnlineWallpaper] { filtered.enumerated().filter { $0.offset % 2 == 1 }.map(\.element) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 23) {
                header.padding(.horizontal, 20)
                if showFeatured { featuredSection }
                searchBar.padding(.horizontal, 20)
                chips
                gridSection.padding(.horizontal, 20)
            }
            .padding(.top, 12)
        }
        .scrollIndicators(.hidden)
        .contentMargins(.bottom, 110, for: .scrollContent)
        .background { AuroraBackground() }
        .toolbar(.hidden, for: .navigationBar)
        .refreshable { await model.reload() }
        .task { await model.reload() }
        .onChange(of: phase) { _, newPhase in if newPhase == .active { Task { await model.reload() } } }
        .sheet(item: $selected) { item in
            OnlineWallpaperDetail(item: item, model: model)
                .presentationDragIndicator(.hidden)
                .presentationCornerRadius(40)
        }
    }

    // MARK: Sections

    private var header: some View {
        VStack(alignment: .leading, spacing: 23) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(alignment: .firstTextBaseline, spacing: 3) {
                        Text("Dynor").font(.system(size: 32, weight: .semibold, design: .serif)).italic()
                        Image(systemName: "sparkle").font(.system(size: 13)).offset(y: -10)
                    }
                    Text("W A L L P A P E R S")
                        .font(.system(size: 9, weight: .medium)).tracking(2.1)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Menu {
                    Button { store.appLanguage = "vi" } label: { Label("Tiếng Việt", systemImage: store.appLanguage == "vi" ? "checkmark" : "globe") }
                    Button { store.appLanguage = "en" } label: { Label("English", systemImage: store.appLanguage == "en" ? "checkmark" : "globe") }
                    Button { store.appLanguage = "zh" } label: { Label("中文", systemImage: store.appLanguage == "zh" ? "checkmark" : "globe") }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "globe")
                        Text(store.appLanguage == "zh" ? "中文" : store.appLanguage == "en" ? "EN" : "VI")
                        Image(systemName: "chevron.down").font(.system(size: 10, weight: .bold))
                    }
                    .font(.system(size: 13, weight: .medium))
                    .padding(.horizontal, 13).frame(height: 42)
                    .modifier(DynorGlass(radius: 22))
                }
                GlassIconButton(symbol: onlyFavorites ? "heart.fill" : "heart", tint: onlyFavorites ? .pink : nil, size: 42) {
                    withAnimation(.easeInOut(duration: 0.25)) { onlyFavorites.toggle() }
                }
                .accessibilityLabel(store.localized("Yêu thích", "Favorites", "收藏"))
            }
            VStack(alignment: .leading, spacing: 7) {
                Text(store.localized("KHÁM PHÁ", "EXPLORE", "探索"))
                    .font(.system(size: 11, weight: .semibold)).tracking(3)
                    .foregroundStyle(.secondary)
                Text(store.localized("Hình nền", "Wallpapers", "壁纸"))
                    .font(.system(size: 48, weight: .regular, design: .serif))
                    .tracking(-1.8)
                Text(store.localized("Hình nền động và tĩnh tuyển chọn cho thiết bị của bạn.",
                                     "Curated animated and static wallpapers for your device.",
                                     "为你的设备精选动态与静态壁纸。"))
                    .font(.system(size: 14)).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            HStack(spacing: 12) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 18, weight: .regular)).foregroundStyle(.secondary)
                TextField(store.localized("Tìm hình nền…", "Search wallpapers…", "搜索壁纸…"), text: $query)
                    .font(.system(size: 15))
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                if !query.isEmpty {
                    Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                }
            }
            .padding(.horizontal, 17).frame(height: 52)
            .modifier(DynorGlass(radius: 26))
            Menu {
                Button(store.localized("Tất cả", "All", "全部")) { category = "Tất cả"; onlyFavorites = false }
                Button(store.localized("Yêu thích", "Favorites", "收藏")) { onlyFavorites = true }
                ForEach(categories.filter { $0 != "Tất cả" }, id: \.self) { value in
                    Button(value) { category = value }
                }
            } label: {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 17))
                    .foregroundStyle(.primary)
                    .frame(width: 52, height: 52)
                    .modifier(DynorGlass(radius: 26))
            }
        }
    }

    private func categorySymbol(_ value: String) -> String {
        let v = value.lowercased()
        if value == "Tất cả" { return "square.grid.2x2" }
        if v.contains("nature") || v.contains("phong") || v.contains("自然") { return "mountain.2" }
        if v.contains("anime") || v.contains("动漫") { return "sparkles.rectangle.stack" }
        if v.contains("abstract") || v.contains("trừu") { return "sparkle" }
        if v.contains("minimal") || v.contains("tối giản") { return "square.3.layers.3d" }
        return "square.stack.3d.up"
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(categories, id: \.self) { value in
                    let active = category == value
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) { category = value }
                    } label: {
                        VStack(spacing: 9) {
                            Image(systemName: categorySymbol(value))
                                .font(.system(size: 20, weight: .light))
                            Text(value == "Tất cả" ? store.localized("Tất cả", "All", "全部") : value)
                                .font(.system(size: 12, weight: active ? .semibold : .regular))
                                .lineLimit(1)
                        }
                        .foregroundStyle(active ? Color.primary : Color.secondary)
                        .frame(width: 88, height: 80)
                        .background {
                            RoundedRectangle(cornerRadius: 23)
                                .fill(active ? Color.white.opacity(0.22) : Color.white.opacity(0.045))
                        }
                        .modifier(DynorGlass(radius: 23))
                    }
                    .buttonStyle(DynorPressStyle(scale: 0.96))
                }
            }.padding(.horizontal, 20).padding(.vertical, 3)
        }
    }

    private var featuredSection: some View {
        VStack(spacing: 9) {
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 12) {
                    ForEach(featured) { item in
                        FeaturedCard(item: item,
                                     isFavorite: model.favorites.contains(item.id),
                                     onOpen: { selected = item },
                                     onFavorite: { Task { await model.toggleFavorite(item.id) } })
                            .containerRelativeFrame(.horizontal) { width, _ in width * 0.89 }
                    }
                }
                .scrollTargetLayout()
            }
            .contentMargins(.horizontal, 20, for: .scrollContent)
            .scrollTargetBehavior(.viewAligned)
        }
    }

    private var gridSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            DynorSectionTitle(title: onlyFavorites ? store.localized("Yêu thích", "Favorites", "收藏") : store.localized("Mới nhất", "Latest", "最新"),
                              detail: String(format: "%02d", filtered.count))
            if model.loading && model.items.isEmpty {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(store.localized("Đang đồng bộ hình nền…", "Loading wallpapers…", "正在加载壁纸…")).font(.subheadline).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 40)
            }
            if let error = model.error {
                Label(error, systemImage: "wifi.exclamationmark")
                    .font(.caption).foregroundStyle(.red)
                    .dynorGlass(radius: 16, padding: 12)
            }
            if filtered.isEmpty && !model.loading {
                VStack(spacing: 12) {
                    Image(systemName: onlyFavorites ? "heart.slash" : "square.stack")
                        .font(.system(size: 34, weight: .light)).foregroundStyle(.secondary)
                    Text(onlyFavorites ? store.localized("Chưa có hình nền yêu thích", "No favorites yet", "暂无收藏") : store.localized("Chưa có hình nền", "No wallpapers yet", "暂无壁纸"))
                        .font(.system(size: 20, weight: .semibold))
                    Text(store.localized("Kéo xuống để làm mới bộ sưu tập.", "Pull down to refresh.", "下拉刷新。")).font(.subheadline).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 50)
            } else {
                HStack(alignment: .top, spacing: 14) {
                    LazyVStack(spacing: 18) { ForEach(leftColumn) { posterCard($0) } }
                    LazyVStack(spacing: 18) { ForEach(rightColumn) { posterCard($0) } }
                        .padding(.top, 34)
                }
            }
        }
    }

    private func posterCard(_ item: OnlineWallpaper) -> some View {
        PosterCard(item: item,
                   isFavorite: model.favorites.contains(item.id),
                   onOpen: { selected = item },
                   onFavorite: { Task { await model.toggleFavorite(item.id) } })
    }
}

// MARK: - Cards

private struct RemotePoster: View {
    let url: URL?
    var body: some View {
        AsyncImage(url: url, transaction: Transaction(animation: .easeOut(duration: 0.4))) { phase in
            switch phase {
            case .success(let image):
                image.resizable().scaledToFill()
            case .failure:
                DynorPlaceholder(symbol: "photo")
            default:
                DynorPlaceholder()
            }
        }
    }
}

private struct FavoriteButton: View {
    let isFavorite: Bool
    var size: CGFloat = 38
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: isFavorite ? "heart.fill" : "heart")
                .font(.system(size: size * 0.42, weight: .semibold))
                .foregroundStyle(isFavorite ? Color.pink : Color.white)
                .frame(width: size, height: size)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().strokeBorder(Color.white.opacity(0.22), lineWidth: 0.8))
                .symbolEffect(.bounce, value: isFavorite)
        }
        .buttonStyle(DynorPressStyle(scale: 0.88))
        .environment(\.colorScheme, .dark)
    }
}

private struct FeaturedCard: View {
    let item: OnlineWallpaper
    let isFavorite: Bool
    let onOpen: () -> Void
    let onFavorite: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Button(action: onOpen) {
                Color.clear
                    .aspectRatio(1.48, contentMode: .fit)
                    .overlay { RemotePoster(url: OnlineConfig.preview(item.cover_path)) }
                    .overlay(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(item.category.uppercased())
                                .font(.system(size: 11, weight: .semibold))
                                .tracking(1.4)
                                .foregroundStyle(.white.opacity(0.78))
                            Text(item.title)
                                .font(.system(size: 27, weight: .semibold, design: .serif))
                                .tracking(-0.4)
                                .foregroundStyle(.white)
                                .lineLimit(2)
                                .minimumScaleFactor(0.8)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 20).padding(.bottom, 20).padding(.top, 90)
                        .background(
                            LinearGradient(colors: [.clear, Color.black.opacity(0.35), Color.black.opacity(0.78)],
                                           startPoint: .top, endPoint: .bottom)
                        )
                    }
                    .overlay(alignment: .topLeading) {
                        if item.is_vip { VIPBadge().padding(14) }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous)
                        .strokeBorder(LinearGradient(colors: [Color.white.opacity(0.35), Color.white.opacity(0.04)],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
                    .shadow(color: .black.opacity(0.12), radius: 14, y: 7)
            }
            .buttonStyle(DynorPressStyle(scale: 0.975))
            FavoriteButton(isFavorite: isFavorite, action: onFavorite).padding(12)
        }
    }
}

private struct PosterCard: View {
    let item: OnlineWallpaper
    let isFavorite: Bool
    let onOpen: () -> Void
    let onFavorite: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Button(action: onOpen) {
                Color.clear
                    .aspectRatio(0.6, contentMode: .fit)
                    .overlay { RemotePoster(url: OnlineConfig.preview(item.cover_path)) }
                    .overlay(alignment: .bottom) {
                        DynorCaption(title: item.title, subtitle: item.category)
                    }
                    .overlay(alignment: .topLeading) {
                        if item.is_vip { VIPBadge().padding(10) }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous)
                        .strokeBorder(LinearGradient(colors: [Color.white.opacity(0.28), Color.white.opacity(0.03)],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
                    .shadow(color: .black.opacity(0.10), radius: 10, y: 5)
            }
            .buttonStyle(DynorPressStyle(scale: 0.97))
            FavoriteButton(isFavorite: isFavorite, size: 34, action: onFavorite).padding(8)
        }
    }
}

// MARK: - Detail

private struct OnlineWallpaperDetail: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    @ObservedObject var model: OnlineGalleryModel
    @Environment(\.dismiss) private var dismiss
    @State private var showVideo = false
    @State private var downloading = false
    @State private var importedWallpaper: ImportedWallpaper?
    @State private var notice: String?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            GeometryReader { geo in
                RemotePoster(url: OnlineConfig.preview(item.cover_path))
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
            }
            .ignoresSafeArea()
            LinearGradient(colors: [Color.black.opacity(0.45), .clear, .clear, Color.black.opacity(0.88)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
                .allowsHitTesting(false)
        }
        .overlay(alignment: .top) { topBar }
        .overlay(alignment: .bottom) { bottomPanel }
        .interactiveDismissDisabled(downloading)
        .sheet(isPresented: $showVideo) {
            if let path = item.video_path, let url = OnlineConfig.preview(path) { OnlineVideoView(url: url) }
        }
        .sheet(item: $importedWallpaper) { wallpaper in
            LibraryPreview(item: wallpaper).environmentObject(store)
        }
        .onChange(of: store.selectedTab) { _, tab in
            if tab != .discover { dismiss() }
        }
        .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) { notice = nil }
        } message: { Text(notice ?? "") }
    }

    private var topBar: some View {
        HStack {
            GlassIconButton(symbol: "xmark") { dismiss() }
                .disabled(downloading)
            Spacer()
            FavoriteButton(isFavorite: model.favorites.contains(item.id), size: 44) {
                Task { await model.toggleFavorite(item.id) }
            }
        }
        .environment(\.colorScheme, .dark)
        .padding(.horizontal, 18)
        .padding(.top, 18)
    }

    private var bottomPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 8) {
                DynorBadge(text: item.category)
                if item.is_vip { VIPBadge() }
            }
            Text(item.title)
                .font(.system(size: 32, weight: .bold))
                .tracking(-0.7)
                .foregroundStyle(.white)
                .lineLimit(2)
            if item.video_path != nil {
                Button { showVideo = true } label: {
                    Label(store.localized("Xem video xem trước", "Watch preview", "观看预览"), systemImage: "play.fill")
                }
                .buttonStyle(DynorGlassButtonStyle())
            }
            Button { startDownload() } label: {
                HStack(spacing: 10) {
                    if downloading { ProgressView().tint(store.accentTextColor) }
                    else { Image(systemName: "arrow.down.circle.fill") }
                    Text(downloading ? "Đang tải và nhập…" : "Tải và mở trong Dynor")
                }
            }
            .buttonStyle(DynorPrimaryButtonStyle(tint: store.accentColor, foreground: store.accentTextColor))
            .disabled(downloading)
            Text("Ảnh, tệp .tendies và gói mã hóa .dynor được thêm vào Thư viện rồi mở trong Dynor. Với gói hình nền, chọn Cài hình nền ở màn hình tiếp theo. Gói mã hóa cần đăng nhập và Internet mỗi lần cài. Nội dung VIP cần tài khoản VIP còn hiệu lực.")
                .font(.system(size: 11))
                .foregroundStyle(.white.opacity(0.55))
                .lineSpacing(2)
        }
        .environment(\.colorScheme, .dark)
        .padding(22)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 36, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 36, style: .continuous)
            .strokeBorder(LinearGradient(colors: [Color.white.opacity(0.34), Color.white.opacity(0.05), Color.white.opacity(0.12)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
        .shadow(color: .black.opacity(0.4), radius: 30, y: 14)
        .padding(.horizontal, 12)
        .padding(.bottom, 8)
    }

    private func startDownload() {
        downloading = true
        Task {
            do {
                let downloadedURL = try await model.download(item)
                defer { try? FileManager.default.removeItem(at: downloadedURL.deletingLastPathComponent()) }
                let imported = await store.importWallpapers(urls: [downloadedURL])
                if let wallpaper = imported.first {
                    store.message = nil
                    importedWallpaper = wallpaper
                } else {
                    notice = store.message ?? "Chưa nhập được hình nền đã tải."
                    store.message = nil
                }
            } catch { notice = error.localizedDescription }
            downloading = false
        }
    }
}

private struct OnlineVideoView: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Group { if let player { VideoPlayer(player: player) } else { ProgressView().tint(.white) } }
                .ignoresSafeArea()
            GlassIconButton(symbol: "xmark") { dismiss() }
                .environment(\.colorScheme, .dark)
                .padding(18)
        }
        .onAppear { let p = AVPlayer(url: url); player = p; p.play() }
        .onDisappear { player?.pause(); player = nil }
    }
}
