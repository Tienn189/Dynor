import SwiftUI
import AVKit
import UIKit

private enum OnlineConfig {
    static let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    static let key = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    static func preview(_ path: String) -> URL? {
        let trimmed = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        // The admin website stores absolute Supabase Storage URLs.
        if let url = URL(string: trimmed),
           let scheme = url.scheme?.lowercased(),
           scheme == "https" || scheme == "http" {
            return url
        }

        // Legacy records may store a path relative to dynor-previews.
        let relative = trimmed.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let encoded = relative.split(separator: "/").map { segment in
            String(segment).addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? String(segment)
        }.joined(separator: "/")
        return URL(string: "\(base.absoluteString)/storage/v1/object/public/dynor-previews/\(encoded)")
    }
}

private enum OnlineWallpaperTier: String {
    case free, premium, crown
}

private struct OnlineWallpaper: Identifiable, Decodable {
    let id: UUID
    let title: String
    let category: String
    let cover_path: String
    let video_path: String?
    let preview_states: [String: String]?
    let is_vip: Bool
    let access_tier: String?
    var tier: String { access_tier ?? (is_vip ? "crown" : "free") }
    var knownTier: OnlineWallpaperTier? { OnlineWallpaperTier(rawValue: tier) }

    // The server is the only source of truth for VIP classification.
    var requiresVIP: Bool { tier == "crown" || tier == "premium" }

}

@MainActor
private final class OnlineGalleryModel: ObservableObject {
    @Published var items: [OnlineWallpaper] = []
    @Published var favorites: Set<UUID> = []
    private var favoriteRequests: Set<UUID> = []
    @Published var loading = false
    @Published var error: String?
    private let account = DynorAccountService.shared
    private var reloadInProgress = false

    private func request(_ path: String, method: String = "GET", token: String? = nil, body: Data? = nil, prefer: String? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: OnlineConfig.base)?.absoluteURL else { throw GalleryFailure.message("URL không hợp lệ") }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(OnlineConfig.key, forHTTPHeaderField: "apikey")
        if let token { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body { req.httpBody = body; req.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if let prefer { req.setValue(prefer, forHTTPHeaderField: "Prefer") }
        req.timeoutInterval = 18
        let (data,response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "Không kết nối được Supabase"
            if let payload = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let code = payload["code"] as? String ?? payload["error"] as? String {
                let language = UserDefaults.standard.string(forKey: "dynor.language") ?? "vi"
                func localized(_ vi: String, _ en: String, _ zh: String) -> String { language.hasPrefix("zh") ? zh : (language == "en" ? en : vi) }
                if code == "quota_exceeded" {
                    let used = payload["used"] as? Int ?? 0
                    let limit = payload["limit"] as? Int ?? 0
                    throw GalleryFailure.message(localized(
                        "Bạn đã dùng hết \(limit) lượt tải hình nền VIP (\(used)/\(limit)). Mua thêm gói VIP để nhận thêm lượt. Hình đã tải có thể tải lại miễn phí.",
                        "You've used all \(limit) VIP wallpaper downloads (\(used)/\(limit)). Buy another VIP plan for more credits. Previously downloaded wallpapers are free to download again.",
                        "VIP 壁纸下载次数已用完（\(used)/\(limit)）。购买其他 VIP 套餐即可增加次数。已下载的壁纸可免费重新下载。"))
                }
                if code == "crown_plan_required" {
                    throw GalleryFailure.message(localized("Gói tuần chỉ tải được Premium 💎. Cần gói tháng trở lên để tải Crown 👑.", "Weekly plans include Premium only. A monthly plan or above is required for Crown.", "周卡仅支持 Premium。下载皇冠壁纸需要月卡或更高套餐。"))
                }
                if code == "vip_required" {
                    throw GalleryFailure.message(localized("Cần gói VIP còn hiệu lực để tải hình nền này.", "An active VIP plan is required for this wallpaper.", "下载此壁纸需要有效的 VIP 会员。"))
                }
            }
            throw GalleryFailure.message("Máy chủ: \(text.prefix(180))")
        }
        return data
    }

    // Retry temporary network failures automatically. Keep the last successful
    // wallpapers visible while a refresh is in progress or offline.
    func reload() async {
        guard !reloadInProgress else { return }
        reloadInProgress = true
        loading = true
        defer { loading = false; reloadInProgress = false }
        let delays: [UInt64] = [0, 1_000_000_000, 2_000_000_000, 4_000_000_000]
        for (attempt, delay) in delays.enumerated() {
            if Task.isCancelled { return }
            if delay > 0 {
                try? await Task.sleep(nanoseconds: delay)
                if Task.isCancelled { return }
            }
            do {
                let data = try await request("rest/v1/dynor_wallpapers?select=*&published=eq.true&order=created_at.desc")
                let fresh = try JSONDecoder().decode([OnlineWallpaper].self, from: data)
                items = fresh
                error = nil
                await reloadFavorites()
                return
            } catch {
                if attempt == delays.count - 1 {
                    self.error = "Không tải được hình nền sau nhiều lần thử: \(error.localizedDescription)"
                }
            }
        }
    }

    func reloadFavorites() async {
        guard let token = await account.galleryAccessToken() else { favorites = []; return }
        do {
            let data = try await request("rest/v1/dynor_favorites?select=wallpaper_id", token: token)
            struct Favorite: Decodable { let wallpaper_id: UUID }
            favorites = Set(try JSONDecoder().decode([Favorite].self, from: data).map(\.wallpaper_id))
        } catch { self.error = "Không đồng bộ được yêu thích: \(error.localizedDescription)" }
    }

    private func authenticatedUserID(token: String) async throws -> UUID {
        let data = try await request("auth/v1/user", token: token)
        struct AuthUser: Decodable { let id: UUID }
        return try JSONDecoder().decode(AuthUser.self, from: data).id
    }

    func toggleFavorite(_ id: UUID) async {
        guard !favoriteRequests.contains(id) else { return }
        guard let token = await account.galleryAccessToken() else { error = "Đăng nhập tài khoản Dynor để lưu yêu thích."; return }
        favoriteRequests.insert(id)
        let wasFavorite = favorites.contains(id)
        // Update the UI immediately; restore it if the server request fails.
        withAnimation(.easeInOut(duration: 0.32)) {
            if wasFavorite { favorites.remove(id) } else { favorites.insert(id) }
        }
        defer { favoriteRequests.remove(id) }
        do {
            let userID = try await authenticatedUserID(token: token)
            if wasFavorite {
                _ = try await request("rest/v1/dynor_favorites?wallpaper_id=eq.\(id.uuidString)&user_id=eq.\(userID.uuidString)",method:"DELETE",token:token)
            } else {
                let body = try JSONSerialization.data(withJSONObject: ["wallpaper_id":id.uuidString, "user_id":userID.uuidString])
                _ = try await request("rest/v1/dynor_favorites",method:"POST",token:token,body:body,prefer:"return=minimal")
            }
        } catch {
            withAnimation(.easeInOut(duration: 0.32)) {
                if wasFavorite { favorites.insert(id) } else { favorites.remove(id) }
            }
            self.error = "Không lưu được yêu thích: \(error.localizedDescription)"
        }
    }

    func download(_ item: OnlineWallpaper, progress: @escaping @MainActor (Double) -> Void) async throws -> URL {
        guard let token = await account.galleryAccessToken() else { throw GalleryFailure.message("Đăng nhập Dynor trước khi tải.") }
        let body = try JSONSerialization.data(withJSONObject:["id":item.id.uuidString.lowercased()])
        let data: Data
        do {
            data = try await request("functions/v1/dynor-wallpaper-download",method:"POST",token:token,body:body)
        } catch {
            if error.localizedDescription.contains("NOT_FOUND") {
                throw GalleryFailure.message("Máy chủ chưa triển khai Edge Function dynor-wallpaper-download. Admin cần triển khai chức năng tải có xác thực trên Supabase trước khi tải hình nền.")
            }
            throw error
        }
        struct Signed: Decodable { let url: URL }
        let signed = try JSONDecoder().decode(Signed.self,from:data)
        guard signed.url.scheme == "https", signed.url.host == OnlineConfig.base.host else { throw GalleryFailure.message("Địa chỉ tải không an toàn") }
        progress(0.01)
        let observer = WallpaperDownloadObserver(progress: progress)
        let session = URLSession(configuration: .default, delegate: observer, delegateQueue: nil)
        defer { session.finishTasksAndInvalidate() }
        let (temporary,response) = try await session.download(from:signed.url)
        progress(0.96)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw GalleryFailure.message("Không tải được file") }
        let suggested = response.suggestedFilename ?? "Dynor-Wallpaper"
        let safe = URL(fileURLWithPath:suggested).lastPathComponent
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent(safe)
        try FileManager.default.createDirectory(at:destination.deletingLastPathComponent(),withIntermediateDirectories:true)
        try FileManager.default.moveItem(at:temporary,to:destination)
        Task { await account.refreshVIP() }
        return destination
    }
}

private final class WallpaperDownloadObserver: NSObject, URLSessionDownloadDelegate {
    let progress: @MainActor (Double) -> Void
    init(progress: @escaping @MainActor (Double) -> Void) { self.progress = progress }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {}
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else { return }
        let value = min(0.95, max(0.01, Double(totalBytesWritten) / Double(totalBytesExpectedToWrite) * 0.95))
        Task { @MainActor in progress(value) }
    }
}

private enum GalleryFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
}

struct OnlineGalleryView: View {
    @EnvironmentObject private var store: DynorStore
    @StateObject private var model = OnlineGalleryModel()
    @State private var onlyFavorites = false
    @State private var favoritesContentVisible = true
    @State private var favoritesTransitionTask: Task<Void, Never>?
    @State private var query = ""
    @State private var category = "Tất cả"
    @State private var selectedTier: OnlineWallpaperTier?
    @Environment(\.scenePhase) private var phase
    @Environment(\.horizontalSizeClass) private var sizeClass
    private var columns: [GridItem] {
        [GridItem(.adaptive(minimum: sizeClass == .regular ? 190 : 128, maximum: 280), spacing: 14)]
    }
    private var categories: [String] { ["Tất cả"] + Array(Set(model.items.map(\.category))).sorted() }
    private var searchQuery: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var hasFilters: Bool { selectedTier != nil || category != "Tất cả" || !searchQuery.isEmpty }

    private var filtered: [OnlineWallpaper] {
        let keyword = searchQuery
        return model.items.filter { item in
            (category == "Tất cả" || item.category == category) &&
            (selectedTier == nil || item.knownTier == selectedTier) &&
            (!onlyFavorites || model.favorites.contains(item.id)) &&
            (keyword.isEmpty || "\(item.title) \(item.category)".localizedStandardContains(keyword))
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Text(store.localized("Hình nền tuyển chọn cho iPhone của bạn.", "Selected wallpapers for your iPhone.", "为你的 iPhone 精选壁纸。"))
                    .font(.subheadline).foregroundStyle(.secondary)
                chips
                gridSection
                    .opacity(favoritesContentVisible ? 1 : 0)
                    .offset(y: favoritesContentVisible ? 0 : 7)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 24)
            .frame(maxWidth: 960)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .navigationTitle(store.localized("Khám phá", "Explore", "探索"))
        .navigationBarTitleDisplayMode(.large)
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always),
                    prompt: store.localized("Tìm hình nền", "Search wallpapers", "搜索壁纸"))
        .textInputAutocapitalization(.never)
        .autocorrectionDisabled()
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                languageMenu
                Button {
                    switchFavoritesFilter()
                } label: {
                    Image(systemName: onlyFavorites ? "heart.fill" : "heart")
                }
                .tint(store.accentColor)
                .accessibilityLabel(store.localized("Yêu thích", "Favorites", "收藏"))
                .accessibilityValue(onlyFavorites ? store.localized("Đang lọc", "Filter on", "已筛选") : store.localized("Tất cả", "All", "全部"))
                tierMenu
            }
        }
        .refreshable { await model.reload() }
        .task { await model.reload() }
        .onChange(of: phase) { _, newPhase in if newPhase == .active { Task { await model.reload() } } }

    }

    private func switchFavoritesFilter() {
        favoritesTransitionTask?.cancel()
        guard !UIAccessibility.isReduceMotionEnabled else {
            onlyFavorites.toggle()
            favoritesContentVisible = true
            return
        }
        withAnimation(.easeInOut(duration: 0.14)) {
            favoritesContentVisible = false
        }
        favoritesTransitionTask = Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(145))
            guard !Task.isCancelled else { return }
            onlyFavorites.toggle()
            withAnimation(.easeInOut(duration: 0.22)) {
                favoritesContentVisible = true
            }
        }
    }

    private var languageMenu: some View {
        Menu {
            Button { store.appLanguage = "vi" } label: { Text("🇻🇳 Tiếng Việt" + (store.appLanguage == "vi" ? "  ✓" : "")) }
            Button { store.appLanguage = "en" } label: { Text("🇬🇧 English" + (store.appLanguage == "en" ? "  ✓" : "")) }
            Button { store.appLanguage = "zh-Hans" } label: { Text("🇨🇳 简体中文" + (store.appLanguage == "zh-Hans" ? "  ✓" : "")) }
        } label: {
            Image(systemName: "globe")
        }
        .accessibilityLabel(store.localized("Ngôn ngữ", "Language", "语言"))
    }

    private var tierMenu: some View {
        Menu {
            Picker(store.localized("Phân loại hình nền", "Wallpaper tier", "壁纸类型"), selection: $selectedTier) {
                Text(store.localized("Tất cả", "All", "全部")).tag(nil as OnlineWallpaperTier?)
                Text(store.localized("Miễn phí", "Free", "免费")).tag(OnlineWallpaperTier.free as OnlineWallpaperTier?)
                Text("Premium").tag(OnlineWallpaperTier.premium as OnlineWallpaperTier?)
                Text("Crown").tag(OnlineWallpaperTier.crown as OnlineWallpaperTier?)
            }
            .pickerStyle(.inline)
        } label: {
            Label(store.localized("Lọc hình nền", "Filter wallpapers", "筛选壁纸"),
                  systemImage: selectedTier == nil ? "line.3.horizontal.decrease" : "line.3.horizontal.decrease.circle.fill")
                .labelStyle(.iconOnly)
        }
        .tint(store.accentColor)
    }

    private var chips: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(categories, id: \.self) { value in
                        let active = category == value
                        Button {
                            withAnimation(.smooth(duration: 0.32)) {
                                category = value
                                proxy.scrollTo(value, anchor: .center)
                            }
                        } label: {
                            Text(store.localizedCategory(value))
                                .font(.subheadline.weight(active ? .semibold : .medium))
                                .foregroundStyle(active ? store.accentTextColor : Color.primary)
                                .lineLimit(1)
                                .fixedSize(horizontal: true, vertical: false)
                                .padding(.horizontal, 18)
                                .frame(minHeight: 44)
                                .background {
                                    if active {
                                        Capsule().fill(store.accentColor)
                                    } else {
                                        Capsule().fill(.clear).modifier(DynorGlass(radius: 24, interactive: true))
                                    }
                                }
                                .contentShape(Capsule())
                        }
                        .buttonStyle(.plain)
                        .id(value)
                        .accessibilityAddTraits(active ? .isSelected : [])
                    }
                }
                .padding(.horizontal, 0)
                .padding(.vertical, 10)
            }
            .scrollClipDisabled()
            .contentMargins(.horizontal, 0, for: .scrollContent)
            .onChange(of: category) { _, value in
                withAnimation(.smooth(duration: 0.32)) {
                    proxy.scrollTo(value, anchor: .center)
                }
            }
        }
    }

    private var gridSection: some View {
        let results = filtered
        let emptyFavorites = onlyFavorites && !hasFilters
        return VStack(alignment: .leading, spacing: 16) {
            DynorSectionTitle(title: onlyFavorites ? store.localized("Yêu thích", "Favorites", "收藏") : store.localized("Mới nhất", "Latest", "最新"),
                              detail: "\(results.count)")
            if model.loading && model.items.isEmpty {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(store.localized("Đang tải hình nền…", "Loading wallpapers…", "正在加载壁纸…")).font(.subheadline).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 40)
            }
            if let error = model.error {
                VStack(alignment: .leading, spacing: 12) {
                    Label(error, systemImage: "wifi.exclamationmark").font(.caption).foregroundStyle(.secondary)
                    Button(store.localized("Thử lại", "Try again", "重试")) { Task { await model.reload() } }
                        .font(.subheadline.weight(.semibold)).tint(store.accentColor)
                }
                .frame(maxWidth: .infinity, alignment: .leading).padding(16)
                .modifier(DynorGlass(radius: 20))
            }
            if results.isEmpty && !model.loading && model.error == nil {
                DynorEmptyState(
                    symbol: emptyFavorites ? "heart" : "photo.on.rectangle",
                    title: emptyFavorites ? store.localized("Chưa có yêu thích", "No favorites yet", "暂无收藏") : store.localized("Chưa tìm thấy hình nền", "No wallpapers found", "未找到壁纸"),
                    message: emptyFavorites
                        ? store.localized("Chạm vào trái tim để lưu hình nền tại đây.", "Tap a heart to save a wallpaper here.", "轻点爱心，在这里收藏壁纸。")
                        : store.localized("Thử đổi bộ lọc hoặc từ khóa tìm kiếm.", "Try changing the filters or search terms.", "请尝试更改筛选条件或搜索词。"))
            } else {
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(results) { item in
                        PosterCard(item: item,
                                   model: model)
                    }
                }
            }
        }
    }
}

private struct WallpaperDownloadIcon: View {
    let tier: OnlineWallpaperTier?

    var body: some View {
        switch tier {
        case .free: Image(systemName: "ticket.fill").foregroundStyle(Color.green)
        case .premium: Image(systemName: "diamond.fill").foregroundStyle(Color.cyan)
        case .crown: Image(systemName: "crown.fill").foregroundStyle(Color.yellow)
        case nil: Image(systemName: "arrow.down.circle.fill")
        }
    }
}

// MARK: - Artwork

private struct RemotePoster: View {
    let url: URL?
    var fit: Bool = false
    @State private var attempt = 0
    @State private var retrying = false

    var body: some View {
        AsyncImage(url: url, transaction: Transaction(animation: .easeOut(duration: 0.3))) { phase in
            switch phase {
            case .success(let image):
                image.resizable().aspectRatio(contentMode: fit ? .fit : .fill)
            case .failure:
                ZStack {
                    DynorDesign.mist
                    if attempt >= 4 {
                        Button { attempt = 0 } label: {
                            Image(systemName: "arrow.clockwise")
                                .font(.title2)
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Tải lại ảnh")
                    } else {
                        ProgressView()
                    }
                }
                .task(id: attempt) {
                    guard url != nil, attempt < 4, !retrying else { return }
                    retrying = true
                    defer { retrying = false }
                    let seconds = UInt64(1 << attempt)
                    try? await Task.sleep(for: .seconds(seconds))
                    guard !Task.isCancelled else { return }
                    attempt += 1
                }
            default:
                ZStack {
                    DynorDesign.mist
                    ProgressView()
                }
            }
        }
        .id("\(url?.absoluteString ?? "")-\(attempt)")
        .onChange(of: url) { _, _ in attempt = 0 }
    }
}

private struct FavoriteButton: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let isFavorite: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack {
                Image(systemName: "heart")
                    .foregroundStyle(.white)
                    .opacity(isFavorite ? 0.18 : 1)
                Image(systemName: "heart.fill")
                    .foregroundStyle(.red)
                    .opacity(isFavorite ? 1 : 0)
                    .scaleEffect(isFavorite && !reduceMotion ? 1.08 : 0.92)
            }
            .font(.system(size: 16, weight: .medium))
            .frame(width: 38, height: 38)
            .modifier(DynorGlass(radius: 19, interactive: true))
            .frame(width: 44, height: 44)
            .contentShape(Circle())
        }
        .buttonStyle(DynorPressStyle())
        .environment(\.colorScheme, .dark)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.32), value: isFavorite)
        .accessibilityLabel(isFavorite ? store.localized("Bỏ yêu thích", "Remove favorite", "取消收藏") : store.localized("Thêm yêu thích", "Add favorite", "添加收藏"))
    }
}

/// A smaller glass control with the standard 44-point touch target.
private struct ThumbnailActionButton: View {
    let symbol: String
    var tint: Color = .white
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(tint)
                .frame(width: 38, height: 38)
                .modifier(DynorGlass(radius: 19, interactive: true))
                .frame(width: 44, height: 44)
                .contentShape(Circle())
        }
        .buttonStyle(DynorPressStyle())
        .environment(\.colorScheme, .dark)
    }
}

private struct InlineWallpaperVideo: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> PlayerSurface {
        let view = PlayerSurface()
        view.playerLayer.videoGravity = .resizeAspect
        view.playerLayer.player = player
        return view
    }
    func updateUIView(_ uiView: PlayerSurface, context: Context) {
        uiView.playerLayer.player = player
    }
    final class PlayerSurface: UIView {
        override static var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }
}

private struct PosterCard: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    @ObservedObject var model: OnlineGalleryModel
    @State private var player: AVPlayer?
    @State private var videoVisible = false
    @State private var previewGeneration = 0
    @State private var downloading = false
    @State private var downloadProgress = 0.0
    @State private var heartBurst = false
    @State private var heartPulse = false
    @State private var burstID = 0
    @State private var heartLocation: CGPoint = .zero
    @State private var heartSize: CGSize = .zero
    @State private var notice: String?
    @State private var importedWallpaper: ImportedWallpaper?

    private var cleanTitle: String {
        item.title.replacingOccurrences(of: #"\.(dynor|tendies)$"#, with: "", options: [.regularExpression, .caseInsensitive])
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack {
                RoundedRectangle(cornerRadius: 20).fill(DynorDesign.mist)
                RemotePoster(url: OnlineConfig.preview(item.cover_path), fit: true)
                if let player {
                    InlineWallpaperVideo(player: player)
                        .opacity(videoVisible ? 1 : 0)
                        .allowsHitTesting(false)
                }
                if heartBurst {
                    Image(systemName: "heart.fill")
                        .font(.system(size: 72, weight: .bold))
                        .foregroundStyle(.red)
                        .shadow(color: .red.opacity(0.35), radius: 12)
                        .scaleEffect(heartPulse ? 1.12 : 0.55)
                        .opacity(heartPulse ? 1 : 0)
                        .position(heartLocation)
                        .allowsHitTesting(false)
                }
            }
            .aspectRatio(9.0 / 19.5, contentMode: .fit)
            .frame(maxWidth: .infinity)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .contentShape(RoundedRectangle(cornerRadius: 20))
            .onGeometryChange(for: CGSize.self) { $0.size } action: { heartSize = $0 }
            .onTapGesture(count: 2, coordinateSpace: .local) { point in burstFavorite(at: point) }
            .overlay(alignment: .topLeading) {
                VStack(alignment: .leading, spacing: 7) {
                    if item.video_path != nil {
                        ThumbnailActionButton(symbol: player == nil ? "play.fill" : "pause.fill", action: togglePreview)
                    }
                }
                .padding(8)
            }
            .overlay(alignment: .topTrailing) {
                FavoriteButton(isFavorite: model.favorites.contains(item.id), action: favoriteTapped)
                    .scaleEffect(heartPulse ? 1.16 : 1)
                    .padding(8)
            }
            .overlay(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(cleanTitle)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .shadow(color: .black.opacity(0.7), radius: 3)
                    HStack(spacing: 4) {
                        Text(store.localizedCategory(item.category))
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .padding(.horizontal, 9)
                            .frame(height: 23)
                            .modifier(DynorGlass(radius: 12))
                    }
                    Button(action: startDownload) {
                        ZStack {
                            if downloading {
                                GeometryReader { geometry in
                                    Capsule()
                                        .fill(Color.white.opacity(0.30))
                                        .frame(width: geometry.size.width * min(1, max(0, downloadProgress)))
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }
                                .clipShape(Capsule())
                            }
                            HStack(spacing: 5) {
                                if downloading {
                                    Text("\(Int((downloadProgress * 100).rounded()))%")
                                        .monospacedDigit()
                                } else {
                                    WallpaperDownloadIcon(tier: item.knownTier)
                                    Text(store.localized("Tải hình nền", "Download", "下载壁纸"))
                                        .lineLimit(1).minimumScaleFactor(0.7)
                                }
                            }
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                        }
                        .frame(height: 32)
                        .modifier(DynorGlass(radius: 16, interactive: true))
                        .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                    .disabled(downloading)
                }
                .padding(.horizontal, 9)
                .padding(.bottom, 10)
                .padding(.top, 25)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background {
                    LinearGradient(colors: [.clear, .black.opacity(0.60)], startPoint: .top, endPoint: .bottom)
                        .clipShape(UnevenRoundedRectangle(bottomLeadingRadius: 20, bottomTrailingRadius: 20))
                        .allowsHitTesting(false)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))

        }
        .onReceive(NotificationCenter.default.publisher(for: .AVPlayerItemDidPlayToEndTime)) { notification in
            guard let current = player?.currentItem, notification.object as? AVPlayerItem === current else { return }
            stopPreview()
        }
        .onDisappear { stopPreview() }
        .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) { notice = nil }
        } message: { Text(notice ?? "") }
    }

    private func togglePreview() {
        if player != nil { stopPreview(); return }
        guard let path = item.video_path, let url = OnlineConfig.preview(path) else { return }
        previewGeneration += 1
        let generation = previewGeneration
        videoVisible = false
        let newPlayer = AVPlayer(url: url)
        player = newPlayer
        newPlayer.play()
        Task { @MainActor in
            for _ in 0..<60 {
                guard previewGeneration == generation, player === newPlayer else { return }
                if newPlayer.currentItem?.status == .readyToPlay,
                   newPlayer.timeControlStatus == .playing,
                   newPlayer.currentTime().seconds > 0.08 {
                    withAnimation(.easeInOut(duration: 0.42)) { videoVisible = true }
                    return
                }
                try? await Task.sleep(for: .milliseconds(80))
            }
        }
    }
    private func stopPreview() {
        previewGeneration += 1
        let oldPlayer = player
        withAnimation(.easeInOut(duration: 0.42)) { videoVisible = false }
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(500))
            guard player === oldPlayer else { return }
            oldPlayer?.pause()
            oldPlayer?.replaceCurrentItem(with: nil)
            player = nil
        }
    }
    private func favoriteTapped() {
        withAnimation(.spring(response: 0.22, dampingFraction: 0.5)) { heartPulse = true }
        Task {
            await model.toggleFavorite(item.id)
            withAnimation(.easeOut(duration: 0.2)) { heartPulse = false }
        }
    }
    private func burstFavorite(at point: CGPoint) {
        burstID += 1
        let current = burstID
        heartLocation = point
        // Reset first so repeated double-taps replay the animation.
        var transaction = Transaction(animation: nil)
        withTransaction(transaction) { heartBurst = true; heartPulse = false }
        withAnimation(.spring(response: 0.28, dampingFraction: 0.58)) { heartPulse = true }
        if !model.favorites.contains(item.id) { Task { await model.toggleFavorite(item.id) } }
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(350))
            guard current == burstID else { return }
            withAnimation(.easeOut(duration: 0.35)) { heartPulse = false }
            try? await Task.sleep(for: .milliseconds(360))
            guard current == burstID else { return }
            heartBurst = false
        }
    }
    private func startDownload() {
        guard !downloading else { return }
        downloadProgress = 0
        downloading = true
        Task { @MainActor in
            let started = Date()
            do {
                let url = try await model.download(item, progress: { value in
                    withAnimation(.linear(duration: 0.15)) {
                        downloadProgress = max(downloadProgress, min(0.96, value))
                    }
                })
                defer { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
                downloadProgress = max(downloadProgress, 0.97)
                let imported = await store.importWallpapers(urls: [url])
                if let wallpaper = imported.first {
                    store.message = nil
                    _ = store.attachPreview(OnlineConfig.preview(item.cover_path), to: wallpaper.id)
                    // Complete the visible progress animation before reporting success.
                    let elapsed = Date().timeIntervalSince(started)
                    if elapsed < 0.65 {
                        try? await Task.sleep(for: .milliseconds(Int((0.65 - elapsed) * 1000)))
                    }
                    withAnimation(.linear(duration: 0.65)) { downloadProgress = 1 }
                    try? await Task.sleep(for: .milliseconds(750))
                    notice = store.localized("Đã tải vào Bộ sưu tập.", "Saved to Collection.", "已保存到收藏。")
                } else {
                    notice = store.message ?? "Không nhập được hình nền."
                    store.message = nil
                }
            } catch { notice = error.localizedDescription }
            downloading = false
        }
    }

}

// MARK: - Detail

private struct OnlineWallpaperDetail: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    @ObservedObject var model: OnlineGalleryModel
    @Environment(\.dismiss) private var dismiss
    @State private var inlinePlayer: AVPlayer?
    @State private var selectedPreview: String?
    @State private var expandedPreview = false
    @Environment(\.scenePhase) private var scenePhase
    @State private var downloading = false
    @State private var downloadProgress = 0.0
    @State private var heartPulse = false
    @State private var heartBurst = false
    @State private var detailBurstID = 0
    @State private var detailHeartLocation: CGPoint = .zero
    @State private var importedWallpaper: ImportedWallpaper?
    @State private var notice: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                topBar
                previewArtwork
                .overlay {
                    if heartBurst {
                        Image(systemName: "heart.fill")
                            .font(.system(size: 94, weight: .bold))
                            .foregroundStyle(.white)
                            .shadow(color: .black.opacity(0.25), radius: 12)
                            .transition(.scale.combined(with: .opacity))
                            .allowsHitTesting(false)
                    }
                }
                .onTapGesture(count: 2, coordinateSpace: .local) { point in burstFavorite(at: point) }
                .accessibilityLabel(store.localized("Ảnh xem trước hình nền", "Wallpaper preview", "壁纸预览"))
                previewControls
                bottomPanel
            }
            .padding(20)
            .frame(maxWidth: 640)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .safeAreaInset(edge: .bottom, spacing: 0) { downloadBar }
        .interactiveDismissDisabled(downloading)
        .onDisappear { stopPreview() }
        .onChange(of: scenePhase) { _, phase in if phase != .active { stopPreview() } }
        .fullScreenCover(isPresented: $expandedPreview) {
            OnlineExpandedPreview(item: item, initialState: selectedPreview).environmentObject(store)
        }
        .sheet(item: $importedWallpaper) { wallpaper in
            LibraryPreview(item: wallpaper).environmentObject(store)
        }
        .onChange(of: store.selectedTab) { _, tab in
            if tab != .discover { dismiss() }
        }
        .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) { notice = nil }
        } message: { Text(notice ?? "") }
    }

    private var topBar: some View {
        HStack {
            Text(store.localized("Xem trước", "Preview", "预览")).font(.headline)
            Spacer()
            GlassIconButton(symbol: "arrow.up.left.and.arrow.down.right") {
                let previous = selectedPreview
                stopPreview()
                selectedPreview = previous
                expandedPreview = true
            }
            GlassIconButton(symbol: "xmark") {
                stopPreview()
                dismiss()
            }
                .accessibilityLabel(store.localized("Đóng", "Close", "关闭"))
        }
    }

    private var bottomPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Text(store.localizedCategory(item.category)).font(.subheadline).foregroundStyle(.secondary)
            }
            if item.tier == "crown" || item.tier == "premium" {
                Label(item.tier == "crown"
                    ? store.localized("Vương miện · VIP + lượt tải", "Crown · VIP + download credit", "皇冠 · VIP + 下载次数")
                    : store.localized("Kim cương · VIP không giới hạn", "Diamond · Unlimited for VIP", "钻石 · VIP 无限下载"),
                      systemImage: item.tier == "crown" ? "crown.fill" : "diamond.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(item.tier == "crown" ? Color.orange : Color.cyan)
            }
            Text(item.title)
                .font(.title2.weight(.bold))
                .fixedSize(horizontal: false, vertical: true)
            Text(store.localized("Tải vào Bộ sưu tập, sau đó chọn Cài hình nền. Gói mã hóa cần đăng nhập và Internet mỗi lần cài. Nội dung VIP cần tài khoản VIP còn hiệu lực.", "Download to your collection, then choose Install Wallpaper. Encrypted packages need sign-in and Internet each time. VIP content requires active VIP access.", "下载到收藏后，选择安装壁纸。加密包每次安装均需登录和联网。VIP 内容需要有效的 VIP 权限。"))
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var downloadBar: some View {
        HStack(spacing: 12) {
            Button { animateFavorite() } label: {
                Image(systemName: model.favorites.contains(item.id) ? "heart.fill" : "heart")
                    .font(.title3)
                    .scaleEffect(heartPulse ? 1.35 : 1)
                    .frame(width: 48, height: 48)
            }
            .buttonStyle(.plain)
            .foregroundStyle(model.favorites.contains(item.id) ? .red : store.accentColor)
            .accessibilityLabel(store.localized("Yêu thích", "Favorite", "收藏"))
            Button { startDownload() } label: {
                HStack(spacing: 8) {
                    if downloading {
                        Image(systemName: "arrow.down.circle.fill")
                        Text("\(Int(downloadProgress * 100))%")
                            .monospacedDigit()
                    } else {
                        WallpaperDownloadIcon(tier: item.knownTier)
                        Text(store.localized("Tải hình nền", "Get wallpaper", "下载壁纸"))
                    }
                }
                .font(.body.weight(.semibold))
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(DynorPrimaryButtonStyle())
            .overlay(alignment: .bottomLeading) {
                if downloading {
                    GeometryReader { geo in
                        Capsule().fill(store.accentColor.opacity(0.35))
                            .frame(width: geo.size.width * downloadProgress, height: 4)
                    }.frame(height: 4).padding(.horizontal, 12).padding(.bottom, 3)
                }
            }
            .disabled(downloading)
        }
        .padding(12)
        .modifier(DynorGlass(radius: 28))
        .padding(.horizontal, 16).padding(.vertical, 10)
        .frame(maxWidth: 640)
        .frame(maxWidth: .infinity)
    }

    private var previewArtwork: some View {
        ZStack {
            RemotePoster(url: OnlineConfig.preview(item.cover_path))
                .blur(radius: 35).opacity(0.35)
                .clipped()
            OnlinePreviewSurface(item: item, player: inlinePlayer)
                .padding(14)
        }
        .aspectRatio(9.0 / 19.5, contentMode: .fit)
        .frame(maxWidth: 350)
        .clipShape(RoundedRectangle(cornerRadius: 30))
        .frame(maxWidth: .infinity)
    }

    private var previewControls: some View {
        OnlinePreviewControls(item: item, selection: selectedPreview) { key in
            if selectedPreview == key { stopPreview(); return }
            stopPreview()
            guard let url = item.previewURL(for: key) else { return }
            let p = AVPlayer(url: url)
            p.isMuted = true
            inlinePlayer = p
            selectedPreview = key
            p.play()
        }
    }

    private func stopPreview() {
        inlinePlayer?.pause()
        inlinePlayer?.replaceCurrentItem(with: nil)
        inlinePlayer = nil
        selectedPreview = nil
    }

    private func animateFavorite() {
        withAnimation(.spring(response: 0.22, dampingFraction: 0.45)) { heartPulse = true }
        Task { await model.toggleFavorite(item.id)
            withAnimation(.spring(response: 0.3)) { heartPulse = false }
        }
    }

    private func burstFavorite(at point: CGPoint) {
        detailBurstID += 1
        let current = detailBurstID
        detailHeartLocation = point
        withTransaction(Transaction(animation: nil)) { heartBurst = true; heartPulse = false }
        withAnimation(.spring(response: 0.28, dampingFraction: 0.58)) { heartPulse = true }
        if !model.favorites.contains(item.id) { Task { await model.toggleFavorite(item.id) } }
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(350))
            guard current == detailBurstID else { return }
            withAnimation(.easeOut(duration: 0.35)) { heartPulse = false }
            try? await Task.sleep(for: .milliseconds(360))
            guard current == detailBurstID else { return }
            heartBurst = false
        }
    }
    private func startDownload() {
        downloadProgress = 0
        downloading = true
        Task {
            do {
                let downloadedURL = try await model.download(item, progress: { value in
                    withAnimation(.linear(duration: 0.12)) { downloadProgress = value }
                })
                defer { try? FileManager.default.removeItem(at: downloadedURL.deletingLastPathComponent()) }
                let imported = await store.importWallpapers(urls: [downloadedURL])
                if let wallpaper = imported.first {
                    store.message = nil
                    importedWallpaper = store.attachPreview(OnlineConfig.preview(item.cover_path), to: wallpaper.id) ?? wallpaper
                } else {
                    notice = store.message ?? "Chưa nhập được hình nền đã tải."
                    store.message = nil
                }
            } catch { notice = error.localizedDescription }
            downloading = false
        }
    }
}

private struct OnlineVideoView: View {
    @EnvironmentObject private var store: DynorStore
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Group { if let player { VideoPlayer(player: player) } else { ProgressView().tint(.white) } }
                .ignoresSafeArea()
            GlassIconButton(symbol: "xmark") { dismiss() }
                .accessibilityLabel(store.localized("Đóng video", "Close video", "关闭视频"))
                .environment(\.colorScheme, .dark)
                .padding(18)
        }
        .onAppear { let p = AVPlayer(url: url); player = p; p.play() }
        .onDisappear { player?.pause(); player = nil }
    }
}

// State clips are optional public preview assets, never protected package downloads.
private extension OnlineWallpaper {
    func previewURL(for key: String) -> URL? {
        let path = key == "video" ? video_path : preview_states?[key]
        guard let path else { return nil }
        return OnlineConfig.preview(path)
    }
}

private struct OnlinePreviewControls: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    let selection: String?
    let action: (String) -> Void
    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 4) {
                ForEach(["sleep", "locked", "unlock"], id: \.self) { key in
                    Button { action(key) } label: {
                        Text(key.capitalized).font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity).padding(.vertical, 12)
                            .foregroundStyle(selection == key ? store.accentColor : Color.primary)
                            .background(selection == key ? store.accentColor.opacity(0.12) : Color.clear, in: Capsule())
                    }
                    .buttonStyle(.plain)
                    .disabled(item.previewURL(for: key) == nil)
                    .opacity(item.previewURL(for: key) == nil ? 0.35 : 1)
                }
            }.padding(5).modifier(DynorGlass(radius: 28))
            if item.previewURL(for: "video") != nil {
                Button { action("video") } label: {
                    Label(selection == "video" ? store.localized("Dừng video", "Stop video", "停止视频") : store.localized("Xem video gốc", "Watch original preview", "观看原始预览"), systemImage: selection == "video" ? "stop.fill" : "play.fill")
                        .frame(maxWidth: .infinity)
                }.buttonStyle(DynorGlassButtonStyle())
            }
            if ["sleep", "locked", "unlock"].contains(where: { item.previewURL(for: $0) == nil }) {
                Text(store.localized("Chưa có đủ video cho từng trạng thái.", "Some state previews are unavailable.", "部分状态暂无预览视频。"))
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }
}

private struct OnlinePreviewSurface: View {
    let item: OnlineWallpaper
    let player: AVPlayer?
    var body: some View {
        ZStack {
            RemotePoster(url: OnlineConfig.preview(item.cover_path), fit: true)
            if let player { OnlinePlayerLayer(player: player) }
        }
        .aspectRatio(9.0 / 19.5, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 25, style: .continuous))
    }
}

private final class OnlinePlayerHost: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var videoLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}
private struct OnlinePlayerLayer: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> OnlinePlayerHost {
        let view = OnlinePlayerHost()
        view.videoLayer.videoGravity = .resizeAspectFill
        view.videoLayer.player = player
        return view
    }
    func updateUIView(_ view: OnlinePlayerHost, context: Context) { view.videoLayer.player = player }
    static func dismantleUIView(_ view: OnlinePlayerHost, coordinator: ()) { view.videoLayer.player = nil }
}

private struct OnlineExpandedPreview: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var phase
    let item: OnlineWallpaper
    let initialState: String?
    @State private var selection: String?
    @State private var player: AVPlayer?
    var body: some View {
        VStack(spacing: 14) {
            HStack { Spacer(); GlassIconButton(symbol: "xmark") { dismiss() } }
            OnlinePreviewSurface(item: item, player: player).frame(maxHeight: .infinity)
            OnlinePreviewControls(item: item, selection: selection, action: play)
        }.padding(20).background(DynorDesign.canvas.ignoresSafeArea())
        .onAppear { if let initialState { play(initialState) } }
        .onDisappear { stop() }
        .onChange(of: phase) { _, value in if value != .active { stop() } }
    }
    private func stop() { player?.pause(); player?.replaceCurrentItem(with: nil); player = nil; selection = nil }
    private func play(_ key: String) {
        let same = selection == key
        stop()
        guard !same, let url = item.previewURL(for: key) else { return }
        let p = AVPlayer(url: url); p.isMuted = true; player = p; selection = key; p.play()
    }
}
