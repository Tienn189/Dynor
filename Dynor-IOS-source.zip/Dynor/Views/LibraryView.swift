import SwiftUI
import UIKit
import UniformTypeIdentifiers

@MainActor
struct LibraryView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var importing = false
    @State private var pickerIsVisible = false
    @State private var readingFiles = false
    @State private var importResultMessage: String?
    @State private var selecting = false
    @State private var selected = Set<UUID>()
    @State private var confirmDelete = false
    @State private var preview: ImportedWallpaper?
    @State private var showInstaller = false
    @State private var installationFarewell: String?
    @State private var category = "Tendies"
    private var visible: [ImportedWallpaper] {
        store.library.filter { $0.kind.isTendies }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                importCard
                collectionHeader
                if visible.isEmpty {
                    emptyCollection
                } else {
                    VStack(spacing: 0) {
                        ForEach(Array(visible.enumerated()), id: \.element.id) { index, item in
                            collectionItem(item)
                            if index < visible.count - 1 {
                                Divider().padding(.leading, 70).padding(.trailing, 18)
                            }
                        }
                    }
                    .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                }
                // Selection actions are anchored above the tab bar, not in the scroll content.

            }
            .frame(maxWidth: 920)
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        // Match InstalledWallpapersView: slide the delete action up from the bottom.
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if selecting && !selected.isEmpty {
                selectionActionBar
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .background(DynorDesign.canvas.ignoresSafeArea())
        .sheet(isPresented: $showInstaller) {
            NavigationStack {
                PosterBoardView()
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button(store.localized("Đóng", "Close", "关闭")) { showInstaller = false }
                        }
                    }
            }
        }
        .alert("Dynor", isPresented: Binding(get: { installationFarewell != nil }, set: { if !$0 { installationFarewell = nil } })) {
            Button(store.localized("Đã hiểu", "OK", "确定")) { installationFarewell = nil }
        } message: {
            Text(installationFarewell ?? "")
        }
        .onReceive(NotificationCenter.default.publisher(for: .dynorWallpaperInstalledAndRemoved)) { _ in
            installationFarewell = store.localized("Chúc bạn có những trải nghiệm tuyệt vời cùng Dynor!", "Enjoy a wonderful experience with Dynor!", "祝你在 Dynor 享受美好体验！")
        }
        .navigationTitle(store.localized("Bộ sưu tập", "Collection", "收藏"))
        .navigationBarTitleDisplayMode(.large)
        .sheet(isPresented: $importing, onDismiss: {
            pickerIsVisible = false
            presentImportResult()
        }) {
            WallpaperDocumentPicker(onPick: { urls in
                // Retain and process the selection immediately. Import must not
                // depend on the order of UIKit and SwiftUI dismissal callbacks.
                importing = false
                importPickedDocuments(urls)
            }, onCancel: {
                importing = false
            })
        }
        .overlay {
            if readingFiles {
                ProgressView(store.localized("Đang nhập tệp…", "Importing files…", "正在导入文件…"))
                    .padding(24).background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
            }
        }
        .confirmationDialog(store.localized("Xóa \(selected.count) tệp khỏi Dynor?", "Delete \(selected.count) files from Dynor?", "从 Dynor 删除 \(selected.count) 个文件？"), isPresented: $confirmDelete, titleVisibility: .visible) {
            Button(store.localized("Xóa \(selected.count) tệp", "Delete \(selected.count) files", "删除 \(selected.count) 个文件"), role: .destructive) {
                store.removeImported(ids: selected); selected.removeAll(); selecting = false
            }
            Button(store.localized("Giữ lại", "Keep", "保留"), role: .cancel) {}
        } message: { Text(store.localized("Tệp gốc bên ngoài Dynor vẫn được giữ lại.", "Original files outside Dynor will be kept.", "Dynor 外部的原始文件将保留。")) }
        .sheet(item: $preview, onDismiss: openNextSelectedPreview) {
            LibraryPreview(item: $0).environmentObject(store)
        }
        .onAppear { presentRequestedWallpaper() }
        .onChange(of: store.pendingLibraryPreview) { _, _ in presentRequestedWallpaper() }
    }

    private var importCard: some View {
        Button(action: showImportPicker) {
            HStack(spacing: 14) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 30, weight: .medium))
                    .foregroundStyle(store.accentColor)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text(store.localized("Nhập hình nền", "Import wallpaper", "导入壁纸"))
                        .font(.headline).foregroundStyle(.primary)
                    Text(store.localized("Chọn gói .tendies hoặc .dynor", "Choose a .tendies or .dynor package", "选择 .tendies 或 .dynor 壁纸包"))
                        .font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                if readingFiles || store.isImporting {
                    ProgressView()
                } else {
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
                }
            }
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .modifier(DynorGlass(radius: 22, interactive: true))
            .contentShape(RoundedRectangle(cornerRadius: 22))
        }
        .buttonStyle(.plain)
        .disabled(readingFiles || store.isImporting || store.isInstallingWallpaper)
    }

    @State private var installQueue: [UUID] = []

    // Keep both header states in the same fixed-height slot. This matches
    // InstalledWallpapersView's in-place controls without pushing content down.
    private var collectionHeader: some View {
        ZStack(alignment: .center) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(store.localized("Hình nền của bạn", "Your wallpapers", "你的壁纸"))
                        .font(.headline)
                    Text(store.localized("\(visible.count) gói hình nền", "\(visible.count) wallpaper packages", "\(visible.count) 个壁纸包"))
                        .font(.caption).foregroundStyle(DynorDesign.muted)
                }
                Spacer(minLength: 8)
                Button {
                    selected.removeAll()
                    withAnimation(.easeInOut(duration: 0.25)) { selecting = true }
                } label: {
                    Text(store.localized("Chọn", "Select", "选择"))
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(store.accentColor)
                        .padding(.horizontal, 16).frame(height: 44)
                        .modifier(DynorGlass(radius: 22, interactive: true))
                }
                .disabled(visible.isEmpty || store.isInstallingWallpaper)
            }
            .opacity(selecting ? 0 : 1)
            .allowsHitTesting(!selecting)
            .accessibilityHidden(selecting)

            HStack(spacing: 10) {
                Button {
                    // A single state update, with no per-row animation on Select All.
                    withAnimation(.easeInOut(duration: 0.24)) {
                        if selected.count == visible.count { selected.removeAll() }
                        else { selected = Set(visible.map(\.id)) }
                    }
                } label: {
                    Text(selected.count == visible.count
                         ? store.localized("Bỏ chọn tất cả", "Deselect all", "取消全选")
                         : store.localized("Chọn tất cả", "Select all", "全选"))
                        .font(.caption.weight(.semibold))
                        .lineLimit(1).minimumScaleFactor(0.78)
                        .foregroundStyle(store.accentColor)
                        .padding(.horizontal, 12).frame(height: 44)
                        .modifier(DynorGlass(radius: 22, interactive: true))
                }
                Spacer(minLength: 2)
                Text(store.localized("Đã chọn \(selected.count)", "Selected \(selected.count)", "已选 \(selected.count)"))
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1).minimumScaleFactor(0.8)
                Spacer(minLength: 2)
                Button {
                    withAnimation(.easeInOut(duration: 0.25)) { endSelection() }
                } label: {
                    Text(store.localized("Hoàn tất", "Done", "完成"))
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(store.accentColor)
                        .padding(.horizontal, 12).frame(height: 44)
                        .modifier(DynorGlass(radius: 22, interactive: true))
                }
            }
            .opacity(selecting ? 1 : 0)
            .allowsHitTesting(selecting)
            .accessibilityHidden(!selecting)
        }
        .frame(height: 52)
        .buttonStyle(.plain)
    }

    // Reuse the same delete action appearance as InstalledWallpapersView.
    private var selectionActionBar: some View {
        Button(role: .destructive) { confirmDelete = true } label: {
            Label(store.localized("Xóa (\(selected.count))", "Delete (\(selected.count))", "删除 (\(selected.count))"), systemImage: "trash")
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .modifier(DynorGlass(radius: 25, interactive: true))
        }
        .foregroundStyle(.red)
        .disabled(store.isInstallingWallpaper)
        .padding(.horizontal, 24)
        .padding(.bottom, 8)
    }

    private func endSelection() {
        selecting = false
        selected.removeAll()
        installQueue.removeAll()
    }

    private func openNextSelectedPreview() {
        guard !installQueue.isEmpty else { return }
        let next = installQueue.removeFirst()
        if let item = store.library.first(where: { $0.id == next }) {
            // The existing installer requires confirmation for each package.
            DispatchQueue.main.async { preview = item }
        }
    }

    private var emptyCollection: some View {
        ContentUnavailableView {
            Label(store.localized("Chưa có hình nền", "No wallpapers yet", "暂无壁纸"), systemImage: "square.stack")
        } description: {
            Text(store.localized("Nhập gói hình nền từ Tệp hoặc tìm thêm trong Khám phá.", "Import a package from Files or find a wallpaper in Explore.", "从文件导入壁纸包，或前往探索查找壁纸。"))
        } actions: {
            Button(store.localized("Khám phá hình nền", "Explore wallpapers", "探索壁纸")) {
                store.selectedTab = .discover
            }.buttonStyle(.bordered)
        }
        .padding(.vertical, 30)
    }

    private func collectionItem(_ item: ImportedWallpaper) -> some View {
        let isSelected = selected.contains(item.id)
        return Button {
            if selecting {
                withAnimation(.easeInOut(duration: 0.24)) {
                    if isSelected { selected.remove(item.id) } else { selected.insert(item.id) }
                }
            } else { preview = item }
        } label: {
            HStack(spacing: 16) {
                Image(systemName: "archivebox.fill")
                    .font(.system(size: 23, weight: .medium))
                    .foregroundStyle(store.accentColor)
                    .frame(width: 40, height: 48)
                VStack(alignment: .leading, spacing: 6) {
                    Text(URL(fileURLWithPath: item.displayName).deletingPathExtension().lastPathComponent)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(DynorDesign.ink)
                        .lineLimit(1)
                    Text(store.localized("Collections · 1 hình nền", "Collections · 1 wallpaper", "Collections · 1 张壁纸"))
                        .font(.caption).foregroundStyle(.secondary)
                    Text("\(ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file)) · \(item.addedAt.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption2).foregroundStyle(DynorDesign.muted)
                        .lineLimit(1).minimumScaleFactor(0.8)
                }
                Spacer(minLength: 0)
                if selecting {
                    Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                        .font(.system(size: 27))
                        .foregroundStyle(isSelected ? store.accentColor : Color.secondary.opacity(0.4))

                } else {
                    Image(systemName: "chevron.right")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 17)
            .contentShape(Rectangle())
        }
        .buttonStyle(DynorPressStyle(scale: 0.99))
        .disabled(store.isInstallingWallpaper)
        .accessibilityLabel(item.displayName)
        .accessibilityValue(selecting ? (isSelected ? store.localized("Đã chọn", "Selected", "已选择") : store.localized("Chưa chọn", "Not selected", "未选择")) : "")
    }

    private func showImportPicker() {
        guard !readingFiles, !store.isImporting, !store.isInstallingWallpaper else { return }
        pickerIsVisible = true
        importing = true
    }

    private func importPickedDocuments(_ urls: [URL]) {
        guard !urls.isEmpty, !readingFiles else { return }
        readingFiles = true
        Task { @MainActor in
            defer {
                readingFiles = false
                presentImportResult()
            }
            let imported = await store.importWallpapers(urls: urls)
            ActivityJournal.shared.add(imported.isEmpty ? "Nhập tệp thất bại" : "Đã nhập tệp", detail: imported.isEmpty ? "Không có tệp hợp lệ" : imported.map(\.displayName).joined(separator: ", "), success: !imported.isEmpty)
            let message = store.message
            store.message = nil
            if urls.count == 1, let item = imported.first {
                store.openInLibrary(item)
            } else {
                importResultMessage = message ?? "Chưa nhập được tệp đã chọn. Hãy thử lại."
            }
        }
    }

    private func presentImportResult() {
        guard !pickerIsVisible, !importing, !readingFiles else { return }
        if let message = importResultMessage {
            importResultMessage = nil
            store.message = message
        }
        presentRequestedWallpaper()
    }

    private func presentRequestedWallpaper() {
        guard !pickerIsVisible, !importing, !readingFiles,
              store.selectedTab == .library, let id = store.pendingLibraryPreview,
              let item = store.library.first(where: { $0.id == id }) else { return }
        category = item.kind.isTendies ? "Tendies" : "Ảnh"
        selecting = false
        selected.removeAll()
        preview = item
        store.pendingLibraryPreview = nil
    }
}

private struct LibraryArtwork: View {
    @EnvironmentObject private var store: DynorStore
    let item: ImportedWallpaper
    var allowsRetry = false
    var body: some View {
        GeometryReader { geometry in
            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                Image(uiImage: image).resizable().scaledToFill().frame(width: geometry.size.width, height: geometry.size.height)
            } else {
                TendiesArtworkPreview(archiveURL: store.fileURL(for: item), encrypted: item.kind == .encryptedTendies, allowsRetry: allowsRetry, previewURL: item.previewURL)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .clipped()
            }
        }
    }
}

@MainActor
struct LibraryPreview: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    let item: ImportedWallpaper
    @State private var saving = false
    @State private var notice: String?
    @State private var installing = false
    @State private var installProgress = 0.0
    @State private var installLog: [String] = []
    @State private var verifiedWrite = false
    @State private var removeAfterAcknowledgement = false
    @State private var confirmSingleDelete = false
    private var compatibility: TendiesCompatibility.Assessment { TendiesCompatibility.current }
    private var prerequisiteWarning: String? { PosterBoardAccess.prerequisiteWarning }

    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
              ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    LibraryArtwork(item: item, allowsRetry: true)
                        .frame(width: min(geometry.size.width - 48, max(100, geometry.size.height * 0.34), 260),
                               height: min(geometry.size.width - 48, max(100, geometry.size.height * 0.34), 260))
                        .clipped()
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .frame(maxWidth: .infinity)
                    DynorSoftCard {
                        VStack(alignment: .leading, spacing: 13) {
                            Label(store.localized("Thông tin hình nền", "Wallpaper information", "壁纸信息"), systemImage: "info.circle").font(.headline)
                            infoRow(store.localized("Ngày nhập", "Imported", "导入日期"), item.addedAt.formatted(date: .abbreviated, time: .shortened))
                            infoRow(store.localized("Dung lượng", "File size", "文件大小"), ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                            infoRow(store.localized("Định dạng", "Format", "格式"), (item.storedFilename as NSString).pathExtension.uppercased())
                            infoRow(store.localized("Nguồn", "Source", "来源"), item.kind == .encryptedTendies ? store.localized("Dynor mã hóa", "Encrypted Dynor", "Dynor 加密") : item.kind == .tendies ? "Tendies" : store.localized("Ảnh", "Image", "图片"))

                        }
                    }
                    if item.kind.isTendies {
                        PosterBoardMotionPreview(url: store.fileURL(for: item), encrypted: item.kind == .encryptedTendies)
                        tendiesControls
                    }
                    if item.kind == .image {
                        Button {
                            saving = true
                            Task {
                                await store.saveImportedToPhotos(item)
                                notice = store.message
                                store.message = nil
                                saving = false
                            }
                        } label: {
                            Label(saving ? "Đang lưu…" : "Lưu vào Ảnh", systemImage: "photo.badge.arrow.down")
                                .frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(DynorPrimaryButtonStyle()).disabled(saving)
                        ShareLink(item: store.fileURL(for: item)) {
                            Label(store.localized("Chia sẻ ảnh gốc", "Share original image", "分享原始图片"), systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(.bordered).disabled(installing)
                    }
                }
                .frame(maxWidth: 620)
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .frame(maxWidth: .infinity)
              }
              .scrollIndicators(.hidden)
            }
            .background(DynorDesign.canvas.ignoresSafeArea())
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(store.localized("Đóng", "Close", "关闭")) { dismiss() }.disabled(installing) } }
            .interactiveDismissDisabled(installing)
            .confirmationDialog(store.localized("Xóa gói hình nền này?", "Delete this wallpaper package?", "删除此壁纸包？"), isPresented: $confirmSingleDelete) {
                Button(store.localized("Xóa khỏi Dynor", "Delete from Dynor", "从 Dynor 删除"), role: .destructive) {
                    store.removeImported(ids: Set([item.id]))
                    dismiss()
                }
                Button(store.localized("Hủy", "Cancel", "取消"), role: .cancel) {}
            } message: { Text(store.localized("Tệp gốc bên ngoài Dynor không bị xóa.", "The original file outside Dynor will not be deleted.", "不会删除 Dynor 外部的原始文件。")) }
            .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button(store.localized("OK", "OK", "确定"), role: .cancel) {
                    notice = nil
                    if removeAfterAcknowledgement {
                        removeAfterAcknowledgement = false
                        store.removeImported(ids: Set([item.id]), showConfirmation: false)
                        dismiss()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            NotificationCenter.default.post(name: .dynorWallpaperInstalledAndRemoved, object: nil)
                        }
                    }
                }
            } message: { Text(notice ?? "") }
        }
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
                .fixedSize(horizontal: false, vertical: true)
        }.font(.subheadline)
            .frame(maxWidth: .infinity)
    }

    @ViewBuilder
    private var tendiesControls: some View {
        if let warning = compatibility.warning {
            Label(warning, systemImage: "info.circle")
                .font(.caption).foregroundStyle(.secondary)
        } else if let warning = prerequisiteWarning {
            Label(warning, systemImage: "exclamationmark.shield")
                .font(.caption).foregroundStyle(.secondary)
            Button(store.localized("Mở bộ chọn hình nền", "Open wallpaper picker", "打开壁纸选择器")) {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = store.localized("Không thể mở bộ chọn hình nền tự động. Hãy vào Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra.", "Cannot open the wallpaper picker automatically. Go to Settings → Wallpaper → Add New Wallpaper.", "无法自动打开壁纸选择器。请前往设置 → 墙纸 → 添加新墙纸。")
                }
            }.font(.subheadline)
        }
        if installing {
            ProgressView(value: installProgress)
            Text(store.localized("Đang ghi và xác minh… Giữ Dynor mở, iPhone mở khóa.", "Writing and verifying… Keep Dynor open and iPhone unlocked.", "正在写入并验证…请保持 Dynor 打开且 iPhone 已解锁。"))
                .font(.caption).foregroundStyle(.secondary)
        }
        Button {
            installTendies()
        } label: {
            Label(installing ? store.localized("Đang cài hình nền…", "Installing wallpaper…", "正在安装壁纸…") : verifiedWrite ? store.localized("Ghi lại hình nền", "Reinstall wallpaper", "重新安装壁纸") : store.localized("Cài hình nền", "Install wallpaper", "安装壁纸"), systemImage: "iphone.gen3")
                .frame(maxWidth: .infinity).padding(.vertical, 2)
        }
        .buttonStyle(DynorPrimaryButtonStyle())
        .disabled(installing || store.isInstallingWallpaper || prerequisiteWarning != nil || !compatibility.canAttemptInstall)
        if verifiedWrite {
            Button(store.localized("Mở bộ chọn hình nền", "Open wallpaper picker", "打开壁纸选择器")) {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = store.localized("iOS chưa mở được PosterBoard. Mở Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra. Nếu mẫu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại.", "iOS could not open PosterBoard. Check Settings → Wallpaper → Add New Wallpaper. If missing, restart your iPhone.", "iOS 无法打开 PosterBoard。请在设置 → 墙纸 → 添加新墙纸中查看。如果未显示，请重启 iPhone。")
                }
            }.buttonStyle(.bordered)
        }
        if !installLog.isEmpty {
            DisclosureGroup("Chi tiết cài đặt") {
                Text(installLog.joined(separator: "\n"))
                    .font(.caption2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
            }.font(.caption)
        }
    }

    private func installTendies() {
        guard compatibility.canAttemptInstall, !installing, !store.isInstallingWallpaper, prerequisiteWarning == nil else { return }
        installing = true
        store.isInstallingWallpaper = true
        verifiedWrite = false
        installProgress = 0
        installLog = []
        let previousIdleSetting = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        Task { @MainActor in
            defer {
                installing = false
                store.isInstallingWallpaper = false
                UIApplication.shared.isIdleTimerDisabled = previousIdleSetting
            }
            do {
                let receipt = try await TendiesInstaller.shared.install(
                    archiveURL: store.fileURL(for: item),
                    log: { line in
                        Task { @MainActor in
                            installLog.append(localizedInstallLog(line))
                            if installLog.count > 100 { installLog.removeFirst(installLog.count - 100) }
                        }
                    },
                    progress: { value in Task { @MainActor in installProgress = value } }
                )
                verifiedWrite = true
                removeAfterAcknowledgement = true
                ActivityJournal.shared.add("Đã ghi hình nền", detail: "\(item.displayName) · \(receipt.verifiedFileCount) tệp đã xác minh", success: true)
                // Request PosterBoard after successful verification. iOS decides whether
                // it can foreground the system UI; no private multitasking manipulation.
                let opened = PosterBoardAccess.requestOpenPosterBoard()
                notice = opened
                    ? store.localized("Đã cài dữ liệu hình nền thành công! Trong PosterBoard, chọn hình nền vừa thêm và bấm Thêm/Đặt làm hình nền. Nếu chưa thấy, mở Cài đặt → Hình nền hoặc khởi động lại iPhone.", "Wallpaper data installed successfully! In PosterBoard, select the newly added wallpaper and tap Add or Set as Wallpaper. If it is missing, open Settings → Wallpaper or restart your iPhone.", "壁纸数据安装成功！请在 PosterBoard 中选择新添加的壁纸，然后点击“添加”或“设为壁纸”。如果没有显示，请打开“设置”→“墙纸”，或重启 iPhone。")
                    : store.localized("Đã cài dữ liệu hình nền thành công! iOS chưa cho tự mở PosterBoard; vào Cài đặt → Hình nền → Thêm hình nền mới, chọn mẫu vừa cài. Nếu chưa thấy, khởi động lại iPhone.", "Wallpaper data installed successfully! iOS could not open PosterBoard automatically. Go to Settings → Wallpaper → Add New Wallpaper and choose the new wallpaper. If it is missing, restart your iPhone.", "壁纸数据安装成功！iOS 无法自动打开 PosterBoard。请前往“设置”→“墙纸”→“添加新墙纸”，选择刚安装的壁纸。如果没有显示，请重启 iPhone。")
            } catch {
                removeAfterAcknowledgement = false
                ActivityJournal.shared.add("Cài hình nền thất bại", detail: "\(item.displayName) · \(error.localizedDescription)", success: false)
                notice = store.localized("Chưa hoàn tất cài hình nền: \(error.localizedDescription)", "Wallpaper installation incomplete: \(error.localizedDescription)", "壁纸安装未完成：\(error.localizedDescription)")
            }
        }
    }

    private func localizedInstallLog(_ line: String) -> String {
        if line.hasPrefix("Hệ thống: ") { return store.localized(line, line.replacingOccurrences(of: "Hệ thống:", with: "System:"), line.replacingOccurrences(of: "Hệ thống:", with: "系统：")) }
        if line.hasPrefix("Backend: worse_query") { return store.localized(line, "Backend: worse_query · direct installation, no pairing/VPN", "后端：worse_query · 直接安装，无需配对或 VPN") }
        let messages: [(String, String, String)] = [
            ("Đang xác minh quyền và mở gói mã hóa…", "Verifying permissions and decrypting package…", "正在验证权限并解密文件…"),
            ("Đang kiểm tra và giải nén Tendies…", "Validating and extracting Tendies…", "正在验证并解压 Tendies…"),
            ("Đã xác minh container", "Verified container", "已验证容器"),
            ("Đã ghi và đọc lại", "Written and verified", "已写入并重新验证"),
            ("Đã tìm thấy", "Found", "已找到"),
            ("Đang xác định PosterBoard", "Locating PosterBoard", "正在查找 PosterBoard"),
            ("Đã đọc lại và đối chiếu", "Read back and verified", "已重新读取并核对"),
            ("Đang kiểm tra", "Checking", "正在检查"),
            ("Đang giải nén", "Extracting", "正在解压"),
            ("Đã xác minh", "Verified", "已验证"),
            ("Đã ghi", "Written", "已写入"),
            ("tệp", "files", "个文件"),
            ("cấu hình", "configurations", "个配置"),
            ("trên thiết bị", "on device", "在设备上"),
            ("Chưa xác nhận iOS đã nạp hoặc chọn hình nền.", "iOS wallpaper activation has not been confirmed.", "尚未确认 iOS 已加载或选择壁纸。")
        ]
        if store.appLanguage == "vi" { return line }
        var result = line
        for (vi, en, zh) in messages { result = result.replacingOccurrences(of: vi, with: store.localized(vi, en, zh)) }
        return result
    }
}


private extension Notification.Name {
    static let dynorWallpaperInstalledAndRemoved = Notification.Name("dynor.wallpaper.installedAndRemoved")
}
