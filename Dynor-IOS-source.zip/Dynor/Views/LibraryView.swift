import SwiftUI
import UIKit
import UniformTypeIdentifiers

@MainActor
struct LibraryView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var importing = false
    @State private var pickerIsVisible = false
    @State private var readingFiles = false
    @State private var importResultMessage: String?
    @State private var selecting = false
    @State private var selected = Set<UUID>()
    @State private var confirmDelete = false
    @State private var preview: ImportedWallpaper?
    @State private var showInstaller = false
    @State private var category = "Tendies"
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]
    private var visible: [ImportedWallpaper] {
        store.library.filter { $0.kind.isTendies }
    }
    private var totalBytes: Int64 { visible.reduce(0) { $0 + $1.byteCount } }
    private var encryptedCount: Int { visible.filter { $0.kind == .encryptedTendies }.count }
    private var importDisabled: Bool { readingFiles || store.isImporting || store.isInstallingWallpaper }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                header
                statsRow
                importCard
                listSection
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
        }
        .scrollIndicators(.hidden)
        .contentMargins(.bottom, 110, for: .scrollContent)
        .background { AuroraBackground() }
        .toolbar(.hidden, for: .navigationBar)
        .overlay(alignment: .bottom) {
            deleteBar.animation(.spring(response: 0.4, dampingFraction: 0.8), value: selected.count)
        }
        .sheet(isPresented: $showInstaller) {
            NavigationStack {
                PosterBoardView()
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("Đóng") { showInstaller = false }
                        }
                    }
            }
        }
        .sheet(isPresented: $importing, onDismiss: {
            pickerIsVisible = false
            presentImportResult()
        }) {
            WallpaperDocumentPicker(onPick: { urls in
                // Retain and process the selection immediately. Import must not
                // depend on the order of UIKit and SwiftUI dismissal callbacks.
                importing = false
                importPickedDocuments(urls)
            }, onCancel: {
                importing = false
            })
        }
        .overlay {
            if readingFiles {
                VStack(spacing: 14) {
                    ProgressView().controlSize(.large)
                    Text("Đang nhập tệp…").font(.subheadline.weight(.medium))
                }
                .padding(.horizontal, 34).padding(.vertical, 28)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            }
        }
        .confirmationDialog("Xóa \(selected.count) tệp khỏi Dynor?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Xóa \(selected.count) tệp", role: .destructive) {
                store.removeImported(ids: selected); selected.removeAll(); selecting = false
            }
            Button("Giữ lại", role: .cancel) {}
        } message: { Text("Tệp gốc bên ngoài Dynor vẫn được giữ lại.") }
        .sheet(item: $preview) { LibraryPreview(item: $0).environmentObject(store) }
        .onAppear { presentRequestedWallpaper() }
        .onChange(of: store.pendingLibraryPreview) { _, _ in presentRequestedWallpaper() }
    }

    // MARK: Sections

    private var header: some View {
        DynorHeader(eyebrow: "Dynor · Collection",
                    title: store.localized("Bộ sưu tập", "Collection", "收藏"),
                    subtitle: store.localized("Không gian lưu giữ những tác phẩm của riêng bạn.",
                                              "A private vault for the pieces you love.",
                                              "珍藏你所爱作品的私人空间。")) {
            GlassIconButton(symbol: "plus") { showImportPicker() }
                .disabled(importDisabled)
                .accessibilityLabel("Nhập Tendies")
        }
    }

    private var statsRow: some View {
        HStack(spacing: 12) {
            StatTile(value: "\(visible.count)", label: store.localized("Gói hình nền", "Packages", "壁纸包"), symbol: "square.stack.3d.up.fill")
            StatTile(value: ByteCountFormatter.string(fromByteCount: totalBytes, countStyle: .file),
                     label: store.localized("Dung lượng", "Storage", "占用空间"), symbol: "internaldrive.fill")
            StatTile(value: "\(encryptedCount)", label: store.localized("Mã hóa", "Encrypted", "已加密"), symbol: "lock.shield.fill")
        }
    }

    private var importCard: some View {
        Button(action: showImportPicker) {
            HStack(spacing: 15) {
                Image(systemName: "square.and.arrow.down.fill")
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(store.accentTextColor)
                    .frame(width: 48, height: 48)
                    .background(
                        LinearGradient(colors: [store.accentColor.mix(with: .white, by: 0.2), store.accentColor],
                                       startPoint: .top, endPoint: .bottom),
                        in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.35), lineWidth: 0.7))
                    .shadow(color: store.accentColor.opacity(0.35), radius: 10, y: 5)
                VStack(alignment: .leading, spacing: 3) {
                    Text(store.localized("Nhập gói hình nền", "Import wallpaper package", "导入壁纸包"))
                        .font(.system(size: 16, weight: .semibold))
                    Text(".tendies  ·  .dynor")
                        .font(.system(size: 12.5, weight: .medium))
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.tertiary)
            }
            .foregroundStyle(Color.primary)
            .dynorGlass(radius: 28, padding: 14)
        }
        .buttonStyle(DynorPressStyle(scale: 0.98))
        .disabled(importDisabled)
    }

    private var listSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            DynorSectionTitle(title: store.localized("Tệp của bạn", "Your files", "你的文件"),
                              detail: String(format: "%02d", visible.count))
            if !visible.isEmpty {
                HStack(spacing: 10) {
                    if selecting {
                        smallPill(selected.isSuperset(of: Set(visible.map(\.id))) && !visible.isEmpty ? "Bỏ chọn" : "Chọn tất cả") {
                            let ids = Set(visible.map(\.id))
                            if selected.isSuperset(of: ids) { selected.subtract(ids) } else { selected.formUnion(ids) }
                        }
                        Text("Đã chọn \(selected.count) / \(visible.count)")
                            .font(.system(size: 12)).foregroundStyle(.secondary)
                    }
                    Spacer()
                    smallPill(selecting ? "Xong" : "Chọn nhiều") {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            selecting.toggle(); selected.removeAll()
                        }
                    }
                    .disabled(store.isInstallingWallpaper)
                }
            }
            if visible.isEmpty {
                emptyState
            } else {
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(visible) { libraryCard($0) }
                }
            }
        }
    }

    private func smallPill(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13, weight: .semibold))
                .padding(.horizontal, 15).padding(.vertical, 8)
                .background { ZStack { Capsule().fill(.ultraThinMaterial); Capsule().fill(DynorDesign.surface) } }
                .overlay(Capsule().strokeBorder(DynorDesign.hairline, lineWidth: 0.8))
        }
        .buttonStyle(DynorPressStyle(scale: 0.94))
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "sparkles.rectangle.stack")
                .font(.system(size: 38, weight: .light))
                .foregroundStyle(store.accentColor)
            Text("Bộ sưu tập bắt đầu từ bạn").font(.system(size: 22, weight: .bold)).tracking(-0.3)
            Text("Nhập tệp .tendies hoặc .dynor từ ứng dụng Tệp để bắt đầu.")
                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button(store.localized("Chọn tệp để nhập", "Choose a file", "选择文件"), action: showImportPicker)
                .buttonStyle(DynorPrimaryButtonStyle(tint: store.accentColor, foreground: store.accentTextColor))
                .frame(maxWidth: 240)
                .padding(.top, 6)
                .disabled(importDisabled)
        }
        .frame(maxWidth: .infinity)
        .dynorGlass(radius: 32, padding: 28)
    }

    private func libraryCard(_ item: ImportedWallpaper) -> some View {
        let isOn = selected.contains(item.id)
        return Button {
            if selecting {
                if isOn { selected.remove(item.id) } else { selected.insert(item.id) }
            } else { preview = item }
        } label: {
            Color.clear
                .aspectRatio(0.6, contentMode: .fit)
                .overlay { LibraryArtwork(item: item) }
                .overlay(alignment: .bottom) {
                    DynorCaption(title: item.displayName,
                                 subtitle: ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file),
                                 monospacedSubtitle: true)
                }
                .overlay(alignment: .topLeading) {
                    DynorBadge(text: item.kind == .encryptedTendies ? "DYNOR" : "TENDIES",
                               symbol: item.kind == .encryptedTendies ? "lock.fill" : nil)
                        .padding(10)
                }
                .overlay(alignment: .topTrailing) {
                    if selecting { SelectionMark(isOn: isOn).padding(10) }
                }
                .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 28, style: .continuous)
                        .strokeBorder(isOn ? AnyShapeStyle(store.accentColor)
                                           : AnyShapeStyle(LinearGradient(colors: [Color.white.opacity(0.28), Color.white.opacity(0.03)],
                                                                           startPoint: .topLeading, endPoint: .bottomTrailing)),
                                      lineWidth: isOn ? 2.5 : 0.8)
                )
                .shadow(color: .black.opacity(0.24), radius: 16, y: 9)
                .scaleEffect(isOn ? 0.96 : 1)
                .animation(.spring(response: 0.35, dampingFraction: 0.75), value: isOn)
                .contentShape(Rectangle())
        }
        .buttonStyle(DynorPressStyle(scale: 0.97))
        .contextMenu {
            Button(role: .destructive) {
                selected = [item.id]
                confirmDelete = true
            } label: { Label("Xóa", systemImage: "trash") }
            .disabled(store.isInstallingWallpaper)
        }
    }

    @ViewBuilder
    private var deleteBar: some View {
        if selecting && !selected.isEmpty {
            Button(role: .destructive) { confirmDelete = true } label: {
                Label("Xóa \(selected.count) tệp đã chọn", systemImage: "trash.fill")
            }
            .buttonStyle(DynorGlassButtonStyle(destructive: true))
            .background(.ultraThinMaterial, in: Capsule())
            .disabled(store.isInstallingWallpaper)
            .padding(.horizontal, 36)
            .padding(.bottom, 94)
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
    }

    private func showImportPicker() {
        guard !readingFiles, !store.isImporting, !store.isInstallingWallpaper else { return }
        pickerIsVisible = true
        importing = true
    }

    private func importPickedDocuments(_ urls: [URL]) {
        guard !urls.isEmpty, !readingFiles else { return }
        readingFiles = true
        Task { @MainActor in
            defer {
                readingFiles = false
                presentImportResult()
            }
            let imported = await store.importWallpapers(urls: urls)
            ActivityJournal.shared.add(imported.isEmpty ? "Nhập tệp thất bại" : "Đã nhập tệp", detail: imported.isEmpty ? "Không có tệp hợp lệ" : imported.map(\.displayName).joined(separator: ", "), success: !imported.isEmpty)
            let message = store.message
            store.message = nil
            if urls.count == 1, let item = imported.first {
                store.openInLibrary(item)
            } else {
                importResultMessage = message ?? "Chưa nhập được tệp đã chọn. Hãy thử lại."
            }
        }
    }

    private func presentImportResult() {
        guard !pickerIsVisible, !importing, !readingFiles else { return }
        if let message = importResultMessage {
            importResultMessage = nil
            store.message = message
        }
        presentRequestedWallpaper()
    }

    private func presentRequestedWallpaper() {
        guard !pickerIsVisible, !importing, !readingFiles,
              store.selectedTab == .library, let id = store.pendingLibraryPreview,
              let item = store.library.first(where: { $0.id == id }) else { return }
        category = item.kind.isTendies ? "Tendies" : "Ảnh"
        selecting = false
        selected.removeAll()
        preview = item
        store.pendingLibraryPreview = nil
    }
}

private struct LibraryArtwork: View {
    @EnvironmentObject private var store: DynorStore
    let item: ImportedWallpaper
    var body: some View {
        GeometryReader { geometry in
            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                Image(uiImage: image).resizable().scaledToFill().frame(width: geometry.size.width, height: geometry.size.height)
            } else if item.kind == .tendies {
                TendiesArtworkPreview(archiveURL: store.fileURL(for: item))
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .clipped()
            } else {
                ZStack {
                    LinearGradient(colors: [Color(red: 0.10, green: 0.09, blue: 0.22), store.accentColor.opacity(0.55), Color(red: 0.36, green: 0.22, blue: 0.62)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                    RadialGradient(colors: [Color.white.opacity(0.25), .clear], center: .topTrailing, startRadius: 0, endRadius: 200)
                    VStack(spacing: 14) {
                        Image(systemName: item.kind == .encryptedTendies ? "lock.shield" : "square.3.layers.3d")
                            .font(.system(size: 40, weight: .ultraLight))
                        Text(item.kind == .encryptedTendies ? "DYNOR" : "TENDIES")
                            .font(.system(size: 10, weight: .semibold, design: .monospaced)).tracking(4)
                    }.foregroundStyle(.white)
                }
                .frame(width: geometry.size.width, height: geometry.size.height)
            }
        }
    }
}

@MainActor
struct LibraryPreview: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    let item: ImportedWallpaper
    @State private var saving = false
    @State private var notice: String?
    @State private var installing = false
    @State private var installProgress = 0.0
    @State private var installLog: [String] = []
    @State private var verifiedWrite = false
    @State private var previewMode: WallpaperPreviewMode = .locked
    @State private var confirmSingleDelete = false
    @Namespace private var modeNamespace
    private var compatibility: TendiesCompatibility.Assessment { TendiesCompatibility.current }
    private var prerequisiteWarning: String? { PosterBoardAccess.prerequisiteWarning }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    phone
                    modeSwitch
                    titleBlock
                    infoCard
                    guidance
                    if item.kind.isTendies { tendiesControls }
                    if item.kind == .image { imageActions }
                    Button(role: .destructive) { confirmSingleDelete = true } label: {
                        Label("Xóa hình nền khỏi bộ sưu tập", systemImage: "trash")
                    }
                    .buttonStyle(DynorGlassButtonStyle(destructive: true))
                    .disabled(installing)
                }
                .padding(.horizontal, 20)
                .padding(.top, 6)
                .padding(.bottom, 30)
            }
            .scrollIndicators(.hidden)
            .background { AuroraBackground() }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(store.localized("Đóng", "Close", "关闭")) { dismiss() }.disabled(installing) } }
            .interactiveDismissDisabled(installing)
            .confirmationDialog("Xóa gói hình nền này?", isPresented: $confirmSingleDelete) {
                Button("Xóa khỏi Dynor", role: .destructive) {
                    store.removeImported(ids: Set([item.id]))
                    dismiss()
                }
                Button("Hủy", role: .cancel) {}
            } message: { Text("Tệp gốc bên ngoài Dynor không bị xóa.") }
            .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }
    }

    // MARK: Phone mock-up

    @ViewBuilder
    private var artwork: some View {
        if item.kind == .tendies {
            TendiesArtworkPreview(archiveURL: store.fileURL(for: item), phase: previewMode.rawValue)
        } else {
            LibraryArtwork(item: item)
        }
    }

    private var phone: some View {
        Color.clear
            .aspectRatio(0.485, contentMode: .fit)
            .overlay {
                GeometryReader { geo in
                    ZStack(alignment: .top) {
                        artwork
                            .frame(width: geo.size.width, height: geo.size.height)
                            .clipped()
                            .scaleEffect(previewMode == .sleep ? 1.07 : previewMode == .unlock ? 1.02 : 1)
                            .animation(.easeInOut(duration: 0.85), value: previewMode)
                        VStack(spacing: 4) {
                            Text(Date.now, format: .dateTime.weekday(.wide).month(.abbreviated).day())
                                .font(.system(size: 13, weight: .medium))
                            Text(Date.now, format: .dateTime.hour().minute())
                                .font(.system(size: 62, weight: .thin, design: .rounded))
                        }
                        .foregroundStyle(.white)
                        .shadow(color: .black.opacity(0.45), radius: 8)
                        .padding(.top, 58)
                        if previewMode == .sleep { Color.black.opacity(0.35).allowsHitTesting(false) }
                        Capsule().fill(Color.black).frame(width: 88, height: 26).padding(.top, 11)
                    }
                    .frame(width: geo.size.width, height: geo.size.height)
                    .overlay(alignment: .bottom) {
                        HStack {
                            lockButton("flashlight.off.fill")
                            Spacer()
                            lockButton("camera.fill")
                        }
                        .padding(.horizontal, 26).padding(.bottom, 28)
                        .opacity(previewMode == .sleep ? 0 : 1)
                    }
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 46, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 46, style: .continuous)
                    .strokeBorder(LinearGradient(colors: [Color.white.opacity(0.6), Color.white.opacity(0.08)],
                                                 startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 4)
            )
            .shadow(color: store.accentColor.opacity(0.4), radius: 40, y: 24)
            .frame(maxWidth: 272)
            .frame(maxWidth: .infinity)
            .padding(.top, 8)
    }

    private func lockButton(_ symbol: String) -> some View {
        Image(systemName: symbol)
            .font(.system(size: 15, weight: .medium))
            .foregroundStyle(.white)
            .frame(width: 42, height: 42)
            .background(.ultraThinMaterial, in: Circle())
            .environment(\.colorScheme, .dark)
    }

    private var modeSwitch: some View {
        VStack(spacing: 10) {
            HStack(spacing: 4) {
                ForEach(WallpaperPreviewMode.allCases) { mode in
                    let on = previewMode == mode
                    Button {
                        withAnimation(.spring(response: 0.45, dampingFraction: 0.8)) { previewMode = mode }
                    } label: {
                        Text(mode.title)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(on ? Color.primary : Color.primary.opacity(0.65))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 11)
                            .background {
                                if on {
                                    Capsule()
                                        .fill(.regularMaterial)
                                        .overlay(Capsule().strokeBorder(.white.opacity(0.85), lineWidth: 1.3))
                                        .matchedGeometryEffect(id: "mode", in: modeNamespace)
                                }
                            }
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(5)
            .background(.ultraThinMaterial, in: Capsule())
            .overlay(Capsule().strokeBorder(.white.opacity(0.65), lineWidth: 1))
            Text(store.localized("Đang xem ảnh đại diện từng trạng thái. Hoạt ảnh CAML gốc chưa thể phát bằng trình xem này.", "Showing artwork for each state. Original CAML animation cannot yet play in this viewer.", "正在显示各状态的预览图。此预览器暂不支持播放原始 CAML 动画。"))
                .font(.system(size: 11)).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
    }

    // MARK: Info

    private var titleBlock: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(item.displayName)
                .font(DynorDesign.display(30))
                .tracking(-0.5)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                Label(item.kind == .encryptedTendies ? "Dynor mã hóa" : item.kind == .tendies ? "Tendies" : store.localized("Ảnh", "Image", "图片"),
                      systemImage: item.kind == .encryptedTendies ? "lock.shield.fill" : "square.3.layers.3d")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(store.accentColor)
                    .padding(.horizontal, 11).padding(.vertical, 6)
                    .background(store.accentColor.opacity(0.14), in: Capsule())
            }
        }
    }

    private var infoCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label(store.localized("Thông tin hình nền", "Wallpaper information", "壁纸信息"), systemImage: "info.circle").font(.system(size: 15, weight: .semibold))
            infoRow(store.localized("Ngày nhập", "Imported", "导入日期"), item.addedAt.formatted(date: .abbreviated, time: .shortened))
            infoRow(store.localized("Dung lượng", "File size", "文件大小"), ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
            infoRow(store.localized("Định dạng", "Format", "格式"), (item.storedFilename as NSString).pathExtension.uppercased())
            infoRow(store.localized("Nguồn", "Source", "来源"), item.kind == .encryptedTendies ? "Dynor mã hóa" : item.kind == .tendies ? "Tendies" : "Ảnh")
            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                infoRow(store.localized("Kích thước", "Dimensions", "尺寸"), "\(Int(image.size.width * image.scale)) × \(Int(image.size.height * image.scale)) px")
            } else {
                infoRow(store.localized("Kích thước", "Dimensions", "尺寸"), store.localized("Không có metadata ảnh đại diện", "No preview image metadata", "没有预览图元数据"))
            }
        }
        .dynorGlass(radius: 26, padding: 20)
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
        }.font(.system(size: 14))
    }

    @ViewBuilder
    private var guidance: some View {
        Text(item.kind.isTendies ? "Giữ iPhone mở khóa khi cài. Dynor ghi trực tiếp vào PosterBoard; sau đó mở bộ chọn hình nền để kiểm tra và chọn mẫu mới." : "Lưu ảnh vào Ảnh, sau đó chọn Chia sẻ → Dùng làm hình nền.")
            .font(.system(size: 14)).foregroundStyle(.secondary).lineSpacing(3)
        if item.kind == .encryptedTendies {
            note("Đăng nhập Dynor và kết nối Internet mỗi lần cài gói mã hóa. Gói VIP cần tài khoản VIP còn hiệu lực. Dynor không xuất tệp đã giải mã.", symbol: "lock.shield")
        }
    }

    private func note(_ text: String, symbol: String, tint: Color? = nil) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: symbol).font(.system(size: 14, weight: .semibold)).foregroundStyle(tint ?? store.accentColor)
            Text(text).font(.system(size: 12.5)).foregroundStyle(.secondary).lineSpacing(2)
        }
        .dynorGlass(radius: 18, padding: 14)
    }

    @ViewBuilder
    private var imageActions: some View {
        Button {
            saving = true
            Task {
                await store.saveImportedToPhotos(item)
                notice = store.message
                store.message = nil
                saving = false
            }
        } label: {
            Label(saving ? "Đang lưu…" : "Lưu vào Ảnh", systemImage: "photo.badge.arrow.down")
        }
        .buttonStyle(DynorPrimaryButtonStyle(tint: store.accentColor, foreground: store.accentTextColor))
        .disabled(saving)
        ShareLink(item: store.fileURL(for: item)) {
            Label("Chia sẻ ảnh gốc", systemImage: "square.and.arrow.up")
        }
        .buttonStyle(DynorGlassButtonStyle())
        .disabled(installing)
    }

    // MARK: Tendies install controls

    @ViewBuilder
    private var tendiesControls: some View {
        if compatibility.warning == nil {
            note(compatibility.detail, symbol: "iphone.gen3")
        }
        if let warning = compatibility.warning {
            note(warning, symbol: "info.circle")
        } else if let warning = prerequisiteWarning {
            note(warning, symbol: "exclamationmark.shield", tint: .orange)
            Button("Mở bộ chọn hình nền") {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = "Không thể mở bộ chọn hình nền tự động. Hãy vào Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra."
                }
            }
            .buttonStyle(DynorGlassButtonStyle())
        }
        if installing {
            VStack(alignment: .leading, spacing: 10) {
                ProgressView(value: installProgress).tint(store.accentColor)
                Text("Đang ghi và xác minh… Giữ Dynor mở, iPhone mở khóa.")
                    .font(.system(size: 12)).foregroundStyle(.secondary)
            }
            .dynorGlass(radius: 18, padding: 14)
        }
        Button {
            installTendies()
        } label: {
            Label(installing ? "Đang cài hình nền…" : verifiedWrite ? "Ghi lại hình nền" : "Cài hình nền", systemImage: "iphone.gen3")
        }
        .buttonStyle(DynorPrimaryButtonStyle(tint: store.accentColor, foreground: store.accentTextColor))
        .disabled(installing || store.isInstallingWallpaper || prerequisiteWarning != nil || !compatibility.canAttemptInstall)
        if verifiedWrite {
            Button("Mở bộ chọn hình nền") {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = "iOS chưa mở được PosterBoard. Mở Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra. Nếu mẫu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại."
                }
            }
            .buttonStyle(DynorGlassButtonStyle())
        }
        if !installLog.isEmpty {
            DisclosureGroup("Chi tiết cài đặt") {
                Text(installLog.joined(separator: "\n"))
                    .font(.caption2.monospaced())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
                    .padding(.top, 8)
            }
            .font(.system(size: 13, weight: .medium))
            .dynorGlass(radius: 18, padding: 14)
        }
    }

    private func installTendies() {
        guard compatibility.canAttemptInstall, !installing, !store.isInstallingWallpaper, prerequisiteWarning == nil else { return }
        installing = true
        store.isInstallingWallpaper = true
        verifiedWrite = false
        installProgress = 0
        installLog = []
        let previousIdleSetting = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        Task { @MainActor in
            defer {
                installing = false
                store.isInstallingWallpaper = false
                UIApplication.shared.isIdleTimerDisabled = previousIdleSetting
            }
            do {
                let receipt = try await TendiesInstaller.shared.install(
                    archiveURL: store.fileURL(for: item),
                    log: { line in
                        Task { @MainActor in
                            installLog.append(line)
                            if installLog.count > 100 { installLog.removeFirst(installLog.count - 100) }
                        }
                    },
                    progress: { value in Task { @MainActor in installProgress = value } }
                )
                verifiedWrite = true
                ActivityJournal.shared.add("Đã ghi hình nền", detail: "\(item.displayName) · \(receipt.verifiedFileCount) tệp đã xác minh", success: true)
                // Request PosterBoard after successful verification. iOS decides whether
                // it can foreground the system UI; no private multitasking manipulation.
                let opened = PosterBoardAccess.requestOpenPosterBoard()
                notice = opened
                    ? "Đã cài dữ liệu hình nền thành công! Dynor đã xác minh \(receipt.verifiedFileCount) tệp. Trong PosterBoard, chọn hình nền vừa thêm và bấm Thêm/Đặt làm hình nền. Nếu chưa thấy, mở Cài đặt → Hình nền hoặc khởi động lại iPhone."
                    : "Đã cài dữ liệu hình nền thành công! Dynor đã xác minh \(receipt.verifiedFileCount) tệp. iOS chưa cho tự mở PosterBoard; vào Cài đặt → Hình nền → Thêm hình nền mới, chọn mẫu vừa cài. Nếu chưa thấy, khởi động lại iPhone."
            } catch {
                ActivityJournal.shared.add("Cài hình nền thất bại", detail: "\(item.displayName) · \(error.localizedDescription)", success: false)
                notice = "Chưa hoàn tất cài hình nền: \(error.localizedDescription)"
            }
        }
    }
}

private enum WallpaperPreviewMode: String, CaseIterable, Identifiable {
    case sleep, locked, unlock
    var id: String { rawValue }
    var title: String {
        switch self {
        case .sleep: "Sleep"
        case .locked: "Locked"
        case .unlock: "Unlock"
        }
    }
}
