import SwiftUI
import UIKit
import UniformTypeIdentifiers

@MainActor
struct LibraryView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var importing = false
    @State private var pickerIsVisible = false
    @State private var readingFiles = false
    @State private var importResultMessage: String?
    @State private var selecting = false
    @State private var selected = Set<UUID>()
    @State private var confirmDelete = false
    @State private var preview: ImportedWallpaper?
    @State private var showInstaller = false
    @State private var category = "Tendies"
    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]
    private var visible: [ImportedWallpaper] {
        store.library.filter { $0.kind.isTendies }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 17) {
                    DynorHero(index: "02 / COLLECTION", title: store.localized("Bộ sưu tập", "Collection", "收藏"), subtitle: store.localized("Không gian lưu trữ những tác phẩm của bạn.", "Your personal wallpaper archive.", "你的壁纸档案。"), symbol: "square.stack.3d.up.fill")
                    Button { showImportPicker() } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "square.and.arrow.down")
                            Text(store.localized("Nhập gói hình nền", "Import wallpaper package", "导入壁纸包"))
                            Spacer()
                            Image(systemName: "arrow.up.left").font(.caption).foregroundStyle(.secondary)
                        }
                        .font(.system(size: 16, weight: .semibold))
                        .padding(.horizontal, 18)
                        .frame(maxWidth: .infinity)
                        .frame(height: 66)
                        .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 23, style: .continuous))
                        .contentShape(RoundedRectangle(cornerRadius: 23, style: .continuous))
                    }.buttonStyle(.plain)
                    HStack {
                        Label(store.localized("Tệp của bạn", "Your files", "你的文件"), systemImage: "square.grid.2x2")
                            .font(.caption.weight(.bold)).tracking(1)
                        Spacer()
                        Text(store.localized("\(visible.count) mục", "\(visible.count) items", "\(visible.count) 项")).font(.caption).foregroundStyle(.secondary)
                    }.padding(.top, 6)
                }
                HStack {
                    Text(store.localized("\(visible.count) tệp", "\(visible.count) files", "\(visible.count) 个文件")).font(.subheadline).foregroundStyle(.secondary)
                    Spacer()
                    Menu {
                        Button {
                            selecting.toggle()
                            selected.removeAll()
                        } label: {
                            Label(selecting ? store.localized("Xong", "Done", "完成") : store.localized("Chọn nhiều", "Select multiple", "多选"), systemImage: selecting ? "checkmark" : "checklist")
                        }
                        if selecting && !visible.isEmpty {
                            Button {
                                let ids = Set(visible.map(\.id))
                                if selected.isSuperset(of: ids) { selected.subtract(ids) }
                                else { selected.formUnion(ids) }
                            } label: {
                                Label(selected.count == visible.count ? store.localized("Bỏ chọn tất cả", "Deselect all", "取消全选") : store.localized("Chọn tất cả", "Select all", "全选"), systemImage: "checkmark.circle")
                            }
                        }
                    } label: {
                        Image(systemName: "line.3.horizontal.decrease")
                            .font(.system(size: 19, weight: .semibold))
                            .frame(width: 48, height: 48)
                            .background(DynorDesign.surface, in: Circle())
                            .contentShape(Circle())
                    }
                    .buttonStyle(.plain)
                    .disabled(visible.isEmpty || store.isInstallingWallpaper)
                    .accessibilityLabel(store.localized("Tùy chọn chọn hình nền", "Wallpaper selection options", "壁纸选择选项"))
                }
                if visible.isEmpty {
                    ContentUnavailableView {
                        Label(store.localized("Bộ sưu tập bắt đầu từ bạn", "Your collection starts here", "从这里开始收藏"), systemImage: "square.and.arrow.down")
                    } description: {
                        Text(store.localized("Nhập tệp .tendies hoặc .dynor từ ứng dụng Tệp để bắt đầu.", "Import a .tendies or .dynor file from Files to begin.", "从文件应用导入 .tendies 或 .dynor 文件即可开始。"))
                    } actions: {
                        Button(store.localized("Chọn tệp để nhập", "Choose a file", "选择文件"), action: showImportPicker)
                            .buttonStyle(.bordered)
                            .disabled(readingFiles || store.isImporting || store.isInstallingWallpaper)
                    }.padding(.vertical, 35)
                } else {
                    LazyVGrid(columns: columns, spacing: 18) {
                        ForEach(visible) { item in
                            VStack(alignment: .leading, spacing: 10) {
                                Button {
                                    if selecting {
                                        if selected.contains(item.id) { selected.remove(item.id) }
                                        else { selected.insert(item.id) }
                                    } else { preview = item }
                                } label: {
                                    ZStack(alignment: .topTrailing) {
                                        LibraryArtwork(item: item)
                                            .frame(height: 235).clipped()
                                            .clipShape(RoundedRectangle(cornerRadius: 15))
                                        if selecting {
                                            Image(systemName: selected.contains(item.id) ? "checkmark.circle.fill" : "circle")
                                                .font(.system(size: 30, weight: .semibold))
                                                .foregroundStyle(selected.contains(item.id) ? store.accentColor : .white)
                                                .shadow(color: .black.opacity(0.4), radius: 4)
                                                .padding(12)
                                        }
                                    }
                                    .contentShape(Rectangle())
                                }
                                .buttonStyle(.plain)
                                Text(item.displayName).font(.subheadline.weight(.bold)).lineLimit(1)
                                Text(ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                                    .font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                    }
                }

                if selecting {
                    Text(store.localized("Đã chọn \(selected.count) / \(visible.count) hình nền", "Selected \(selected.count) of \(visible.count) wallpapers", "已选择 \(selected.count) / \(visible.count) 张壁纸"))
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                if selecting && !selected.isEmpty {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label(store.localized("Xóa \(selected.count) tệp đã chọn", "Delete \(selected.count) selected files", "删除 \(selected.count) 个选中文件"), systemImage: "trash")
                            .frame(maxWidth: .infinity).padding(8)
                    }.buttonStyle(.bordered).disabled(store.isInstallingWallpaper)
                }
            }.padding(20)
        }
        .background(DynorDesign.canvas)
        .sheet(isPresented: $showInstaller) {
            NavigationStack {
                PosterBoardView()
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("Đóng") { showInstaller = false }
                        }
                    }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(action: showImportPicker) {
            if readingFiles { ProgressView() } else { Image(systemName: "plus") }
        }.disabled(readingFiles || store.isImporting || store.isInstallingWallpaper)
            .accessibilityLabel("Nhập Tendies") } }
        .sheet(isPresented: $importing, onDismiss: {
            pickerIsVisible = false
            presentImportResult()
        }) {
            WallpaperDocumentPicker(onPick: { urls in
                // Retain and process the selection immediately. Import must not
                // depend on the order of UIKit and SwiftUI dismissal callbacks.
                importing = false
                importPickedDocuments(urls)
            }, onCancel: {
                importing = false
            })
        }
        .overlay {
            if readingFiles {
                ProgressView("Đang nhập tệp…")
                    .padding(24).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
            }
        }
        .confirmationDialog("Xóa \(selected.count) tệp khỏi Dynor?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Xóa \(selected.count) tệp", role: .destructive) {
                store.removeImported(ids: selected); selected.removeAll(); selecting = false
            }
            Button("Giữ lại", role: .cancel) {}
        } message: { Text("Tệp gốc bên ngoài Dynor vẫn được giữ lại.") }
        .sheet(item: $preview) { LibraryPreview(item: $0).environmentObject(store) }
        .onAppear { presentRequestedWallpaper() }
        .onChange(of: store.pendingLibraryPreview) { _, _ in presentRequestedWallpaper() }
    }

    private func showImportPicker() {
        guard !readingFiles, !store.isImporting, !store.isInstallingWallpaper else { return }
        pickerIsVisible = true
        importing = true
    }

    private func importPickedDocuments(_ urls: [URL]) {
        guard !urls.isEmpty, !readingFiles else { return }
        readingFiles = true
        Task { @MainActor in
            defer {
                readingFiles = false
                presentImportResult()
            }
            let imported = await store.importWallpapers(urls: urls)
            ActivityJournal.shared.add(imported.isEmpty ? "Nhập tệp thất bại" : "Đã nhập tệp", detail: imported.isEmpty ? "Không có tệp hợp lệ" : imported.map(\.displayName).joined(separator: ", "), success: !imported.isEmpty)
            let message = store.message
            store.message = nil
            if urls.count == 1, let item = imported.first {
                store.openInLibrary(item)
            } else {
                importResultMessage = message ?? "Chưa nhập được tệp đã chọn. Hãy thử lại."
            }
        }
    }

    private func presentImportResult() {
        guard !pickerIsVisible, !importing, !readingFiles else { return }
        if let message = importResultMessage {
            importResultMessage = nil
            store.message = message
        }
        presentRequestedWallpaper()
    }

    private func presentRequestedWallpaper() {
        guard !pickerIsVisible, !importing, !readingFiles,
              store.selectedTab == .library, let id = store.pendingLibraryPreview,
              let item = store.library.first(where: { $0.id == id }) else { return }
        category = item.kind.isTendies ? "Tendies" : "Ảnh"
        selecting = false
        selected.removeAll()
        preview = item
        store.pendingLibraryPreview = nil
    }
}

private struct LibraryArtwork: View {
    @EnvironmentObject private var store: DynorStore
    let item: ImportedWallpaper
    var body: some View {
        GeometryReader { geometry in
            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                Image(uiImage: image).resizable().scaledToFill().frame(width: geometry.size.width, height: geometry.size.height)
            } else if item.kind == .tendies {
                TendiesArtworkPreview(archiveURL: store.fileURL(for: item))
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .clipped()
            } else {
                ZStack {
                    LinearGradient(colors: [.init(red: 0.35, green: 0.48, blue: 0.43), .init(red: 0.7, green: 0.7, blue: 0.46)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    VStack(spacing: 20) {
                        Image(systemName: item.kind == .encryptedTendies ? "lock.shield" : "square.3.layers.3d").font(.system(size: 42, weight: .ultraLight))
                        Text(item.kind == .encryptedTendies ? "DYNOR" : "TENDIES").font(.caption.weight(.medium)).tracking(4)
                    }.foregroundStyle(.white)
                }
            }
        }
    }
}

@MainActor
struct LibraryPreview: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    let item: ImportedWallpaper
    @State private var saving = false
    @State private var notice: String?
    @State private var installing = false
    @State private var installProgress = 0.0
    @State private var installLog: [String] = []
    @State private var verifiedWrite = false
    @State private var previewMode: WallpaperPreviewMode = .locked
    @State private var confirmSingleDelete = false
    private var compatibility: TendiesCompatibility.Assessment { TendiesCompatibility.current }
    private var prerequisiteWarning: String? { PosterBoardAccess.prerequisiteWarning }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(spacing: 16) {
                        ZStack(alignment: .top) {
                            Group {
                                if item.kind == .tendies {
                                    TendiesArtworkPreview(archiveURL: store.fileURL(for: item), phase: previewMode.rawValue)
                                } else {
                                    LibraryArtwork(item: item)
                                }
                            }
                                .frame(height: 470).clipped()
                                .scaleEffect(previewMode == .sleep ? 1.07 : previewMode == .unlock ? 1.02 : 1)
                                .animation(.easeInOut(duration: 0.85), value: previewMode)
                            if true {
                                VStack(spacing: 6) {
                                    Text(Date.now, format: .dateTime.weekday(.wide).month(.abbreviated).day())
                                        .font(.caption.weight(.medium))
                                    Text(Date.now, format: .dateTime.hour().minute())
                                        .font(.system(size: 62, weight: .thin, design: .rounded))
                                }
                                .foregroundStyle(.white)
                                .shadow(color: .black.opacity(0.5), radius: 8)
                                .padding(.top, 52)
                            }
                            if previewMode == .sleep {
                                Color.black.opacity(0.68).allowsHitTesting(false)
                            }
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
                        HStack(spacing: 7) {
                            ForEach(WallpaperPreviewMode.allCases) { mode in
                                Button {
                                    withAnimation(.easeInOut(duration: 0.85)) { previewMode = mode }
                                } label: {
                                    Text(mode.title).font(.caption.weight(.semibold))
                                        .frame(maxWidth: .infinity).padding(.vertical, 12)
                                        .foregroundStyle(previewMode == mode ? Color.white : Color.primary)
                                        .background(previewMode == mode ? store.accentColor : Color(uiColor: .tertiarySystemGroupedBackground), in: Capsule())
                                }.buttonStyle(.plain)
                            }
                        }
                        Text("Chế độ này xem trước ảnh đại diện của từng trạng thái. Animation CAML gốc cần trình dựng tương thích và chưa được phát trong Dynor.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                    DynorSoftCard {
                        VStack(alignment: .leading, spacing: 13) {
                            Label("Thông tin hình nền", systemImage: "info.circle").font(.headline)
                            infoRow("Ngày nhập", item.addedAt.formatted(date: .abbreviated, time: .shortened))
                            infoRow("Dung lượng", ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                            infoRow("Định dạng", (item.storedFilename as NSString).pathExtension.uppercased())
                            infoRow("Nguồn", item.kind == .encryptedTendies ? "Dynor mã hóa" : item.kind == .tendies ? "Tendies" : "Ảnh")
                            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                                infoRow("Kích thước", "\(Int(image.size.width * image.scale)) × \(Int(image.size.height * image.scale)) px")
                            } else {
                                infoRow("Kích thước", "Không có metadata ảnh đại diện")
                            }
                        }
                    }
                    Text(item.displayName).font(.title2.bold())
                    Button(role: .destructive) { confirmSingleDelete = true } label: {
                        Label("Xóa hình nền khỏi bộ sưu tập", systemImage: "trash")
                            .frame(maxWidth: .infinity).padding(12)
                    }
                    .buttonStyle(.bordered)
                    .disabled(installing)
                    Text(item.kind.isTendies ? "Giữ iPhone mở khóa khi cài. Dynor ghi trực tiếp vào PosterBoard; sau đó mở bộ chọn hình nền để kiểm tra và chọn mẫu mới." : "Lưu ảnh vào Ảnh, sau đó chọn Chia sẻ → Dùng làm hình nền.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    if item.kind == .encryptedTendies {
                        Label("Đăng nhập Dynor và kết nối Internet mỗi lần cài gói mã hóa. Gói VIP cần tài khoản VIP còn hiệu lực. Dynor không xuất tệp đã giải mã.", systemImage: "lock.shield")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if item.kind.isTendies {
                        tendiesControls
                    }
                    if item.kind == .image {
                        Button {
                            saving = true
                            Task {
                                await store.saveImportedToPhotos(item)
                                notice = store.message
                                store.message = nil
                                saving = false
                            }
                        } label: {
                            Label(saving ? "Đang lưu…" : "Lưu vào Ảnh", systemImage: "photo.badge.arrow.down")
                                .frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(.borderedProminent).disabled(saving)
                        ShareLink(item: store.fileURL(for: item)) {
                            Label("Chia sẻ ảnh gốc", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(.bordered).disabled(installing)
                    }
                }.padding(20)
            }.toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() }.disabled(installing) } }
            .interactiveDismissDisabled(installing)
            .confirmationDialog("Xóa gói hình nền này?", isPresented: $confirmSingleDelete) {
                Button("Xóa khỏi Dynor", role: .destructive) {
                    store.removeImported(ids: Set([item.id]))
                    dismiss()
                }
                Button("Hủy", role: .cancel) {}
            } message: { Text("Tệp gốc bên ngoài Dynor không bị xóa.") }
            .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
        }.font(.subheadline)
    }

    @ViewBuilder
    private var tendiesControls: some View {
        if compatibility.warning == nil {
            Label(compatibility.detail, systemImage: "iphone")
                .font(.caption).foregroundStyle(.secondary)
        }
        if let warning = compatibility.warning {
            Label(warning, systemImage: "info.circle")
                .font(.caption).foregroundStyle(.secondary)
        } else if let warning = prerequisiteWarning {
            Label(warning, systemImage: "exclamationmark.shield")
                .font(.caption).foregroundStyle(.secondary)
            Button("Mở bộ chọn hình nền") {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = "Không thể mở bộ chọn hình nền tự động. Hãy vào Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra."
                }
            }.font(.subheadline)
        }
        if installing {
            ProgressView(value: installProgress)
            Text("Đang ghi và xác minh… Giữ Dynor mở, iPhone mở khóa.")
                .font(.caption).foregroundStyle(.secondary)
        }
        Button {
            installTendies()
        } label: {
            Label(installing ? "Đang cài hình nền…" : verifiedWrite ? "Ghi lại hình nền" : "Cài hình nền", systemImage: "iphone.gen3")
                .frame(maxWidth: .infinity).padding(8)
        }
        .buttonStyle(.borderedProminent)
        .disabled(installing || store.isInstallingWallpaper || prerequisiteWarning != nil || !compatibility.canAttemptInstall)
        if verifiedWrite {
            Button("Mở bộ chọn hình nền") {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = "iOS chưa mở được PosterBoard. Mở Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra. Nếu mẫu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại."
                }
            }.buttonStyle(.bordered)
        }
        if !installLog.isEmpty {
            DisclosureGroup("Chi tiết cài đặt") {
                Text(installLog.joined(separator: "\n"))
                    .font(.caption2.monospaced())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
            }.font(.caption)
        }
    }

    private func installTendies() {
        guard compatibility.canAttemptInstall, !installing, !store.isInstallingWallpaper, prerequisiteWarning == nil else { return }
        installing = true
        store.isInstallingWallpaper = true
        verifiedWrite = false
        installProgress = 0
        installLog = []
        let previousIdleSetting = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        Task { @MainActor in
            defer {
                installing = false
                store.isInstallingWallpaper = false
                UIApplication.shared.isIdleTimerDisabled = previousIdleSetting
            }
            do {
                let receipt = try await TendiesInstaller.shared.install(
                    archiveURL: store.fileURL(for: item),
                    log: { line in
                        Task { @MainActor in
                            installLog.append(line)
                            if installLog.count > 100 { installLog.removeFirst(installLog.count - 100) }
                        }
                    },
                    progress: { value in Task { @MainActor in installProgress = value } }
                )
                verifiedWrite = true
                ActivityJournal.shared.add("Đã ghi hình nền", detail: "\(item.displayName) · \(receipt.verifiedFileCount) tệp đã xác minh", success: true)
                // Request PosterBoard after successful verification. iOS decides whether
                // it can foreground the system UI; no private multitasking manipulation.
                let opened = PosterBoardAccess.requestOpenPosterBoard()
                notice = opened
                    ? "Đã cài dữ liệu hình nền thành công! Dynor đã xác minh \(receipt.verifiedFileCount) tệp. Trong PosterBoard, chọn hình nền vừa thêm và bấm Thêm/Đặt làm hình nền. Nếu chưa thấy, mở Cài đặt → Hình nền hoặc khởi động lại iPhone."
                    : "Đã cài dữ liệu hình nền thành công! Dynor đã xác minh \(receipt.verifiedFileCount) tệp. iOS chưa cho tự mở PosterBoard; vào Cài đặt → Hình nền → Thêm hình nền mới, chọn mẫu vừa cài. Nếu chưa thấy, khởi động lại iPhone."
            } catch {
                ActivityJournal.shared.add("Cài hình nền thất bại", detail: "\(item.displayName) · \(error.localizedDescription)", success: false)
                notice = "Chưa hoàn tất cài hình nền: \(error.localizedDescription)"
            }
        }
    }
}

private enum WallpaperPreviewMode: String, CaseIterable, Identifiable {
    case sleep, locked, unlock
    var id: String { rawValue }
    var title: String {
        switch self {
        case .sleep: "Sleep"
        case .locked: "Locked"
        case .unlock: "Unlock"
        }
    }
}
