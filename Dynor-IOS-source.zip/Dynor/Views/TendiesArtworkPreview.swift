import SwiftUI
import UIKit

/// A bounded preview extracted from a validated .tendies archive.
/// Encrypted .dynor packages do not expose their artwork until unlocked.
struct TendiesArtworkPreview: View {
    let archiveURL: URL
    @State private var artwork: UIImage?
    var body: some View {
        Group {
            if let artwork {
                Image(uiImage: artwork).resizable().scaledToFill()
            } else {
                LinearGradient(colors: [.indigo.opacity(0.65), .cyan.opacity(0.55), .mint.opacity(0.65)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .overlay { Image(systemName: "photo.stack.fill").font(.largeTitle).foregroundStyle(.white.opacity(0.8)) }
            }
        }
        .task(id: archiveURL.path) {
            let url = archiveURL
            artwork = await Task.detached(priority: .utility) { () -> UIImage? in
                let fm = FileManager.default
                let temp = fm.temporaryDirectory.appendingPathComponent("dynor-preview-" + UUID().uuidString, isDirectory: true)
                defer { try? fm.removeItem(at: temp) }
                do {
                    let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: url)
                    let candidates = entries.filter { !$0.isDirectory && !$0.isMetadata && $0.uncompressedSize <= 12_000_000 &&
                        ["jpg", "jpeg", "png", "heic", "webp"].contains(($0.path as NSString).pathExtension.lowercased()) }
                    guard !candidates.isEmpty else { return nil }
                    try TendiesArchiveValidator.extract(at: url, to: temp, entries: entries)
                    let sorted = candidates.sorted {
                        let a = $0.path.lowercased(), b = $1.path.lowercased()
                        let ascore = (a.contains("preview") || a.contains("thumbnail") || a.contains("lock")) ? 0 : 1
                        let bscore = (b.contains("preview") || b.contains("thumbnail") || b.contains("lock")) ? 0 : 1
                        return ascore == bscore ? a < b : ascore < bscore
                    }
                    for entry in sorted.prefix(15) {
                        let file = temp.appendingPathComponent(entry.path)
                        if let data = try? Data(contentsOf: file), let image = UIImage(data: data) { return image }
                    }
                } catch { return nil }
                return nil
            }.value
        }
    }
}
