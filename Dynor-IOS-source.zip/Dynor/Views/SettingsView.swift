import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var activeSheet: SettingsSheet?
    @State private var customColor = Color(red: 0.20, green: 0.47, blue: 0.96)
    @State private var confirmReset = false
    @State private var resetting = false
    @State private var resetMessage: String?

    @StateObject private var account = DynorAccountService.shared
    private var appVersion: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
        return "Phiên bản \(version) (build \(build))"
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 19) {
                    DynorHero(index: "04 / SETTINGS", title: store.localized("Cài đặt", "Settings", "设置"), subtitle: store.localized("Thiết bị, giao diện và dữ liệu.", "Device, appearance and data.", "设备、外观和数据。"), symbol: "gearshape.2.fill")
                    accountCard
                    appearanceCard
                    vipCard
                    deviceCard
                    compatibilityCard
                    activityCard
                    maintenanceCard
                    informationCard
                    Text(appVersion).font(.caption2).foregroundStyle(.secondary)
                }
                .padding(20)
            }
            .background(DynorDesign.canvas)
            .toolbar(.hidden, for: .navigationBar)
            .confirmationDialog("Đặt lại các hình nền Dynor đã ghi?", isPresented: $confirmReset) {
                Button("Xóa cấu hình Dynor", role: .destructive) { resetInstalled() }
            } message: { Text("Chỉ xóa các cấu hình Dynor đã ghi, không xóa hình nền hệ thống khác.") }
            .alert("Đặt lại bộ sưu tập", isPresented: Binding(get: { resetMessage != nil }, set: { if !$0 { resetMessage = nil } })) {
                Button("OK") { resetMessage = nil }
            } message: { Text(resetMessage ?? "") }
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .account: SettingsAccountSheet()
                case .vip: SettingsVIPSheet()
                case .contact: SettingsInformationSheet(title: "Thông tin liên hệ", symbol: "envelope", text: "Thông tin liên hệ của nhà phát triển chưa được cung cấp. Email, số điện thoại và liên kết hỗ trợ cần được cập nhật trước khi phát hành.")
                case .credits: SettingsCreditsSheet()
                case .colors: ThemeColorPickerView()
                case .privacy: SettingsInformationSheet(title: "Dữ liệu ở lại với bạn", symbol: "lock.shield", text: "Ảnh và tệp Tendies bạn nhập được sao chép vào vùng lưu trữ riêng của Dynor trên thiết bị. Tên hồ sơ trải nghiệm, ID, giao diện, yêu thích và tiến trình quảng cáo mô phỏng được lưu cục bộ.\n\nGói Tendies được kiểm tra và ghi trực tiếp vào container PosterBoard qua worse_query. Cơ chế này cần App Group được cấp quyền trong chữ ký IPA. Dynor đọc lại và đối chiếu dữ liệu đã ghi; bạn chọn hình nền trong bộ chọn của iOS.\n\nBản này chưa có tài khoản được xác thực hoặc đồng bộ đám mây. Gỡ ứng dụng có thể làm mất dữ liệu cục bộ. Ảnh đã lưu vào ứng dụng Ảnh được quản lý riêng bởi iOS.")
                }
            }
        }
    }


    private var deviceCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 13) {
                Label("Thông tin thiết bị", systemImage: "iphone.gen3").font(.headline)
                deviceRow("Thiết bị", UIDevice.current.model)
                deviceRow("Tên thiết bị", UIDevice.current.name)
                deviceRow("Hệ điều hành", "iOS " + UIDevice.current.systemVersion)
                deviceRow("Phiên bản Dynor", appVersion)
                deviceRow("Bundle ID", Bundle.main.bundleIdentifier ?? "—")
                deviceRow("App Group", PosterBoardAccess.prerequisiteWarning == nil ? "Có quyền truy cập" : "Chưa sẵn sàng")
            }
        }
    }
    private func deviceRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 8)
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
        }.font(.subheadline)
    }
    private var compatibilityCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("Phiên bản iOS hỗ trợ", systemImage: "checkmark.shield").font(.headline)
                Text("Phạm vi cơ chế worse_query được khai báo; không đồng nghĩa mọi bản đều đã kiểm thử.")
                    .font(.caption).foregroundStyle(.secondary)
                compatibilityRow("iOS 26.0 – 26.7.2", "Có thể thử", .green)
                compatibilityRow("iOS 27.0 – 27.2.0", "Có thể thử", .green)
                compatibilityRow("Các phiên bản khác", "Chưa hỗ trợ", .orange)
                Divider()
                Label(TendiesCompatibility.current.canAttemptInstall ? "Phiên bản iOS hiện tại nằm trong phạm vi thử nghiệm" : "Phiên bản iOS hiện tại nằm ngoài phạm vi", systemImage: "info.circle")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }
    private func compatibilityRow(_ version: String, _ status: String, _ color: Color) -> some View {
        HStack { Text(version); Spacer(); Text(status).font(.caption.weight(.semibold)).foregroundStyle(color) }.font(.subheadline)
    }
    private var activityCard: some View {
        SettingsGlassCard {
            NavigationLink {
                ActivityHistoryView()
            } label: {
                HStack {
                    Image(systemName: "clock.arrow.circlepath").foregroundStyle(store.accentColor)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Nhật ký hoạt động").font(.headline)
                        Text("Lịch sử nhập và cài hình nền").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
                }
            }.buttonStyle(.plain)
        }
    }

    private var accountCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 18) {
                Text("Tài khoản").font(.headline)
                HStack(spacing: 14) {
                    SettingsAvatar()
                    VStack(alignment: .leading, spacing: 5) {
                        Text(account.email ?? store.profile?.name ?? "Chào bạn, người sáng tạo").font(.subheadline.weight(.semibold))
                        Text(account.email == nil ? "Đăng nhập để đồng bộ quyền lợi VIP." : (account.isVIP ? "Dynor VIP đang hoạt động" : "Tài khoản đã xác minh"))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                Button { activeSheet = .account } label: {
                    HStack {
                        Text(account.email == nil ? "Đăng nhập" : "Quản lý tài khoản")
                        Spacer()
                        Image(systemName: "arrow.right")
                    }
                    .font(.subheadline.weight(.semibold))
                }
                .tint(store.accentColor)
            }
        }
    }

    private var appearanceCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 19) {
                Text("Giao diện").font(.headline)
                VStack(alignment: .leading, spacing: 10) {
                    Text("Chế độ hiển thị").font(.subheadline.weight(.medium))
                    Picker("Chế độ hiển thị", selection: $store.theme) {
                        Text("Sáng").tag(ThemeMode.light)
                        Text("Tối").tag(ThemeMode.dark)
                        Text("Tự động").tag(ThemeMode.system)
                    }
                    .pickerStyle(.segmented)
                }
                Divider()
                Button { activeSheet = .colors } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "paintpalette.fill").foregroundStyle(store.accentColor)
                        Text("Màu chủ đề").foregroundStyle(.primary)
                        Spacer()
                        Circle().fill(store.accentColor).frame(width: 24, height: 24)
                        Image(systemName: "chevron.right").foregroundStyle(.secondary)
                    }.font(.subheadline.weight(.medium))
                }.buttonStyle(.plain)
                Divider()
                HStack {
                    Label("Ngôn ngữ", systemImage: "globe")
                    Spacer()
                    Picker("Ngôn ngữ", selection: $store.appLanguage) {
                        Text("Tiếng Việt").tag("vi")
                        Text("English").tag("en")
                        Text("中文").tag("zh-Hans")
                    }.labelsHidden()
                }
                Text(store.localized("Ngôn ngữ áp dụng cho giao diện. Thông báo kỹ thuật có thể giữ nguyên ngôn ngữ gốc.", "Language applies to the interface. Technical diagnostics may remain in their original language.", "语言设置应用于界面。技术诊断信息可能保留原文。"))
                    .font(.caption2).foregroundStyle(.secondary)
                Divider()
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Liquid glass").font(.subheadline.weight(.medium))
                        Text("Kính mờ thích ứng nền sáng và tối.").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Label("Bật", systemImage: "checkmark.circle.fill")
                        .font(.caption.weight(.semibold)).foregroundStyle(store.accentColor)
                }
            }
        }
    }

    private var vipCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            Image(systemName: "crown.fill").font(.system(size: 30)).foregroundStyle(Color.primary)
            Text("Mở hết cảm hứng.\nSống trọn chất riêng.").font(.title2.weight(.semibold))
            Text("Khám phá các gói Dynor VIP từ 39.000đ / tuần.")
                .font(.subheadline).foregroundStyle(.secondary)
            Button { activeSheet = .vip } label: {
                HStack {
                    Text("Khám phá VIP")
                    Spacer()
                    Image(systemName: "arrow.right")
                }
                .font(.subheadline.weight(.semibold))
                .padding(14)
                .foregroundStyle(store.accentTextColor)
                .background(store.accentColor, in: RoundedRectangle(cornerRadius: 13))
            }
            Text("VIP chỉ được kích hoạt sau khi máy chủ xác nhận giao dịch.").font(.caption2).foregroundStyle(.secondary)
        }
        .padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 17)
                .fill(.ultraThinMaterial)
                .overlay(alignment: .topTrailing) {
                    Circle().fill(Color.primary.opacity(0.07)).frame(width: 150, height: 150).blur(radius: 40).offset(x: 30, y: -45)
                }
                .clipShape(RoundedRectangle(cornerRadius: 17))
        }
        
    }

    private var maintenanceCard: some View {
        SettingsGlassCard {
            Button(role: .destructive) { confirmReset = true } label: {
                HStack {
                    Label("Đặt lại bộ sưu tập đã cài", systemImage: "arrow.counterclockwise")
                    Spacer()
                    if resetting { ProgressView() }
                }.font(.subheadline.weight(.semibold))
            }.disabled(resetting)
            Text("Chỉ gỡ cấu hình PosterBoard do Dynor ghi; không xóa gói trong Bộ sưu tập hoặc hình nền hệ thống khác.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
    private func resetInstalled() {
        resetting = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: PosterBoardDescriptorWriter.installedPaths()) }
            await MainActor.run {
                resetting = false
                switch result {
                case .success(let count): resetMessage = "Đã xóa \(count) cấu hình Dynor."
                case .failure(let error): resetMessage = error.localizedDescription
                }
            }
        }
    }
    private var informationCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 3) {
                Text("Thông tin & hỗ trợ").font(.headline).padding(.bottom, 10)
                SettingsLinkRow(title: "Thông tin liên hệ", symbol: "envelope") { activeSheet = .contact }
                Divider()
                SettingsLinkRow(title: "Về Dynor & ghi công", symbol: "sparkles") { activeSheet = .credits }
                Divider()
                SettingsLinkRow(title: "Dữ liệu của bạn", symbol: "lock.shield") { activeSheet = .privacy }
            }
        }
    }
}

private enum SettingsSheet: String, Identifiable {
    case account, vip, contact, credits, privacy, colors
    var id: String { rawValue }
}

private struct SettingsHeader: View {
    let eyebrow: String
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(eyebrow).font(.system(size: 10, weight: .medium)).tracking(2).foregroundStyle(.secondary)
            Text(title).font(.system(size: 30, weight: .semibold, design: .rounded))
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 10)
    }
}

private struct SettingsGlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        content.padding(21).frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 17))
            .overlay(RoundedRectangle(cornerRadius: 17).strokeBorder(DynorDesign.outline, lineWidth: 0.7))
    }
}

private struct SettingsAvatar: View {
    var body: some View {
        Group {
            if let path = Bundle.main.path(forResource: "AppIcon", ofType: "jpg"), let image = UIImage(contentsOfFile: path) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: "person.crop.square.fill").resizable().foregroundStyle(.secondary)
            }
        }
        .frame(width: 54, height: 54)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .accessibilityLabel("Icon Dynor")
    }
}

private struct SettingsLinkRow: View {
    let title: String
    let symbol: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol).frame(width: 22).foregroundStyle(.secondary)
                Text(title)
                Spacer()
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
            }
            .font(.subheadline)
            .foregroundStyle(.primary)
            .padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

private struct SettingsAccountSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var inputEmail = ""
    @State private var otp = ""
    @State private var awaitingOTP = false
    @State private var working = false
    @State private var errorText: String?

    private var validEmail: Bool {
        let value = inputEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.contains("@") && value.split(separator: "@").last?.contains(".") == true
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 14) {
                        Text("D")
                            .font(.system(size: 27, weight: .black, design: .rounded))
                            .foregroundStyle(store.accentTextColor)
                            .frame(width: 52, height: 52)
                            .background(store.accentColor, in: RoundedRectangle(cornerRadius: 16))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Dynor").font(.title3.bold())
                            Text("Không gian của riêng bạn")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.bottom, 32)

                    VStack(alignment: .leading, spacing: 23) {
                        HStack {
                            Image(systemName: "crown.fill").font(.title2)
                            Spacer()
                            Image(systemName: "sparkle").foregroundStyle(.secondary)
                        }
                        Text("DYNOR ACCOUNT")
                            .font(.caption.weight(.bold))
                            .tracking(2.4)
                            .foregroundStyle(.secondary)
                        Text(account.email == nil ? "Chào mừng trở lại." : "Tài khoản của bạn.")
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                            .minimumScaleFactor(0.8)
                            .lineLimit(2)
                        Text(account.email == nil
                             ? "Đăng nhập bằng email để khám phá trải nghiệm Dynor của bạn."
                             : "Tài khoản Dynor của bạn đã được xác minh.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)

                        if let email = account.email {
                            VStack(alignment: .leading, spacing: 13) {
                                Text("EMAIL ĐANG ĐĂNG NHẬP")
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text(email).font(.headline).textSelection(.enabled)
                                Label(account.isVIP ? "Dynor VIP đang hoạt động" : "Tài khoản thường",
                                      systemImage: account.isVIP ? "crown.fill" : "person.crop.circle")
                                if let date = account.vipExpiresAt, account.isVIP {
                                    Text("VIP đến: \(date.formatted(date: .abbreviated, time: .shortened))")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                }
                                Button("Kiểm tra lại trạng thái VIP") {
                                    Task { await account.refreshVIP() }
                                }
                                .foregroundStyle(.primary)
                                Button("Đăng xuất", role: .destructive) {
                                    account.signOut(); awaitingOTP = false; otp = ""
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        } else {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Địa chỉ email").font(.subheadline.weight(.semibold))
                                TextField(text: $inputEmail, prompt: Text("tenban@gmail.com").foregroundColor(Color(uiColor: .lightGray))) { EmptyView() }
                                    .textContentType(.emailAddress)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .padding(16)
                                    .background(Color(uiColor: .systemBackground),
                                                in: RoundedRectangle(cornerRadius: 15))
                                    
                                    .disabled(awaitingOTP)
                                if awaitingOTP {
                                    Text("Mã xác minh gồm 6 chữ số")
                                        .font(.subheadline.weight(.semibold))
                                    TextField(text: $otp, prompt: Text("Nhập mã OTP").foregroundColor(.gray)) { EmptyView() }
                                        .keyboardType(.numberPad)
                                        .textContentType(.oneTimeCode)
                                        .padding(16)
                                        .background(Color(uiColor: .systemBackground),
                                                    in: RoundedRectangle(cornerRadius: 15))
                                        
                                    Button {
                                        Task {
                                            await perform {
                                                try await account.verifyOTP(email: inputEmail, code: otp)
                                            }
                                            if account.email != nil { awaitingOTP = false }
                                        }
                                    } label: {
                                        primaryButton("Xác minh & đăng nhập")
                                    }
                                    .disabled(working || otp.count != 6)
                                    Button("Gửi lại mã") {
                                        Task { await perform { try await account.sendOTP(to: inputEmail) } }
                                    }.disabled(working)
                                    Button("Đổi email") { awaitingOTP = false; otp = "" }
                                } else {
                                    Button {
                                        Task {
                                            await perform { try await account.sendOTP(to: inputEmail) }
                                            if errorText == nil { awaitingOTP = true }
                                        }
                                    } label: {
                                        primaryButton("Nhận mã xác minh")
                                    }
                                    .disabled(working || !validEmail)
                                }
                            }
                        }
                        if working { ProgressView() }
                        if let errorText {
                            Text(errorText).font(.footnote).foregroundStyle(.red)
                        }
                        if !account.statusMessage.isEmpty {
                            Text(account.statusMessage)
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                        if account.email == nil {
                            Text("Mã OTP gồm 6 chữ số sẽ được gửi tới email của bạn.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .padding(22)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(uiColor: .secondarySystemGroupedBackground),
                                in: RoundedRectangle(cornerRadius: 26))
                    
                    .padding(.bottom, 24)

                    Text("DYNOR · BẢN TRẢI NGHIỆM iOS\nĐăng nhập an toàn qua Supabase")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 18)
                .padding(.top, 30)
                .padding(.bottom, 40)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Tài khoản")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }

    private func primaryButton(_ title: String) -> some View {
        HStack {
            Spacer()
            Text(title).font(.headline)
            Image(systemName: "arrow.right")
            Spacer()
        }
        .foregroundStyle(store.accentTextColor)
        .padding(.vertical, 17)
        .background(store.accentColor, in: RoundedRectangle(cornerRadius: 17))
    }

    private func perform(_ operation: @escaping () async throws -> Void) async {
        working = true; errorText = nil
        defer { working = false }
        do { try await operation() }
        catch { errorText = error.localizedDescription }
    }
}

private struct SettingsVIPSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var selected = SettingsVIPPlan.month
    @State private var order: DynorPaymentOrder?
    @State private var paymentError: String?
    @State private var busy = false
    @State private var checking = false
    @State private var paidNotice = false
    @State private var completedCode: String?
    @State private var pollingTask: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Image(systemName: "crown.fill")
                        .font(.system(size: 43))
                    SettingsHeader(eyebrow: "DYNOR VIP", title: "Không giới hạn.", subtitle: "Mọi hình nền, không cần xem quảng cáo khi VIP còn hạn.")
                    ForEach(SettingsVIPPlan.allCases) { plan in
                        Button {
                            stopPolling()
                            selected = plan
                            order = nil
                            paymentError = nil
                            paidNotice = false
                        } label: {
                            HStack(spacing: 14) {
                                Image(systemName: selected == plan ? "checkmark.circle.fill" : "circle")
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(plan.title).font(.headline)
                                    Text(plan.duration).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(plan.price).font(.headline)
                            }
                            .padding(18)
                            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
                            .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(selected == plan ? Color.primary : .gray.opacity(0.2)))
                        }.buttonStyle(.plain)
                    }
                    if account.isVIP {
                        Label("VIP đang hoạt động", systemImage: "checkmark.seal.fill")
                        if let date = account.vipExpiresAt {
                            Text("Hạn: \(date.formatted(date: .numeric, time: .shortened))")
                        } else {
                            Text("Gói VIP vĩnh viễn")
                        }
                    }
                    if paidNotice {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Label("Thanh toán thành công!", systemImage: "checkmark.seal.fill")
                                    .font(.headline)
                                    .foregroundStyle(.green)
                                Text("Gói VIP đã được cập nhật. Mã QR cũ đã được ẩn để tránh chuyển khoản trùng.")
                                    .font(.subheadline)
                                if let date = account.vipExpiresAt {
                                    Text("Hạn VIP mới: \(date.formatted(date: .numeric, time: .shortened))")
                                        .font(.subheadline.weight(.semibold))
                                }
                                Button("Mua thêm gói VIP") {
                                    paidNotice = false
                                    completedCode = nil
                                }
                                .font(.subheadline.weight(.semibold))
                            }
                        }
                    }
                    if let order, !paidNotice {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 14) {
                                Text("Chuyển khoản để kích hoạt VIP").font(.headline)
                                if let url = order.qrURL {
                                    AsyncImage(url: url) { image in
                                        image.resizable().scaledToFit()
                                    } placeholder: {
                                        ProgressView().frame(height: 240)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 260)
                                    .accessibilityLabel("QR thanh toán ngân hàng")
                                }
                                Text("Ngân hàng: \(order.bankName)")
                                Text("Số tài khoản: \(order.bankAccount)").textSelection(.enabled)
                                Text("Số tiền: \(order.amount.formatted())đ").font(.headline)
                                Text("Nội dung chuyển khoản:").font(.caption).foregroundStyle(.secondary)
                                Text(order.paymentCode)
                                    .font(.system(.body, design: .monospaced).weight(.bold))
                                    .textSelection(.enabled)
                                ShareLink("Chia sẻ mã thanh toán", item: order.paymentCode)
                                HStack(spacing: 8) {
                                    ProgressView().controlSize(.small)
                                    Text("Đang tự động kiểm tra thanh toán...")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Text("Chỉ chuyển khoản đúng số tiền và nội dung trên. Sau khi ngân hàng ghi nhận, mã QR sẽ tự ẩn.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if let paymentError {
                        Text(paymentError).font(.caption).foregroundStyle(.red)
                    }
                    if order == nil && !paidNotice {
                        Button { Task { await createOrder() } } label: {
                            HStack {
                                Spacer()
                                if busy { ProgressView().tint(.white) }
                                Text("Tạo đơn trong Dynor").font(.headline)
                                Spacer()
                            }
                            .padding(.vertical, 17)
                            .foregroundStyle(store.accentTextColor)
                            .background(store.accentColor, in: RoundedRectangle(cornerRadius: 18))
                        }
                        .disabled(busy || account.email == nil)
                    }
                    if account.email == nil {
                        Text("Đăng nhập tài khoản Dynor trước khi tạo đơn.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Button {
                        Task {
                            if let code = order?.paymentCode {
                                await checkPayment(code: code, showError: true)
                            } else {
                                await account.refreshVIP()
                            }
                        }
                    } label: {
                        HStack {
                            if checking { ProgressView().controlSize(.small) }
                            Text("Kiểm tra lại VIP")
                        }
                    }
                    .disabled(checking)
                    .foregroundStyle(.primary)
                }
                .padding(22)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Dynor VIP")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
        .tint(store.accentColor)
        .onDisappear { stopPolling() }
    }

    private func stopPolling() {
        pollingTask?.cancel()
        pollingTask = nil
    }

    private func startPolling(code: String) {
        stopPolling()
        pollingTask = Task {
            while !Task.isCancelled {
                await checkPayment(code: code, showError: false)
                if Task.isCancelled || completedCode == code || order?.paymentCode != code {
                    break
                }
                try? await Task.sleep(for: .seconds(5))
            }
        }
    }

    private func checkPayment(code: String, showError: Bool) async {
        guard order?.paymentCode == code, completedCode != code, !checking else { return }
        checking = true
        defer { checking = false }
        do {
            let status = try await account.paymentStatus(for: code)
            guard !Task.isCancelled, order?.paymentCode == code else { return }
            if status == "paid" {
                completedCode = code
                order = nil
                paidNotice = true
                paymentError = nil
                stopPolling()
                await account.refreshVIP()
            } else if status == "expired" {
                order = nil
                stopPolling()
                paymentError = "Đơn hàng đã hết hạn. Hãy tạo đơn mới."
            } else if showError {
                paymentError = "Máy chủ chưa xác nhận thanh toán. Vui lòng đợi ngân hàng và SePay xử lý."
            }
        } catch {
            if showError { paymentError = error.localizedDescription }
        }
    }

    private func createOrder() async {
        busy = true
        paymentError = nil
        paidNotice = false
        stopPolling()
        defer { busy = false }
        do {
            let newOrder = try await account.createVIPOrder(plan: selected.rawValue)
            order = newOrder
            completedCode = nil
            startPolling(code: newOrder.paymentCode)
        } catch {
            order = nil
            paymentError = error.localizedDescription
        }
    }
}

private enum SettingsVIPPlan: String, CaseIterable, Identifiable {
    case week, month, lifetime
    var id: String { rawValue }
    var title: String { switch self { case .week: return "Thẻ tuần"; case .month: return "Thẻ tháng"; case .lifetime: return "Vĩnh viễn" } }
    var price: String { switch self { case .week: return "39.000đ"; case .month: return "59.000đ"; case .lifetime: return "99.000đ" } }
    var duration: String { switch self { case .week: return "7 ngày cảm hứng"; case .month: return "30 ngày khám phá"; case .lifetime: return "Một lần chọn, mãi mãi" } }
}

private struct SettingsInformationSheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let symbol: String
    let text: String
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Image(systemName: symbol).font(.system(size: 36)).foregroundStyle(.secondary)
                    Text(title).font(.title.weight(.semibold))
                    Text(text).font(.body).foregroundStyle(.secondary).lineSpacing(5)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

private struct SettingsCreditsSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    SettingsAvatar()
                    Text("Dynor").font(.largeTitle.weight(.bold))
                    Text("Một màn hình. Một thế giới mới.").font(.title3)
                    Text("Ứng dụng iOS viết bằng SwiftUI theo yêu cầu của bạn. Icon sử dụng ảnh bạn cung cấp. Hình nền trưng bày: Unsplash.")
                        .foregroundStyle(.secondary)
                    Divider()
                    Text("GHI CÔNG CÔNG NGHỆ").font(.caption.weight(.black)).tracking(2)
                    Text("worse_query").font(.system(size: 30, weight: .black, design: .rounded))
                    Text("Phát triển bởi forcequitOS. Cơ chế truy cập container được sử dụng trong tính năng cài hình nền PosterBoard của Dynor.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    Link("Mã nguồn worse_query", destination: URL(string: "https://github.com/forcequitOS/worse_query")!)
                    Text("Dynor cũng ghi nhận các thành phần bên thứ ba khác theo giấy phép và thông báo trong thư mục ThirdParty của source.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .navigationTitle("Về Dynor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

