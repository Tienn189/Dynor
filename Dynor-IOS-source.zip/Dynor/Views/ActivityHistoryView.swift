import SwiftUI

struct ActivityHistoryView: View {
    @ObservedObject private var journal = ActivityJournal.shared
    var body: some View {
        NavigationStack {
            Group {
                if journal.entries.isEmpty {
                    ContentUnavailableView("Chưa có hoạt động", systemImage: "clock.arrow.circlepath", description: Text("Các lần nhập và cài hình nền sẽ được lưu trên thiết bị."))
                } else {
                    List {
                        ForEach(journal.entries) { event in
                            HStack(alignment: .top, spacing: 13) {
                                Image(systemName: event.success ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                                    .foregroundStyle(event.success ? .green : .orange)
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(event.title).font(.headline)
                                    Text(event.detail).font(.subheadline).foregroundStyle(.secondary)
                                    Text(event.date, style: .date).font(.caption2).foregroundStyle(.tertiary)
                                    Text(event.date, style: .time).font(.caption2).foregroundStyle(.tertiary)
                                }
                            }.padding(.vertical, 5)
                        }
                    }.listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Nhật ký hoạt động")
            .toolbar { if !journal.entries.isEmpty { Button("Xóa lịch sử", role: .destructive) { journal.clear() } } }
        }
    }
}
