import SwiftUI

struct ActivityHistoryView: View {
    @ObservedObject private var journal = ActivityJournal.shared
    @State private var confirmClear = false
    private var logText: String {
        journal.entries.map { item in
            let stamp = item.date.formatted(.dateTime.year().month(.twoDigits).day(.twoDigits).hour().minute().second())
            return "[\(stamp)] [DYNOR] \(item.success ? "OK" : "ERROR") · \(item.title)\n\(item.detail)"
        }.joined(separator: "\n\n")
    }

    var body: some View {
        Group {
            if journal.entries.isEmpty {
                ContentUnavailableView("Chưa có sự kiện nào", systemImage: "clock.arrow.circlepath",
                                       description: Text("Các lần nhập và cài Tendies sẽ xuất hiện tại đây."))
            } else {
                List {
                    ForEach(journal.entries) { event in
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: event.success ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                                .font(.title3)
                                .foregroundStyle(event.success ? Color.green : Color.orange)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(event.title).font(.body.weight(.medium))
                                if !event.detail.isEmpty {
                                    Text(event.detail).font(.subheadline).foregroundStyle(.secondary)
                                }
                                Text(event.date.formatted(date: .abbreviated, time: .standard))
                                    .font(.caption).foregroundStyle(.tertiary)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
                .listStyle(.insetGrouped)
            }
        }
        .background(DynorDesign.canvas)
        .navigationTitle("Nhật ký hoạt động")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { UIPasteboard.general.string = logText } label: { Image(systemName: "doc.on.doc") }
                ShareLink(item: logText) { Image(systemName: "square.and.arrow.up") }
                Button("Xóa", role: .destructive) { confirmClear = true }.disabled(journal.entries.isEmpty)
            }
        }
        .confirmationDialog("Xóa toàn bộ nhật ký?", isPresented: $confirmClear) {
            Button("Xóa nhật ký", role: .destructive) { journal.clear() }
        }
    }
}
