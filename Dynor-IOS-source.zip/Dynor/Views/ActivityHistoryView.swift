import SwiftUI

struct ActivityHistoryView: View {
    @ObservedObject private var journal = ActivityJournal.shared
    @State private var confirmClear = false
    private var logText: String {
        journal.entries.map { item in
            let stamp = item.date.formatted(.dateTime.year().month(.twoDigits).day(.twoDigits).hour().minute().second())
            return "[\(stamp)] [DYNOR] \(item.success ? "OK" : "ERROR") · \(item.title)\n\(item.detail)"
        }.joined(separator: "\n\n")
    }
    private func eventLine(_ event: DynorActivity) -> String {
        let timestamp = event.date.formatted(date: .omitted, time: .standard)
        let status = event.success ? "OK" : "ERROR"
        return "[\(timestamp)] [DYNOR] \(status) · \(event.title)"
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Text("DYNOR / ACTIVITY LOG")
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .foregroundStyle(DynorDesign.deepYellow)
                    .padding(.bottom, 20)

                if journal.entries.isEmpty {
                    Text("[DYNOR] Chưa có sự kiện nào.\nCác lần nhập và cài Tendies sẽ xuất hiện tại đây.")
                        .foregroundStyle(.secondary).padding(20)
                } else {
                    ForEach(journal.entries) { event in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(eventLine(event))
                                .foregroundStyle(event.success ? Color.primary : Color.orange)
                            Text(event.detail).foregroundStyle(.secondary)
                        }
                        .font(.system(size: 13, design: .monospaced))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 16)
                        Divider().overlay(DynorDesign.yellow.opacity(0.35))
                    }
                }
            }.padding(.horizontal, 18)
        }
        .background(DynorDesign.canvas)
        .navigationTitle("Nhật ký hoạt động")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { UIPasteboard.general.string = logText } label: { Image(systemName: "doc.on.doc") }
                ShareLink(item: logText) { Image(systemName: "square.and.arrow.up") }
                Button("Xóa", role: .destructive) { confirmClear = true }.disabled(journal.entries.isEmpty)
            }
        }
        .confirmationDialog("Xóa toàn bộ nhật ký?", isPresented: $confirmClear) {
            Button("Xóa nhật ký", role: .destructive) { journal.clear() }
        }
    }
}
