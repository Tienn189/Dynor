import SwiftUI

struct ActivityHistoryView: View {
    @EnvironmentObject private var store: DynorStore
    @ObservedObject private var journal = ActivityJournal.shared
    @State private var confirmClear = false
    private var logText: String {
        journal.entries.map { item in
            let stamp = item.date.formatted(.dateTime.year().month(.twoDigits).day(.twoDigits).hour().minute().second())
            return "[\(stamp)] [DYNOR] \(item.success ? "OK" : "ERROR") · \(item.title)\n\(item.detail)"
        }.joined(separator: "\n\n")
    }
    private var successCount: Int { journal.entries.filter(\.success).count }
    private var failureCount: Int { journal.entries.count - successCount }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                DynorHeader(eyebrow: "Dynor · Activity",
                            title: store.localized("Nhật ký", "Activity", "活动"),
                            subtitle: store.localized("Lịch sử nhập tệp và cài hình nền.",
                                                      "History of imports and wallpaper installs.",
                                                      "导入文件和安装壁纸的记录。"))
                HStack(spacing: 12) {
                    StatTile(value: "\(journal.entries.count)", label: store.localized("Sự kiện", "Events", "事件"), symbol: "list.bullet.rectangle.fill")
                    StatTile(value: "\(successCount)", label: store.localized("Thành công", "Succeeded", "成功"), symbol: "checkmark.circle.fill")
                    StatTile(value: "\(failureCount)", label: store.localized("Lỗi", "Errors", "错误"), symbol: "exclamationmark.triangle.fill")
                }

                if journal.entries.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "terminal").font(.system(size: 34, weight: .light)).foregroundStyle(store.accentColor)
                        Text("[DYNOR] Chưa có sự kiện nào.")
                            .font(.system(size: 13, weight: .medium, design: .monospaced))
                        Text("Các lần nhập và cài Tendies sẽ xuất hiện tại đây.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .dynorGlass(radius: 28, padding: 28)
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(journal.entries) { event in entryCard(event) }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 4)
        }
        .scrollIndicators(.hidden)
        .contentMargins(.bottom, 110, for: .scrollContent)
        .background { AuroraBackground() }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { UIPasteboard.general.string = logText } label: { Image(systemName: "doc.on.doc") }
                    .disabled(journal.entries.isEmpty)
                ShareLink(item: logText) { Image(systemName: "square.and.arrow.up") }
                    .disabled(journal.entries.isEmpty)
                Button(role: .destructive) { confirmClear = true } label: { Image(systemName: "trash") }
                    .disabled(journal.entries.isEmpty)
            }
        }
        .confirmationDialog("Xóa toàn bộ nhật ký?", isPresented: $confirmClear) {
            Button("Xóa nhật ký", role: .destructive) { journal.clear() }
        }
    }

    private func entryCard(_ event: DynorActivity) -> some View {
        let tint: Color = event.success ? .green : .orange
        return HStack(alignment: .top, spacing: 14) {
            ZStack {
                Circle().fill(tint.opacity(0.16))
                Image(systemName: event.success ? "checkmark" : "exclamationmark")
                    .font(.system(size: 13, weight: .bold)).foregroundStyle(tint)
            }
            .frame(width: 34, height: 34)
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Text(event.title).font(.system(size: 15, weight: .semibold))
                    Spacer(minLength: 8)
                    Text(event.date.formatted(date: .omitted, time: .standard))
                        .font(.system(size: 11, weight: .medium, design: .monospaced))
                        .foregroundStyle(.secondary)
                }
                Text(event.detail)
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .lineSpacing(2)
                    .textSelection(.enabled)
                Text(event.date.formatted(date: .abbreviated, time: .omitted))
                    .font(.system(size: 10.5)).foregroundStyle(.tertiary)
            }
        }
        .dynorGlass(radius: 22, padding: 14)
    }
}
