import SwiftUI
import UIKit

// MARK: - Dynor "Aurora Noir" design system
// Deep ink canvas, aurora light leaks tinted by the user's accent, glass surfaces,
// serif display type and hairline gradient borders.

enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }

    private static func dyn(dark: UIColor, light: UIColor) -> Color {
        Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? dark : light })
    }

    static let canvas = dyn(dark: UIColor(red: 0.031, green: 0.031, blue: 0.055, alpha: 1),
                            light: UIColor(red: 0.957, green: 0.945, blue: 0.929, alpha: 1))
    static let surface = dyn(dark: UIColor(white: 1, alpha: 0.065), light: UIColor(white: 1, alpha: 0.80))
    static let surfaceStrong = dyn(dark: UIColor(white: 1, alpha: 0.12), light: UIColor(white: 1, alpha: 1))
    static let outline = dyn(dark: UIColor(white: 1, alpha: 0.10), light: UIColor(white: 0, alpha: 0.07))

    static let gold = LinearGradient(colors: [Color(red: 1, green: 0.86, blue: 0.45), Color(red: 0.96, green: 0.60, blue: 0.16)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing)

    static func display(_ size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .serif)
    }
}

// MARK: - Background

struct AuroraBackground: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.colorScheme) private var scheme
    var intensity: Double = 1

    var body: some View {
        let dark = scheme == .dark
        ZStack {
            DynorDesign.canvas
            RadialGradient(colors: [store.accentColor.opacity((dark ? 0.42 : 0.26) * intensity), .clear],
                           center: .topLeading, startRadius: 0, endRadius: 440)
            RadialGradient(colors: [Color(red: 0.50, green: 0.28, blue: 1.0).opacity((dark ? 0.30 : 0.16) * intensity), .clear],
                           center: .topTrailing, startRadius: 0, endRadius: 400)
            RadialGradient(colors: [Color(red: 0.10, green: 0.75, blue: 0.85).opacity((dark ? 0.16 : 0.10) * intensity), .clear],
                           center: .bottomTrailing, startRadius: 0, endRadius: 380)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

// MARK: - Glass surfaces

struct DynorGlass: ViewModifier {
    @Environment(\.colorScheme) private var scheme
    var radius: CGFloat = 24

    private var strokeColors: [Color] {
        scheme == .dark ? [Color.white.opacity(0.24), Color.white.opacity(0.04)]
                        : [Color.white, Color.black.opacity(0.05)]
    }

    func body(content: Content) -> some View {
        content
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .strokeBorder(LinearGradient(colors: strokeColors, startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(scheme == .dark ? 0 : 0.06), radius: 16, y: 8)
    }
}

extension View {
    func dynorGlass(radius: CGFloat = 24, padding: CGFloat = 18) -> some View {
        self.padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .modifier(DynorGlass(radius: radius))
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View { content.dynorGlass() }
}

struct DynorQuietAction: ViewModifier {
    func body(content: Content) -> some View {
        content.foregroundStyle(Color.primary).padding(.horizontal, 17).padding(.vertical, 12).modifier(DynorGlass(radius: 16))
    }
}

// MARK: - Buttons

struct DynorPressStyle: ButtonStyle {
    var scale: CGFloat = 0.96
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? scale : 1)
            .opacity(configuration.isPressed ? 0.92 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct DynorPrimaryButtonStyle: ButtonStyle {
    let tint: Color
    let foreground: Color
    @Environment(\.isEnabled) private var enabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .semibold))
            .foregroundStyle(foreground)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 17)
            .background(
                LinearGradient(colors: [tint.mix(with: .white, by: 0.30), tint], startPoint: .top, endPoint: .bottom),
                in: Capsule()
            )
            .overlay(Capsule().strokeBorder(Color.white.opacity(0.35), lineWidth: 0.8))
            .shadow(color: tint.opacity(enabled ? 0.45 : 0), radius: 18, y: 8)
            .opacity(enabled ? 1 : 0.45)
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct DynorGlassButtonStyle: ButtonStyle {
    var destructive = false
    @Environment(\.isEnabled) private var enabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(destructive ? Color.red : Color.primary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .background(DynorDesign.surfaceStrong, in: Capsule())
            .overlay(Capsule().strokeBorder(DynorDesign.outline, lineWidth: 1))
            .opacity(enabled ? 1 : 0.45)
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct GlassIconButton: View {
    let symbol: String
    var tint: Color? = nil
    var size: CGFloat = 44
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: size * 0.38, weight: .semibold))
                .foregroundStyle(tint ?? Color.primary)
                .frame(width: size, height: size)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().strokeBorder(DynorDesign.outline, lineWidth: 1))
        }
        .buttonStyle(DynorPressStyle())
    }
}

// MARK: - Typography blocks

struct DynorHeader<Trailing: View>: View {
    @EnvironmentObject private var store: DynorStore
    let eyebrow: String
    let title: String
    let subtitle: String
    let trailing: Trailing

    init(eyebrow: String, title: String, subtitle: String, @ViewBuilder trailing: () -> Trailing) {
        self.eyebrow = eyebrow
        self.title = title
        self.subtitle = subtitle
        self.trailing = trailing()
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            VStack(alignment: .leading, spacing: 9) {
                HStack(spacing: 8) {
                    Circle().fill(store.accentColor).frame(width: 6, height: 6)
                        .shadow(color: store.accentColor, radius: 4)
                    Text(eyebrow.uppercased())
                        .font(.system(size: 10.5, weight: .semibold, design: .monospaced))
                        .tracking(2.2)
                        .foregroundStyle(.secondary)
                }
                Text(title)
                    .font(DynorDesign.display(40))
                    .tracking(-0.8)
                    .minimumScaleFactor(0.7)
                    .lineLimit(1)
                Text(subtitle)
                    .font(.system(size: 14.5))
                    .foregroundStyle(.secondary)
                    .lineSpacing(3)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            trailing
        }
    }
}

extension DynorHeader where Trailing == EmptyView {
    init(eyebrow: String, title: String, subtitle: String) {
        self.init(eyebrow: eyebrow, title: title, subtitle: subtitle, trailing: { EmptyView() })
    }
}

/// Compatibility wrapper for older screens.
struct DynorHero: View {
    let index: String
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        DynorHeader(eyebrow: index.components(separatedBy: "/").last?.trimmingCharacters(in: .whitespaces) ?? index,
                    title: title, subtitle: subtitle) {
            Image(systemName: symbol).font(.system(size: 18, weight: .medium)).foregroundStyle(.secondary)
        }
    }
}

struct DynorSectionTitle: View {
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(title).font(DynorDesign.display(23))
            Spacer()
            Text(detail)
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .foregroundStyle(.secondary)
        }
    }
}

// MARK: - Small components

struct DynorChip: View {
    @EnvironmentObject private var store: DynorStore
    let title: String
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: selected ? .semibold : .medium))
                .foregroundStyle(selected ? store.accentTextColor : Color.primary.opacity(0.75))
                .padding(.horizontal, 17).padding(.vertical, 10)
                .background {
                    if selected {
                        Capsule().fill(LinearGradient(colors: [store.accentColor.mix(with: .white, by: 0.22), store.accentColor],
                                                      startPoint: .top, endPoint: .bottom))
                            .shadow(color: store.accentColor.opacity(0.4), radius: 10, y: 4)
                    } else {
                        Capsule().fill(DynorDesign.surface)
                            .overlay(Capsule().strokeBorder(DynorDesign.outline, lineWidth: 1))
                    }
                }
        }
        .buttonStyle(DynorPressStyle(scale: 0.94))
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: selected)
    }
}

struct DynorBadge: View {
    let text: String
    var symbol: String? = nil
    var body: some View {
        HStack(spacing: 4) {
            if let symbol { Image(systemName: symbol).font(.system(size: 9, weight: .bold)) }
            Text(text).font(.system(size: 10, weight: .bold)).tracking(0.8)
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 9).padding(.vertical, 5)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.22), lineWidth: 0.6))
        .environment(\.colorScheme, .dark)
    }
}

struct VIPBadge: View {
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: "crown.fill").font(.system(size: 9, weight: .bold))
            Text("VIP").font(.system(size: 10, weight: .heavy)).tracking(1)
        }
        .foregroundStyle(Color.black.opacity(0.85))
        .padding(.horizontal, 9).padding(.vertical, 5)
        .background(DynorDesign.gold, in: Capsule())
        .shadow(color: Color.orange.opacity(0.45), radius: 8, y: 3)
    }
}

struct StatTile: View {
    @EnvironmentObject private var store: DynorStore
    let value: String
    let label: String
    let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(store.accentColor)
            VStack(alignment: .leading, spacing: 2) {
                Text(value).font(DynorDesign.display(22)).lineLimit(1).minimumScaleFactor(0.7)
                Text(label).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
            }
        }
        .dynorGlass(radius: 20, padding: 14)
    }
}

/// Loading / failed placeholder for artwork.
struct DynorPlaceholder: View {
    @EnvironmentObject private var store: DynorStore
    var symbol: String? = nil
    var body: some View {
        ZStack {
            LinearGradient(colors: [store.accentColor.opacity(0.30), Color(red: 0.18, green: 0.14, blue: 0.40).opacity(0.55)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            if let symbol {
                Image(systemName: symbol).font(.system(size: 28, weight: .light)).foregroundStyle(.white.opacity(0.7))
            } else {
                ProgressView().tint(.white)
            }
        }
    }
}

/// Selection ring used by grids.
struct SelectionMark: View {
    @EnvironmentObject private var store: DynorStore
    let isOn: Bool
    var body: some View {
        ZStack {
            Circle().fill(isOn ? store.accentColor : Color.black.opacity(0.35))
            Circle().strokeBorder(Color.white.opacity(isOn ? 0 : 0.9), lineWidth: 1.5)
            if isOn { Image(systemName: "checkmark").font(.system(size: 12, weight: .heavy)).foregroundStyle(store.accentTextColor) }
        }
        .frame(width: 28, height: 28)
        .shadow(color: .black.opacity(0.3), radius: 4)
    }
}
