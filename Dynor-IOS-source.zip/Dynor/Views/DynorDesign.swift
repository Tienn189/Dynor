import SwiftUI
import UIKit

/// Minimal design system (V5): quiet neutral canvas, white/near-black surfaces,
/// generous continuous corners and almost no chrome. Liquid glass is untouched
/// and lives at the bottom of this file.
enum DynorRadius {
    static let card: CGFloat = 28      // grouped cards
    static let tile: CGFloat = 26      // wallpaper posters
    static let control: CGFloat = 20   // buttons, rows
    static let small: CGFloat = 14
}

enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark
        ? UIColor(red: 0.035, green: 0.035, blue: 0.043, alpha: 1)
        : UIColor(red: 0.961, green: 0.961, blue: 0.969, alpha: 1) })
    static let surface = Color(uiColor: UIColor { $0.userInterfaceStyle == .dark
        ? UIColor(red: 0.098, green: 0.098, blue: 0.110, alpha: 1)
        : UIColor.white })
    static let outline = Color(uiColor: .separator).opacity(0.12)
}

/// Quiet large title: no icons, no eyebrow, just type.
struct DynorHero: View {
    let index: String
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 34, weight: .bold))
                .tracking(-0.6)
                .foregroundStyle(.primary)
                .minimumScaleFactor(0.8)
                .lineLimit(1)
            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 10)
        .padding(.bottom, 4)
    }
}

struct DynorQuietAction: ViewModifier {
    func body(content: Content) -> some View {
        content
            .foregroundStyle(Color.primary)
            .padding(.horizontal, 18)
            .padding(.vertical, 14)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: DynorRadius.control, style: .continuous))
    }
}

/// Flat, borderless card with a whisper of shadow in light mode.
struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: DynorRadius.card, style: .continuous))
            .shadow(color: .black.opacity(0.035), radius: 14, y: 5)
    }
}

struct DynorSectionTitle: View {
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            Text(title).font(.title3.weight(.semibold)).tracking(-0.2)
            Spacer()
            Text(detail)
                .font(.footnote.weight(.medium)).monospacedDigit()
                .foregroundStyle(.secondary)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(DynorDesign.surface, in: Capsule())
        }
    }
}

// MARK: - Glass compatibility for the imported Explore layout.
// Uses the original File 1 design palette; no File 2 design tokens are imported.
struct DynorGlass: ViewModifier {
    var radius: CGFloat = 22
    @ViewBuilder func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular, in: shape)
        } else {
            content.background(.ultraThinMaterial, in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.6))
        }
    }
}

struct DynorPressStyle: ButtonStyle {
    var scale: CGFloat = 0.96
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? scale : 1)
            .animation(.spring(response: 0.28, dampingFraction: 0.82), value: configuration.isPressed)
    }
}

struct DynorGlassButtonStyle: ButtonStyle {
    var destructive = false
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(destructive ? Color.red : Color.primary)
            .frame(maxWidth: .infinity).frame(height: 50)
            .modifier(DynorGlass(radius: 18))

    }
}

struct GlassIconButton: View {
    let symbol: String
    var tint: Color? = nil
    var size: CGFloat = 44
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: size * 0.36, weight: .semibold))
                .foregroundStyle(tint ?? Color.primary)
                .frame(width: size, height: size)
                .modifier(DynorGlass(radius: size / 2))
        }
        .buttonStyle(.plain)
    }
}
