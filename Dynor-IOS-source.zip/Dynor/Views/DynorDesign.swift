import SwiftUI

/// Adaptive editorial design system. The chosen accent never recolors card borders.
enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
    static let outline = Color(uiColor: .separator).opacity(0.16)
}

/// Editorial page heading: no large white hero, brand badge or corner dot.
struct DynorHero: View {
    @EnvironmentObject private var store: DynorStore
    let index: String
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .center) {
                Text("DYNOR / " + index.components(separatedBy: "/").last!.trimmingCharacters(in: .whitespaces))
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .tracking(1.5)
                    .foregroundStyle(.secondary)
                Spacer()
                Image(systemName: symbol)
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(.secondary)
            }
            .padding(.bottom, 9)
            Text(title)
                .font(.system(size: 38, weight: .bold, design: .rounded))
                .tracking(-1.8)
                .foregroundStyle(.primary)
                .minimumScaleFactor(0.8)
            Text(subtitle)
                .font(.system(size: 14))
                .foregroundStyle(.secondary)
                .lineSpacing(3)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 13)
        .padding(.bottom, 4)
    }
}

struct DynorQuietAction: ViewModifier {
    func body(content: Content) -> some View {
        content
            .foregroundStyle(Color.primary)
            .padding(.horizontal, 17)
            .padding(.vertical, 12)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(DynorDesign.outline, lineWidth: 0.7))
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).strokeBorder(DynorDesign.outline, lineWidth: 0.8))
    }
}

struct DynorSectionTitle: View {
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(title).font(.system(size: 20, weight: .bold, design: .rounded))
            Spacer()
            Text(detail).font(.system(size: 12)).foregroundStyle(.secondary)
        }
    }
}
