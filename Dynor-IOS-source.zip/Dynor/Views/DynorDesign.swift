import SwiftUI

/// Shared adaptive design tokens. Accent is read at render time, not cached.
enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}

struct DynorHero: View {
    @EnvironmentObject private var store: DynorStore
    let index: String
    let title: String
    let subtitle: String
    let symbol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .center) {
                HStack(spacing: 12) {
                    Image(systemName: symbol)
                        .font(.system(size: 22, weight: .medium))
                        .foregroundStyle(store.accentColor)
                        .frame(width: 48, height: 48)
                        .background(store.accentColor.opacity(0.09), in: RoundedRectangle(cornerRadius: 16))
                    VStack(alignment: .leading, spacing: 3) {
                        Text("DYNOR").font(.caption.weight(.heavy)).tracking(3)
                        Text("WALLPAPER ATELIER").font(.system(size: 10, weight: .medium)).tracking(1.2)
                            .foregroundStyle(.secondary)
                    }
                }
                Spacer()
                Image(systemName: "circle.grid.2x2.fill")
                    .foregroundStyle(.secondary)
                    .frame(width: 38, height: 38)
                    .background(Color(uiColor: .tertiarySystemGroupedBackground), in: Circle())
            }
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.system(size: 42, weight: .bold, design: .rounded)).tracking(-1.8)
                Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 22)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            
            .shadow(color: .black.opacity(0.045), radius: 18, y: 8)
    }
}

struct DynorSectionTitle: View {
    @EnvironmentObject private var store: DynorStore
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Image(systemName: "circle.hexagongrid.fill").foregroundStyle(.secondary).font(.caption)
            Text(title).font(.title3.weight(.bold))
            Spacer()
            Text(detail).font(.caption).foregroundStyle(.secondary)
        }
    }
}
