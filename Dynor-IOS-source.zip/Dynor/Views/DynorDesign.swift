import SwiftUI

/// Shared adaptive design tokens. Accent is read at render time, not cached.
enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}

struct DynorHero: View {
    @EnvironmentObject private var store: DynorStore
    let index: String
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Text("DYNOR  /  STUDIO")
                    .font(.system(size: 12, weight: .black, design: .monospaced))
                    .tracking(2.8)
                Spacer()
                Image(systemName: symbol)
                    .font(.system(size: 19, weight: .medium))
                    .frame(width: 48, height: 48)
                    .background(.white.opacity(0.75), in: Circle())
            }
            Rectangle().fill(Color.primary.opacity(0.12)).frame(height: 1)
            Text(index.uppercased())
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .tracking(2.5).foregroundStyle(.secondary)
            Text(title)
                .font(.system(size: 49, weight: .black, design: .serif))
                .tracking(-2)
                .minimumScaleFactor(0.75)
            Text(subtitle).font(.system(size: 15)).foregroundStyle(.secondary)
        }
        .padding(25)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.62), in: RoundedRectangle(cornerRadius: 8))
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            
            .shadow(color: .black.opacity(0.045), radius: 18, y: 8)
    }
}

struct DynorSectionTitle: View {
    @EnvironmentObject private var store: DynorStore
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Image(systemName: "circle.hexagongrid.fill").foregroundStyle(.secondary).font(.caption)
            Text(title).font(.title3.weight(.bold))
            Spacer()
            Text(detail).font(.caption).foregroundStyle(.secondary)
        }
    }
}
