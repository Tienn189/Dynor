import SwiftUI

/// Shared adaptive design tokens. Accent is read at render time, not cached.
enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}

struct DynorHero: View {
    @EnvironmentObject private var store: DynorStore
    let index: String
    let title: String
    let subtitle: String
    let symbol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(store.accentColor)
                    .frame(width: 48, height: 48)
                    .background(store.accentColor.opacity(0.12), in: RoundedRectangle(cornerRadius: 16))
                VStack(alignment: .leading, spacing: 3) {
                    Text("DYNOR STUDIO")
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .tracking(2).foregroundStyle(store.accentColor)
                    Text(index.components(separatedBy: "/").last?.trimmingCharacters(in: .whitespaces) ?? index)
                        .font(.caption2.weight(.medium)).foregroundStyle(.secondary)
                }
                Spacer()
                Circle().fill(store.accentColor).frame(width: 9, height: 9)
                    .accessibilityLabel("Accent")
            }
            VStack(alignment: .leading, spacing: 7) {
                Text(title.replacingOccurrences(of: "\n", with: " "))
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .tracking(-0.9).fixedSize(horizontal: false, vertical: true)
                Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .fill(DynorDesign.surface)
                .overlay(alignment: .top) {
                    RoundedRectangle(cornerRadius: 3).fill(store.accentColor)
                        .frame(width: 60, height: 4).padding(.top, 0)
                }
        }
        .overlay(RoundedRectangle(cornerRadius: 26).strokeBorder(store.accentColor.opacity(0.12)))
    }
}

struct DynorSectionTitle: View {
    @EnvironmentObject private var store: DynorStore
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            RoundedRectangle(cornerRadius: 2).fill(store.accentColor).frame(width: 4, height: 19)
            Text(title).font(.title3.weight(.bold))
            Spacer()
            Text(detail).font(.caption).foregroundStyle(.secondary)
        }
    }
}
