import SwiftUI

/// Adaptive editorial design system. The chosen accent never recolors card borders.
enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
    static let outline = Color(uiColor: .separator).opacity(0.24)
}

struct DynorHero: View {
    @EnvironmentObject private var store: DynorStore
    let index: String
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 10) {
                Image(systemName: symbol)
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(store.accentColor)
                    .frame(width: 45, height: 45)
                    .background(store.accentColor.opacity(0.10), in: RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading, spacing: 4) {
                    Text("DYNOR STUDIO")
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .tracking(2.1)
                        .foregroundStyle(store.accentColor)
                    Text(index.uppercased())
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "square.grid.2x2.fill")
                    .font(.system(size: 12))
                    .foregroundStyle(.tertiary)
            }
            Rectangle().fill(DynorDesign.outline).frame(height: 1)
            Text(title)
                .font(.system(size: 33, weight: .bold, design: .rounded))
                .tracking(-1.1)
                .foregroundStyle(.primary)
                .fixedSize(horizontal: false, vertical: true)
            Text(subtitle)
                .font(.system(size: 14))
                .foregroundStyle(.secondary)
                .lineSpacing(4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(DynorDesign.outline, lineWidth: 0.8))
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(DynorDesign.outline, lineWidth: 0.8))
    }
}

struct DynorSectionTitle: View {
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(title).font(.system(size: 20, weight: .bold, design: .rounded))
            Spacer()
            Text(detail).font(.system(size: 12)).foregroundStyle(.secondary)
        }
    }
}
