import SwiftUI

/// Shared adaptive design tokens. Accent is read at render time, not cached.
enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}

struct DynorHero: View {
    @EnvironmentObject private var store: DynorStore
    let index: String
    let title: String
    let subtitle: String
    let symbol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("DYNOR  /  " + index.components(separatedBy: "/").last!.trimmingCharacters(in: .whitespaces), systemImage: symbol)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                Spacer()
                HStack(spacing: 7) {
                    Circle().fill(Color.green).frame(width: 7, height: 7)
                    Text("STUDIO").font(.caption2.weight(.bold)).tracking(1)
                }
                .padding(.horizontal, 13).padding(.vertical, 9)
                .background(.white.opacity(0.82), in: Capsule())
            }
            Text(title).font(.system(size: 37, weight: .bold, design: .rounded)).tracking(-1.4)
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 12)
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).strokeBorder(Color(uiColor: .separator).opacity(0.13), lineWidth: 0.6))
            .shadow(color: .black.opacity(0.045), radius: 18, y: 8)
    }
}

struct DynorSectionTitle: View {
    @EnvironmentObject private var store: DynorStore
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            RoundedRectangle(cornerRadius: 2).fill(store.accentColor).frame(width: 4, height: 19)
            Text(title).font(.title3.weight(.bold))
            Spacer()
            Text(detail).font(.caption).foregroundStyle(.secondary)
        }
    }
}
