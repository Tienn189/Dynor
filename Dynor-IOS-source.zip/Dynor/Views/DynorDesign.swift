import SwiftUI
import UIKit

// MARK: - Dynor "Atelier" design system
// Quiet near-black / porcelain canvas, a single soft accent glow, SF Pro typography,
// and layered liquid-glass surfaces (material + specular edge + soft depth shadow).

enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }

    private static func dyn(dark: UIColor, light: UIColor) -> Color {
        Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? dark : light })
    }

    /// App canvas. True-black-leaning in dark mode, Apple grouped grey in light mode.
    static let canvas = dyn(dark: UIColor(red: 0.020, green: 0.020, blue: 0.028, alpha: 1),
                            light: UIColor(red: 0.949, green: 0.949, blue: 0.969, alpha: 1))
    /// Tint layered on top of the glass material.
    static let surface = dyn(dark: UIColor(white: 1, alpha: 0.045), light: UIColor(white: 1, alpha: 0.55))
    static let surfaceStrong = dyn(dark: UIColor(white: 1, alpha: 0.10), light: UIColor(white: 1, alpha: 0.92))
    static let outline = dyn(dark: UIColor(white: 1, alpha: 0.09), light: UIColor(white: 0, alpha: 0.06))
    static let hairline = dyn(dark: UIColor(white: 1, alpha: 0.07), light: UIColor(white: 0, alpha: 0.08))

    static let gold = LinearGradient(colors: [Color(red: 1, green: 0.88, blue: 0.55), Color(red: 0.93, green: 0.64, blue: 0.22)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing)

    /// Specular edge used by every glass surface: bright at the top-leading corner, fading out.
    static func specular(_ scheme: ColorScheme) -> LinearGradient {
        LinearGradient(
            colors: scheme == .dark
                ? [Color.white.opacity(0.30), Color.white.opacity(0.05), Color.white.opacity(0.12)]
                : [Color.white, Color.black.opacity(0.03), Color.white.opacity(0.7)],
            startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    /// SF Pro display type. (Name kept for source compatibility with existing screens.)
    static func display(_ size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .default)
    }

    /// Rounded numerals for counters and statistics.
    static func numeral(_ size: CGFloat, weight: Font.Weight = .bold) -> Font {
        .system(size: size, weight: weight, design: .rounded)
    }
}

// MARK: - Background

/// Ambient background: one soft accent glow rising from the top edge plus a faint counter-light.
struct AuroraBackground: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.colorScheme) private var scheme
    var intensity: Double = 1

    var body: some View {
        let dark = scheme == .dark
        ZStack {
            DynorDesign.canvas
            RadialGradient(colors: [store.accentColor.opacity((dark ? 0.30 : 0.18) * intensity), .clear],
                           center: UnitPoint(x: 0.5, y: -0.05), startRadius: 0, endRadius: 520)
            RadialGradient(colors: [store.accentColor.mix(with: .purple, by: 0.55).opacity((dark ? 0.12 : 0.07) * intensity), .clear],
                           center: .bottomTrailing, startRadius: 0, endRadius: 420)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

// MARK: - Glass surfaces

struct DynorGlass: ViewModifier {
    @Environment(\.colorScheme) private var scheme
    var radius: CGFloat = 24

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        let dark = scheme == .dark
        content
            .background {
                ZStack {
                    shape.fill(.ultraThinMaterial)
                    shape.fill(DynorDesign.surface)
                    // Soft top sheen: the "lens" highlight of liquid glass.
                    shape.fill(LinearGradient(colors: [Color.white.opacity(dark ? 0.08 : 0.45), .clear],
                                              startPoint: .top, endPoint: UnitPoint(x: 0.5, y: 0.55)))
                }
            }
            .overlay(shape.strokeBorder(DynorDesign.specular(scheme), lineWidth: 0.8))
            .shadow(color: Color.black.opacity(dark ? 0.35 : 0.07), radius: 20, y: 10)
    }
}

extension View {
    func dynorGlass(radius: CGFloat = 24, padding: CGFloat = 18) -> some View {
        self.padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .modifier(DynorGlass(radius: radius))
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View { content.dynorGlass() }
}

struct DynorQuietAction: ViewModifier {
    func body(content: Content) -> some View {
        content.foregroundStyle(Color.primary).padding(.horizontal, 17).padding(.vertical, 12).modifier(DynorGlass(radius: 16))
    }
}

// MARK: - Buttons

struct DynorPressStyle: ButtonStyle {
    var scale: CGFloat = 0.96
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? scale : 1)
            .opacity(configuration.isPressed ? 0.9 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.72), value: configuration.isPressed)
    }
}

struct DynorPrimaryButtonStyle: ButtonStyle {
    let tint: Color
    let foreground: Color
    @Environment(\.isEnabled) private var enabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .semibold))
            .foregroundStyle(foreground)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background {
                ZStack {
                    Capsule().fill(LinearGradient(colors: [tint.mix(with: .white, by: 0.16), tint.mix(with: .black, by: 0.06)],
                                                  startPoint: .top, endPoint: .bottom))
                    Capsule().fill(LinearGradient(colors: [Color.white.opacity(0.28), .clear],
                                                  startPoint: .top, endPoint: UnitPoint(x: 0.5, y: 0.5)))
                }
            }
            .overlay(Capsule().strokeBorder(LinearGradient(colors: [Color.white.opacity(0.55), Color.white.opacity(0.05)],
                                                           startPoint: .top, endPoint: .bottom), lineWidth: 0.8))
            .shadow(color: tint.opacity(enabled ? 0.30 : 0), radius: 14, y: 7)
            .opacity(enabled ? 1 : 0.45)
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.72), value: configuration.isPressed)
    }
}

struct DynorGlassButtonStyle: ButtonStyle {
    var destructive = false
    @Environment(\.isEnabled) private var enabled
    @Environment(\.colorScheme) private var scheme

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15.5, weight: .semibold))
            .foregroundStyle(destructive ? Color.red : Color.primary)
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .background { ZStack { Capsule().fill(.ultraThinMaterial); Capsule().fill(DynorDesign.surface) } }
            .overlay(Capsule().strokeBorder(DynorDesign.specular(scheme), lineWidth: 0.8))
            .opacity(enabled ? 1 : 0.45)
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.72), value: configuration.isPressed)
    }
}

struct GlassIconButton: View {
    @Environment(\.colorScheme) private var scheme
    let symbol: String
    var tint: Color? = nil
    var size: CGFloat = 44
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: size * 0.36, weight: .semibold))
                .foregroundStyle(tint ?? Color.primary)
                .frame(width: size, height: size)
                .background { ZStack { Circle().fill(.ultraThinMaterial); Circle().fill(DynorDesign.surface) } }
                .overlay(Circle().strokeBorder(DynorDesign.specular(scheme), lineWidth: 0.8))
                .shadow(color: .black.opacity(scheme == .dark ? 0.3 : 0.07), radius: 10, y: 5)
        }
        .buttonStyle(DynorPressStyle())
    }
}

// MARK: - Typography blocks

/// Large-title header in the manner of Apple's own apps.
struct DynorHeader<Trailing: View>: View {
    @EnvironmentObject private var store: DynorStore
    let eyebrow: String
    let title: String
    let subtitle: String
    let trailing: Trailing

    init(eyebrow: String, title: String, subtitle: String, @ViewBuilder trailing: () -> Trailing) {
        self.eyebrow = eyebrow
        self.title = title
        self.subtitle = subtitle
        self.trailing = trailing()
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            VStack(alignment: .leading, spacing: 6) {
                Text(eyebrow.uppercased())
                    .font(.system(size: 11.5, weight: .semibold))
                    .tracking(1.4)
                    .foregroundStyle(store.accentColor)
                Text(title)
                    .font(.system(size: 38, weight: .bold))
                    .tracking(-0.9)
                    .minimumScaleFactor(0.7)
                    .lineLimit(1)
                Text(subtitle)
                    .font(.system(size: 15))
                    .foregroundStyle(.secondary)
                    .lineSpacing(2)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.top, 1)
            }
            Spacer(minLength: 0)
            trailing.padding(.top, 4)
        }
    }
}

extension DynorHeader where Trailing == EmptyView {
    init(eyebrow: String, title: String, subtitle: String) {
        self.init(eyebrow: eyebrow, title: title, subtitle: subtitle, trailing: { EmptyView() })
    }
}

/// Compatibility wrapper for older screens.
struct DynorHero: View {
    let index: String
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        DynorHeader(eyebrow: index.components(separatedBy: "/").last?.trimmingCharacters(in: .whitespaces) ?? index,
                    title: title, subtitle: subtitle) {
            Image(systemName: symbol).font(.system(size: 18, weight: .medium)).foregroundStyle(.secondary)
        }
    }
}

struct DynorSectionTitle: View {
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            Text(title).font(.system(size: 22, weight: .bold)).tracking(-0.3)
            Spacer()
            Text(detail)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(.secondary)
                .padding(.horizontal, 10).padding(.vertical, 4)
                .background(DynorDesign.surfaceStrong.opacity(0.7), in: Capsule())
                .overlay(Capsule().strokeBorder(DynorDesign.hairline, lineWidth: 0.6))
        }
    }
}

// MARK: - Small components

struct DynorChip: View {
    @Environment(\.colorScheme) private var scheme
    let title: String
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: selected ? .semibold : .medium))
                .foregroundStyle(selected ? DynorDesign.canvas : Color.primary.opacity(0.78))
                .padding(.horizontal, 16).frame(height: 38)
                .background {
                    if selected {
                        Capsule().fill(Color.primary)
                            .shadow(color: .black.opacity(scheme == .dark ? 0.3 : 0.15), radius: 8, y: 4)
                    } else {
                        ZStack { Capsule().fill(.ultraThinMaterial); Capsule().fill(DynorDesign.surface) }
                            .overlay(Capsule().strokeBorder(DynorDesign.specular(scheme), lineWidth: 0.7))
                    }
                }
        }
        .buttonStyle(DynorPressStyle(scale: 0.94))
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: selected)
    }
}

struct DynorBadge: View {
    let text: String
    var symbol: String? = nil
    var body: some View {
        HStack(spacing: 4) {
            if let symbol { Image(systemName: symbol).font(.system(size: 9, weight: .bold)) }
            Text(text).font(.system(size: 10, weight: .semibold)).tracking(0.9)
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 10).padding(.vertical, 5)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.22), lineWidth: 0.6))
        .environment(\.colorScheme, .dark)
    }
}

struct VIPBadge: View {
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: "crown.fill").font(.system(size: 9, weight: .bold))
            Text("VIP").font(.system(size: 10, weight: .heavy)).tracking(1)
        }
        .foregroundStyle(Color.black.opacity(0.85))
        .padding(.horizontal, 10).padding(.vertical, 5)
        .background(DynorDesign.gold, in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.45), lineWidth: 0.6))
        .shadow(color: Color.orange.opacity(0.35), radius: 8, y: 3)
    }
}

/// Compact metric tile: tinted icon, rounded numeral, quiet caption.
struct StatTile: View {
    @EnvironmentObject private var store: DynorStore
    let value: String
    let label: String
    let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(store.accentColor)
                .frame(width: 30, height: 30)
                .background(store.accentColor.opacity(0.15), in: Circle())
            VStack(alignment: .leading, spacing: 2) {
                Text(value).font(DynorDesign.numeral(21)).lineLimit(1).minimumScaleFactor(0.65)
                Text(label).font(.system(size: 11.5, weight: .medium)).foregroundStyle(.secondary).lineLimit(1)
            }
        }
        .dynorGlass(radius: 22, padding: 14)
    }
}

/// Floating glass caption used on top of artwork cards.
struct DynorCaption: View {
    let title: String
    let subtitle: String
    var monospacedSubtitle = false
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.system(size: 14, weight: .semibold)).lineLimit(1)
            Text(subtitle)
                .font(.system(size: 11, weight: .medium, design: monospacedSubtitle ? .monospaced : .default))
                .foregroundStyle(.white.opacity(0.72))
                .lineLimit(1)
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 13).padding(.vertical, 10)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous)
            .strokeBorder(LinearGradient(colors: [Color.white.opacity(0.35), Color.white.opacity(0.06)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.7))
        .environment(\.colorScheme, .dark)
        .padding(8)
    }
}

/// Loading / failed placeholder for artwork.
struct DynorPlaceholder: View {
    @EnvironmentObject private var store: DynorStore
    var symbol: String? = nil
    var body: some View {
        ZStack {
            LinearGradient(colors: [store.accentColor.opacity(0.28), Color(red: 0.10, green: 0.10, blue: 0.18)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            if let symbol {
                Image(systemName: symbol).font(.system(size: 28, weight: .light)).foregroundStyle(.white.opacity(0.65))
            } else {
                ProgressView().tint(.white)
            }
        }
    }
}

/// Selection ring used by grids.
struct SelectionMark: View {
    @EnvironmentObject private var store: DynorStore
    let isOn: Bool
    var body: some View {
        ZStack {
            Circle().fill(isOn ? AnyShapeStyle(store.accentColor) : AnyShapeStyle(Material.ultraThinMaterial))
            Circle().strokeBorder(Color.white.opacity(isOn ? 0.0 : 0.85), lineWidth: 1.5)
            if isOn { Image(systemName: "checkmark").font(.system(size: 12, weight: .heavy)).foregroundStyle(store.accentTextColor) }
        }
        .frame(width: 28, height: 28)
        .shadow(color: .black.opacity(0.25), radius: 4)
    }
}
