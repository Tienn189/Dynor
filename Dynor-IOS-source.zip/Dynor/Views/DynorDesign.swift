import SwiftUI

enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "yellow")?.color ?? ThemeAccent.yellow.color }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}

struct DynorHero: View {
    let index: String
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 19) {
            HStack {
                Text("DYNOR  /  " + index).font(.system(size: 11, weight: .heavy, design: .monospaced)).tracking(2)
                Spacer()
                Image(systemName: symbol).font(.title2.weight(.bold))
            }
            Spacer(minLength: 4)
            Text(title).font(.system(size: 39, weight: .black, design: .rounded)).tracking(-1.7)
                .fixedSize(horizontal: false, vertical: true)
            Text(subtitle).font(.subheadline.weight(.medium)).foregroundStyle(.black.opacity(0.7))
        }
        .foregroundStyle(.black)
        .padding(24).frame(maxWidth: .infinity, alignment: .leading)
        .frame(minHeight: 215)
        .background(DynorDesign.yellow, in: RoundedRectangle(cornerRadius: 30))
    }
}

struct DynorSectionTitle: View {
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.title3.weight(.black))
            Spacer()
            Text(detail).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
        }
    }
}
