import SwiftUI

enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? ThemeAccent.blue.color }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}

struct DynorHero: View {
    let index: String
    let title: String
    let subtitle: String
    let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text(index).font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(1.5).foregroundStyle(DynorDesign.yellow)
                Spacer()
                Image(systemName: symbol).foregroundStyle(DynorDesign.yellow)
            }
            Text(title.replacingOccurrences(of: "\n", with: " "))
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .fixedSize(horizontal: false, vertical: true)
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 12)
    }
}

struct DynorSectionTitle: View {
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.title3.weight(.black))
            Spacer()
            Text(detail).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
        }
    }
}
