import SwiftUI
import UIKit

struct ThemeColorPickerView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedColor = Color.blue

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text("Màu có sẵn").font(.headline)
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 18) {
                        ForEach(ThemeAccent.allCases.filter { $0 != .custom }) { option in
                            Button {
                                store.accent = option
                                selectedColor = option.color
                            } label: {
                                VStack(spacing: 8) {
                                    Circle().fill(option.color).frame(width: 54, height: 54)
                                        .overlay {
                                            if store.accent == option {
                                                Image(systemName: "checkmark").font(.headline.bold()).foregroundStyle(.white)
                                            }
                                        }
                                    Text(option.title).font(.caption).foregroundStyle(.primary)
                                }
                            }.buttonStyle(.plain)
                        }
                    }
                    Divider()
                    ColorPicker("Tự chọn màu", selection: $selectedColor, supportsOpacity: false)
                        .font(.headline)
                    Button("Áp dụng màu tự chọn") {
                        let color = UIColor(selectedColor)
                        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
                        color.getRed(&r, green: &g, blue: &b, alpha: &a)
                        store.customAccentHex = String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
                        store.accent = .custom
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(store.accentColor)
                    Text("Màu đã chọn áp dụng cho các thành phần nhấn của Dynor, không thay đổi màu ảnh nền.")
                        .font(.caption).foregroundStyle(.secondary)
                }.padding(20)
            }
            .navigationTitle("Màu chủ đề")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
            .onAppear { selectedColor = store.accentColor }
        }
    }
}
