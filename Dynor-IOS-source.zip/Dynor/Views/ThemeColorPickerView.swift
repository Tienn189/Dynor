import SwiftUI
import UIKit

struct ThemeColorPickerView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedColor = Color.blue

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    preview
                    Text("Màu có sẵn").font(DynorDesign.display(21))
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 20) {
                        ForEach(ThemeAccent.allCases.filter { $0 != .custom }) { option in
                            swatch(option)
                        }
                    }
                    VStack(alignment: .leading, spacing: 16) {
                        ColorPicker("Tự chọn màu", selection: $selectedColor, supportsOpacity: false)
                            .font(.system(size: 16, weight: .semibold))
                        Button("Áp dụng màu tự chọn") {
                            let color = UIColor(selectedColor)
                            var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
                            color.getRed(&r, green: &g, blue: &b, alpha: &a)
                            store.customAccentHex = String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
                            store.accent = .custom
                        }
                        .buttonStyle(DynorPrimaryButtonStyle(tint: store.accentColor, foreground: store.accentTextColor))
                    }
                    .dynorGlass(radius: 26, padding: 18)
                    Text("Màu đã chọn áp dụng cho các thành phần nhấn của Dynor, không thay đổi màu ảnh nền.")
                        .font(.system(size: 12)).foregroundStyle(.secondary)
                }
                .padding(20)
            }
            .scrollIndicators(.hidden)
            .background { AuroraBackground() }
            .navigationTitle("Màu chủ đề")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
            .onAppear { selectedColor = store.accentColor }
        }
    }

    private var preview: some View {
        HStack(spacing: 14) {
            Image(systemName: "sparkles")
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(store.accentTextColor)
                .frame(width: 52, height: 52)
                .background(LinearGradient(colors: [store.accentColor.mix(with: .white, by: 0.25), store.accentColor],
                                           startPoint: .top, endPoint: .bottom), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                .shadow(color: store.accentColor.opacity(0.5), radius: 14, y: 6)
            VStack(alignment: .leading, spacing: 4) {
                Text("Xem trước").font(DynorDesign.display(20))
                Text("Nút, thẻ chọn và điểm nhấn sẽ dùng màu này.")
                    .font(.system(size: 12.5)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
        .dynorGlass(radius: 28, padding: 16)
    }

    private func swatch(_ option: ThemeAccent) -> some View {
        let on = store.accent == option
        return Button {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                store.accent = option
                selectedColor = option.color
            }
        } label: {
            VStack(spacing: 9) {
                Circle()
                    .fill(LinearGradient(colors: [option.color.mix(with: .white, by: 0.3), option.color],
                                         startPoint: .top, endPoint: .bottom))
                    .frame(width: 54, height: 54)
                    .overlay(Circle().strokeBorder(Color.white.opacity(0.35), lineWidth: 1))
                    .overlay {
                        if on {
                            Image(systemName: "checkmark").font(.system(size: 16, weight: .heavy)).foregroundStyle(.white)
                        }
                    }
                    .padding(4)
                    .overlay(Circle().strokeBorder(on ? option.color : Color.clear, lineWidth: 2))
                    .shadow(color: option.color.opacity(on ? 0.55 : 0.25), radius: on ? 12 : 6, y: 4)
                Text(option.title).font(.system(size: 12, weight: on ? .semibold : .regular)).foregroundStyle(.primary)
            }
        }
        .buttonStyle(DynorPressStyle(scale: 0.92))
    }
}
