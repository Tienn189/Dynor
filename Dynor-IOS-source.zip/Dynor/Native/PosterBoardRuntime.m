#import "PosterBoardRuntime.h"
#import <Security/Security.h>
#import <objc/message.h>
#include <dlfcn.h>

NSArray<NSString *> *dynor_signed_app_groups(void) {
    // SecTask's declarations are absent from the public iOS SDK. Resolve only
    // these two read-only entitlement functions and fail closed if unavailable.
    typedef CFTypeRef (*CreateTask)(CFAllocatorRef);
    typedef CFTypeRef (*CopyEntitlement)(CFTypeRef, CFStringRef, CFErrorRef *);
    CreateTask createTask = (CreateTask)dlsym(RTLD_DEFAULT, "SecTaskCreateFromSelf");
    CopyEntitlement copyEntitlement = (CopyEntitlement)dlsym(RTLD_DEFAULT, "SecTaskCopyValueForEntitlement");
    if (!createTask || !copyEntitlement) return nil;
    CFTypeRef task = createTask(kCFAllocatorDefault);
    if (!task) return nil;
    CFTypeRef value = copyEntitlement(task, CFSTR("com.apple.security.application-groups"), NULL);
    CFRelease(task);
    if (!value) return nil;
    id result = CFBridgingRelease(value);
    if (![result isKindOfClass:[NSArray class]]) return nil;
    for (id entry in result) {
        if (![entry isKindOfClass:[NSString class]]) return nil;
    }
    return result;
}

NSString *dynor_posterboard_container_hint(void) {
    Class proxyClass = NSClassFromString(@"LSApplicationProxy");
    SEL lookup = NSSelectorFromString(@"applicationProxyForIdentifier:");
    SEL container = NSSelectorFromString(@"dataContainerURL");
    if (!proxyClass || ![proxyClass respondsToSelector:lookup]) return nil;
    id proxy = ((id (*)(id, SEL, NSString *))objc_msgSend)(proxyClass, lookup, @"com.apple.PosterBoard");
    if (!proxy || ![proxy respondsToSelector:container]) return nil;
    id url = ((id (*)(id, SEL))objc_msgSend)(proxy, container);
    return [url isKindOfClass:[NSURL class]] ? [url path] : nil;
}

BOOL dynor_open_posterboard(void) {
    if (![NSThread isMainThread]) return NO;
    Class workspaceClass = NSClassFromString(@"LSApplicationWorkspace");
    SEL shared = NSSelectorFromString(@"defaultWorkspace");
    SEL open = NSSelectorFromString(@"openApplicationWithBundleID:");
    if (!workspaceClass || ![workspaceClass respondsToSelector:shared]) return NO;
    id workspace = ((id (*)(id, SEL))objc_msgSend)(workspaceClass, shared);
    if (!workspace || ![workspace respondsToSelector:open]) return NO;
    return ((BOOL (*)(id, SEL, NSString *))objc_msgSend)(workspace, open, @"com.apple.PosterBoard");
}
