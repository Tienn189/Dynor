#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/// Reads this process's signed App Group entitlement, not the source plist.
NSArray<NSString *> * _Nullable dynor_signed_app_groups(void);
/// Discovery hint only; callers must verify the container's on-disk identity.
NSString * _Nullable dynor_posterboard_container_hint(void);
/// Must be called on the main thread. Returns the workspace API's BOOL result.
BOOL dynor_open_posterboard(void);
NS_ASSUME_NONNULL_END
