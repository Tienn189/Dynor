# Dynor App Group diagnostics

This build distinguishes missing runtime App Group entitlements, unavailable group container URL, and failed write/read probe. The probe is temporary and is removed.

Build and sign with LCSign, then open PosterBoard and capture the exact new message. A successful probe only confirms App Group storage, not PosterBoard access or wallpaper installation.

Bundle ID remains com.dynor.wallpapers. App Group remains group.3fae94347e97b250.4.
