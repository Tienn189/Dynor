import SwiftUI

/// Shared adaptive design tokens. Accent is read at render time, not cached.
enum DynorDesign {
    static var yellow: Color { ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "blue")?.color ?? .blue }
    static var deepYellow: Color { yellow }
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let outline = Color(uiColor: .separator).opacity(0.22)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}

struct DynorHero: View {
    @EnvironmentObject private var store: DynorStore
    let index: String
    let title: String
    let subtitle: String
    let symbol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(spacing: 9) {
                Circle().fill(store.accentColor).frame(width: 7, height: 7)
                Text(index.uppercased())
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .tracking(1.7).foregroundStyle(.secondary)
                Spacer()
                Image(systemName: symbol)
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(store.accentColor)
                    .frame(width: 46, height: 46)
                    .background(store.accentColor.opacity(0.10), in: RoundedRectangle(cornerRadius: 15))
            }
            VStack(alignment: .leading, spacing: 9) {
                Text(title)
                    .font(.system(size: 33, weight: .bold, design: .rounded))
                    .tracking(-1.1).foregroundStyle(.primary)
                    .fixedSize(horizontal: false, vertical: true)
                Text(subtitle).font(.system(size: 14))
                    .foregroundStyle(.secondary).lineSpacing(3)
                    .fixedSize(horizontal: false, vertical: true)
            }
            HStack(spacing: 5) {
                Capsule().fill(store.accentColor).frame(width: 27, height: 3)
                Capsule().fill(store.accentColor.opacity(0.25)).frame(width: 10, height: 3)
                Capsule().fill(store.accentColor.opacity(0.12)).frame(width: 10, height: 3)
            }.accessibilityHidden(true)
        }
        .padding(22).frame(maxWidth: .infinity, alignment: .leading)
        .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous)
            .strokeBorder(DynorDesign.outline, lineWidth: 1))
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(19)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 21, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 21).strokeBorder(DynorDesign.outline, lineWidth: 1))
    }
}

struct DynorSectionTitle: View {
    @EnvironmentObject private var store: DynorStore
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Image(systemName: "circle.hexagongrid.fill").foregroundStyle(.secondary).font(.caption)
            Text(title).font(.title3.weight(.bold))
            Spacer()
            Text(detail).font(.caption).foregroundStyle(.secondary)
        }
    }
}
