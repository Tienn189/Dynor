// Deterministic TEST ONLY material. This is never used by the web app.
import { createCipheriv, createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const packageId = '01234567-89ab-4cde-8fab-0123456789ab';
const key = Buffer.from(Array.from({ length: 32 }, (_, i) => i));
const nonce = Buffer.from(Array.from({ length: 12 }, (_, i) => 0xa0 + i));
const header = Buffer.concat([Buffer.from('DYNORT01', 'ascii'), Buffer.from(packageId.replaceAll('-', ''), 'hex')]);
const plaintext = Buffer.from(readFileSync(new URL('./fixture-plaintext.base64', import.meta.url), 'utf8').trim(), 'base64');
const cipher = createCipheriv('aes-256-gcm', key, nonce);
cipher.setAAD(header);
const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
const encrypted = Buffer.concat([header, nonce, ciphertext, cipher.getAuthTag()]);
const fixture = {
  purpose: 'TEST ONLY: publicly known deterministic interop vector; never use this key or nonce in production',
  format: 'Dynor encrypted Tendies v1',
  package_id: packageId,
  key_base64: key.toString('base64'),
  nonce_base64: nonce.toString('base64'),
  header_hex: header.toString('hex'),
  plaintext_base64: plaintext.toString('base64'),
  encrypted_base64: encrypted.toString('base64'),
  sha256: createHash('sha256').update(encrypted).digest('hex'),
};
writeFileSync(new URL('./interop-v1.json', import.meta.url), `${JSON.stringify(fixture, null, 2)}\n`);
console.log('Wrote independent OpenSSL AES-GCM interop fixture.');
