import test from 'node:test';
import assert from 'node:assert/strict';
import { webcrypto, createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import {
  MAGIC,
  MAX_TENDIES_BYTES,
  buildHeader,
  encryptTendies,
  outputFilename,
  validateTendiesFile,
} from '../dist/crypto.mjs';

const fixture = JSON.parse(readFileSync(new URL('./interop-v1.json', import.meta.url), 'utf8'));
const fromBase64 = value => new Uint8Array(Buffer.from(value, 'base64'));
const plaintext = fromBase64(fixture.plaintext_base64);
const fixedOptions = () => ({
  packageId: fixture.package_id,
  keyBytes: fromBase64(fixture.key_base64),
  nonce: fromBase64(fixture.nonce_base64),
});

async function decryptEnvelope(encrypted, keyBytes = fromBase64(fixture.key_base64)) {
  const key = await webcrypto.subtle.importKey('raw', keyBytes, { name: 'AES-GCM' }, false, ['decrypt']);
  return new Uint8Array(await webcrypto.subtle.decrypt({
    name: 'AES-GCM',
    iv: encrypted.subarray(24, 36),
    additionalData: encrypted.subarray(0, 24),
    tagLength: 128,
  }, key, encrypted.subarray(36)));
}

test('header carries the exact magic and RFC 4122 UUID bytes', () => {
  assert.equal(MAGIC, 'DYNORT01');
  const header = buildHeader(fixture.package_id);
  assert.equal(header.byteLength, 24);
  assert.equal(Buffer.from(header).toString('hex'), fixture.header_hex);
  assert.deepEqual(buildHeader(fixture.package_id.toUpperCase()), header);
  for (const invalid of ['', 'abc', '../01234567-89ab-4cde-8fab-0123456789ab', '0123456789ab4cde8fab0123456789ab', 'g1234567-89ab-4cde-8fab-0123456789ab']) {
    assert.throws(() => buildHeader(invalid));
  }
});

test('file selection accepts only nonempty .tendies files within the configured limit', () => {
  assert.equal(MAX_TENDIES_BYTES, 50 * 1024 * 1024);
  assert.doesNotThrow(() => validateTendiesFile({ name: 'Batman.TENDIES', size: plaintext.length }));
  assert.doesNotThrow(() => validateTendiesFile({ name: 'Đồi cát.tendies', size: MAX_TENDIES_BYTES }));
  for (const file of [
    { name: 'Batman.zip', size: 100 },
    { name: 'Batman.tendies.exe', size: 100 },
    { name: 'Batman.tendies', size: 0 },
    { name: 'Batman.tendies', size: MAX_TENDIES_BYTES + 1 },
    { name: '.tendies', size: 100 },
    { name: ' Batman.tendies', size: 100 },
    { name: '../Batman.tendies', size: 100 },
    { name: 'folder\\Batman.tendies', size: 100 },
    { name: 'Batman\n.tendies', size: 100 },
  ]) {
    assert.throws(() => validateTendiesFile(file));
  }
});

test('encrypted bytes match an independently generated OpenSSL AES-256-GCM vector', async () => {
  const result = await encryptTendies(plaintext, fixedOptions());
  assert.equal(result.packageId, fixture.package_id);
  assert.equal(result.bytes.length, plaintext.length + 52);
  assert.equal(Buffer.from(result.bytes).toString('base64'), fixture.encrypted_base64);
  assert.equal(result.sha256, fixture.sha256);
  assert.equal(result.sha256, createHash('sha256').update(result.bytes).digest('hex'));
  assert.deepEqual(await decryptEnvelope(result.bytes), plaintext);
});

test('changing the package identifier, nonce, ciphertext, or tag fails authentication', async () => {
  const { bytes } = await encryptTendies(plaintext, fixedOptions());
  // Includes AAD, nonce, encrypted payload, and authentication tag.
  for (const position of [8, 24, 36, bytes.length - 1]) {
    const tampered = Uint8Array.from(bytes);
    tampered[position] ^= 0x01;
    await assert.rejects(() => decryptEnvelope(tampered));
  }
});

test('a different content key cannot decrypt a package', async () => {
  const { bytes } = await encryptTendies(plaintext, fixedOptions());
  const wrongKey = fromBase64(fixture.key_base64);
  wrongKey[0] ^= 1;
  await assert.rejects(() => decryptEnvelope(bytes, wrongKey));
});

test('ordinary encryption creates independent package IDs, nonces, and content keys', async () => {
  const first = await encryptTendies(plaintext);
  const second = await encryptTendies(plaintext);
  assert.notEqual(first.packageId, second.packageId);
  assert.match(first.packageId, /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);
  assert.notDeepEqual(first.bytes.subarray(24, 36), second.bytes.subarray(24, 36));
  assert.notDeepEqual(first.keyBytes, second.keyBytes);
  assert.equal(first.keyBytes.length, 32);
  assert.deepEqual(await decryptEnvelope(first.bytes, first.keyBytes), plaintext);
  assert.deepEqual(await decryptEnvelope(second.bytes, second.keyBytes), plaintext);
});

test('invalid content and excessive input sizes fail before encryption', async () => {
  for (const invalid of [new Uint8Array(), new Uint8Array([0x50, 0x4b, 0x03]), new TextEncoder().encode('not a ZIP archive')]) {
    await assert.rejects(() => encryptTendies(invalid));
  }
  const excessive = new Uint8Array(MAX_TENDIES_BYTES + 1);
  excessive.set([0x50, 0x4b, 0x03, 0x04]);
  await assert.rejects(() => encryptTendies(excessive));
});

test('both local-header and empty-archive ZIP signatures can be encrypted', async () => {
  for (const prefix of [[0x50, 0x4b, 0x03, 0x04], [0x50, 0x4b, 0x05, 0x06]]) {
    const body = Uint8Array.from([...prefix, 0, 0, 0, 0]);
    const result = await encryptTendies(body, fixedOptions());
    assert.deepEqual(await decryptEnvelope(result.bytes), body);
  }
});

test('encrypted downloads have .dynor names without changing the original stem', () => {
  assert.equal(outputFilename('Batman.TENDIES'), 'Batman.dynor');
  assert.equal(outputFilename('Đồi cát.tendies'), 'Đồi cát.dynor');
});
