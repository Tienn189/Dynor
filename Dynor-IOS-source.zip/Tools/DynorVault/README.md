# Dynor Vault

Công cụ web mã hóa `.tendies` thành `.dynor`. Mở bản hosted tại https://dynor-vault.amberstingray1.chatgpt.site hoặc phục vụ thư mục `dist/` qua HTTPS. Cần triển khai SQL và Edge Functions theo `../../ENCRYPTED_TENDIES_SETUP.md` trước khi đăng ký gói. Không có khóa nội dung hoặc KEK production trong source.

Kiểm tra JavaScript: `npm run check`. Kiểm thử crypto: `node --test --test-isolation=none tests/*.test.mjs` (Node 24). Fixture trong `tests/` chứa khóa công khai chỉ dành cho kiểm thử.
