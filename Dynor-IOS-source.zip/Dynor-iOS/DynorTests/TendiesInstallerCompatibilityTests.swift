import Foundation
import XCTest
@testable import Dynor

final class TendiesInstallerCompatibilityTests: XCTestCase {
    func testUpstreamRangeIncludesIOS266() {
        for (major, minor, patch) in [(26, 0, 0), (26, 6, 0), (26, 6, 1), (26, 7, 2), (27, 0, 0), (27, 1, 0), (27, 2, 0)] {
            let version = OperatingSystemVersion(majorVersion: major, minorVersion: minor, patchVersion: patch)
            XCTAssertNil(TendiesInstaller.supportWarning(for: version), "iOS \(major).\(minor).\(patch)")
        }
    }

    func testOldBackendRangeAndUnknownFutureBuildsAreBlocked() {
        for (major, minor, patch) in [(17, 0, 0), (26, 7, 3), (26, 8, 0), (27, 2, 1), (27, 3, 0), (28, 0, 0)] {
            let version = OperatingSystemVersion(majorVersion: major, minorVersion: minor, patchVersion: patch)
            XCTAssertNotNil(TendiesInstaller.supportWarning(for: version), "iOS \(major).\(minor).\(patch)")
            XCTAssertFalse(TendiesCompatibility.assess(version: version).canAttemptInstall)
        }
    }
}
