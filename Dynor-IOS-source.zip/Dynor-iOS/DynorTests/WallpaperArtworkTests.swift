import XCTest
import UIKit
@testable import Dynor

final class WallpaperArtworkTests: XCTestCase {
    // A real ZIP containing a small blue PNG; no keys or account are needed.
    private let archiveBase64 = "UEsDBBQAAAAAAFYwdV12t/UNTQAAAE0AAAALAAAAcHJldmlldy5wbmeJUE5HDQoaCgAAAA1JSERSAAAABAAAAAYIAgAAAGtbqCIAAAAUSURBVHicY2So+s8AA0wMSIAcDgBxDwGFV6LoGwAAAABJRU5ErkJgglBLAQIUAxQAAAAAAFYwdV12t/UNTQAAAE0AAAALAAAAAAAAAAAAAACAAQAAAABwcmV2aWV3LnBuZ1BLBQYAAAAAAQABADkAAAB2AAAAAAA="

    func testLegacyEncryptedLibraryRecordsDecodeWithoutPreviewMetadata() throws {
        let id = UUID()
        let legacy: [String: Any] = ["id": id.uuidString, "displayName": "Example.dynor",
            "storedFilename": id.uuidString + ".dynor", "kind": "encryptedTendies",
            "addedAt": 0, "byteCount": 2048]
        let record = try JSONDecoder().decode(ImportedWallpaper.self, from: JSONSerialization.data(withJSONObject: legacy))
        XCTAssertEqual(record.id, id)
        XCTAssertEqual(record.kind, .encryptedTendies)
        XCTAssertNil(record.previewURL)
        var updated = record
        updated.previewURL = URL(string: "https://example.com/cover.jpg")
        let restored = try JSONDecoder().decode(ImportedWallpaper.self, from: JSONEncoder().encode(updated))
        XCTAssertEqual(restored.previewURL, updated.previewURL)
        XCTAssertEqual(restored.storedFilename, record.storedFilename)
    }

    func testEncryptedPreviewCoalescesLoadsAndRemovesDecryptedWorkspace() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let staging = root.appendingPathComponent("decrypted")
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
        let archive = staging.appendingPathComponent("source.tendies")
        try XCTUnwrap(Data(base64Encoded: archiveBase64)).write(to: archive)
        let original = root.appendingPathComponent("wallpaper.dynor")
        let encryptedBytes = Data("original encrypted bytes".utf8)
        try encryptedBytes.write(to: original)
        let counter = RequestCounter()
        let loader = WallpaperArtworkLoader(prepareEncrypted: { _ in
            await counter.increment()
            await Task.yield()
            return PreparedEncryptedTendies(url: archive, directory: staging)
        })
        async let first = loader.artwork(at: original, encrypted: true, previewURL: nil)
        async let second = loader.artwork(at: original, encrypted: true, previewURL: nil)
        let (a, b) = try await (first, second)
        XCTAssertEqual(a, b)
        XCTAssertNotNil(UIImage(data: a))
        let requests = await counter.count
        XCTAssertEqual(requests, 1)
        XCTAssertFalse(FileManager.default.fileExists(atPath: staging.path))
        XCTAssertEqual(try Data(contentsOf: original), encryptedBytes)
        // The preview remains available after the decrypted archive has been removed.
        let cached = try await loader.artwork(at: original, encrypted: true, previewURL: nil)
        XCTAssertEqual(cached, a)
    }

    func testInvalidDecryptedArchiveStillRemovesWorkspace() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let staging = root.appendingPathComponent("decrypted")
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
        let archive = staging.appendingPathComponent("source.tendies")
        try Data("invalid archive".utf8).write(to: archive)
        let loader = WallpaperArtworkLoader(prepareEncrypted: { _ in
            PreparedEncryptedTendies(url: archive, directory: staging)
        })
        do {
            _ = try await loader.artwork(at: root.appendingPathComponent("bad.dynor"), encrypted: true, previewURL: nil)
            XCTFail("Invalid archives must not produce a preview")
        } catch {
            XCTAssertFalse(FileManager.default.fileExists(atPath: staging.path))
        }
    }
}

private actor RequestCounter {
    private(set) var count = 0
    func increment() { count += 1 }
}
