# Apple-style UI refresh

Chỉ thay đổi giao diện (SwiftUI views). Không đụng logic, tài khoản, cài đặt PosterBoard, ký IPA.

Giữ nguyên Liquid Glass: DynorGlass (glassEffect iOS 26 / ultraThinMaterial), GlassIconButton,
DynorGlassButtonStyle, các material của sheet chi tiết, VIP card, thanh tab.

Đã đổi: large title kiểu Apple, font hệ thống (bỏ rounded / tracking / chữ mono / eyebrow),
thẻ phẳng bo continuous 20pt không viền, chip dạng capsule, lưới 2 cột + tên dưới ảnh,
segmented Picker cho Sleep/Locked/Unlock, nhật ký hoạt động dạng danh sách inset grouped,
tab bar dùng màu nhấn.
Chưa build được trên Xcode trong môi trường này — hãy build qua Codemagic và gửi lỗi nếu có.
