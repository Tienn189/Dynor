# worse_query native dependency

The four files in `Dynor/Native` are vendored unchanged from
[forcequitOS/worse_query](https://github.com/forcequitOS/worse_query/tree/d1540e20cd82b974d891e0551ced6d6aeb570ac2),
revision `d1540e20cd82b974d891e0551ced6d6aeb570ac2` (GPL-3.0-or-later).
The license, original README and per-file SHA-256 pins are in this directory.

`scripts/verify_dependencies.py` verifies these files before XcodeGen generates the
project. They compile from source with the iOS SDK; no worse_query binary or
Swift package download is required. `Dynor-Prefix.pch` supplies standard C
declarations without changing the upstream files. Dynor-specific access and
installation code lives separately in `Dynor/Services`.

The upstream PoC declares iOS 26.0–26.7.2 and iOS 27.0–27.2.0 as target
ranges. Dynor gates automatic use to those versions; this is not a guarantee of
success on every device/build. Runtime behavior must be verified on the physical
target iPhone.

This mechanism requires a real, provisioned App Group controlled by the signing
team. Merely inserting the entitlement in an IPA does not authorize it. The
default group is `group.3fae94347e97b250.4`, configured by
`DYNOR_APP_GROUP_IDENTIFIER`; the application bundle ID remains
`com.dynor.wallpapers`. `scripts/verify_signed_app.py` checks both the signed
entitlement and provisioning profile after signing. Runtime access still needs
verification on the physical target iPhone.

No AirliftFFI binary, Rust toolchain, Swift package, pairing record or companion
app is required by this integration.
