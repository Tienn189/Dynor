# Dynor — iOS UI / Liquid Glass / Blue

Cập nhật 21/11/2026 theo phản hồi của người dùng.

## Giao diện

- Một kiểu chữ hệ thống San Francisco, dùng text style native để hỗ trợ Dynamic Type.
- Bỏ serif, tiêu đề trang trí, nền kem và bố cục Studio.
- Thanh tab, navigation title, thanh tìm kiếm, grouped settings và color picker dùng thành phần SwiftUI native.
- Nút nổi dùng Liquid Glass thực trên iOS 26+ (`glassEffect`, `glass`, `glassProminent`).
  iOS 18–25 dùng material và nút hệ thống tương thích; giữ deployment target iOS 18.
- Màu chủ đề mặc định là system blue. Lần đầu mở bản này đặt màu nhấn về xanh dương;
  những lần sau giữ lựa chọn tùy chỉnh của người dùng.
- Màn Màu chủ đề chỉ có Custom color. Không còn swatch hoặc bảng màu mẫu.
  Chọn màu rồi bấm Xong để áp dụng, hoặc Hủy để giữ màu cũ.
- Hỗ trợ dark mode và Reduce Transparency. Ảnh hình nền giữ màu gốc.

Các tab Khám phá, Bộ sưu tập, Đã cài và Cài đặt được làm gọn; giữ đầy đủ
nhập/tải/yêu thích, xem trước/cài/gỡ hình nền, tài khoản và VIP/thanh toán.

## Chỉnh sửa theo ảnh phản hồi

- Bỏ hoàn toàn mục Nổi bật ở Khám phá; giữ danh sách Mới nhất và bộ lọc.
- Bộ sưu tập dùng nút Chọn/Xong trực tiếp, cùng kiểu với tab Đã cài.
  Chọn tất cả và xóa vẫn có trong chế độ chọn.
- Tab Đã cài không gắn dấu tích xanh khi đang xem bình thường.
  Trong chế độ chọn, chỉ mục được chọn mới có dấu tích; mục chưa chọn có vòng tròn rỗng.

## Ảnh xem trước và video (v3)

- Bỏ bộ chọn Sleep/Locked/Unlock và mô phỏng đồng hồ; trang chi tiết chỉ hiển thị ảnh.
- Gói tải từ Khám phá lưu URL ảnh bìa cùng bản ghi trong Bộ sưu tập.
- Gói .dynor nhập từ Tệp có thể đọc ảnh bằng luồng cấp quyền/giải mã hiện có.
  Cần đăng nhập, Internet và quyền mở gói ở lần đọc ảnh đầu tiên nếu chưa có ảnh bìa.
  Gói không chứa ảnh hợp lệ sẽ hiển thị trạng thái không có ảnh xem trước.
- Chỉ cache JPEG thu nhỏ (tối đa 1200px); dọn gói giải mã và thư mục giải nén sau khi đọc,
  cả khi lỗi. Gộp các yêu cầu đồng thời cho cùng tệp; không sửa hoặc xuất gói nguồn.
- Nút yêu thích trên thẻ ảnh nhỏ từ 44 xuống 38pt, vẫn giữ vùng chạm 44pt.
- Hình nền có video xuất hiện nút Play góc trên trái ở danh sách Khám phá.
  Chạm để phát video ngay trong trình xem, không cần mở chi tiết. Video dừng khi đóng.
  Nhãn VIP chuyển xuống góc dưới trái để không che nút Play.

## Kiểm tra

- Parse 34 tệp Swift bằng tree-sitter-swift: không lỗi cú pháp.
- Thêm XCTest cho tương thích bản ghi thư viện cũ, lưu URL ảnh bìa,
  gộp yêu cầu ảnh mã hóa, giữ nguyên tệp nguồn và dọn workspace khi thành công/thất bại.
- Fixture ZIP/PNG của các test được kiểm tra CRC và giải mã ảnh bằng Python.
- Giữ nguyên dịch vụ cấp khóa, định dạng mã hóa, installer và quyền tài khoản/VIP.
- Chưa chạy XCTest, biên dịch SwiftUI hoặc xác nhận hiển thị/phát video trên iPhone:
  môi trường Linux không có Xcode/iOS SDK. Parse cú pháp không phải type-check.

## Build

Cần Mac có Xcode 26+ với iOS SDK 26+ và XcodeGen. Runtime tối thiểu của app
vẫn là iOS 18. Xem `BUILD_IPA.md` và `GITHUB_ACTIONS.md`.

```sh
bash scripts/build_ipa.sh
```
