# Dynor — iOS UI / Liquid Glass / Blue

Cập nhật 21/11/2026 theo phản hồi của người dùng.

## Giao diện

- Một kiểu chữ hệ thống San Francisco, dùng text style native để hỗ trợ Dynamic Type.
- Bỏ serif, tiêu đề trang trí, nền kem và bố cục Studio.
- Thanh tab, navigation title, thanh tìm kiếm, grouped settings và color picker dùng thành phần SwiftUI native.
- Nút nổi dùng Liquid Glass thực trên iOS 26+ (`glassEffect`, `glass`, `glassProminent`).
  iOS 18–25 dùng material và nút hệ thống tương thích; giữ deployment target iOS 18.
- Màu chủ đề mặc định là system blue. Lần đầu mở bản này đặt màu nhấn về xanh dương;
  những lần sau giữ lựa chọn tùy chỉnh của người dùng.
- Màn Màu chủ đề chỉ có Custom color. Không còn swatch hoặc bảng màu mẫu.
  Chọn màu rồi bấm Xong để áp dụng, hoặc Hủy để giữ màu cũ.
- Hỗ trợ dark mode và Reduce Transparency. Ảnh hình nền giữ màu gốc.

Các tab Khám phá, Bộ sưu tập, Đã cài và Cài đặt được làm gọn; giữ đầy đủ
nhập/tải/yêu thích, xem trước/cài/gỡ hình nền, tài khoản và VIP/thanh toán.

## Kiểm tra

- Parse toàn bộ 32 tệp Swift bằng tree-sitter-swift: không lỗi cú pháp.
- Đối chiếu với ZIP nguồn: dịch vụ, model gallery và các hàm xử lý nhập/tải,
  cài/gỡ, đăng nhập và thanh toán giữ nguyên. Store chỉ đổi phần giao diện/màu.
- Source dịch vụ và XCTest giữ nguyên. Các kiểm tra dependency/Python/Node đã đạt
  ở lần rà soát trước; không có thay đổi backend trong lần chỉnh này.
- Chưa biên dịch SwiftUI, chạy XCTest hoặc xác nhận hiển thị trên simulator/iPhone:
  môi trường Linux không có Xcode/iOS SDK. Parse cú pháp không phải type-check.

## Build

Cần Mac có Xcode 26+ với iOS SDK 26+ và XcodeGen. Runtime tối thiểu của app
vẫn là iOS 18. Xem `BUILD_IPA.md` và `GITHUB_ACTIONS.md`.

```sh
bash scripts/build_ipa.sh
```
