# Dynor Studio Multi-layer update

Added PhotosPicker multi-selection (up to 20 images), image layers, one-finger drag, pinch scale, two-finger rotation, visibility, lock, duplicate, reorder and image rendering in PNG export. Images are resized to maximum 1800 pixels on import to reduce memory pressure.

This is not the CAPlayground rendering engine or its project format. Animation timeline, video layers, real Liquid Glass and PosterBoard installation are not implemented. Build and on-device testing still required.
