# Cập nhật quyền tải và biểu tượng

- Free: biểu tượng tải xuống trước chữ tải ở thẻ và màn hình chi tiết.
- Thẻ tuần 💎: Premium không giới hạn khi còn hạn; không tải Crown, không cộng lượt Crown.
- Thẻ tháng 💎 👑: Premium và 5 lượt Crown; 3 tháng 💎 👑: Premium và 10 lượt Crown.
- Giữ màu hồng mặc định theo icon ở bản trước.

## Triển khai

1. Với máy chủ đã có hệ thống lượt tải cộng dồn: chạy Supabase/sql/20261123_week_premium_only.sql trong SQL Editor. File này cập nhật hàm kiểm tra quyền, tính lượt và thanh toán; không xóa lịch sử tải. Nếu chưa có các bảng lượt tải, chạy vip_download_quota.sql trước.
2. Deploy lại Edge Function dynor-wallpaper-download bằng Supabase/dynor-wallpaper-download/index.ts. File cũng đã sửa regex UUID.
3. Build lại IPA từ source này và cài bản mới để thấy biểu tượng và nội dung gói.

Các lượt Crown từ đơn tuần cũ không còn được tính. Lượt đã dùng vẫn được giữ để không hoàn lượt đã tiêu. Quyền Crown dựa trên plan_id đang lưu trong dynor_vip; hệ thống thanh toán hiện dùng gói mua gần nhất và cộng dồn ngày hết hạn (không chia kỳ theo từng gói).

Chưa build iOS hoặc chạy migration trên máy chủ thật trong môi trường này.
