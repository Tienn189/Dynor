# Dynor Studio – initial integration

This change adds a new native SwiftUI Studio tab to Dynor. It can import a photo, overlay text, choose a gradient, adjust text size and placement, and export a static 1170×2535 wallpaper through the iOS share sheet.

This is **not** an integration of the CAPlayground engine. CAPlayground animation formats, 3D/gyro layers, timelines, project import/export, and PosterBoard installation require a separate technical and licensing review. No CAPlayground code was copied into this build.

Existing authentication, VIP, App Group and PosterBoard installer code was left unchanged. This project has not been compiled on macOS/Xcode in this environment.
