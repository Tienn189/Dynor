Sửa phản hồi đăng ký GoTrue: nhận cả đối tượng User trực tiếp (khi cần xác minh email) và session có trường user (khi xác minh email bị tắt). Giữ kiểm tra identities rỗng, không đổi mật khẩu tài khoản cũ, chỉ chấp nhận đăng nhập khi máy chủ trả đủ token.
Cần build lại IPA; không cần SQL hoặc thay Edge Function cho lỗi này.
Nếu lần thử trước đã tạo tài khoản chưa xác minh, kiểm tra email và dùng gửi lại mã.
Chưa build iOS trong môi trường này.
