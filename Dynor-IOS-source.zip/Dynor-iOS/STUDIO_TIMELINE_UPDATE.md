# Dynor Studio — Timeline editor update

- Keeps multiple photo layers and direct drag, pinch, rotation.
- Adds a 0–3 second timeline with scrub and play controls.
- Allows recording start and end keyframes for each selected layer.
- Interpolates position, scale, opacity and rotation for the preview.
- Persists keyframes in the existing project JSON file.
- PNG export remains static. This is not a CAPlayground project exporter and does not install animated PosterBoard wallpapers.

Build status: not compiled with Xcode/iOS SDK in this environment. Validate with Codemagic/Xcode before distribution.
