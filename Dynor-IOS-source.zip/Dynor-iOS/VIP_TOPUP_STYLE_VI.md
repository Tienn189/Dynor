# Gói lượt tải và giao diện VIP mới

5 lượt Crown giá 10.000đ, mã gói credits5. Cần gói tháng, quý hoặc lifetime đang có hiệu lực để tạo đơn. Chỉ cộng lượt tải, không đổi plan_id hay ngày hết hạn thành viên. Tuần không được mua gói này.

Sau khi thanh toán được xác nhận bởi luồng webhook hiện tại, hàm dynor_settle_payment ghi nhận đơn đã trả và cấp 5 lượt một lần. Đơn hợp lệ tạo trước khi VIP hết hạn vẫn được ghi nhận thanh toán; nếu VIP đã hết hạn thì lượt chỉ dùng được sau khi gia hạn thành viên đủ điều kiện.

## Cập nhật máy chủ đã dùng bản tuần chỉ Premium
1. SQL Editor: chạy Supabase/sql/20261123_crown_topup_5.sql. Cần có các bảng lượt cộng dồn từ các bản trước. Migration cũng mở rộng các check đơn cột của plan_id và duration_days cho gói mới.
2. Edge Functions: cập nhật dynor-create-order bằng Supabase/dynor-create-order/index.ts rồi Deploy.
3. Build lại IPA từ source mới. Không cần thay HTML quản trị.

Không chạy lại các migration cũ sau migration mới này vì chúng có thể ghi đè hàm thanh toán.

## Giao diện
Thẻ Dynor VIP và banner trang VIP dùng nền tối pha màu chủ đề với ánh sao lấp lánh. Hỗ trợ Giảm chuyển động; tạm dừng khi ứng dụng không hoạt động. Thẻ gói màu than, chữ trắng, viền màu chủ đề khi chọn; bỏ hiển thị giảm giá để gọn hơn. Giữ các thay đổi icon và đăng ký trước đó.

## Kiểm tra
13 trường hợp tạo đơn giả lập đã đạt: tháng/quý/lifetime được mua; tuần, hết hạn hoặc chưa có gói bị chặn; giá lấy từ máy chủ, không từ client; gói thành viên cũ vẫn tạo được đơn. Chưa chạy migration PostgreSQL thật, thanh toán thật hoặc build Xcode trong môi trường này.
