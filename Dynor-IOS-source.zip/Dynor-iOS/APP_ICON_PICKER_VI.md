Đổi icon tại Cài đặt → Giao diện → Đổi icon ứng dụng.
Còn 2 lựa chọn: Hoa Anh Đào (mặc định) và Vũ Điệu Hồng. Đã xóa Cánh Hoa khỏi giao diện, tài nguyên và cấu hình build.
Giữ bản sửa @MainActor cho tên icon. Build lại IPA để áp dụng. Không cần cập nhật Supabase.
Chưa build Xcode trong môi trường này.
