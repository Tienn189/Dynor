Đổi icon tại Cài đặt → Giao diện → Đổi icon ứng dụng.
Có 3 lựa chọn: Hoa Anh Đào (icon mặc định), Cánh Hoa (ảnh 1), Vũ Điệu Hồng (ảnh 2).
Sử dụng API setAlternateIconName của iOS, đọc lại icon hiện tại từ hệ thống; không lưu lựa chọn giả khi đổi thất bại.
Đã cấu hình bộ icon iPhone/iPad và build settings cho cả hai icon thay thế. Script prepare_icons.py tạo lại đủ 3 bộ icon trên macOS. Các bộ icon đã tạo cũng được kèm sẵn.
Build lại IPA từ source này; không cần cập nhật Supabase.
Đã kiểm tra kích thước và ảnh không có alpha ở mọi slot icon cùng đường dẫn preview. Chưa build Xcode hoặc thử đổi icon trên iPhone trong môi trường này.
