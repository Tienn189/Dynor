Căn đều hai hàng chọn icon: ảnh 56pt, chiều cao hàng tối thiểu 80pt, lề đồng nhất và cột dấu tích cố định. Nhãn Mặc định nằm dưới tên Hoa Anh Đào. Không có Cánh Hoa.
Sau khi setAlternateIconName trả thành công, đánh dấu đúng icon đã yêu cầu và lưu lựa chọn bằng AppStorage. Không đọc lại giá trị cũ từ UIKit ngay trong callback; không thay dấu tích khi API báo lỗi. Khi mở lại màn hình, khôi phục lựa chọn thành công gần nhất.
Build lại IPA để cập nhật. Chưa kiểm tra bằng Xcode hoặc trên iPhone thật trong môi trường này.
