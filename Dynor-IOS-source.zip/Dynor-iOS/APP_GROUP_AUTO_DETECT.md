# Dynor – App Group tự nhận diện sau khi ký IPA

- Dynor ưu tiên `DynorAppGroupIdentifier` nếu nhóm này còn tồn tại trong entitlement thực tế và đọc/ghi được.
- Nếu LCSign thay đổi nhóm được cấp quyền, Dynor thử các nhóm khác trong `com.apple.security.application-groups` của **ứng dụng đã ký**.
- Mỗi nhóm được kiểm tra `containerURL` và thử ghi/đọc tệp tạm trước khi sử dụng.
- Không lấy nhóm tùy ý từ provisioning profile khi runtime entitlement không có.
- Nếu không có App Group hợp lệ, ứng dụng báo lỗi rõ ràng. Không có cách sửa mã SwiftUI để tự cấp entitlement thiếu.
- Nhận diện nhóm thành công **không bảo đảm** cơ chế `worse_query` hoặc PosterBoard sẽ hoạt động trên mọi phiên bản iOS/chứng chỉ.
- `project.yml` vẫn giữ nhóm mặc định để hỗ trợ quy trình build/ký cũ. Không cần thay nhóm này nếu trình ký cấp nhóm khác trong entitlement runtime.
