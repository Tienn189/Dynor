#!/usr/bin/env python3
"""Verify the vendored native worse_query source dependency."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


REVISION = "d1540e20cd82b974d891e0551ced6d6aeb570ac2"
REPOSITORY = "https://github.com/forcequitOS/worse_query"
EXPECTED_PATHS = {
    "Dynor/Native/worse_query.h", "Dynor/Native/worse_query.m",
    "Dynor/Native/GXCacheDirectory.h", "Dynor/Native/GXCacheDirectory.m",
    "Dynor/Native/pathleak.h", "Dynor/Native/pathleak.m",
    "ThirdParty/WorseQuery/LICENSE", "ThirdParty/WorseQuery/UPSTREAM_README.md",
}


def verify_worse_query(source_root: Path) -> None:
    manifest = json.loads((source_root / "ThirdParty/WorseQuery/provenance.json").read_text())
    if manifest.get("revision") != REVISION or manifest.get("repository") != REPOSITORY:
        raise ValueError("worse_query provenance does not match the pinned upstream revision.")
    entries = manifest.get("files", [])
    if len(entries) != len(EXPECTED_PATHS) or {entry["path"] for entry in entries} != EXPECTED_PATHS:
        raise ValueError("worse_query provenance must list exactly the eight vendored files.")
    for entry in entries:
        path = source_root / entry["path"]
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Missing or unsafe vendored dependency: {entry['path']}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError(f"worse_query SHA-256 mismatch: {entry['path']}")
    print("worse_query: eight vendored source/license SHA-256 hashes verified.")




def verify_airlift(source_root: Path) -> None:
    manifest = json.loads((source_root / "ThirdParty/AirCard/provenance.json").read_text())
    if manifest.get("revision") != "40640c4d827aeab8d798285b57d24fcf6be070d0":
        raise ValueError("AirliftFFI provenance does not match the pinned upstream revision.")
    for entry in manifest.get("files", []):
        # The provenance paths are repo-relative; the framework is vendored
        # under Frameworks/ in this project.
        rel = entry["path"]
        candidates = [source_root / "Frameworks" / Path(rel).name.replace("Headers/", "")]
        path = None
        for candidate in candidates:
            pass
        # Map upstream AirliftFFI.xcframework/... paths onto Frameworks/.
        parts = Path(rel).parts
        if "AirliftFFI.xcframework" in parts:
            idx = parts.index("AirliftFFI.xcframework")
            path = source_root / "Frameworks" / Path(*parts[idx:])
        else:
            continue
        if path is None or path.is_symlink() or not path.is_file():
            raise ValueError(f"Missing or unsafe vendored dependency: {rel}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError(f"AirliftFFI SHA-256 mismatch: {rel}")
    print("AirliftFFI: vendored xcframework SHA-256 hashes verified.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parents[1])
    arguments = parser.parse_args()
    root = arguments.source_root.resolve()
    verify_worse_query(root)
    verify_airlift(root)
