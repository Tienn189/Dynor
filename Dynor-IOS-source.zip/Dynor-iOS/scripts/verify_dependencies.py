#!/usr/bin/env python3
"""Verify pinned vendored source dependencies and the slim device-only Airlift XCFramework."""
from __future__ import annotations

import argparse
import hashlib
import json
import plistlib
from pathlib import Path

REVISION = "d1540e20cd82b974d891e0551ced6d6aeb570ac2"
REPOSITORY = "https://github.com/forcequitOS/worse_query"
EXPECTED_PATHS = {
    "Dynor/Native/worse_query.h", "Dynor/Native/worse_query.m",
    "Dynor/Native/GXCacheDirectory.h", "Dynor/Native/GXCacheDirectory.m",
    "Dynor/Native/pathleak.h", "Dynor/Native/pathleak.m",
    "ThirdParty/WorseQuery/LICENSE", "ThirdParty/WorseQuery/UPSTREAM_README.md",
}


def verify_hash(path: Path, expected: str, label: str) -> None:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"Missing or unsafe vendored dependency: {label}")
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError(f"{label} SHA-256 mismatch: expected {expected}, got {actual}")


def verify_worse_query(source_root: Path) -> None:
    manifest = json.loads((source_root / "ThirdParty/WorseQuery/provenance.json").read_text())
    if manifest.get("revision") != REVISION or manifest.get("repository") != REPOSITORY:
        raise ValueError("worse_query provenance does not match the pinned upstream revision.")
    entries = manifest.get("files", [])
    if len(entries) != len(EXPECTED_PATHS) or {entry["path"] for entry in entries} != EXPECTED_PATHS:
        raise ValueError("worse_query provenance must list exactly the eight vendored files.")
    for entry in entries:
        verify_hash(source_root / entry["path"], entry["sha256"], entry["path"])
    print("worse_query: eight vendored source/license SHA-256 hashes verified.")


def verify_airlift(source_root: Path) -> None:
    manifest = json.loads((source_root / "ThirdParty/AirCard/provenance.json").read_text())
    if manifest.get("repository") != "https://github.com/Mak5er/AirCard-iOS":
        raise ValueError("AirliftFFI repository provenance is invalid.")
    if manifest.get("revision") != "40640c4d827aeab8d798285b57d24fcf6be070d0":
        raise ValueError("AirliftFFI provenance does not match the pinned upstream revision.")

    framework = source_root / "Frameworks/AirliftFFI.xcframework"
    info_path = framework / "Info.plist"
    info = plistlib.loads(info_path.read_bytes())
    libraries = info.get("AvailableLibraries", [])
    if len(libraries) != 1:
        raise ValueError("Slim Airlift XCFramework must contain exactly one device library.")
    library = libraries[0]
    if (library.get("LibraryIdentifier") != "ios-arm64"
            or library.get("SupportedPlatform") != "ios"
            or library.get("SupportedArchitectures") != ["arm64"]):
        raise ValueError("Airlift XCFramework must contain the iOS arm64 device slice.")

    entries = manifest.get("files", [])
    if not entries:
        raise ValueError("Airlift provenance contains no retained framework files.")
    seen = set()
    for entry in entries:
        rel = Path(entry["path"])
        parts = rel.parts
        if "AirliftFFI.xcframework" not in parts:
            raise ValueError(f"Unexpected Airlift provenance path: {entry['path']}")
        if any(part == "ios-arm64-simulator" for part in parts):
            raise ValueError("Simulator files must not be listed in the device-only Airlift package.")
        idx = parts.index("AirliftFFI.xcframework")
        local = framework.joinpath(*parts[idx + 1:])
        verify_hash(local, entry["sha256"], entry["path"])
        seen.add(local.relative_to(framework).as_posix())

    required = {
        "Info.plist",
        "ios-arm64/Headers/airlift.h",
        "ios-arm64/Headers/module.modulemap",
        "ios-arm64/libairlift_ffi.a",
    }
    if seen != required:
        raise ValueError(f"Airlift provenance must cover exactly the retained files: {sorted(required)}")
    print("AirliftFFI: device-only XCFramework structure and SHA-256 hashes verified.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.source_root.resolve()
    verify_worse_query(root)
    verify_airlift(root)
