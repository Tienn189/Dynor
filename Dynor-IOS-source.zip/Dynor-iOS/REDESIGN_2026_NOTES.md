# Dynor new editorial UI iteration

Changes: Removed old oversized Dynor Studio hero in favor of plain editorial headings; rebuilt Explore search/filter appearance and image-card chrome; redesigned Collection import entry and selection hierarchy; rebuilt Installed header; reduced Settings card radius/shadows; neutral tab tint; neutral thin borders and reduced accent saturation across high-visibility surfaces. Preserves wallpaper import/install code and Codemagic settings.

This is a source-level UI iteration, not a complete recreation of the reference video. No iOS/Xcode build or device 120Hz validation was possible in this Linux environment. ProMotion opt-in already exists in project.yml.
