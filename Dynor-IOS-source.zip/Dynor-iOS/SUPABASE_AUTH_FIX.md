# Dynor Auth — cấu hình bắt buộc trong Supabase

Đã sửa iOS để đăng ký bằng `POST /auth/v1/signup` và xác minh bằng OTP `type=signup` thay vì `magiclink` + `PUT /user/password`. Điều này tránh việc người dùng vô tình đặt lại mật khẩu tài khoản cũ qua màn hình đăng ký.

## Dashboard → Authentication → Email Templates

1. **Confirm signup**: mẫu email PHẢI chứa mã 6 số `{{ .Token }}` (không chỉ `{{ .ConfirmationURL }}`). Ví dụ: `Mã xác minh Dynor: {{ .Token }}`.
2. **Reset Password**: mẫu email PHẢI chứa mã 6 số `{{ .Token }}`. Ví dụ: `Mã đặt lại mật khẩu Dynor: {{ .Token }}`. Nếu giữ nút liên kết reset mặc định thì giao diện nhập OTP 6 số trong app sẽ không khớp.
3. **Authentication → Providers → Email**: bật **Confirm email**. Nếu tắt, signup có thể trả phiên đăng nhập ngay, không cần OTP.
4. **Authentication → URL Configuration**: thay Site URL `localhost` bằng HTTPS hợp lệ của ứng dụng; chỉ cấu hình Redirect URLs cho các link/deep link thực sự sử dụng. Với mẫu email OTP thuần, người dùng không cần bấm link và không mở localhost.

## Lưu ý bảo mật

- GoTrue có thể che giấu việc email đã tồn tại (chống dò email). App không thể đảm bảo phát hiện mọi email trùng chỉ bằng API công khai; không được dùng service-role key trong iOS để truy vấn danh sách người dùng.
- Khi email đã có tài khoản, người dùng nên chọn Đăng nhập hoặc Quên mật khẩu. Không tiết lộ sự tồn tại của tài khoản qua API công khai.
- Mã OTP chỉ được xác thực bởi Supabase, không tự so sánh ở máy khách.
- Nếu chưa chỉnh hai mẫu email, việc nhập OTP trong app sẽ chưa hoạt động đúng.
- Không thay đổi logic SePay, đơn hàng hoặc cấp quyền VIP.
