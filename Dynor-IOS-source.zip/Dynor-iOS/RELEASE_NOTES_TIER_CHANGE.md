# 2026-11-23 tier and pricing changes

Prices: week 19,000 VND; month 39,000 VND; quarter (90 days) 79,000 VND. Crown gallery downloads use VIP credits (week 2, month 5, quarter 10); Premium gallery downloads require active VIP and do not consume credits; Free requires a logged-in user.

DEPLOY: run Supabase/sql/20261123_wallpaper_tiers.sql and Supabase/sql/vip_download_quota.sql (if not already deployed), then Supabase/sql/upgrade_settlement_all_plans.sql. Deploy Edge Functions dynor-create-order, dynor-wallpaper-download, dynor-register-package and dynor-package-key, then deploy the updated app and admin HTML. Existing lifetime memberships remain honored but no new lifetime plans are sold.

IMPORTANT: Vault encrypted-package access_tier is stored and VIP-gated for Crown/Premium, but the package-key endpoint does not deduct VIP credits. Crown credit limits are enforced only by gallery downloads; sharing a .dynor package can bypass Crown quota. For Crown, distribute only via the gallery until package-key quota enforcement is implemented. This source has not been built or tested on an Apple macOS runner.
