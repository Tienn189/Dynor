import SwiftUI
import UIKit
import PhotosUI

struct SettingsView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var activeSheet: SettingsSheet?
    @State private var posterBoardOpenFailed = false
    @State private var showResetConfirmation = false
    @State private var resettingWallpapers = false
    @State private var resetResultMessage: String?

    @StateObject private var account = DynorAccountService.shared
    @ObservedObject private var localProfile = DynorLocalProfile.shared
    private func resetInstalledWallpapers() {
        guard !resettingWallpapers else { return }
        resettingWallpapers = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: PosterBoardDescriptorWriter.installedPaths()) }
            await MainActor.run {
                resettingWallpapers = false
                switch result {
                case .success(let count):
                    ActivityJournal.shared.add("Đặt lại hình nền", detail: "Đã gỡ \(count) cấu hình PosterBoard do Dynor quản lý", success: true)
                    if !PosterBoardAccess.requestOpenPosterBoard() {
                        posterBoardOpenFailed = true
                    }
                case .failure(let error):
                    resetResultMessage = error.localizedDescription
                }
            }
        }
    }

    private var appVersion: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
        return store.localized("Phiên bản \(version) (build \(build))", "Version \(version) (build \(build))", "版本 \(version)（构建 \(build)）")
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    accountRow
                }
                Section {
                    vipRow
                }
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                Section(store.localized("Giao diện", "Appearance", "外观")) {
                    Button { activeSheet = .colors } label: {
                        HStack {
                            Label { Text(store.localized("Màu chủ đề", "Theme color", "主题颜色")).foregroundStyle(.primary) } icon: { Image(systemName: "paintpalette").foregroundStyle(store.accentColor) }
                            Spacer()
                            Circle().fill(store.accentColor).frame(width: 22, height: 22)
                            chevron
                        }
                        .frame(minHeight: 32)
                    }
                    .buttonStyle(.plain)

                }
                Section(store.localized("Ứng dụng", "Application", "应用")) {
                    NavigationLink {
                        ActivityHistoryView()
                    } label: {
                        settingsLabel(store.localized("Nhật ký hoạt động", "Activity history", "活动历史"), symbol: "clock.arrow.circlepath")
                    }
                    NavigationLink {
                        deviceScreen
                    } label: {
                        settingsLabel(store.localized("Thông tin thiết bị", "Device information", "设备信息"), symbol: "iphone")
                    }
                    NavigationLink {
                        compatibilityScreen
                    } label: {
                        settingsLabel(store.localized("Khả năng tương thích", "Compatibility", "兼容性"), symbol: "checkmark.shield")
                    }
                }
                Section {
                    SettingsLinkRow(title: store.localized("Thông tin liên hệ", "Contact", "联系方式"), symbol: "envelope") { activeSheet = .contact }
                    SettingsLinkRow(title: store.localized("Về Dynor & ghi công", "About Dynor & credits", "关于 Dynor 与致谢"), symbol: "info.circle") { activeSheet = .credits }
                    SettingsLinkRow(title: store.localized("Dữ liệu của bạn", "Your data", "你的数据"), symbol: "lock.shield") { activeSheet = .privacy }
                } header: {
                    Text(store.localized("Thông tin & hỗ trợ", "Information & support", "信息与支持"))
                }
                Section {
                    Button {
                        showResetConfirmation = true
                    } label: {
                        HStack {
                            Label { Text(store.localized("Đặt lại hình nền đã cài", "Reset installed wallpapers", "重置已安装的壁纸")) } icon: { Image(systemName: "arrow.counterclockwise").foregroundStyle(store.accentColor) }
                            Spacer()
                        }
                        .frame(minHeight: 32)
                    }
                } footer: {
                    VStack(alignment: .leading, spacing: 20) {
                        Text(store.localized("Chỉ gỡ cấu hình do Dynor ghi. Tệp trong Bộ sưu tập và hình nền hệ thống được giữ lại.", "Removes configurations created by Dynor. Collection files and system wallpapers are kept.", "仅移除 Dynor 创建的配置，保留收藏文件和系统壁纸。"))
                        Text(appVersion).frame(maxWidth: .infinity).multilineTextAlignment(.center)
                    }
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .background(DynorDesign.canvas)
            .navigationTitle(store.localized("Cài đặt", "Settings", "设置"))
            .alert(store.localized("Không thể mở PosterBoard", "Cannot open PosterBoard", "无法打开 PosterBoard"), isPresented: $posterBoardOpenFailed) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(store.localized("Vào Cài đặt → Hình nền để mở bộ chọn hình nền trên iPhone.", "Open Settings → Wallpaper to access the iPhone wallpaper picker.", "请前往设置 → 墙纸打开 iPhone 墙纸选择器。"))
            }
            .alert(store.localized("Đặt lại hình nền đã cài?", "Reset installed wallpapers?", "重置已安装的壁纸？"), isPresented: $showResetConfirmation) {
                Button(store.localized("Hủy", "Cancel", "取消"), role: .cancel) {}
                Button(store.localized("Đặt lại", "Reset", "重置"), role: .destructive) {
                    resetInstalledWallpapers()
                }
            } message: {
                Text(store.localized("Bạn muốn xóa các cấu hình hình nền do Dynor đã cài? Hình nền hệ thống và các tệp trong Bộ sưu tập sẽ được giữ nguyên.", "Remove wallpaper configurations installed by Dynor? System wallpapers and Collection files will remain untouched.", "要移除 Dynor 安装的壁纸配置吗？系统壁纸和收藏中的文件将保留。"))
            }
            .alert("Dynor", isPresented: Binding(get: { resetResultMessage != nil }, set: { if !$0 { resetResultMessage = nil } })) {
                Button(store.localized("Đã hiểu", "OK", "知道了")) { resetResultMessage = nil }
            } message: {
                Text(resetResultMessage ?? "")
            }
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .account: SettingsAccountSheet()
                case .vip: SettingsVIPSheet()
                case .contact: SettingsContactSheet()
                case .credits: SettingsCreditsSheet()
                case .colors: ThemeColorPickerView()
                case .privacy: SettingsInformationSheet(title: "Dữ liệu ở lại với bạn", symbol: "lock.shield", text: "Ảnh và tệp Tendies bạn nhập được sao chép vào vùng lưu trữ riêng của Dynor trên thiết bị. Tên hồ sơ trải nghiệm, ID, giao diện, yêu thích và tiến trình quảng cáo mô phỏng được lưu cục bộ.\n\nGói Tendies được kiểm tra và ghi trực tiếp vào container PosterBoard qua worse_query. Cơ chế này cần App Group được cấp quyền trong chữ ký IPA. Dynor đọc lại và đối chiếu dữ liệu đã ghi; bạn chọn hình nền trong bộ chọn của iOS.\n\nBản này chưa có tài khoản được xác thực hoặc đồng bộ đám mây. Gỡ ứng dụng có thể làm mất dữ liệu cục bộ. Ảnh đã lưu vào ứng dụng Ảnh được quản lý riêng bởi iOS.")
                }
            }
        }
    }


    private var chevron: some View {
        Image(systemName: "chevron.right")
            .font(.caption.weight(.semibold))
            .foregroundStyle(.tertiary)
    }

    private func settingsLabel(_ title: String, symbol: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(store.accentColor)
                .frame(width: 29, height: 29)

            Text(title)
        }
        .frame(minHeight: 32)
    }

    private var accountRow: some View {
        Button { activeSheet = .account } label: {
            HStack(spacing: 14) {
                SettingsAvatar(showProfile: account.email != nil)
                VStack(alignment: .leading, spacing: 4) {
                    Text(account.email == nil ? store.localized("Đăng nhập Dynor", "Sign in to Dynor", "登录 Dynor") : (localProfile.displayName.isEmpty ? "Dynor" : localProfile.displayName))
                        .font(.headline)
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(account.email == nil
                         ? store.localized("Đồng bộ yêu thích và quyền lợi VIP", "Sync favorites and VIP access", "同步收藏与 VIP 权益")
                         : (account.isVIP ? "Dynor VIP" : store.localized("Quản lý tài khoản", "Manage account", "管理账户")))
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                chevron
            }
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var vipRow: some View {
        Button { activeSheet = .vip } label: {
            HStack(spacing: 14) {
                Image(systemName: "crown.fill")
                    .font(.title).foregroundStyle(Color(red: 1, green: 0.84, blue: 0.42))
                VStack(alignment: .leading, spacing: 5) {
                    Text("DYNOR VIP").font(.title3.bold()).foregroundStyle(.white)
                    Text(account.isVIP ? store.localized("Đang hoạt động", "Active", "已启用") : store.localized("Mở khóa đặc quyền cao cấp", "Unlock premium benefits", "解锁高级特权"))
                        .font(.caption).foregroundStyle(.white.opacity(0.85))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white)
            }
            .padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [Color(red: 0.25, green: 0.17, blue: 0.57), Color(red: 0.47, green: 0.29, blue: 0.65), Color(red: 0.66, green: 0.42, blue: 0.23)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 22))
            .overlay(RoundedRectangle(cornerRadius: 22).strokeBorder(.white.opacity(0.22)))
            .contentShape(RoundedRectangle(cornerRadius: 22))
        }.buttonStyle(.plain)
    }

    private var deviceScreen: some View {
        List {
            Section {
                deviceRow("Thiết bị", UIDevice.current.model)
                deviceRow("Tên thiết bị", UIDevice.current.name)
                deviceRow("Hệ điều hành", "iOS " + UIDevice.current.systemVersion)
                deviceRow("Phiên bản Dynor", appVersion)
            }
            Section {
                deviceRow("Bundle ID", Bundle.main.bundleIdentifier ?? "—")
                deviceRow("App Group", PosterBoardAccess.prerequisiteWarning == nil ? "Có quyền truy cập" : "Chưa sẵn sàng")
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(store.localized("Thiết bị", "Device", "设备"))
        .navigationBarTitleDisplayMode(.inline)
    }

    private func deviceRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(title)
            Spacer(minLength: 8)
            Text(value).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
        }
    }

    private var compatibilityScreen: some View {
        List {
            Section {
                compatibilityRow("iOS 26.0 – 26.7.2", "Có thể thử", .green)
                compatibilityRow("iOS 27.0 – 27.2.0", "Có thể thử", .green)
                compatibilityRow("Các phiên bản khác", "Chưa hỗ trợ", .orange)
            } footer: {
                Text("Phạm vi cơ chế worse_query được khai báo; không đồng nghĩa mọi bản đều đã kiểm thử.")
            }
            Section {
                Label(TendiesCompatibility.current.canAttemptInstall ? "Phiên bản iOS hiện tại nằm trong phạm vi thử nghiệm" : "Phiên bản iOS hiện tại nằm ngoài phạm vi", systemImage: "info.circle")
                    .foregroundStyle(.secondary)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(store.localized("Tương thích", "Compatibility", "兼容性"))
        .navigationBarTitleDisplayMode(.inline)
    }

    private func compatibilityRow(_ version: String, _ status: String, _ color: Color) -> some View {
        HStack {
            Text(version)
            Spacer()
            Text(status).font(.subheadline).foregroundStyle(color)
        }
    }


}

private enum SettingsSheet: String, Identifiable {
    case account, vip, contact, credits, privacy, colors
    var id: String { rawValue }
}

private struct SettingsHeader: View {
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.title2.bold())
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct SettingsGlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .modifier(DynorGlass(radius: 20))
    }
}

@MainActor
private final class DynorLocalProfile: ObservableObject {
    static let shared = DynorLocalProfile()
    @Published var displayName: String = UserDefaults.standard.string(forKey: "dynor.displayName") ?? ""
    @Published var avatarData: Data? = try? Data(contentsOf: DynorLocalProfile.avatarURL)
    static var avatarURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("dynor-profile-avatar.jpg")
    }
    func clear() {
        UserDefaults.standard.removeObject(forKey: "dynor.displayName")
        if FileManager.default.fileExists(atPath: Self.avatarURL.path) {
            try? FileManager.default.removeItem(at: Self.avatarURL)
        }
        displayName = ""
        avatarData = nil
    }
    func save(name: String, avatar: Data?) throws {
        let cleaned = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(60))
        let directory = Self.avatarURL.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        if let avatar { try avatar.write(to: Self.avatarURL, options: .atomic) }
        else if FileManager.default.fileExists(atPath: Self.avatarURL.path) { try FileManager.default.removeItem(at: Self.avatarURL) }
        UserDefaults.standard.set(cleaned, forKey: "dynor.displayName")
        displayName = cleaned
        avatarData = avatar
    }
}

private struct SettingsAvatar: View {
    @ObservedObject private var profile = DynorLocalProfile.shared
    var showProfile: Bool = false
    var body: some View {
        Group {
            if showProfile, let data = profile.avatarData, let image = UIImage(data: data) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: "person.crop.circle")
                    .resizable().scaledToFit().padding(9)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(width: 52, height: 52)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: Circle())
        .clipShape(Circle())
        .accessibilityLabel("Ảnh đại diện")
    }
}

private struct SettingsLinkRow: View {
    @EnvironmentObject private var store: DynorStore
    let title: String
    let symbol: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundStyle(store.accentColor)
                    .frame(width: 29, height: 29)
                Text(title).foregroundStyle(.primary)
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .frame(minHeight: 32)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

private struct SettingsAccountSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var inputEmail = ""
    @State private var otp = ""
    @State private var isRegistering = false
    @State private var registrationSent = false
    @State private var resettingPassword = false
    @State private var resetCodeSent = false
    @State private var changingPassword = false
    @State private var currentPassword = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var showPassword = false
    @State private var showConfirmPassword = false
    @State private var working = false
    @State private var errorText: String?
    @ObservedObject private var localProfile = DynorLocalProfile.shared
    @State private var editedName = ""
    @State private var editedAvatar: Data?
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var profileMessage: String?

    private var validEmail: Bool {
        let value = inputEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.contains("@") && value.split(separator: "@").last?.contains(".") == true
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 14) {
                        Text("D")
                            .font(.title2.bold())
                            .foregroundStyle(store.accentTextColor)
                            .frame(width: 52, height: 52)
                            .background(store.accentColor, in: RoundedRectangle(cornerRadius: 16))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Dynor").font(.title3.bold())
                            Text("Không gian của riêng bạn")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.bottom, 24)

                    if account.email != nil {
                    VStack(alignment: .leading, spacing: 14) {
                        Text(store.localized("Chỉnh sửa hồ sơ", "Edit profile", "编辑个人资料")).font(.headline)
                        HStack(spacing: 16) {
                            Group {
                                if let data = editedAvatar, let image = UIImage(data: data) {
                                    Image(uiImage: image).resizable().scaledToFill()
                                } else {
                                    Image(systemName: "person.crop.circle.fill").resizable().scaledToFit().foregroundStyle(.secondary)
                                }
                            }.frame(width: 70, height: 70).clipShape(Circle())
                            VStack(alignment: .leading, spacing: 8) {
                                PhotosPicker(selection: $selectedPhoto, matching: .images) {
                                    Label(store.localized("Chọn ảnh đại diện", "Choose photo", "选择头像"), systemImage: "photo")
                                }
                                Button(store.localized("Xóa ảnh", "Remove photo", "移除头像")) { editedAvatar = nil }
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        TextField(store.localized("Tên hiển thị", "Display name", "显示名称"), text: $editedName)
                            .textInputAutocapitalization(.words)
                            .padding(13)
                            .background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 12))
                        Button {
                            do {
                                try localProfile.save(name: editedName, avatar: editedAvatar)
                                profileMessage = store.localized("Đã lưu thay đổi", "Changes saved", "更改已保存")
                            } catch { profileMessage = error.localizedDescription }
                        } label: {
                            Text(store.localized("Lưu thay đổi", "Save changes", "保存更改"))
                                .font(.headline).frame(maxWidth: .infinity).padding(13)
                                .foregroundStyle(.white)
                                .background(store.accentColor, in: RoundedRectangle(cornerRadius: 14))
                        }
                        if let profileMessage { Text(profileMessage).font(.caption).foregroundStyle(.secondary) }
                    }
                    .padding(18)
                    .modifier(DynorGlass(radius: 20))
                    .padding(.bottom, 22)
                    }

                    VStack(alignment: .leading, spacing: 23) {
                        HStack {
                            Image(systemName: "crown.fill").font(.title2)
                            Spacer()
                            Image(systemName: "sparkle").foregroundStyle(.secondary)
                        }
                        Text(account.email == nil ? "Chào mừng trở lại." : "Tài khoản của bạn.")
                            .font(.title2.bold())
                            .minimumScaleFactor(0.8)
                            .lineLimit(2)
                        Text(account.email == nil
                             ? "Đăng nhập bằng email để khám phá trải nghiệm Dynor của bạn."
                             : "Tài khoản Dynor của bạn đã được xác minh.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)

                        if let email = account.email {
                            VStack(alignment: .leading, spacing: 13) {
                                Text("EMAIL ĐANG ĐĂNG NHẬP")
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text(email).font(.headline).textSelection(.enabled)
                                Label(account.isVIP ? "Dynor VIP đang hoạt động" : "Tài khoản thường",
                                      systemImage: account.isVIP ? "crown.fill" : "person.crop.circle")
                                if let date = account.vipExpiresAt, account.isVIP {
                                    Text("VIP đến: \(date.formatted(date: .abbreviated, time: .shortened))")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                }
                                Button("Kiểm tra lại trạng thái VIP") {
                                    Task { await account.refreshVIP() }
                                }
                                .foregroundStyle(.primary)
                                Button("Đổi mật khẩu") {
                                    changingPassword.toggle(); errorText = nil
                                }
                                if changingPassword {
                                    SecureField("Mật khẩu hiện tại", text: $currentPassword)
                                        .textContentType(.password)
                                        .padding(14).background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 14))
                                    SecureField("Mật khẩu mới", text: $password)
                                        .textContentType(.newPassword)
                                        .padding(14).background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 14))
                                    SecureField("Nhập lại mật khẩu mới", text: $confirmPassword)
                                        .textContentType(.newPassword)
                                        .padding(14).background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 14))
                                    Button("Lưu mật khẩu mới") {
                                        Task { await perform { try await account.changePassword(current: currentPassword, newPassword: password); currentPassword = ""; password = ""; confirmPassword = ""; changingPassword = false } }
                                    }
                                    .disabled(working || currentPassword.isEmpty || password.count < 6 || password != confirmPassword)
                                }
                                Button("Đăng xuất", role: .destructive) {
                                    account.signOut(); localProfile.clear(); editedName = ""; editedAvatar = nil; selectedPhoto = nil; profileMessage = nil; registrationSent = false; isRegistering = false; otp = ""; password = ""; confirmPassword = ""
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        } else {
                            VStack(alignment: .leading, spacing: 14) {
                                Text(resettingPassword ? "Quên mật khẩu" : (isRegistering ? "Đăng ký" : "Đăng nhập"))
                                    .font(.title3.bold())
                                Text("Địa chỉ email").font(.subheadline.weight(.semibold))
                                TextField("tenban@gmail.com", text: $inputEmail)
                                    .textContentType(.emailAddress)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .padding(16)
                                    .background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 15))
                                    .disabled(registrationSent || resetCodeSent)

                                if (isRegistering && registrationSent) || (resettingPassword && resetCodeSent) {
                                    Text("Mã xác minh email").font(.subheadline.weight(.semibold))
                                    TextField("Nhập mã 6 chữ số", text: $otp)
                                        .keyboardType(.numberPad)
                                        .textContentType(.oneTimeCode)
                                        .padding(16)
                                        .background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 15))
                                }

                                Text(resettingPassword ? "Mật khẩu mới" : (isRegistering ? "Tạo mật khẩu" : "Mật khẩu"))
                                    .font(.subheadline.weight(.semibold))
                                HStack {
                                    Group {
                                        if showPassword { TextField("Nhập mật khẩu", text: $password) }
                                        else { SecureField("Nhập mật khẩu", text: $password) }
                                    }
                                    .textContentType((isRegistering || resettingPassword) ? .newPassword : .password)
                                    Button { showPassword.toggle() } label: {
                                        Image(systemName: showPassword ? "eye.slash" : "eye")
                                            .foregroundStyle(.secondary)
                                    }
                                    .accessibilityLabel(showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu")
                                }
                                .padding(16)
                                .background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 15))

                                if isRegistering || resettingPassword {
                                    Text("Nhập lại mật khẩu").font(.subheadline.weight(.semibold))
                                    HStack {
                                        Group {
                                            if showConfirmPassword { TextField("Nhập lại mật khẩu", text: $confirmPassword) }
                                            else { SecureField("Nhập lại mật khẩu", text: $confirmPassword) }
                                        }
                                        .textContentType(.newPassword)
                                        Button { showConfirmPassword.toggle() } label: {
                                            Image(systemName: showConfirmPassword ? "eye.slash" : "eye")
                                                .foregroundStyle(.secondary)
                                        }
                                        .accessibilityLabel(showConfirmPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu")
                                    }
                                    .padding(16)
                                    .background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 15))
                                    if !password.isEmpty && !confirmPassword.isEmpty && password != confirmPassword {
                                        Text("Mật khẩu nhập lại không khớp")
                                            .font(.caption).foregroundStyle(.red)
                                    }
                                }

                                Button {
                                    Task {
                                        if resettingPassword {
                                            if resetCodeSent {
                                                await perform { try await account.resetPassword(email: inputEmail, code: otp, newPassword: password); resettingPassword = false; resetCodeSent = false; otp = "" }
                                            } else {
                                                await perform { try await account.sendPasswordResetCode(email: inputEmail); resetCodeSent = true }
                                            }
                                        } else if isRegistering {
                                            if registrationSent {
                                                await perform { try await account.verifyRegistration(email: inputEmail, code: otp, password: password) }
                                            } else {
                                                await perform {
                                                    let signedIn = try await account.register(email: inputEmail, password: password)
                                                    if !signedIn { registrationSent = true }
                                                }
                                            }
                                        } else {
                                            await perform { try await account.signIn(email: inputEmail, password: password) }
                                        }
                                    }
                                } label: {
                                    primaryButton(resettingPassword ? (resetCodeSent ? "Đặt lại mật khẩu" : "Gửi mã khôi phục") : (isRegistering ? (registrationSent ? "Xác minh & đăng ký" : "Gửi mã xác minh") : "Đăng nhập"))
                                }
                                .buttonStyle(DynorPrimaryButtonStyle())
                                .disabled(working || !validEmail || password.isEmpty || ((isRegistering || resettingPassword) && (password.count < 6 || password != confirmPassword || ((registrationSent || resetCodeSent) && otp.count != 6))))

                                if (isRegistering && registrationSent) || (resettingPassword && resetCodeSent) {
                                    Button("Gửi lại mã") {
                                        Task {
                                            if resettingPassword { await perform { try await account.sendPasswordResetCode(email: inputEmail) } }
                                            else { await perform { try await account.resendRegistrationCode(email: inputEmail) } }
                                        }
                                    }.disabled(working)
                                }
                                if !isRegistering && !resettingPassword {
                                    Button("Quên mật khẩu?") {
                                        resettingPassword = true; resetCodeSent = false; otp = ""; password = ""; confirmPassword = ""; errorText = nil
                                    }.font(.subheadline).frame(maxWidth: .infinity, alignment: .trailing)
                                }
                                if resettingPassword {
                                    Button("Quay lại đăng nhập") {
                                        resettingPassword = false; resetCodeSent = false; otp = ""; password = ""; confirmPassword = ""; errorText = nil
                                    }.font(.subheadline).frame(maxWidth: .infinity)
                                }

                                if !resettingPassword { HStack(spacing: 4) {
                                    Text(isRegistering ? "Đã có tài khoản?" : "Chưa có tài khoản?")
                                        .foregroundStyle(.secondary)
                                    Button(isRegistering ? "Đăng nhập" : "Đăng ký ngay") {
                                        isRegistering.toggle()
                                        registrationSent = false
                                        otp = ""
                                        password = ""
                                        confirmPassword = ""
                                        errorText = nil
                                    }
                                    .fontWeight(.semibold)
                                }
                                .font(.subheadline)
                                .frame(maxWidth: .infinity)
                                }
                            }
                        }
                        if working { ProgressView() }
                        if let errorText {
                            Text(errorText).font(.footnote).foregroundStyle(.red)
                        }
                        if !account.statusMessage.isEmpty {
                            Text(account.statusMessage)
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                        if account.email == nil {
                            Text(isRegistering ? "Mã xác minh được gửi khi đăng ký tài khoản." : "Đăng nhập an toàn bằng email và mật khẩu.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .padding(22)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .modifier(DynorGlass(radius: 22))
                    
                    .padding(.bottom, 24)

                    Text("Tài khoản được bảo vệ bằng email và mật khẩu")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                }
                .frame(maxWidth: 620)
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .frame(maxWidth: .infinity)
                .padding(.bottom, 40)
            }
            .background(DynorDesign.canvas)
            .onAppear { editedName = account.email == nil ? "" : localProfile.displayName; editedAvatar = account.email == nil ? nil : localProfile.avatarData }
            .onChange(of: account.email) { _, newEmail in
                if newEmail == nil {
                    localProfile.clear()
                    editedName = ""
                    editedAvatar = nil
                    selectedPhoto = nil
                    profileMessage = nil
                }
            }
            .onChange(of: selectedPhoto) { _, photo in
                Task {
                    guard let photo, let bytes = try? await photo.loadTransferable(type: Data.self),
                          let image = UIImage(data: bytes),
                          let jpeg = image.jpegData(compressionQuality: 0.82) else { return }
                    await MainActor.run { editedAvatar = jpeg }
                }
            }
            .navigationTitle("Tài khoản")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }

    private func primaryButton(_ title: String) -> some View {
        Label(title, systemImage: "arrow.right")
            .frame(maxWidth: .infinity)
    }

    private func perform(_ operation: @escaping () async throws -> Void) async {
        working = true; errorText = nil
        defer { working = false }
        do { try await operation() }
        catch { errorText = error.localizedDescription }
    }
}

private struct SettingsVIPSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var selected = SettingsVIPPlan.month
    @State private var order: DynorPaymentOrder?
    @State private var paymentError: String?
    @State private var busy = false
    @State private var checking = false
    @State private var paidNotice = false
    @State private var completedCode: String?
    @State private var pollingTask: Task<Void, Never>?

    private func vipBenefit(_ symbol: String, _ vi: String, _ en: String, _ zh: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: symbol).font(.title3).foregroundStyle(Color(red: 0.82, green: 0.60, blue: 0.19)).frame(width: 28)
            Text(store.localized(vi, en, zh)).font(.subheadline)
            Spacer(minLength: 0)
            Image(systemName: "checkmark.circle.fill").foregroundStyle(Color(red: 0.82, green: 0.60, blue: 0.19))
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "crown.fill").font(.largeTitle)
                            Spacer()
                            Image(systemName: "sparkles").font(.title)
                        }
                        Text("DYNOR VIP").font(.largeTitle.bold())
                        Text(store.localized("Trải nghiệm hình nền cao cấp", "Premium wallpaper experience", "高级壁纸体验"))
                            .font(.subheadline)
                    }
                    .foregroundStyle(.white)
                    .padding(24).frame(maxWidth: .infinity, alignment: .leading)
                    .background(LinearGradient(colors: [Color(red: 0.21, green: 0.15, blue: 0.48), Color(red: 0.53, green: 0.32, blue: 0.63), Color(red: 0.76, green: 0.50, blue: 0.23)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24))
                    VStack(alignment: .leading, spacing: 16) {
                        Text(store.localized("Đặc quyền Dynor VIP", "Dynor VIP benefits", "Dynor VIP 特权"))
                            .font(.title3.bold())
                        vipBenefit("lock.open.fill", "Mở khóa hình nền VIP", "Unlock VIP wallpapers", "解锁 VIP 壁纸")
                        vipBenefit("arrow.down.circle.fill", "Tải hình nền không giới hạn", "Unlimited wallpaper downloads", "无限下载壁纸")
                        vipBenefit("play.rectangle.fill", "Hoạt ảnh cao cấp", "Premium animations", "高级动态效果")
                        vipBenefit("sparkles", "Không quảng cáo", "Ad-free experience", "无广告体验")
                        vipBenefit("checkmark.shield.fill", "Khôi phục quyền lợi VIP", "Restore VIP benefits", "恢复 VIP 权益")
                    }
                    .padding(20).modifier(DynorGlass(radius: 20))
                    Text(store.localized("Chọn gói thành viên", "Choose your plan", "选择会员套餐"))
                        .font(.title3.bold())
                    ForEach(SettingsVIPPlan.allCases) { plan in
                        Button {
                            stopPolling()
                            selected = plan
                            order = nil
                            paymentError = nil
                            paidNotice = false
                        } label: {
                            HStack(spacing: 14) {
                                Image(systemName: selected == plan ? "checkmark.circle.fill" : "circle")
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(store.localized(plan.title, plan.englishTitle, plan.chineseTitle)).font(.headline)
                                    Text(store.localized(plan.labelVI, plan.labelEN, plan.labelZH))
                                        .font(.caption2.bold()).foregroundStyle(.orange)
                                    Text(store.localized(plan.duration, plan.englishDuration, plan.chineseDuration)).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                VStack(alignment: .trailing, spacing: 3) {
                                    Text(plan.originalPrice).font(.caption).strikethrough().foregroundStyle(.secondary)
                                    Text(plan.price).font(.headline).foregroundStyle(store.accentColor)
                                    if let discount = plan.discountPercent {
                                        Text("-\(discount)%").font(.caption2.bold()).foregroundStyle(.orange)
                                    }
                                }
                            }
                            .padding(18)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background {
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .fill(DynorDesign.surface)
                            }
                            .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                            .overlay {
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .strokeBorder(selected == plan ? store.accentColor : Color.clear, lineWidth: 1.5)
                                    .allowsHitTesting(false)
                            }
                        }.buttonStyle(.plain)
                    }
                    if account.isVIP {
                        Label("VIP đang hoạt động", systemImage: "checkmark.seal.fill")
                        if let date = account.vipExpiresAt {
                            Text("Hạn: \(date.formatted(date: .numeric, time: .shortened))")
                        } else {
                            Text("Gói VIP vĩnh viễn")
                        }
                    }
                    if paidNotice {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Label("Thanh toán thành công!", systemImage: "checkmark.seal.fill")
                                    .font(.headline)
                                    .foregroundStyle(.green)
                                Text("Gói VIP đã được cập nhật. Mã QR cũ đã được ẩn để tránh chuyển khoản trùng.")
                                    .font(.subheadline)
                                if let date = account.vipExpiresAt {
                                    Text("Hạn VIP mới: \(date.formatted(date: .numeric, time: .shortened))")
                                        .font(.subheadline.weight(.semibold))
                                }
                                Button("Mua thêm gói VIP") {
                                    paidNotice = false
                                    completedCode = nil
                                }
                                .font(.subheadline.weight(.semibold))
                            }
                        }
                    }
                    if let order, !paidNotice {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 14) {
                                Text("Chuyển khoản để kích hoạt VIP").font(.headline)
                                if let url = order.qrURL {
                                    AsyncImage(url: url) { image in
                                        image.resizable().scaledToFit()
                                    } placeholder: {
                                        ProgressView().frame(height: 240)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 260)
                                    .accessibilityLabel("QR thanh toán ngân hàng")
                                }
                                Text("Ngân hàng: \(order.bankName)")
                                Text("Số tài khoản: \(order.bankAccount)").textSelection(.enabled)
                                Text("Số tiền: \(order.amount.formatted())đ").font(.headline)
                                Text("Nội dung chuyển khoản:").font(.caption).foregroundStyle(.secondary)
                                Text(order.paymentCode)
                                    .font(.system(.body, design: .monospaced).weight(.semibold))
                                    .textSelection(.enabled)
                                ShareLink("Chia sẻ mã thanh toán", item: order.paymentCode)
                                HStack(spacing: 8) {
                                    ProgressView().controlSize(.small)
                                    Text("Đang tự động kiểm tra thanh toán...")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Text("Chỉ chuyển khoản đúng số tiền và nội dung trên. Sau khi ngân hàng ghi nhận, mã QR sẽ tự ẩn.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if let paymentError {
                        Text(paymentError).font(.caption).foregroundStyle(.red)
                    }
                    if order == nil && !paidNotice {
                        Button { Task { await createOrder() } } label: {
                            HStack {
                                Spacer()
                                if busy { ProgressView().tint(.white) }
                                Text("Tạo đơn trong Dynor").font(.headline)
                                Spacer()
                            }
                        }
                        .buttonStyle(DynorPrimaryButtonStyle())
                        .disabled(busy || account.email == nil)
                    }
                    if account.email == nil {
                        Text("Đăng nhập tài khoản Dynor trước khi tạo đơn.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Button {
                        Task {
                            if let code = order?.paymentCode {
                                await checkPayment(code: code, showError: true)
                            } else {
                                await account.refreshVIP()
                            }
                        }
                    } label: {
                        HStack {
                            if checking { ProgressView().controlSize(.small) }
                            Text("Kiểm tra lại VIP")
                        }
                    }
                    .disabled(checking)
                    .foregroundStyle(.primary)
                }
                .frame(maxWidth: 620)
                .padding(24)
                .frame(maxWidth: .infinity)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Dynor VIP")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
        .tint(store.accentColor)
        .onDisappear { stopPolling() }
    }

    private func stopPolling() {
        pollingTask?.cancel()
        pollingTask = nil
    }

    private func startPolling(code: String) {
        stopPolling()
        pollingTask = Task {
            while !Task.isCancelled {
                await checkPayment(code: code, showError: false)
                if Task.isCancelled || completedCode == code || order?.paymentCode != code {
                    break
                }
                try? await Task.sleep(for: .seconds(5))
            }
        }
    }

    private func checkPayment(code: String, showError: Bool) async {
        guard order?.paymentCode == code, completedCode != code, !checking else { return }
        checking = true
        defer { checking = false }
        do {
            let status = try await account.paymentStatus(for: code)
            guard !Task.isCancelled, order?.paymentCode == code else { return }
            if status == "paid" {
                completedCode = code
                order = nil
                paidNotice = true
                paymentError = nil
                stopPolling()
                await account.refreshVIP()
            } else if status == "expired" {
                order = nil
                stopPolling()
                paymentError = "Đơn hàng đã hết hạn. Hãy tạo đơn mới."
            } else if showError {
                paymentError = "Máy chủ chưa xác nhận thanh toán. Vui lòng đợi ngân hàng và SePay xử lý."
            }
        } catch {
            if showError { paymentError = error.localizedDescription }
        }
    }

    private func createOrder() async {
        busy = true
        paymentError = nil
        paidNotice = false
        stopPolling()
        defer { busy = false }
        do {
            let newOrder = try await account.createVIPOrder(plan: selected.rawValue)
            order = newOrder
            completedCode = nil
            startPolling(code: newOrder.paymentCode)
        } catch {
            order = nil
            paymentError = error.localizedDescription
        }
    }
}

private enum SettingsVIPPlan: String, CaseIterable, Identifiable {
    case week, month, lifetime
    var id: String { rawValue }
    var title: String { switch self { case .week: return "Thẻ tuần"; case .month: return "Thẻ tháng"; case .lifetime: return "Vĩnh viễn" } }
    var englishTitle: String { switch self { case .week: return "Weekly"; case .month: return "Monthly"; case .lifetime: return "Lifetime" } }
    var chineseTitle: String { switch self { case .week: return "周卡"; case .month: return "月卡"; case .lifetime: return "永久" } }
    var englishDuration: String { switch self { case .week: return "7 days of inspiration"; case .month: return "30 days of discovery"; case .lifetime: return "One purchase, forever" } }
    var chineseDuration: String { switch self { case .week: return "7 天灵感"; case .month: return "30 天探索"; case .lifetime: return "一次购买，永久使用" } }
    var labelVI: String { switch self { case .week: return "Trải nghiệm ngay"; case .month: return "Lựa chọn nổi bật"; case .lifetime: return "Đặc quyền trọn đời" } }
    var labelEN: String { switch self { case .week: return "Try it today"; case .month: return "Featured choice"; case .lifetime: return "Lifetime privileges" } }
    var labelZH: String { switch self { case .week: return "立即体验"; case .month: return "精选推荐"; case .lifetime: return "终身特权" } }
    var originalPrice: String { switch self { case .week: return "99.000đ"; case .month: return "199.000đ"; case .lifetime: return "349.000đ" } }
    var discountPercent: Int? {
        let original: Int
        let current: Int
        switch self { case .week: original = 99000; current = 49000; case .month: original = 199000; current = 79000; case .lifetime: original = 349000; current = 149000 }
        return Int((Double(original - current) / Double(original) * 100).rounded())
    }
    var price: String { switch self { case .week: return "49.000đ"; case .month: return "79.000đ"; case .lifetime: return "149.000đ" } }
    var duration: String { switch self { case .week: return "7 ngày cảm hứng"; case .month: return "30 ngày khám phá"; case .lifetime: return "Một lần chọn, mãi mãi" } }
}

private struct SettingsInformationSheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let symbol: String
    let text: String
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Image(systemName: symbol).font(.system(size: 36)).foregroundStyle(.secondary)
                    Text(title).font(.title2.bold())
                    Text(text).font(.body).foregroundStyle(.secondary).lineSpacing(5)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(DynorDesign.canvas)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

private struct SettingsContactSheet: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: DynorStore

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    Image("ContactTelegramQR")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: 330)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .accessibilityLabel("Telegram QR @TIENN189")
                    Text("@TIENN189")
                        .font(.title2.bold())
                    Text(store.localized("Quét mã QR để liên hệ qua Telegram", "Scan the QR code to contact us on Telegram", "扫描二维码通过 Telegram 联系我们"))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(24)
            }
            .background(DynorDesign.canvas)
            .navigationTitle(store.localized("Thông tin liên hệ", "Contact", "联系方式"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(store.localized("Xong", "Done", "完成")) { dismiss() }
                }
            }
        }
    }
}

private struct SettingsCreditsSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    SettingsAvatar(showProfile: false)
                    Text("Dynor").font(.largeTitle.bold())
                    Text("Một màn hình. Một thế giới mới.").font(.title3)
                    Divider()
                    Text("Ghi công công nghệ").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    Text("worse_query").font(.title.weight(.bold))
                    Text("Phát triển bởi forcequitOS. Cơ chế truy cập container được sử dụng trong tính năng cài hình nền PosterBoard của Dynor.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    Link("Mã nguồn worse_query", destination: URL(string: "https://github.com/forcequitOS/worse_query")!)
                    Divider()
                    Text("Minhhozhang").font(.title2.weight(.bold))
                    Text("Cảm ơn Minhhozhang đã đồng hành, hỗ trợ kỹ thuật và đóng góp ý kiến trong quá trình xây dựng, hoàn thiện ứng dụng Dynor.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    Text("Dynor cũng ghi nhận các thành phần bên thứ ba khác theo giấy phép và thông báo trong thư mục ThirdParty của source.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Về Dynor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

/// Dedicated PosterBoard reset flow, inspired by the supplied reference recording.
/// Only Dynor-managed descriptor folders are eligible for removal.
struct DynorResetManagerView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: DynorStore
    @State private var resetting = false
    @State private var confirmReset = false
    @State private var resultMessage: String?
    @State private var installedCount = PosterBoardDescriptorWriter.installedPaths().count

    var body: some View {
        List {
            Section {
                Label(store.localized("Quyền PosterBoard", "PosterBoard access", "PosterBoard 权限"), systemImage: "checkmark.shield")
                HStack {
                    Text(store.localized("Trạng thái", "Status", "状态"))
                    Spacer()
                    Text(PosterBoardAccess.prerequisiteWarning == nil ? store.localized("Có thể thử truy cập", "Access available to attempt", "可尝试访问") : store.localized("Cần kiểm tra quyền", "Access needs checking", "需要检查权限"))
                        .foregroundStyle(.secondary)
                }
                if let warning = PosterBoardAccess.prerequisiteWarning {
                    Text(warning).font(.footnote).foregroundStyle(.secondary)
                }
            } header: {
                Text(store.localized("Kết nối", "Connection", "连接"))
            }
            Section {
                HStack {
                    Label(store.localized("Hình nền Dynor đã ghi", "Dynor-installed wallpapers", "Dynor 已安装壁纸"), systemImage: "photo.on.rectangle")
                    Spacer()
                    Text("\(installedCount)").foregroundStyle(.secondary)
                }
                Button {
                    _ = PosterBoardAccess.requestOpenPosterBoard()
                } label: {
                    Label(store.localized("Mở bộ chọn hình nền", "Open wallpaper picker", "打开壁纸选择器"), systemImage: "rectangle.on.rectangle")
                }
            } header: {
                Text(store.localized("Hình nền", "Wallpapers", "壁纸"))
            } footer: {
                Text(store.localized("Chỉ các cấu hình do Dynor ghi mới được đặt lại. Hình nền khác trên iPhone và các tệp trong Bộ sưu tập vẫn được giữ nguyên.", "Only Dynor-created configurations will be reset. Other iPhone wallpapers and Collection files are preserved.", "仅重置 Dynor 创建的配置。其他 iPhone 壁纸及收藏文件将保留。"))
            }
            Section {
                Button(role: .destructive) { confirmReset = true } label: {
                    HStack {
                        Label(store.localized("Đặt lại bộ sưu tập", "Reset wallpaper collection", "重置壁纸集合"), systemImage: "arrow.counterclockwise")
                        Spacer()
                        if resetting { ProgressView() }
                    }
                }
                .disabled(resetting || installedCount == 0)
            }
        }
        .navigationTitle(store.localized("Đặt lại bộ sưu tập", "Reset collection", "重置集合"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(store.localized("Xong", "Done", "完成")) { dismiss() } } }
        .confirmationDialog(store.localized("Xóa các cấu hình do Dynor đã ghi?", "Remove Dynor-installed configurations?", "移除 Dynor 安装的配置？"), isPresented: $confirmReset) {
            Button(store.localized("Đặt lại", "Reset", "重置"), role: .destructive) { performReset() }
        }
        .alert("Dynor", isPresented: Binding(get: { resultMessage != nil }, set: { if !$0 { resultMessage = nil } })) {
            Button("OK") { resultMessage = nil }
        } message: { Text(resultMessage ?? "") }
    }

    private func performReset() {
        guard !resetting else { return }
        resetting = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: PosterBoardDescriptorWriter.installedPaths()) }
            await MainActor.run {
                resetting = false
                installedCount = PosterBoardDescriptorWriter.installedPaths().count
                switch result {
                case .success(let count):
                    resultMessage = store.localized("Đã đặt lại \(count) cấu hình Dynor. Chúc bạn trải nghiệm vui vẻ!", "Reset \(count) Dynor configurations. Enjoy your experience!", "已重置 \(count) 个 Dynor 配置。祝你使用愉快！")
                case .failure(let error): resultMessage = error.localizedDescription
                }
            }
        }
    }
}
