import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var activeSheet: SettingsSheet?
    @State private var confirmReset = false
    @State private var resetting = false
    @State private var resetMessage: String?

    @StateObject private var account = DynorAccountService.shared
    private var appVersion: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
        return store.localized("Phiên bản \(version) (build \(build))", "Version \(version) (build \(build))", "版本 \(version)（构建 \(build)）")
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    accountRow
                }
                Section {
                    vipRow
                }
                .listRowBackground(Color.clear)
                .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                Section(store.localized("Giao diện", "Appearance", "外观")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Label(store.localized("Chế độ hiển thị", "Display mode", "显示模式"), systemImage: "circle.lefthalf.filled")
                        HStack(spacing: 3) {
                            themeOption(.light, title: store.localized("Sáng", "Light", "浅色"))
                            themeOption(.dark, title: store.localized("Tối", "Dark", "深色"))
                            themeOption(.system, title: store.localized("Tự động", "Automatic", "自动"))
                        }
                        .padding(3)
                        .background(Color(uiColor: .tertiarySystemFill), in: Capsule())
                        .transaction { $0.animation = nil }
                    }
                    .padding(.vertical, 6)
                    Button { activeSheet = .colors } label: {
                        HStack {
                            Label(store.localized("Màu chủ đề", "Theme color", "主题颜色"), systemImage: "paintpalette")
                                .foregroundStyle(.primary)
                            Spacer()
                            Circle().fill(store.accentColor).frame(width: 22, height: 22)
                            chevron
                        }
                        .frame(minHeight: 32)
                    }
                    .buttonStyle(.plain)

                }
                Section(store.localized("Ứng dụng", "Application", "应用")) {
                    NavigationLink {
                        ActivityHistoryView()
                    } label: {
                        settingsLabel(store.localized("Nhật ký hoạt động", "Activity history", "活动历史"), symbol: "clock.arrow.circlepath")
                    }
                    NavigationLink {
                        deviceScreen
                    } label: {
                        settingsLabel(store.localized("Thông tin thiết bị", "Device information", "设备信息"), symbol: "iphone")
                    }
                    NavigationLink {
                        compatibilityScreen
                    } label: {
                        settingsLabel(store.localized("Khả năng tương thích", "Compatibility", "兼容性"), symbol: "checkmark.shield")
                    }
                }
                Section {
                    SettingsLinkRow(title: store.localized("Thông tin liên hệ", "Contact", "联系方式"), symbol: "envelope") { activeSheet = .contact }
                    SettingsLinkRow(title: store.localized("Về Dynor & ghi công", "About Dynor & credits", "关于 Dynor 与致谢"), symbol: "info.circle") { activeSheet = .credits }
                    SettingsLinkRow(title: store.localized("Dữ liệu của bạn", "Your data", "你的数据"), symbol: "lock.shield") { activeSheet = .privacy }
                } header: {
                    Text(store.localized("Thông tin & hỗ trợ", "Information & support", "信息与支持"))
                }
                Section {
                    Button(role: .destructive) { confirmReset = true } label: {
                        HStack {
                            Label(store.localized("Đặt lại hình nền đã cài", "Reset installed wallpapers", "重置已安装的壁纸"), systemImage: "arrow.counterclockwise")
                            Spacer()
                            if resetting { ProgressView() }
                        }
                        .frame(minHeight: 32)
                    }
                    .disabled(resetting)
                } footer: {
                    VStack(alignment: .leading, spacing: 20) {
                        Text(store.localized("Chỉ gỡ cấu hình do Dynor ghi. Tệp trong Bộ sưu tập và hình nền hệ thống được giữ lại.", "Removes configurations created by Dynor. Collection files and system wallpapers are kept.", "仅移除 Dynor 创建的配置，保留收藏文件和系统壁纸。"))
                        Text(appVersion).frame(maxWidth: .infinity).multilineTextAlignment(.center)
                    }
                }
            }
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .background(DynorDesign.canvas)
            .navigationTitle(store.localized("Cài đặt", "Settings", "设置"))
            .confirmationDialog("Đặt lại các hình nền Dynor đã ghi?", isPresented: $confirmReset) {
                Button("Xóa cấu hình Dynor", role: .destructive) { resetInstalled() }
            } message: { Text("Chỉ xóa các cấu hình Dynor đã ghi, không xóa hình nền hệ thống khác.") }
            .alert("Đặt lại bộ sưu tập", isPresented: Binding(get: { resetMessage != nil }, set: { if !$0 { resetMessage = nil } })) {
                Button("OK") { resetMessage = nil }
            } message: { Text(resetMessage ?? "") }
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .account: SettingsAccountSheet()
                case .vip: SettingsVIPSheet()
                case .contact: SettingsInformationSheet(title: "Thông tin liên hệ", symbol: "envelope", text: "Thông tin liên hệ của nhà phát triển chưa được cung cấp. Email, số điện thoại và liên kết hỗ trợ cần được cập nhật trước khi phát hành.")
                case .credits: SettingsCreditsSheet()
                case .colors: ThemeColorPickerView()
                case .privacy: SettingsInformationSheet(title: "Dữ liệu ở lại với bạn", symbol: "lock.shield", text: "Ảnh và tệp Tendies bạn nhập được sao chép vào vùng lưu trữ riêng của Dynor trên thiết bị. Tên hồ sơ trải nghiệm, ID, giao diện, yêu thích và tiến trình quảng cáo mô phỏng được lưu cục bộ.\n\nGói Tendies được kiểm tra và ghi trực tiếp vào container PosterBoard qua worse_query. Cơ chế này cần App Group được cấp quyền trong chữ ký IPA. Dynor đọc lại và đối chiếu dữ liệu đã ghi; bạn chọn hình nền trong bộ chọn của iOS.\n\nBản này chưa có tài khoản được xác thực hoặc đồng bộ đám mây. Gỡ ứng dụng có thể làm mất dữ liệu cục bộ. Ảnh đã lưu vào ứng dụng Ảnh được quản lý riêng bởi iOS.")
                }
            }
        }
    }


    // Fixed-width segments prevent UIKit's UISegmentedControl from briefly
    // overlapping/repositioning labels during a color-scheme transition.
    private func themeOption(_ mode: ThemeMode, title: String) -> some View {
        Button {
            var transaction = Transaction(animation: nil)
            transaction.disablesAnimations = true
            withTransaction(transaction) { store.theme = mode }
        } label: {
            Text(title)
                .font(.system(size: 13, weight: store.theme == mode ? .semibold : .medium))
                .foregroundStyle(Color.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
                .frame(maxWidth: .infinity, minHeight: 32)
                .background {
                    if store.theme == mode {
                        Capsule().fill(Color(uiColor: .secondarySystemGroupedBackground))
                            .shadow(color: .black.opacity(0.09), radius: 2, y: 1)
                    }
                }
                .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(store.theme == mode ? [.isSelected] : [])
    }

    private var chevron: some View {
        Image(systemName: "chevron.right")
            .font(.caption.weight(.semibold))
            .foregroundStyle(.tertiary)
    }

    private func settingsLabel(_ title: String, symbol: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: 29, height: 29)
                .background(Color.blue, in: RoundedRectangle(cornerRadius: 7))
            Text(title)
        }
        .frame(minHeight: 32)
    }

    private var accountRow: some View {
        Button { activeSheet = .account } label: {
            HStack(spacing: 14) {
                SettingsAvatar()
                VStack(alignment: .leading, spacing: 4) {
                    Text(account.email ?? store.profile?.name ?? store.localized("Đăng nhập Dynor", "Sign in to Dynor", "登录 Dynor"))
                        .font(.headline)
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(account.email == nil
                         ? store.localized("Đồng bộ yêu thích và quyền lợi VIP", "Sync favorites and VIP access", "同步收藏与 VIP 权益")
                         : (account.isVIP ? "Dynor VIP" : store.localized("Quản lý tài khoản", "Manage account", "管理账户")))
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                chevron
            }
            .padding(.vertical, 4)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var vipRow: some View {
        Button { activeSheet = .vip } label: {
            HStack(spacing: 14) {
                Image(systemName: "crown.fill")
                    .font(.title2)
                    .foregroundStyle(.blue)
                    .frame(width: 44, height: 44)
                    .background(Color.blue.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 4) {
                    Text("Dynor VIP").font(.headline).foregroundStyle(.primary)
                    Text(account.isVIP
                         ? store.localized("Đang hoạt động", "Active", "已启用")
                         : store.localized("Xem các gói · Từ 39.000đ / tuần", "View plans · From 39,000₫ / week", "查看计划 · 每周 39,000₫ 起"))
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                chevron
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .modifier(DynorGlass(radius: 20, interactive: true))
        }
        .buttonStyle(.plain)
    }

    private var deviceScreen: some View {
        List {
            Section {
                deviceRow("Thiết bị", UIDevice.current.model)
                deviceRow("Tên thiết bị", UIDevice.current.name)
                deviceRow("Hệ điều hành", "iOS " + UIDevice.current.systemVersion)
                deviceRow("Phiên bản Dynor", appVersion)
            }
            Section {
                deviceRow("Bundle ID", Bundle.main.bundleIdentifier ?? "—")
                deviceRow("App Group", PosterBoardAccess.prerequisiteWarning == nil ? "Có quyền truy cập" : "Chưa sẵn sàng")
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(store.localized("Thiết bị", "Device", "设备"))
        .navigationBarTitleDisplayMode(.inline)
    }

    private func deviceRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(title)
            Spacer(minLength: 8)
            Text(value).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
        }
    }

    private var compatibilityScreen: some View {
        List {
            Section {
                compatibilityRow("iOS 26.0 – 26.7.2", "Có thể thử", .green)
                compatibilityRow("iOS 27.0 – 27.2.0", "Có thể thử", .green)
                compatibilityRow("Các phiên bản khác", "Chưa hỗ trợ", .orange)
            } footer: {
                Text("Phạm vi cơ chế worse_query được khai báo; không đồng nghĩa mọi bản đều đã kiểm thử.")
            }
            Section {
                Label(TendiesCompatibility.current.canAttemptInstall ? "Phiên bản iOS hiện tại nằm trong phạm vi thử nghiệm" : "Phiên bản iOS hiện tại nằm ngoài phạm vi", systemImage: "info.circle")
                    .foregroundStyle(.secondary)
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(store.localized("Tương thích", "Compatibility", "兼容性"))
        .navigationBarTitleDisplayMode(.inline)
    }

    private func compatibilityRow(_ version: String, _ status: String, _ color: Color) -> some View {
        HStack {
            Text(version)
            Spacer()
            Text(status).font(.subheadline).foregroundStyle(color)
        }
    }

    private func resetInstalled() {
        resetting = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: PosterBoardDescriptorWriter.installedPaths()) }
            await MainActor.run {
                resetting = false
                switch result {
                case .success(let count): resetMessage = "Đã xóa \(count) cấu hình Dynor."
                case .failure(let error): resetMessage = error.localizedDescription
                }
            }
        }
    }
}

private enum SettingsSheet: String, Identifiable {
    case account, vip, contact, credits, privacy, colors
    var id: String { rawValue }
}

private struct SettingsHeader: View {
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.title2.bold())
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct SettingsGlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .modifier(DynorGlass(radius: 20))
    }
}

private struct SettingsAvatar: View {
    var body: some View {
        Image(systemName: "person.fill")
            .font(.system(size: 26, weight: .medium))
            .foregroundStyle(.blue)
            .frame(width: 52, height: 52)
            .background(Color.blue.opacity(0.12), in: Circle())
            .accessibilityHidden(true)
    }
}

private struct SettingsLinkRow: View {
    let title: String
    let symbol: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundStyle(.white)
                    .frame(width: 29, height: 29)
                    .background(Color.blue, in: RoundedRectangle(cornerRadius: 7))
                Text(title).foregroundStyle(.primary)
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .frame(minHeight: 32)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

private struct SettingsAccountSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var inputEmail = ""
    @State private var otp = ""
    @State private var awaitingOTP = false
    @State private var working = false
    @State private var errorText: String?

    private var validEmail: Bool {
        let value = inputEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.contains("@") && value.split(separator: "@").last?.contains(".") == true
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 14) {
                        Text("D")
                            .font(.title2.bold())
                            .foregroundStyle(store.accentTextColor)
                            .frame(width: 52, height: 52)
                            .background(store.accentColor, in: RoundedRectangle(cornerRadius: 16))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Dynor").font(.title3.bold())
                            Text("Không gian của riêng bạn")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.bottom, 32)

                    VStack(alignment: .leading, spacing: 23) {
                        HStack {
                            Image(systemName: "crown.fill").font(.title2)
                            Spacer()
                            Image(systemName: "sparkle").foregroundStyle(.secondary)
                        }
                        Text(account.email == nil ? "Chào mừng trở lại." : "Tài khoản của bạn.")
                            .font(.title2.bold())
                            .minimumScaleFactor(0.8)
                            .lineLimit(2)
                        Text(account.email == nil
                             ? "Đăng nhập bằng email để khám phá trải nghiệm Dynor của bạn."
                             : "Tài khoản Dynor của bạn đã được xác minh.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)

                        if let email = account.email {
                            VStack(alignment: .leading, spacing: 13) {
                                Text("EMAIL ĐANG ĐĂNG NHẬP")
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text(email).font(.headline).textSelection(.enabled)
                                Label(account.isVIP ? "Dynor VIP đang hoạt động" : "Tài khoản thường",
                                      systemImage: account.isVIP ? "crown.fill" : "person.crop.circle")
                                if let date = account.vipExpiresAt, account.isVIP {
                                    Text("VIP đến: \(date.formatted(date: .abbreviated, time: .shortened))")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                }
                                Button("Kiểm tra lại trạng thái VIP") {
                                    Task { await account.refreshVIP() }
                                }
                                .foregroundStyle(.primary)
                                Button("Đăng xuất", role: .destructive) {
                                    account.signOut(); awaitingOTP = false; otp = ""
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        } else {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Địa chỉ email").font(.subheadline.weight(.semibold))
                                TextField(text: $inputEmail, prompt: Text("tenban@gmail.com").foregroundColor(Color(uiColor: .lightGray))) { EmptyView() }
                                    .textContentType(.emailAddress)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .padding(16)
                                    .background(DynorDesign.canvas,
                                                in: RoundedRectangle(cornerRadius: 15))
                                    
                                    .disabled(awaitingOTP)
                                if awaitingOTP {
                                    Text("Mã xác minh gồm 6 chữ số")
                                        .font(.subheadline.weight(.semibold))
                                    TextField(text: $otp, prompt: Text("Nhập mã OTP").foregroundColor(.gray)) { EmptyView() }
                                        .keyboardType(.numberPad)
                                        .textContentType(.oneTimeCode)
                                        .padding(16)
                                        .background(DynorDesign.canvas,
                                                    in: RoundedRectangle(cornerRadius: 15))
                                        
                                    Button {
                                        Task {
                                            await perform {
                                                try await account.verifyOTP(email: inputEmail, code: otp)
                                            }
                                            if account.email != nil { awaitingOTP = false }
                                        }
                                    } label: {
                                        primaryButton("Xác minh & đăng nhập")
                                    }
                                    .buttonStyle(DynorPrimaryButtonStyle())
                                    .disabled(working || otp.count != 6)
                                    Button("Gửi lại mã") {
                                        Task { await perform { try await account.sendOTP(to: inputEmail) } }
                                    }.disabled(working)
                                    Button("Đổi email") { awaitingOTP = false; otp = "" }
                                } else {
                                    Button {
                                        Task {
                                            await perform { try await account.sendOTP(to: inputEmail) }
                                            if errorText == nil { awaitingOTP = true }
                                        }
                                    } label: {
                                        primaryButton("Nhận mã xác minh")
                                    }
                                    .buttonStyle(DynorPrimaryButtonStyle())
                                    .disabled(working || !validEmail)
                                }
                            }
                        }
                        if working { ProgressView() }
                        if let errorText {
                            Text(errorText).font(.footnote).foregroundStyle(.red)
                        }
                        if !account.statusMessage.isEmpty {
                            Text(account.statusMessage)
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                        if account.email == nil {
                            Text("Mã OTP gồm 6 chữ số sẽ được gửi tới email của bạn.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .padding(22)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .modifier(DynorGlass(radius: 22))
                    
                    .padding(.bottom, 24)

                    Text("Tài khoản được bảo vệ bằng mã xác minh email")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                }
                .frame(maxWidth: 620)
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .frame(maxWidth: .infinity)
                .padding(.bottom, 40)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Tài khoản")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }

    private func primaryButton(_ title: String) -> some View {
        Label(title, systemImage: "arrow.right")
            .frame(maxWidth: .infinity)
    }

    private func perform(_ operation: @escaping () async throws -> Void) async {
        working = true; errorText = nil
        defer { working = false }
        do { try await operation() }
        catch { errorText = error.localizedDescription }
    }
}

private struct SettingsVIPSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var selected = SettingsVIPPlan.month
    @State private var order: DynorPaymentOrder?
    @State private var paymentError: String?
    @State private var busy = false
    @State private var checking = false
    @State private var paidNotice = false
    @State private var completedCode: String?
    @State private var pollingTask: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Image(systemName: "crown.fill")
                        .font(.title)
                        .foregroundStyle(.blue)
                    SettingsHeader(title: "Dynor VIP", subtitle: store.localized("Mọi hình nền, không cần xem quảng cáo khi VIP còn hạn.", "All wallpapers, without ads while VIP is active.", "VIP 有效期间畅享所有壁纸，无需观看广告。"))
                    ForEach(SettingsVIPPlan.allCases) { plan in
                        Button {
                            stopPolling()
                            selected = plan
                            order = nil
                            paymentError = nil
                            paidNotice = false
                        } label: {
                            HStack(spacing: 14) {
                                Image(systemName: selected == plan ? "checkmark.circle.fill" : "circle")
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(store.localized(plan.title, plan.englishTitle, plan.chineseTitle)).font(.headline)
                                    Text(store.localized(plan.duration, plan.englishDuration, plan.chineseDuration)).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(plan.price).font(.headline)
                            }
                            .padding(18)
                            .modifier(DynorGlass(radius: 18, interactive: true))
                            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(selected == plan ? store.accentColor : Color.clear, lineWidth: 1.5))
                        }.buttonStyle(.plain)
                    }
                    if account.isVIP {
                        Label("VIP đang hoạt động", systemImage: "checkmark.seal.fill")
                        if let date = account.vipExpiresAt {
                            Text("Hạn: \(date.formatted(date: .numeric, time: .shortened))")
                        } else {
                            Text("Gói VIP vĩnh viễn")
                        }
                    }
                    if paidNotice {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Label("Thanh toán thành công!", systemImage: "checkmark.seal.fill")
                                    .font(.headline)
                                    .foregroundStyle(.green)
                                Text("Gói VIP đã được cập nhật. Mã QR cũ đã được ẩn để tránh chuyển khoản trùng.")
                                    .font(.subheadline)
                                if let date = account.vipExpiresAt {
                                    Text("Hạn VIP mới: \(date.formatted(date: .numeric, time: .shortened))")
                                        .font(.subheadline.weight(.semibold))
                                }
                                Button("Mua thêm gói VIP") {
                                    paidNotice = false
                                    completedCode = nil
                                }
                                .font(.subheadline.weight(.semibold))
                            }
                        }
                    }
                    if let order, !paidNotice {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 14) {
                                Text("Chuyển khoản để kích hoạt VIP").font(.headline)
                                if let url = order.qrURL {
                                    AsyncImage(url: url) { image in
                                        image.resizable().scaledToFit()
                                    } placeholder: {
                                        ProgressView().frame(height: 240)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 260)
                                    .accessibilityLabel("QR thanh toán ngân hàng")
                                }
                                Text("Ngân hàng: \(order.bankName)")
                                Text("Số tài khoản: \(order.bankAccount)").textSelection(.enabled)
                                Text("Số tiền: \(order.amount.formatted())đ").font(.headline)
                                Text("Nội dung chuyển khoản:").font(.caption).foregroundStyle(.secondary)
                                Text(order.paymentCode)
                                    .font(.system(.body, design: .monospaced).weight(.semibold))
                                    .textSelection(.enabled)
                                ShareLink("Chia sẻ mã thanh toán", item: order.paymentCode)
                                HStack(spacing: 8) {
                                    ProgressView().controlSize(.small)
                                    Text("Đang tự động kiểm tra thanh toán...")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Text("Chỉ chuyển khoản đúng số tiền và nội dung trên. Sau khi ngân hàng ghi nhận, mã QR sẽ tự ẩn.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if let paymentError {
                        Text(paymentError).font(.caption).foregroundStyle(.red)
                    }
                    if order == nil && !paidNotice {
                        Button { Task { await createOrder() } } label: {
                            HStack {
                                Spacer()
                                if busy { ProgressView().tint(.white) }
                                Text("Tạo đơn trong Dynor").font(.headline)
                                Spacer()
                            }
                        }
                        .buttonStyle(DynorPrimaryButtonStyle())
                        .disabled(busy || account.email == nil)
                    }
                    if account.email == nil {
                        Text("Đăng nhập tài khoản Dynor trước khi tạo đơn.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Button {
                        Task {
                            if let code = order?.paymentCode {
                                await checkPayment(code: code, showError: true)
                            } else {
                                await account.refreshVIP()
                            }
                        }
                    } label: {
                        HStack {
                            if checking { ProgressView().controlSize(.small) }
                            Text("Kiểm tra lại VIP")
                        }
                    }
                    .disabled(checking)
                    .foregroundStyle(.primary)
                }
                .frame(maxWidth: 620)
                .padding(24)
                .frame(maxWidth: .infinity)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Dynor VIP")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
        .tint(store.accentColor)
        .onDisappear { stopPolling() }
    }

    private func stopPolling() {
        pollingTask?.cancel()
        pollingTask = nil
    }

    private func startPolling(code: String) {
        stopPolling()
        pollingTask = Task {
            while !Task.isCancelled {
                await checkPayment(code: code, showError: false)
                if Task.isCancelled || completedCode == code || order?.paymentCode != code {
                    break
                }
                try? await Task.sleep(for: .seconds(5))
            }
        }
    }

    private func checkPayment(code: String, showError: Bool) async {
        guard order?.paymentCode == code, completedCode != code, !checking else { return }
        checking = true
        defer { checking = false }
        do {
            let status = try await account.paymentStatus(for: code)
            guard !Task.isCancelled, order?.paymentCode == code else { return }
            if status == "paid" {
                completedCode = code
                order = nil
                paidNotice = true
                paymentError = nil
                stopPolling()
                await account.refreshVIP()
            } else if status == "expired" {
                order = nil
                stopPolling()
                paymentError = "Đơn hàng đã hết hạn. Hãy tạo đơn mới."
            } else if showError {
                paymentError = "Máy chủ chưa xác nhận thanh toán. Vui lòng đợi ngân hàng và SePay xử lý."
            }
        } catch {
            if showError { paymentError = error.localizedDescription }
        }
    }

    private func createOrder() async {
        busy = true
        paymentError = nil
        paidNotice = false
        stopPolling()
        defer { busy = false }
        do {
            let newOrder = try await account.createVIPOrder(plan: selected.rawValue)
            order = newOrder
            completedCode = nil
            startPolling(code: newOrder.paymentCode)
        } catch {
            order = nil
            paymentError = error.localizedDescription
        }
    }
}

private enum SettingsVIPPlan: String, CaseIterable, Identifiable {
    case week, month, lifetime
    var id: String { rawValue }
    var title: String { switch self { case .week: return "Thẻ tuần"; case .month: return "Thẻ tháng"; case .lifetime: return "Vĩnh viễn" } }
    var englishTitle: String { switch self { case .week: return "Weekly"; case .month: return "Monthly"; case .lifetime: return "Lifetime" } }
    var chineseTitle: String { switch self { case .week: return "周卡"; case .month: return "月卡"; case .lifetime: return "永久" } }
    var englishDuration: String { switch self { case .week: return "7 days of inspiration"; case .month: return "30 days of discovery"; case .lifetime: return "One purchase, forever" } }
    var chineseDuration: String { switch self { case .week: return "7 天灵感"; case .month: return "30 天探索"; case .lifetime: return "一次购买，永久使用" } }
    var price: String { switch self { case .week: return "39.000đ"; case .month: return "59.000đ"; case .lifetime: return "99.000đ" } }
    var duration: String { switch self { case .week: return "7 ngày cảm hứng"; case .month: return "30 ngày khám phá"; case .lifetime: return "Một lần chọn, mãi mãi" } }
}

private struct SettingsInformationSheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let symbol: String
    let text: String
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Image(systemName: symbol).font(.system(size: 36)).foregroundStyle(.secondary)
                    Text(title).font(.title2.bold())
                    Text(text).font(.body).foregroundStyle(.secondary).lineSpacing(5)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(DynorDesign.canvas)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

private struct SettingsCreditsSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    SettingsAvatar()
                    Text("Dynor").font(.largeTitle.bold())
                    Text("Một màn hình. Một thế giới mới.").font(.title3)
                    Text("Ứng dụng iOS viết bằng SwiftUI theo yêu cầu của bạn. Icon sử dụng ảnh bạn cung cấp. Hình nền trưng bày: Unsplash.")
                        .foregroundStyle(.secondary)
                    Divider()
                    Text("Ghi công công nghệ").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    Text("worse_query").font(.title.weight(.bold))
                    Text("Phát triển bởi forcequitOS. Cơ chế truy cập container được sử dụng trong tính năng cài hình nền PosterBoard của Dynor.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    Link("Mã nguồn worse_query", destination: URL(string: "https://github.com/forcequitOS/worse_query")!)
                    Text("Dynor cũng ghi nhận các thành phần bên thứ ba khác theo giấy phép và thông báo trong thư mục ThirdParty của source.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Về Dynor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

