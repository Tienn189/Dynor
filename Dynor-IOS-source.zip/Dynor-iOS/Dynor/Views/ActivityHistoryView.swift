import SwiftUI
import UIKit

struct ActivityHistoryView: View {
    @ObservedObject private var journal = ActivityJournal.shared
    @State private var confirmClear = false
    private var logText: String {
        journal.entries.map { item in
            let stamp = item.date.formatted(.dateTime.year().month(.twoDigits).day(.twoDigits).hour().minute().second())
            return "[\(stamp)] [DYNOR] \(item.success ? "OK" : "ERROR") · \(item.title)\n\(item.detail)"
        }.joined(separator: "\n\n")
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                if journal.entries.isEmpty {
                    DynorEmptyState(symbol: "clock", title: "Chưa có hoạt động", message: "Các lần nhập và cài hình nền sẽ xuất hiện tại đây.")
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(journal.entries) { event in
                            HStack(alignment: .top, spacing: 14) {
                                Image(systemName: event.success ? "checkmark" : "exclamationmark")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundStyle(event.success ? DynorDesign.ink : Color.orange)
                                    .frame(width: 36, height: 36)
                                    .background(DynorDesign.mist, in: Circle())
                                    .accessibilityLabel(event.success ? "Hoàn tất" : "Có lỗi")
                                VStack(alignment: .leading, spacing: 7) {
                                    Text(event.title).font(.subheadline.weight(.semibold)).foregroundStyle(DynorDesign.ink)
                                    if !event.detail.isEmpty {
                                        Text(event.detail).font(.caption).foregroundStyle(DynorDesign.muted)
                                            .fixedSize(horizontal: false, vertical: true)
                                    }
                                    Text(event.date.formatted(date: .abbreviated, time: .shortened))
                                        .font(.caption2).foregroundStyle(DynorDesign.muted)
                                }
                                Spacer(minLength: 0)
                            }
                            .padding(18)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 20))
                        }
                    }
                }
            }
            .padding(24)
            .frame(maxWidth: 720)
            .frame(maxWidth: .infinity)
        }
        .background(DynorDesign.canvas)
        .navigationTitle("Nhật ký hoạt động")
        .navigationBarTitleDisplayMode(.large)
        .toolbar(.visible, for: .navigationBar)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { UIPasteboard.general.string = logText } label: { Image(systemName: "doc.on.doc") }
                    .accessibilityLabel("Sao chép nhật ký").disabled(journal.entries.isEmpty)
                ShareLink(item: logText) { Image(systemName: "square.and.arrow.up") }
                    .accessibilityLabel("Chia sẻ nhật ký").disabled(journal.entries.isEmpty)
                Button("Xóa", role: .destructive) { confirmClear = true }.disabled(journal.entries.isEmpty)
            }
        }
        .confirmationDialog("Xóa toàn bộ nhật ký?", isPresented: $confirmClear) {
            Button("Xóa nhật ký", role: .destructive) { journal.clear() }
        }
    }
}
