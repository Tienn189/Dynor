import SwiftUI
import UIKit

struct ActivityHistoryView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var journal = ActivityJournal.shared
    @State private var confirmClear = false

    private var logText: String {
        journal.entries.map { event in
            "[\(event.date.formatted(.dateTime.year().month(.twoDigits).day(.twoDigits).hour().minute().second()))] [Dynor] \(event.success ? "OK" : "ERROR") · \(event.title)\(event.detail.isEmpty ? "" : " — " + event.detail)"
        }.joined(separator: "\n")
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                if journal.entries.isEmpty {
                    Text("Chưa có nhật ký hoạt động.")
                        .font(.system(size: 15, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .padding(.vertical, 28)
                } else {
                    ForEach(journal.entries) { event in
                        VStack(alignment: .leading, spacing: 6) {
                            Text("[Dynor] \(event.title)")
                            if !event.detail.isEmpty { Text(event.detail) }
                            Text(event.date.formatted(.dateTime.year().month(.twoDigits).day(.twoDigits).hour().minute().second()))
                                .foregroundStyle(.secondary)
                                .font(.system(size: 12, design: .monospaced))
                        }
                        .font(.system(size: 14, design: .monospaced))
                        .foregroundStyle(.primary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 18)
                        Divider()
                    }
                }
            }
            .padding(.horizontal, 18)
            .padding(.top, 20)
        }
        .background(DynorDesign.canvas)
        .navigationTitle("Nhật ký hoạt động")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button("Xóa", role: .destructive) { confirmClear = true }
                    .disabled(journal.entries.isEmpty)
            }
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { UIPasteboard.general.string = logText } label: {
                    Image(systemName: "doc.on.doc")
                }
                .accessibilityLabel("Sao chép nhật ký")
                .disabled(journal.entries.isEmpty)
                ShareLink(item: logText) { Image(systemName: "square.and.arrow.up") }
                    .disabled(journal.entries.isEmpty)
                Button("Xong") { dismiss() }
            }
        }
        .alert("Xóa toàn bộ nhật ký?", isPresented: $confirmClear) {
            Button("Hủy", role: .cancel) { }
            Button("Xóa nhật ký", role: .destructive) { journal.clear() }
        } message: {
            Text("Tất cả bản ghi hoạt động trong Dynor sẽ bị xóa.")
        }
    }
}
