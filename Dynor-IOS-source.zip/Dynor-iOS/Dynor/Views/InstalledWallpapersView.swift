import SwiftUI
import UIKit

/// iOS does not expose a public API to enumerate all system wallpapers.
/// This screen displays descriptors successfully written by Dynor.
struct InstalledWallpapersView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var paths: [String] = []
    @State private var thumbnails: [String: UIImage] = [:]
    @State private var selected = Set<String>()
    @State private var selecting = false
    @State private var busy = false
    @State private var message: String?
    @State private var confirmDelete = false
    @State private var previewPath: String?
    private let columns = [GridItem(.adaptive(minimum: 128, maximum: 250), spacing: 14)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                deviceSummary
                HStack {
                    Text(store.localized("Hình nền đã cài", "Installed wallpapers", "已安装的壁纸"))
                        .font(.headline)
                    Spacer(minLength: 8)
                    Button {
                        selecting.toggle()
                        selected.removeAll()
                    } label: {
                        Text(selecting ? store.localized("Xong", "Done", "完成") : store.localized("Chọn", "Select", "选择"))
                            .font(.subheadline.weight(.medium)).foregroundStyle(store.accentColor)
                            .padding(.horizontal, 16).frame(height: 44)
                            .modifier(DynorGlass(radius: 22, interactive: true))
                    }.disabled(paths.isEmpty || busy)
                }
                if paths.isEmpty {
                    ContentUnavailableView {
                        Label(store.localized("Chưa có hình nền đã cài", "No installed wallpapers", "暂无已安装壁纸"), systemImage: "iphone")
                    } description: {
                        Text(store.localized("Hình nền bạn cài từ Bộ sưu tập sẽ xuất hiện tại đây.", "Wallpapers installed from Collection will appear here.", "从收藏中安装的壁纸会显示在这里。"))
                    } actions: {
                        Button(store.localized("Mở Bộ sưu tập", "Open Collection", "打开收藏")) {
                            store.selectedTab = .library
                        }.buttonStyle(.bordered)
                    }
                    .padding(.vertical, 30)
                } else {
                    LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                        ForEach(paths, id: \.self) { path in installedItem(path) }
                    }
                }
                if selecting && !selected.isEmpty {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label(store.localized("Xóa \(selected.count) hình nền", "Delete \(selected.count) wallpapers", "删除 \(selected.count) 张壁纸"), systemImage: "trash")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity).padding(16)
                            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
                    }.disabled(busy)
                }
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "info.circle").padding(.top, 1)
                    Text(store.localized("Chỉ hiển thị hình nền do Dynor cài. Một số gói không có ảnh xem trước.", "Shows wallpapers installed by Dynor. Some packages do not include a preview.", "仅显示 Dynor 安装的壁纸。部分壁纸包不含预览图。"))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .font(.caption).foregroundStyle(DynorDesign.muted)
            }
            .frame(maxWidth: 920)
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .navigationTitle(store.localized("Đã cài", "Installed", "已安装"))
        .navigationBarTitleDisplayMode(.large)
        .onAppear { reload() }
        .sheet(item: Binding(get: { previewPath.map { PreviewSelection(path: $0) } },
                             set: { previewPath = $0?.path })) { item in
            NavigationStack {
                VStack(spacing: 18) {
                    Spacer()
                    if let image = thumbnails[item.path] {
                        Image(uiImage: image).resizable().scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                            .padding(.horizontal, 28)
                    } else {
                        DynorEmptyState(symbol: "photo", title: store.localized("Không có ảnh xem trước", "No preview available", "暂无预览图"), message: store.localized("Gói hình nền không chứa ảnh tĩnh có thể hiển thị.", "This wallpaper package does not include a still preview.", "此壁纸包不含静态预览图。"))
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .background(DynorDesign.canvas)
                .navigationTitle("Xem trước hình nền")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) {
                    Button("Đóng") { previewPath = nil }
                } }
            }
        }
        .confirmationDialog("Xóa hình nền đã chọn?", isPresented: $confirmDelete) {
            Button("Xóa", role: .destructive) { deleteSelected() }
        }
        .alert("Dynor", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private var deviceSummary: some View {
        HStack(spacing: 12) {
            Image(systemName: "iphone")
                .font(.title3).foregroundStyle(store.accentColor).accessibilityHidden(true)
            Text(store.localized("\(paths.count) hình nền trên thiết bị", "\(paths.count) wallpapers on your device", "设备上有 \(paths.count) 张壁纸"))
                .font(.subheadline.weight(.medium))
            Spacer(minLength: 0)
            Button(action: reload) {
                Group {
                    if busy { ProgressView() }
                    else { Image(systemName: "arrow.clockwise").font(.body.weight(.medium)) }
                }
                .frame(width: 44, height: 44)
            }
            .foregroundStyle(store.accentColor)
            .disabled(busy)
            .accessibilityLabel(store.localized("Làm mới hình nền đã cài", "Refresh installed wallpapers", "刷新已安装壁纸"))
        }
        .padding(.leading, 16).padding(.trailing, 6).padding(.vertical, 6)
        .modifier(DynorGlass(radius: 20))
    }

    private func installedItem(_ path: String) -> some View {
        Button {
            if selecting {
                if selected.contains(path) { selected.remove(path) }
                else { selected.insert(path) }
            } else { previewPath = path }
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                GeometryReader { geometry in
                    ZStack {
                        DynorDesign.mist
                        if let image = thumbnails[path] {
                            Image(uiImage: image).resizable().scaledToFill()
                                .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                        } else {
                            VStack(spacing: 12) {
                                Image(systemName: "photo.artframe").font(.system(size: 28, weight: .light))
                                Text(store.localized("Không có ảnh xem trước", "No preview", "暂无预览图")).font(.caption2).multilineTextAlignment(.center)
                            }.foregroundStyle(DynorDesign.muted)
                        }
                    }
                }
                .aspectRatio(0.72, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 22))
                .overlay(alignment: .topTrailing) {
                    if selecting {
                        Image(systemName: selected.contains(path) ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 26, weight: .semibold))
                            .foregroundStyle(selected.contains(path) ? store.accentColor : .white)
                            .padding(10).background(.black.opacity(0.12), in: Circle()).padding(6)
                    }
                }
                Text(store.localized("Hình nền Dynor", "Dynor wallpaper", "Dynor 壁纸"))
                    .font(.subheadline.weight(.semibold)).foregroundStyle(DynorDesign.ink)
                Text(URL(fileURLWithPath: path).lastPathComponent.prefix(8).uppercased())
                    .font(.caption2)
                    .foregroundStyle(DynorDesign.muted)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(DynorPressStyle(scale: 0.98))
        .disabled(busy)
        .accessibilityLabel(store.localized("Hình nền Dynor", "Dynor wallpaper", "Dynor 壁纸") + " " + String(URL(fileURLWithPath: path).lastPathComponent.prefix(8)))
        .accessibilityValue(selecting ? (selected.contains(path) ? store.localized("Đã chọn", "Selected", "已选择") : store.localized("Chưa chọn", "Not selected", "未选择")) : "")
    }

    private func reload() {
        paths = PosterBoardDescriptorWriter.installedPaths()
        let current = paths
        Task.detached(priority: .utility) {
            let loaded = PosterBoardDescriptorWriter.previewImages(paths: current)
            await MainActor.run { thumbnails = loaded }
        }
    }

    private func deleteSelected() {
        let targets = Array(selected)
        busy = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: targets) }
            await MainActor.run {
                busy = false
                switch result {
                case .success(let count): message = "Đã xóa \(count) hình nền Dynor."
                case .failure(let error): message = error.localizedDescription
                }
                reload()
                selected.removeAll()
                selecting = false
            }
        }
    }
}

private struct PreviewSelection: Identifiable {
    let path: String
    var id: String { path }
}
