import SwiftUI
import UIKit

/// iOS does not expose a public API to enumerate all system wallpapers.
/// This screen displays descriptors successfully written by Dynor.
struct InstalledWallpapersView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var paths: [String] = []
    @State private var thumbnails: [String: UIImage] = [:]
    @State private var selected = Set<String>()
    @State private var selecting = false
    @State private var busy = false
    @State private var message: String?
    @State private var confirmDelete = false
    @State private var previewPath: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                deviceSummary
                if selecting {
                    HStack(spacing: 10) {
                        Button {
                            withAnimation(.easeInOut(duration: 0.24)) {
                                if selected.count == paths.count { selected.removeAll() }
                                else { selected = Set(paths) }
                            }
                        } label: {
                            Text(selected.count == paths.count ? store.localized("Bỏ chọn tất cả", "Deselect all", "取消全选") : store.localized("Chọn tất cả", "Select all", "全选"))
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(store.accentColor)
                                .padding(.horizontal, 12).frame(height: 44)
                                .modifier(DynorGlass(radius: 22, interactive: true))
                        }
                        Spacer(minLength: 2)
                        Text(store.localized("Đã chọn \(selected.count)", "Selected \(selected.count)", "已选 \(selected.count)"))
                            .font(.subheadline.weight(.semibold)).lineLimit(1).minimumScaleFactor(0.8)
                        Spacer(minLength: 2)
                        Button {
                            withAnimation(.easeInOut(duration: 0.25)) { selecting = false; selected.removeAll() }
                        } label: {
                            Text(store.localized("Hoàn tất", "Done", "完成"))
                                .font(.caption.weight(.semibold)).foregroundStyle(store.accentColor)
                                .padding(.horizontal, 12).frame(height: 44)
                                .modifier(DynorGlass(radius: 22, interactive: true))
                        }
                    }
                } else {
                    HStack {
                        Text(store.localized("Hình nền đã cài", "Installed wallpapers", "已安装的壁纸"))
                            .font(.headline)
                        Spacer(minLength: 8)
                        Button {
                            withAnimation(.easeInOut(duration: 0.25)) { selecting = true; selected.removeAll() }
                        } label: {
                            Text(store.localized("Chọn", "Select", "选择"))
                                .font(.subheadline.weight(.medium)).foregroundStyle(store.accentColor)
                                .padding(.horizontal, 16).frame(height: 44)
                                .modifier(DynorGlass(radius: 22, interactive: true))
                        }.disabled(paths.isEmpty || busy)
                    }
                }
                if paths.isEmpty {
                    ContentUnavailableView {
                        Label(store.localized("Chưa có hình nền đã cài", "No installed wallpapers", "暂无已安装壁纸"), systemImage: "iphone")
                    } description: {
                        Text(store.localized("Hình nền bạn cài từ Bộ sưu tập sẽ xuất hiện tại đây.", "Wallpapers installed from Collection will appear here.", "从收藏中安装的壁纸会显示在这里。"))
                    } actions: {
                        Button(store.localized("Mở Bộ sưu tập", "Open Collection", "打开收藏")) {
                            store.selectedTab = .library
                        }.buttonStyle(.bordered)
                    }
                    .padding(.vertical, 30)
                } else {
                    LazyVStack(spacing: 0) {
                        ForEach(paths, id: \.self) { path in
                            installedItem(path)
                            if path != paths.last { Divider().padding(.leading, 96) }
                        }
                    }
                    .padding(.horizontal, 14)
                    .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                }
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "info.circle").padding(.top, 1)
                    Text(store.localized("Chỉ hiển thị hình nền do Dynor cài. Một số gói không có ảnh xem trước.", "Shows wallpapers installed by Dynor. Some packages do not include a preview.", "仅显示 Dynor 安装的壁纸。部分壁纸包不含预览图。"))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .font(.caption).foregroundStyle(DynorDesign.muted)
            }
            .frame(maxWidth: 920)
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if selecting && !selected.isEmpty {
                Button(role: .destructive) { confirmDelete = true } label: {
                    Label(store.localized("Xóa (\(selected.count))", "Delete (\(selected.count))", "删除 (\(selected.count))"), systemImage: "trash")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .modifier(DynorGlass(radius: 25, interactive: true))
                }
                .foregroundStyle(.red)
                .disabled(busy)
                .padding(.horizontal, 24)
                .padding(.bottom, 8)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .navigationTitle(store.localized("Đã cài", "Installed", "已安装"))
        .navigationBarTitleDisplayMode(.large)
        .onAppear { reload() }
        .sheet(item: Binding(get: { previewPath.map { PreviewSelection(path: $0) } },
                             set: { previewPath = $0?.path })) { item in
            NavigationStack {
                VStack(spacing: 18) {
                    Spacer()
                    if let image = thumbnails[item.path] {
                        Image(uiImage: image).resizable().scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                            .padding(.horizontal, 28)
                    } else {
                        DynorEmptyState(symbol: "photo", title: store.localized("Không có ảnh xem trước", "No preview available", "暂无预览图"), message: store.localized("Gói hình nền không chứa ảnh tĩnh có thể hiển thị.", "This wallpaper package does not include a still preview.", "此壁纸包不含静态预览图。"))
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .background(DynorDesign.canvas)
                .navigationTitle("Xem trước hình nền")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) {
                    Button("Đóng") { previewPath = nil }
                } }
            }
        }
        .confirmationDialog("Xóa hình nền đã chọn?", isPresented: $confirmDelete) {
            Button("Xóa", role: .destructive) { deleteSelected() }
        }
        .alert("Dynor", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private var deviceSummary: some View {
        HStack(spacing: 12) {
            Image(systemName: "iphone")
                .font(.title3).foregroundStyle(store.accentColor).accessibilityHidden(true)
            Text(store.localized("\(paths.count) hình nền trên thiết bị", "\(paths.count) wallpapers on your device", "设备上有 \(paths.count) 张壁纸"))
                .font(.subheadline.weight(.medium))
            Spacer(minLength: 0)
            Button(action: reload) {
                Group {
                    if busy { ProgressView() }
                    else { Image(systemName: "arrow.clockwise").font(.body.weight(.medium)) }
                }
                .frame(width: 44, height: 44)
            }
            .foregroundStyle(store.accentColor)
            .disabled(busy)
            .accessibilityLabel(store.localized("Làm mới hình nền đã cài", "Refresh installed wallpapers", "刷新已安装壁纸"))
        }
        .padding(.leading, 16).padding(.trailing, 6).padding(.vertical, 6)
        .modifier(DynorGlass(radius: 20))
    }

    private func installedItem(_ path: String) -> some View {
        Button {
            if selecting {
                withAnimation(.easeInOut(duration: 0.2)) {
                    if selected.contains(path) { selected.remove(path) }
                    else { selected.insert(path) }
                }
            } else { previewPath = path }
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    DynorDesign.mist
                    if let image = thumbnails[path] {
                        Image(uiImage: image).resizable().scaledToFill()
                            .frame(width: 76, height: 76).clipped()
                    } else {
                        Image(systemName: "photo.artframe")
                            .font(.system(size: 25, weight: .light))
                            .foregroundStyle(DynorDesign.muted)
                    }
                }
                .frame(width: 76, height: 76)
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                VStack(alignment: .leading, spacing: 7) {
                    Text(store.localized("Hình nền Dynor", "Dynor wallpaper", "Dynor 壁纸"))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(DynorDesign.ink)
                        .lineLimit(2)
                    Text("ID: " + String(URL(fileURLWithPath: path).lastPathComponent.prefix(8).uppercased()))
                        .font(.caption).foregroundStyle(DynorDesign.muted)
                    Text(store.localized("Đã cài trên thiết bị", "Installed on device", "已安装在设备上"))
                        .font(.caption2).foregroundStyle(DynorDesign.muted)
                }
                Spacer(minLength: 0)
                if selecting {
                    ZStack {
                        Circle()
                            .fill(selected.contains(path) ? store.accentColor : Color.clear)
                        Circle()
                            .strokeBorder(selected.contains(path) ? store.accentColor : DynorDesign.muted.opacity(0.55), lineWidth: 1.7)
                        if selected.contains(path) {
                            Image(systemName: "checkmark")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundStyle(.white)
                        }
                    }
                    .frame(width: 27, height: 27)
                    .padding(.leading, 4)
                    .transition(.scale(scale: 0.75).combined(with: .opacity))
                }
            }
            .padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(DynorPressStyle(scale: 0.99))
        .disabled(busy)
        .accessibilityLabel(store.localized("Hình nền Dynor", "Dynor wallpaper", "Dynor 壁纸") + " " + String(URL(fileURLWithPath: path).lastPathComponent.prefix(8)))
        .accessibilityValue(selecting ? (selected.contains(path) ? store.localized("Đã chọn", "Selected", "已选择") : store.localized("Chưa chọn", "Not selected", "未选择")) : "")
    }

    private func reload() {
        paths = PosterBoardDescriptorWriter.installedPaths()
        let current = paths
        Task.detached(priority: .utility) {
            let loaded = PosterBoardDescriptorWriter.previewImages(paths: current)
            await MainActor.run { thumbnails = loaded }
        }
    }

    private func deleteSelected() {
        let targets = Array(selected)
        busy = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: targets) }
            await MainActor.run {
                busy = false
                switch result {
                case .success(let count): message = "Đã xóa \(count) hình nền Dynor."
                case .failure(let error): message = error.localizedDescription
                }
                reload()
                selected.removeAll()
                selecting = false
            }
        }
    }
}

private struct PreviewSelection: Identifiable {
    let path: String
    var id: String { path }
}
