import SwiftUI

@MainActor
struct PosterBoardView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var notice: String?
    private var ready: Bool { PosterBoardAccess.prerequisiteWarning == nil }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    HStack(spacing: 14) {
                        Image(systemName: "iphone")
                            .font(.title2).foregroundStyle(store.accentColor)
                            .frame(width: 44, height: 52)
                        VStack(alignment: .leading, spacing: 5) {
                            Text(ready ? "Sẵn sàng cài đặt" : "Kiểm tra quyền truy cập")
                                .font(.headline)
                            Text("Hình nền trên thiết bị của bạn")
                                .font(.subheadline).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                    }.dynorSurface()
                    VStack(alignment: .leading, spacing: 15) {
                        Label("Cài hình nền", systemImage: "sparkles.rectangle.stack").font(.title3.bold())
                        Text("Nhập gói Tendies trong Bộ sưu tập, chọn mẫu rồi bấm Cài hình nền. Dynor sẽ xác minh dữ liệu và thử mở PosterBoard để bạn áp dụng.")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Button { store.selectedTab = .library } label: {
                            Label("Đến Bộ sưu tập", systemImage: "arrow.up.right").frame(maxWidth: .infinity).padding(9)
                        }.buttonStyle(DynorPrimaryButtonStyle())
                        Button { if !PosterBoardAccess.requestOpenPosterBoard() { notice = "Không thể mở PosterBoard tự động. Vào Cài đặt → Hình nền → Thêm hình nền mới." } } label: {
                            Label("Mở bộ chọn hình nền", systemImage: "iphone.gen3").frame(maxWidth: .infinity).padding(7)
                        }.buttonStyle(DynorGlassButtonStyle())
                    }.dynorSurface()
                    if let warning = PosterBoardAccess.prerequisiteWarning {
                        Label(warning, systemImage: "exclamationmark.triangle.fill")
                            .font(.caption).foregroundStyle(.orange).padding(16)
                            .frame(maxWidth: .infinity, alignment: .leading).dynorSurface()
                    }
                }.padding(24).frame(maxWidth: 760).frame(maxWidth: .infinity)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Cài hình nền").navigationBarTitleDisplayMode(.large)
            .alert("PosterBoard", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }.tint(store.accentColor)
    }
}

struct DynorSurface: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(DynorDesign.outline.opacity(0.65), lineWidth: 0.7))
    }
}
extension View { func dynorSurface() -> some View { modifier(DynorSurface()) } }
