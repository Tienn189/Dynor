import SwiftUI

/// A dark jewel surface that follows the selected accent color.
struct VIPCardBackground: View {
    let accent: Color
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 15, paused: reduceMotion || scenePhase != .active)) { timeline in
            let time = reduceMotion ? 0 : timeline.date.timeIntervalSinceReferenceDate
            GeometryReader { geometry in
                ZStack {
                    Color(red: 0.035, green: 0.035, blue: 0.055)
                    LinearGradient(colors: [accent.opacity(0.50), accent.opacity(0.12), .black.opacity(0.55)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    RadialGradient(colors: [accent.opacity(0.40), .clear], center: .topTrailing, startRadius: 0, endRadius: geometry.size.width * 0.85)
                    LinearGradient(colors: [.white.opacity(0.13), .clear, .white.opacity(0.04)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    Canvas { context, size in
                        for index in 0..<19 {
                            let x = CGFloat((index * 47 + 13) % 101) / 100 * size.width
                            let y = CGFloat((index * 31 + 17) % 97) / 96 * size.height
                            let pulse = 0.18 + 0.52 * (sin(time * 1.25 + Double(index) * 1.7) + 1) / 2
                            let radius: CGFloat = index.isMultiple(of: 4) ? 2.8 : 1.1
                            let rect = CGRect(x: x - radius, y: y - radius, width: radius * 2, height: radius * 2)
                            context.fill(Path(ellipseIn: rect), with: .color(.white.opacity(pulse)))
                            if index.isMultiple(of: 4) {
                                var star = Path()
                                star.move(to: CGPoint(x: x - 5, y: y))
                                star.addLine(to: CGPoint(x: x + 5, y: y))
                                star.move(to: CGPoint(x: x, y: y - 5))
                                star.addLine(to: CGPoint(x: x, y: y + 5))
                                context.stroke(star, with: .color(.white.opacity(pulse * 0.7)), lineWidth: 0.6)
                            }
                        }
                    }
                }
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
