import SwiftUI
import UIKit

private enum DynorAppIcon: String, CaseIterable, Identifiable {
    case original, petals, dance
    var id: String { rawValue }
    var alternateName: String? {
        switch self {
        case .original: return nil
        case .petals: return "PetalIcon"
        case .dance: return "DanceIcon"
        }
    }
    var preview: String {
        switch self {
        case .original: return "DefaultIconPreview"
        case .petals: return "PetalIconPreview"
        case .dance: return "DanceIconPreview"
        }
    }
    func title(_ store: DynorStore) -> String {
        switch self {
        case .original: return store.localized("Hoa Anh Đào · Mặc định", "Cherry Blossom · Default", "樱花 · 默认")
        case .petals: return store.localized("Cánh Hoa", "Petals", "花瓣")
        case .dance: return store.localized("Vũ Điệu Hồng", "Pink Dance", "粉色之舞")
        }
    }
}

struct AppIconPickerView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var selectedName: String? = UIApplication.shared.alternateIconName
    @State private var changing = false
    @State private var errorMessage: String?

    var body: some View {
        List {
            Section {
                ForEach(DynorAppIcon.allCases) { icon in
                    Button { select(icon) } label: {
                        HStack(spacing: 16) {
                            Image(icon.preview)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 64, height: 64)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                .accessibilityHidden(true)
                            Text(icon.title(store)).foregroundStyle(.primary)
                            Spacer()
                            if selectedName == icon.alternateName {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(store.accentColor)
                            }
                        }
                        .padding(.vertical, 6)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .disabled(changing || !UIApplication.shared.supportsAlternateIcons)
                    .accessibilityAddTraits(selectedName == icon.alternateName ? [.isSelected] : [])
                }
            } footer: {
                Text(store.localized("Chọn biểu tượng Dynor trên màn hình chính.", "Choose the Dynor icon on your Home Screen.", "选择主屏幕上的 Dynor 图标。"))
            }
            if changing {
                HStack {
                    ProgressView()
                    Text(store.localized("Đang đổi icon…", "Changing icon…", "正在更换图标…"))
                }
            }
            if !UIApplication.shared.supportsAlternateIcons {
                Text(store.localized("Bản cài đặt này chưa hỗ trợ đổi icon.", "This installation does not support alternate icons.", "此安装版本不支持更换图标。"))
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle(store.localized("Icon ứng dụng", "App icon", "应用图标"))
        .navigationBarTitleDisplayMode(.inline)
        .tint(store.accentColor)
        .onAppear { selectedName = UIApplication.shared.alternateIconName }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { selectedName = UIApplication.shared.alternateIconName }
        }
        .alert(store.localized("Không thể đổi icon", "Cannot change icon", "无法更换图标"), isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button(store.localized("Đã hiểu", "OK", "知道了")) { errorMessage = nil }
        } message: { Text(errorMessage ?? "") }
    }

    private func select(_ icon: DynorAppIcon) {
        guard !changing, UIApplication.shared.supportsAlternateIcons,
              UIApplication.shared.alternateIconName != icon.alternateName else { return }
        changing = true
        UIApplication.shared.setAlternateIconName(icon.alternateName) { error in
            DispatchQueue.main.async {
                changing = false
                selectedName = UIApplication.shared.alternateIconName
                if let error { errorMessage = error.localizedDescription }
            }
        }
    }
}
