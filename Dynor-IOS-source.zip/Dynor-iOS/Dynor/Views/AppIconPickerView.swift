import SwiftUI
import UIKit

private enum DynorAppIcon: String, CaseIterable, Identifiable {
    case original, dance
    var id: String { rawValue }
    var alternateName: String? {
        switch self {
        case .original: return nil
        case .dance: return "DanceIcon"
        }
    }
    var preview: String {
        switch self {
        case .original: return "DefaultIconPreview"
        case .dance: return "DanceIconPreview"
        }
    }
    @MainActor
    func title(_ store: DynorStore) -> String {
        switch self {
        case .original: return store.localized("Hoa Anh Đào", "Cherry Blossom", "樱花")
        case .dance: return store.localized("Vũ Điệu Hồng", "Pink Dance", "粉色之舞")
        }
    }
}

@MainActor
struct AppIconPickerView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var selectedName: String? = UIApplication.shared.alternateIconName
    @AppStorage("dynor.appIcon.confirmed") private var confirmedIcon = ""
    @State private var changing = false
    @State private var errorMessage: String?

    var body: some View {
        List {
            Section {
                ForEach(DynorAppIcon.allCases) { icon in
                    Button { select(icon) } label: {
                        HStack(spacing: 16) {
                            Image(icon.preview)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                .accessibilityHidden(true)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(icon.title(store)).foregroundStyle(.primary)
                                if icon == .original {
                                    Text(store.localized("Mặc định", "Default", "默认"))
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(store.accentColor)
                                .frame(width: 24, height: 24)
                                .opacity(selectedName == icon.alternateName ? 1 : 0)
                                .accessibilityHidden(true)
                        }
                        .frame(minHeight: 80, alignment: .center)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowInsets(EdgeInsets(top: 8, leading: 20, bottom: 8, trailing: 20))
                    .alignmentGuide(.listRowSeparatorLeading) { _ in 0 }
                    .disabled(changing || !UIApplication.shared.supportsAlternateIcons)
                    .accessibilityAddTraits(selectedName == icon.alternateName ? [.isSelected] : [])
                }
            } footer: {
                Text(store.localized("Chọn biểu tượng Dynor trên màn hình chính.", "Choose the Dynor icon on your Home Screen.", "选择主屏幕上的 Dynor 图标。"))
            }
            if changing {
                HStack {
                    ProgressView()
                    Text(store.localized("Đang đổi icon…", "Changing icon…", "正在更换图标…"))
                }
            }
            if !UIApplication.shared.supportsAlternateIcons {
                Text(store.localized("Bản cài đặt này chưa hỗ trợ đổi icon.", "This installation does not support alternate icons.", "此安装版本不支持更换图标。"))
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle(store.localized("Icon ứng dụng", "App icon", "应用图标"))
        .navigationBarTitleDisplayMode(.inline)
        .tint(store.accentColor)
        .onAppear { restoreSelection() }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active && !changing { restoreSelection() }
        }
        .alert(store.localized("Không thể đổi icon", "Cannot change icon", "无法更换图标"), isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button(store.localized("Đã hiểu", "OK", "知道了")) { errorMessage = nil }
        } message: { Text(errorMessage ?? "") }
    }

    private func restoreSelection() {
        guard !changing else { return }
        // The last successful API completion survives navigation and app restarts.
        // UIKit's getter can briefly report the previous icon during its alert.
        if let confirmed = DynorAppIcon(rawValue: confirmedIcon) {
            selectedName = confirmed.alternateName
        } else {
            selectedName = UIApplication.shared.alternateIconName
        }
    }

    private func select(_ icon: DynorAppIcon) {
        guard !changing, UIApplication.shared.supportsAlternateIcons,
              selectedName != icon.alternateName else { return }
        changing = true
        UIApplication.shared.setAlternateIconName(icon.alternateName) { error in
            DispatchQueue.main.async {
                changing = false
                if let error {
                    errorMessage = error.localizedDescription
                } else {
                    selectedName = icon.alternateName
                    confirmedIcon = icon.rawValue
                }
            }
        }
    }
}
