import SwiftUI
import UIKit

struct ThemeColorPickerView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedColor = Color.blue

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    ColorPicker(selection: $selectedColor, supportsOpacity: false) {
                        Text(store.localized("Màu tùy chỉnh", "Custom color", "自定义颜色"))
                    }
                    .padding(.vertical, 4)
                } footer: {
                    Text(store.localized("Chọn màu nhấn cho các nút và mục đang chọn trong Dynor.", "Choose an accent for buttons and selected items in Dynor.", "为 Dynor 的按钮和选中项目选择强调色。"))
                }
            }
            .navigationTitle(store.localized("Màu chủ đề", "Theme color", "主题颜色"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(store.localized("Hủy", "Cancel", "取消")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(store.localized("Xong", "Done", "完成")) {
                        applyColor()
                        dismiss()
                    }
                }
            }
            .onAppear { selectedColor = store.accentColor }
        }
        .tint(store.accentColor)
    }

    private func applyColor() {
        let color = UIColor(selectedColor)
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        guard color.getRed(&red, green: &green, blue: &blue, alpha: &alpha) else { return }
        store.customAccentHex = String(format: "#%02X%02X%02X", Int((red * 255).rounded()), Int((green * 255).rounded()), Int((blue * 255).rounded()))
        store.accent = .custom
    }
}
