// Adapted from AirCard's TendiesDocumentPickerView (MIT).
// See ThirdParty/AirCard/LICENSE and provenance.json.
import SwiftUI
import UIKit
import UniformTypeIdentifiers

enum WallpaperDocumentTypes {
    /// Include every registered Tendies type: another installed app or a file
    /// provider can associate the extension with a different identifier.
    static var pickerTypes: [UTType] {
        let tendiesTypes = [
            UTType(exportedAs: "com.dynor.tendies", conformingTo: .zip),
            UTType(importedAs: "com.aircard.tendies", conformingTo: .zip),
            UTType(exportedAs: "com.dynor.encrypted-tendies", conformingTo: .data)
        ] + ["tendies", "dynor"].flatMap {
            UTType.types(tag: $0, tagClass: .filenameExtension, conformingTo: nil)
        }
        var seen = Set<String>()
        return (tendiesTypes + [.archive, .zip, .image, .data, .item]).filter {
            seen.insert($0.identifier).inserted
        }
    }
}

/// A copy-based picker materializes provider documents into the app's sandbox
/// before handing their URLs to the import service. Validate selected files there.
struct WallpaperDocumentPicker: UIViewControllerRepresentable {
    var contentTypes: [UTType] = WallpaperDocumentTypes.pickerTypes
    var allowsMultipleSelection = true
    let onPick: ([URL]) -> Void
    let onCancel: () -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: contentTypes, asCopy: true)
        picker.allowsMultipleSelection = allowsMultipleSelection
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private let parent: WallpaperDocumentPicker
        private var completed = false

        init(parent: WallpaperDocumentPicker) { self.parent = parent }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard !completed else { return }
            completed = true
            if urls.isEmpty { parent.onCancel() } else { parent.onPick(urls) }
        }

        // Some providers call the single-document delegate even when multiple
        // selection is enabled; route it through the same completion path.
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
            documentPicker(controller, didPickDocumentsAt: [url])
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            guard !completed else { return }
            completed = true
            parent.onCancel()
        }
    }
}
