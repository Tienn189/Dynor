import SwiftUI
import UIKit

struct DynorOnboardingView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var step = 0
    let onFinish: () -> Void

    private func tr(_ vi: String, _ en: String, _ zh: String) -> String {
        store.localized(vi, en, zh)
    }

    var body: some View {
        VStack(spacing: 16) {
            HStack {
                Button { move(-1) } label: {
                    Image(systemName: "chevron.left").font(.headline)
                        .frame(width: 44, height: 44)
                        .background(.thinMaterial, in: Circle())
                }.opacity(step == 0 ? 0 : 1).disabled(step == 0)
                Spacer()
                ForEach(0..<3) { index in
                    Capsule().fill(index == step ? store.accentColor : Color.secondary.opacity(0.2))
                        .frame(width: index == step ? 28 : 8, height: 8)
                }
                Spacer()
                Text("\(step + 1)/3").font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                    .frame(width: 44)
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Image(systemName: ["rectangle.stack.fill", "globe", "iphone"][step])
                        .font(.system(size: 38, weight: .medium))
                        .foregroundStyle(store.accentColor)
                        .frame(width: 84, height: 84)
                        .background(store.accentColor.opacity(0.12), in: RoundedRectangle(cornerRadius: 26))
                    if step == 0 {
                        Text("Dynor").font(.system(size: 48, weight: .bold, design: .rounded))
                        Text("1.0.0 Beta 1").font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                        Text(tr("Chào mừng đến với Dynor", "Welcome to Dynor", "欢迎使用 Dynor")).font(.title2.bold())
                        Text(tr("Khám phá hình nền, cá nhân hóa iPhone và quản lý bộ sưu tập của bạn. Đây là phiên bản thử nghiệm; một số tính năng có thể chưa hoàn thiện.", "Discover wallpapers, personalize your iPhone and manage your collection. This is a beta release; some features may still be incomplete.", "探索壁纸、个性化 iPhone 并管理收藏。这是测试版本，部分功能可能尚未完善。")).foregroundStyle(.secondary)
                        feature("square.grid.2x2", tr("Khám phá hình nền", "Discover wallpapers", "探索壁纸"))
                        feature("square.stack", tr("Bộ sưu tập cá nhân", "Personal collection", "个人收藏"))
                    } else if step == 1 {
                        Text(tr("Chọn ngôn ngữ", "Choose your language", "选择语言")).font(.largeTitle.bold())
                        Text(tr("Bạn có thể thay đổi sau trong cài đặt.", "You can change this later in Settings.", "稍后可在设置中更改。")).foregroundStyle(.secondary)
                        language("vi", "🇻🇳", "Tiếng Việt")
                        language("en", "🇬🇧", "English")
                        language("zh-Hans", "🇨🇳", "简体中文")
                    } else {
                        Text(tr("Tương thích iOS", "iOS compatibility", "iOS 兼容性")).font(.largeTitle.bold())
                        Text(tr("Phạm vi có thể thử cài hình nền trực tiếp", "Experimental direct installation range", "可尝试直接安装壁纸的版本范围")).foregroundStyle(.secondary)
                        feature("checkmark.circle", "iOS 26.0 – 26.7.2")
                        feature("checkmark.circle", "iOS 27.0 – 27.2.0")
                        feature("info.circle", tr("Các phiên bản khác: chưa hỗ trợ cài trực tiếp", "Other versions: direct installation unsupported", "其他版本：不支持直接安装"))
                        VStack(alignment: .leading, spacing: 8) {
                            Text("iOS " + UIDevice.current.systemVersion).font(.headline)
                            Text(TendiesCompatibility.current.canAttemptInstall ? tr("Thiết bị nằm trong phạm vi thử nghiệm.", "Your device is within the experimental range.", "您的设备处于实验范围内。") : tr("Thiết bị nằm ngoài phạm vi thử nghiệm.", "Your device is outside the experimental range.", "您的设备不在实验范围内。"))
                                .foregroundStyle(.secondary)
                        }.padding(16).frame(maxWidth: .infinity, alignment: .leading).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                        Text(tr("Không phải mọi phiên bản đều đã kiểm thử. Cài trực tiếp cần App Group hợp lệ.", "Not every version has been tested. Direct installation requires a valid App Group.", "并非所有版本均经过测试。直接安装需要有效的 App Group。" )).font(.footnote).foregroundStyle(.secondary)
                    }
                }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 18)
                .id(step)
            }.scrollIndicators(.hidden)
            Button {
                if step == 2 { onFinish() } else { move(1) }
            } label: {
                Text(step == 2 ? tr("Bắt đầu sử dụng", "Get started", "开始使用") : tr("Tiếp tục", "Continue", "继续"))
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 8)
            }.buttonStyle(.borderedProminent).buttonBorderShape(.capsule).controlSize(.large)
        }.padding(24).frame(maxWidth: 540).frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
    }

    private func move(_ delta: Int) {
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.25)) { step = min(2, max(0, step + delta)) }
    }

    private func feature(_ icon: String, _ title: String) -> some View {
        Label(title, systemImage: icon).font(.body.weight(.medium))
            .frame(maxWidth: .infinity, alignment: .leading).padding(16)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
    }

    private func language(_ code: String, _ flag: String, _ title: String) -> some View {
        Button { store.appLanguage = code } label: {
            HStack(spacing: 14) {
                Text(flag).font(.title2)
                Text(title).font(.headline).foregroundStyle(.primary)
                Spacer()
                Image(systemName: store.appLanguage == code ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(store.appLanguage == code ? store.accentColor : Color.secondary)
            }.padding(18).background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
        }.buttonStyle(.plain)
    }
}
