import SwiftUI
import UIKit

/// One artwork preview for both ordinary and encrypted wallpaper packages.
struct TendiesArtworkPreview: View {
    @EnvironmentObject private var store: DynorStore
    @ObservedObject private var account = DynorAccountService.shared
    let archiveURL: URL
    var encrypted = false
    var allowsRetry = false
    var previewURL: URL? = nil
    @State private var artwork: UIImage?
    @State private var loading = false
    @State private var failure: String?
    @State private var retry = 0

    var body: some View {
        Group {
            if let artwork {
                Image(uiImage: artwork).resizable().scaledToFill()
            } else {
                ZStack {
                    DynorDesign.mist
                    VStack(spacing: 10) {
                        if loading { ProgressView() }
                        else {
                            Image(systemName: "photo").font(.title2)
                            Text(store.localized("Chưa có ảnh xem trước", "Preview unavailable", "暂无预览图"))
                                .font(.caption).multilineTextAlignment(.center)
                            if let failure {
                                Text(failure).font(.caption2).multilineTextAlignment(.center).lineLimit(3)
                            }
                            if allowsRetry {
                                Button(store.localized("Thử lại", "Retry", "重试")) { retry += 1 }
                                    .font(.caption)
                            }
                        }
                    }.foregroundStyle(.secondary).padding(12)
                }
            }
        }
        .task(id: archiveURL.path + (previewURL?.absoluteString ?? "") + ":\(retry):\(account.email ?? ""):\(account.isVIP)") {
            loading = true
            failure = nil
            defer { loading = false }
            do {
                let bytes = try await WallpaperArtworkLoader.shared.artwork(at: archiveURL, encrypted: encrypted, previewURL: previewURL)
                guard !Task.isCancelled else { return }
                artwork = UIImage(data: bytes)
            } catch {
                guard !Task.isCancelled else { return }
                if let error = error as? EncryptedTendiesError { failure = error.localizedDescription }
            }
        }
    }
}
