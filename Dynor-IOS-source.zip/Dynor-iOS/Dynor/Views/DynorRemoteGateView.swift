import SwiftUI

struct DynorRemoteGateView: View {
    @EnvironmentObject private var store: DynorStore
    @ObservedObject private var gate = DynorRemoteGate.shared
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        if let blocker = gate.blocker, let config = gate.config {
            ZStack {
                Color.black.opacity(0.52).ignoresSafeArea()
                VStack(spacing: 18) {
                    Image(systemName: blocker == .maintenance ? "wrench.adjustable.fill" : "arrow.down.app.fill")
                        .font(.system(size: 34, weight: .semibold))
                        .foregroundStyle(store.accentColor)
                        .frame(width: 86, height: 86)
                        .background(store.accentColor.opacity(0.14), in: Circle())
                    Text(blocker == .maintenance
                         ? (config.maintenance_title ?? store.localized("Dynor đang bảo trì", "Dynor is under maintenance", "Dynor 正在维护"))
                         : (config.update_title ?? store.localized("Đã có phiên bản Dynor mới!", "A new Dynor version is available!", "Dynor 有新版本！")))
                        .font(.title2.bold())
                        .multilineTextAlignment(.center)
                    if blocker == .update, let version = config.latest_version, !version.isEmpty {
                        Text(version).font(.subheadline).foregroundStyle(.secondary)
                    }
                    Text(blocker == .maintenance
                         ? (config.maintenance_message ?? store.localized("Vui lòng quay lại sau.", "Please come back later.", "请稍后再试。"))
                         : (config.update_message ?? store.localized("Vào nhóm Telegram để tải IPA mới nhất và tiếp tục sử dụng.", "Join Telegram to download the latest IPA and continue.", "请前往 Telegram 下载最新版 IPA。")))
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                    if blocker == .maintenance, let eta = config.maintenance_eta, !eta.isEmpty {
                        Text(eta).font(.footnote).foregroundStyle(.secondary)
                    }
                    if blocker == .maintenance {
                        Button {
                            Task { await gate.refresh() }
                        } label: {
                            HStack(spacing: 9) {
                                if gate.checking { ProgressView().tint(.white) }
                                else { Image(systemName: "arrow.clockwise") }
                                Text(store.localized("Thử lại", "Try again", "重试"))
                            }
                            .frame(maxWidth: .infinity).padding(.vertical, 15)
                        }
                        .disabled(gate.checking)
                    } else if let link = config.telegram_url,
                              let url = URL(string: link),
                              url.scheme?.lowercased() == "https",
                              url.host?.lowercased() == "t.me" || url.host?.lowercased() == "telegram.me" {
                        Link(destination: url) {
                            Label(store.localized("Vào Telegram cập nhật", "Update via Telegram", "前往 Telegram 更新"), systemImage: "paperplane.fill")
                                .frame(maxWidth: .infinity).padding(.vertical, 15)
                        }
                    } else {
                        Text(store.localized("Chưa cấu hình liên kết Telegram.", "Telegram link is not configured.", "尚未配置 Telegram 链接。"))
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    if blocker == .update {
                        Text(store.localized("Cần cài IPA mới để tiếp tục sử dụng.", "Install the new IPA to continue.", "请安装新版 IPA 后继续使用。"))
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                .buttonStyle(.plain)
                .padding(26)
                .frame(maxWidth: 390)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 32, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 32).strokeBorder(.white.opacity(colorScheme == .dark ? 0.2 : 0.8), lineWidth: 1))
                .shadow(color: .black.opacity(0.16), radius: 25, y: 12)
                .padding(22)
                .tint(store.accentColor)
                .modifier(GateButtonStyle(color: store.accentColor))
            }
            .zIndex(999)
            .transition(.opacity.combined(with: .scale(scale: 0.97)))
        }
    }
}

private struct GateButtonStyle: ViewModifier {
    let color: Color
    func body(content: Content) -> some View {
        content.buttonStyle(GateCapsuleStyle(color: color))
    }
}
private struct GateCapsuleStyle: ButtonStyle {
    let color: Color
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .foregroundStyle(.white)
            .background(color.opacity(configuration.isPressed ? 0.8 : 1), in: RoundedRectangle(cornerRadius: 18))
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }
}
