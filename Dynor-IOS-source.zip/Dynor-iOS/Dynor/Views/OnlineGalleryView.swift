import SwiftUI
import AVKit

private enum OnlineConfig {
    static let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    static let key = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    static func preview(_ path: String) -> URL? {
        let trimmed = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        // The admin website stores absolute Supabase Storage URLs.
        if let url = URL(string: trimmed),
           let scheme = url.scheme?.lowercased(),
           scheme == "https" || scheme == "http" {
            return url
        }

        // Legacy records may store a path relative to dynor-previews.
        let relative = trimmed.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let encoded = relative.split(separator: "/").map { segment in
            String(segment).addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? String(segment)
        }.joined(separator: "/")
        return URL(string: "\(base.absoluteString)/storage/v1/object/public/dynor-previews/\(encoded)")
    }
}

private struct OnlineWallpaper: Identifiable, Decodable {
    let id: UUID
    let title: String
    let category: String
    let cover_path: String
    let video_path: String?
    let is_vip: Bool
}

@MainActor
private final class OnlineGalleryModel: ObservableObject {
    @Published var items: [OnlineWallpaper] = []
    @Published var favorites: Set<UUID> = []
    @Published var loading = false
    @Published var error: String?
    private let account = DynorAccountService.shared

    private func request(_ path: String, method: String = "GET", token: String? = nil, body: Data? = nil, prefer: String? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: OnlineConfig.base)?.absoluteURL else { throw GalleryFailure.message("URL không hợp lệ") }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(OnlineConfig.key, forHTTPHeaderField: "apikey")
        if let token { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body { req.httpBody = body; req.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if let prefer { req.setValue(prefer, forHTTPHeaderField: "Prefer") }
        let (data,response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "Không kết nối được Supabase"
            throw GalleryFailure.message("Máy chủ: \(text.prefix(180))")
        }
        return data
    }

    func reload() async {
        loading = true
        defer { loading = false }
        do {
            let data = try await request("rest/v1/dynor_wallpapers?select=id,title,category,cover_path,video_path,is_vip&published=eq.true&order=created_at.desc")
            items = try JSONDecoder().decode([OnlineWallpaper].self, from: data)
            error = nil
            await reloadFavorites()
        } catch { self.error = error.localizedDescription }
    }

    func reloadFavorites() async {
        guard let token = await account.galleryAccessToken() else { favorites = []; return }
        do {
            let data = try await request("rest/v1/dynor_favorites?select=wallpaper_id", token: token)
            struct Favorite: Decodable { let wallpaper_id: UUID }
            favorites = Set(try JSONDecoder().decode([Favorite].self, from: data).map(\.wallpaper_id))
        } catch { self.error = "Không đồng bộ được yêu thích: \(error.localizedDescription)" }
    }

    private func authenticatedUserID(token: String) async throws -> UUID {
        let data = try await request("auth/v1/user", token: token)
        struct AuthUser: Decodable { let id: UUID }
        return try JSONDecoder().decode(AuthUser.self, from: data).id
    }

    func toggleFavorite(_ id: UUID) async {
        guard let token = await account.galleryAccessToken() else { error = "Đăng nhập tài khoản Dynor để lưu yêu thích."; return }
        let wasFavorite = favorites.contains(id)
        do {
            let userID = try await authenticatedUserID(token: token)
            if wasFavorite {
                _ = try await request("rest/v1/dynor_favorites?wallpaper_id=eq.\(id.uuidString)&user_id=eq.\(userID.uuidString)",method:"DELETE",token:token)
                favorites.remove(id)
            } else {
                let body = try JSONSerialization.data(withJSONObject: ["wallpaper_id":id.uuidString, "user_id":userID.uuidString])
                _ = try await request("rest/v1/dynor_favorites",method:"POST",token:token,body:body,prefer:"return=minimal")
                favorites.insert(id)
            }
        } catch { self.error = "Không lưu được yêu thích: \(error.localizedDescription)" }
    }

    func download(_ item: OnlineWallpaper, progress: @escaping @MainActor (Double) -> Void) async throws -> URL {
        guard let token = await account.galleryAccessToken() else { throw GalleryFailure.message("Đăng nhập Dynor trước khi tải.") }
        let body = try JSONSerialization.data(withJSONObject:["id":item.id.uuidString.lowercased()])
        let data: Data
        do {
            data = try await request("functions/v1/dynor-wallpaper-download",method:"POST",token:token,body:body)
        } catch {
            if error.localizedDescription.contains("NOT_FOUND") {
                throw GalleryFailure.message("Máy chủ chưa triển khai Edge Function dynor-wallpaper-download. Admin cần triển khai chức năng tải có xác thực trên Supabase trước khi tải hình nền.")
            }
            throw error
        }
        struct Signed: Decodable { let url: URL }
        let signed = try JSONDecoder().decode(Signed.self,from:data)
        guard signed.url.scheme == "https", signed.url.host == OnlineConfig.base.host else { throw GalleryFailure.message("Địa chỉ tải không an toàn") }
        let observer = WallpaperDownloadObserver(progress: progress)
        let session = URLSession(configuration: .default, delegate: observer, delegateQueue: nil)
        defer { session.finishTasksAndInvalidate() }
        let (temporary,response) = try await session.download(from:signed.url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw GalleryFailure.message("Không tải được file") }
        let suggested = response.suggestedFilename ?? "Dynor-Wallpaper"
        let safe = URL(fileURLWithPath:suggested).lastPathComponent
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent(safe)
        try FileManager.default.createDirectory(at:destination.deletingLastPathComponent(),withIntermediateDirectories:true)
        try FileManager.default.moveItem(at:temporary,to:destination)
        return destination
    }
}

private final class WallpaperDownloadObserver: NSObject, URLSessionDownloadDelegate {
    let progress: @MainActor (Double) -> Void
    init(progress: @escaping @MainActor (Double) -> Void) { self.progress = progress }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {}
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else { return }
        let value = min(1, max(0, Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)))
        Task { @MainActor in progress(value) }
    }
}

private enum GalleryFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
}

struct OnlineGalleryView: View {
    @EnvironmentObject private var store: DynorStore
    @StateObject private var model = OnlineGalleryModel()
    @State private var onlyFavorites = false
    @State private var query = ""
    @State private var category = "Tất cả"
    @Environment(\.scenePhase) private var phase
    @Environment(\.horizontalSizeClass) private var sizeClass
    private var columns: [GridItem] {
        [GridItem(.adaptive(minimum: sizeClass == .regular ? 190 : 128, maximum: 280), spacing: 14)]
    }
    private var categories: [String] { ["Tất cả"] + Array(Set(model.items.map(\.category))).sorted() }
    private var filtered: [OnlineWallpaper] {
        model.items.filter { item in
            (category == "Tất cả" || item.category == category) &&
            (!onlyFavorites || model.favorites.contains(item.id)) &&
            (query.isEmpty || "\(item.title) \(item.category)".localizedCaseInsensitiveContains(query))
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Text(store.localized("Hình nền tuyển chọn cho iPhone của bạn.", "Selected wallpapers for your iPhone.", "为你的 iPhone 精选壁纸。"))
                    .font(.subheadline).foregroundStyle(.secondary)
                chips
                gridSection
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 24)
            .frame(maxWidth: 960)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .navigationTitle(store.localized("Khám phá", "Explore", "探索"))
        .navigationBarTitleDisplayMode(.large)
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always),
                    prompt: store.localized("Tìm hình nền", "Search wallpapers", "搜索壁纸"))
        .textInputAutocapitalization(.never)
        .autocorrectionDisabled()
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                languageMenu
                Button {
                    onlyFavorites.toggle()
                } label: {
                    Image(systemName: onlyFavorites ? "heart.fill" : "heart")
                }
                .tint(store.accentColor)
                .accessibilityLabel(store.localized("Yêu thích", "Favorites", "收藏"))
                .accessibilityValue(onlyFavorites ? store.localized("Đang lọc", "Filter on", "已筛选") : store.localized("Tất cả", "All", "全部"))
            }
        }
        .refreshable { await model.reload() }
        .task { await model.reload() }
        .onChange(of: phase) { _, newPhase in if newPhase == .active { Task { await model.reload() } } }

    }

    private var languageMenu: some View {
        Menu {
            Button { store.appLanguage = "vi" } label: { Text("Tiếng Việt" + (store.appLanguage == "vi" ? "  ✓" : "")) }
            Button { store.appLanguage = "en" } label: { Text("English" + (store.appLanguage == "en" ? "  ✓" : "")) }
            Button { store.appLanguage = "zh-Hans" } label: { Text("中文" + (store.appLanguage == "zh-Hans" ? "  ✓" : "")) }
        } label: {
            Image(systemName: "globe")
        }
        .accessibilityLabel(store.localized("Ngôn ngữ", "Language", "语言"))
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(categories, id: \.self) { value in
                    let active = category == value
                    Button { category = value } label: {
                        Text(value == "Tất cả" ? store.localized("Tất cả", "All", "全部") : value)
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(active ? store.accentTextColor : Color.primary)
                            .lineLimit(1)
                            .padding(.horizontal, 16)
                            .frame(minHeight: 44)
                            .background {
                                if active {
                                    Capsule().fill(store.accentColor)
                                } else {
                                    Capsule().fill(.clear).modifier(DynorGlass(radius: 24, interactive: true))
                                }
                            }
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(active ? .isSelected : [])
                }
            }
            .padding(.vertical, 4)
        }
    }

    private var gridSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            DynorSectionTitle(title: onlyFavorites ? store.localized("Yêu thích", "Favorites", "收藏") : store.localized("Mới nhất", "Latest", "最新"),
                              detail: "\(filtered.count)")
            if model.loading && model.items.isEmpty {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(store.localized("Đang tải hình nền…", "Loading wallpapers…", "正在加载壁纸…")).font(.subheadline).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 40)
            }
            if let error = model.error {
                VStack(alignment: .leading, spacing: 12) {
                    Label(error, systemImage: "wifi.exclamationmark").font(.caption).foregroundStyle(.secondary)
                    Button(store.localized("Thử lại", "Try again", "重试")) { Task { await model.reload() } }
                        .font(.subheadline.weight(.semibold)).tint(store.accentColor)
                }
                .frame(maxWidth: .infinity, alignment: .leading).padding(16)
                .modifier(DynorGlass(radius: 20))
            }
            if filtered.isEmpty && !model.loading && model.error == nil {
                DynorEmptyState(
                    symbol: onlyFavorites ? "heart" : "photo.on.rectangle",
                    title: onlyFavorites ? store.localized("Chưa có yêu thích", "No favorites yet", "暂无收藏") : store.localized("Chưa tìm thấy hình nền", "No wallpapers found", "未找到壁纸"),
                    message: onlyFavorites ? store.localized("Chạm vào trái tim để lưu hình nền tại đây.", "Tap a heart to save a wallpaper here.", "轻点爱心，在这里收藏壁纸。") : store.localized("Thử từ khóa khác hoặc kéo xuống để làm mới.", "Try another search or pull down to refresh.", "尝试其他关键词或下拉刷新。"))
            } else {
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(filtered) { item in
                        PosterCard(item: item,
                                   isFavorite: model.favorites.contains(item.id),
                                   model: model)
                    }
                }
            }
        }
    }
}

// MARK: - Artwork

private struct RemotePoster: View {
    let url: URL?
    var fit: Bool = false
    var body: some View {
        AsyncImage(url: url, transaction: Transaction(animation: .easeOut(duration: 0.3))) { phase in
            switch phase {
            case .success(let image):
                image.resizable().aspectRatio(contentMode: fit ? .fit : .fill)
            case .failure:
                ZStack {
                    DynorDesign.mist
                    Image(systemName: "photo").font(.title2).foregroundStyle(.secondary)
                }
            default:
                ZStack {
                    DynorDesign.mist
                    ProgressView()
                }
            }
        }
    }
}

private struct FavoriteButton: View {
    @EnvironmentObject private var store: DynorStore
    let isFavorite: Bool
    let action: () -> Void
    var body: some View {
        ThumbnailActionButton(symbol: isFavorite ? "heart.fill" : "heart", tint: isFavorite ? store.accentColor : .white, action: action)
            .environment(\.colorScheme, .dark)
            .accessibilityLabel(isFavorite ? store.localized("Bỏ yêu thích", "Remove favorite", "取消收藏") : store.localized("Thêm yêu thích", "Add favorite", "添加收藏"))
    }
}

/// A smaller glass control with the standard 44-point touch target.
private struct ThumbnailActionButton: View {
    let symbol: String
    var tint: Color = .white
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(tint)
                .frame(width: 38, height: 38)
                .modifier(DynorGlass(radius: 19, interactive: true))
                .frame(width: 44, height: 44)
                .contentShape(Circle())
        }
        .buttonStyle(DynorPressStyle())
        .environment(\.colorScheme, .dark)
    }
}

private struct VIPBadge: View {
    var body: some View {
        Text("VIP").font(.caption2.weight(.semibold))
            .padding(.horizontal, 8).padding(.vertical, 5)
            .foregroundStyle(.white)
            .background(Color.blue, in: Capsule())
    }
}

private struct InlineWallpaperVideo: UIViewRepresentable {
    let player: AVPlayer
    func makeUIView(context: Context) -> PlayerSurface {
        let view = PlayerSurface()
        view.playerLayer.videoGravity = .resizeAspect
        view.playerLayer.player = player
        return view
    }
    func updateUIView(_ uiView: PlayerSurface, context: Context) {
        uiView.playerLayer.player = player
    }
    final class PlayerSurface: UIView {
        override static var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }
}

private struct PosterCard: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    @ObservedObject var model: OnlineGalleryModel
    @State private var player: AVPlayer?
    @State private var downloading = false
    @State private var downloadProgress = 0.0
    @State private var heartBurst = false
    @State private var heartPulse = false
    @State private var burstID = 0
    @State private var notice: String?
    @State private var importedWallpaper: ImportedWallpaper?

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            ZStack {
                RoundedRectangle(cornerRadius: 20).fill(DynorDesign.mist)
                RemotePoster(url: OnlineConfig.preview(item.cover_path), fit: true)
                if let player {
                    InlineWallpaperVideo(player: player)
                        .background(Color.black)
                }
                if heartBurst {
                    Image(systemName: "heart.fill")
                        .font(.system(size: 78, weight: .bold))
                        .foregroundStyle(.white)
                        .shadow(color: .black.opacity(0.3), radius: 10)
                        .scaleEffect(heartPulse ? 1.15 : 0.75)
                        .allowsHitTesting(false)
                }
            }
            .aspectRatio(9.0 / 19.5, contentMode: .fit)
            .frame(maxWidth: .infinity)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .contentShape(RoundedRectangle(cornerRadius: 20))
            .onTapGesture(count: 2) { burstFavorite() }
            .overlay(alignment: .topLeading) {
                if item.video_path != nil {
                    ThumbnailActionButton(symbol: player == nil ? "play.fill" : "pause.fill", action: togglePreview)
                        .padding(5)
                }
            }
            .overlay(alignment: .topTrailing) {
                FavoriteButton(isFavorite: model.favorites.contains(item.id), action: favoriteTapped)
                    .scaleEffect(heartPulse ? 1.16 : 1)
                    .padding(5)
            }
            .overlay(alignment: .bottomLeading) {
                if item.is_vip { VIPBadge().padding(10) }
            }
            Text(item.title.replacingOccurrences(of: #"\.(dynor|tendies)$"#, with: "", options: [.regularExpression, .caseInsensitive]))
                .font(.subheadline.weight(.semibold)).lineLimit(1)
            Text(item.category).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            Button(action: startDownload) {
                VStack(spacing: 5) {
                    HStack(spacing: 5) {
                        if downloading {
                            Text("\(Int(downloadProgress * 100))%")
                                .monospacedDigit()
                        } else {
                            Image(systemName: "arrow.down")
                            Text(store.localized("Tải hình nền", "Download", "下载壁纸"))
                                .lineLimit(1).minimumScaleFactor(0.7)
                        }
                    }
                    .font(.caption.weight(.semibold))
                    if downloading {
                        ProgressView(value: downloadProgress)
                            .tint(store.accentTextColor)
                    }
                }
                .foregroundStyle(store.accentTextColor)
                .frame(maxWidth: .infinity, minHeight: 38)
                .padding(.horizontal, 8)
                .background(store.accentColor, in: RoundedRectangle(cornerRadius: 13))
            }
            .buttonStyle(.plain)
            .disabled(downloading)
        }
        .onDisappear { stopPreview() }
        .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) { notice = nil }
        } message: { Text(notice ?? "") }
        .sheet(item: $importedWallpaper) { wallpaper in
            LibraryPreview(item: wallpaper).environmentObject(store)
        }
    }

    private func togglePreview() {
        if player != nil { stopPreview(); return }
        guard let path = item.video_path, let url = OnlineConfig.preview(path) else { return }
        let newPlayer = AVPlayer(url: url)
        player = newPlayer
        newPlayer.play()
    }
    private func stopPreview() {
        player?.pause()
        player?.replaceCurrentItem(with: nil)
        player = nil
    }
    private func favoriteTapped() {
        withAnimation(.spring(response: 0.22, dampingFraction: 0.5)) { heartPulse = true }
        Task {
            await model.toggleFavorite(item.id)
            withAnimation(.easeOut(duration: 0.2)) { heartPulse = false }
        }
    }
    private func burstFavorite() {
        burstID += 1
        let current = burstID
        withAnimation(.spring(response: 0.2, dampingFraction: 0.5)) {
            heartBurst = true
            heartPulse = true
        }
        if !model.favorites.contains(item.id) { Task { await model.toggleFavorite(item.id) } }
        Task {
            try? await Task.sleep(for: .milliseconds(550))
            guard current == burstID else { return }
            withAnimation(.easeOut(duration: 0.2)) {
                heartBurst = false
                heartPulse = false
            }
        }
    }
    private func startDownload() {
        guard !downloading else { return }
        downloadProgress = 0
        downloading = true
        Task {
            do {
                let url = try await model.download(item, progress: { value in
                    withAnimation(.linear(duration: 0.12)) { downloadProgress = value }
                })
                defer { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
                let imported = await store.importWallpapers(urls: [url])
                if let wallpaper = imported.first {
                    store.message = nil
                    _ = store.attachPreview(OnlineConfig.preview(item.cover_path), to: wallpaper.id)
                    downloadProgress = 1
                    notice = store.localized("Đã tải vào Bộ sưu tập.", "Saved to Collection.", "已保存到收藏。")
                } else {
                    notice = store.message ?? "Không nhập được hình nền."
                    store.message = nil
                }
            } catch { notice = error.localizedDescription }
            downloading = false
        }
    }
}

// MARK: - Detail

private struct OnlineWallpaperDetail: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    @ObservedObject var model: OnlineGalleryModel
    @Environment(\.dismiss) private var dismiss
    @State private var inlinePlayer: AVPlayer?
    @State private var downloading = false
    @State private var downloadProgress = 0.0
    @State private var heartPulse = false
    @State private var heartBurst = false
    @State private var importedWallpaper: ImportedWallpaper?
    @State private var notice: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                topBar
                ZStack {
                    RoundedRectangle(cornerRadius: 24).fill(DynorDesign.mist)
                    if let inlinePlayer {
                        VideoPlayer(player: inlinePlayer)
                    } else {
                        RemotePoster(url: OnlineConfig.preview(item.cover_path), fit: true)
                    }
                }
                .aspectRatio(9.0 / 19.5, contentMode: .fit)
                .frame(maxWidth: 390)
                .frame(maxWidth: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 24))
                .overlay {
                    if heartBurst {
                        Image(systemName: "heart.fill")
                            .font(.system(size: 94, weight: .bold))
                            .foregroundStyle(.white)
                            .shadow(color: .black.opacity(0.25), radius: 12)
                            .transition(.scale.combined(with: .opacity))
                            .allowsHitTesting(false)
                    }
                }
                .onTapGesture(count: 2) { burstFavorite() }
                .accessibilityLabel(store.localized("Ảnh xem trước hình nền", "Wallpaper preview", "壁纸预览"))
                bottomPanel
            }
            .padding(20)
            .frame(maxWidth: 640)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .safeAreaInset(edge: .bottom, spacing: 0) { downloadBar }
        .interactiveDismissDisabled(downloading)
        .onDisappear { stopPreview() }
        .sheet(item: $importedWallpaper) { wallpaper in
            LibraryPreview(item: wallpaper).environmentObject(store)
        }
        .onChange(of: store.selectedTab) { _, tab in
            if tab != .discover { dismiss() }
        }
        .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) { notice = nil }
        } message: { Text(notice ?? "") }
    }

    private var topBar: some View {
        HStack {
            Text(store.localized("Xem trước", "Preview", "预览")).font(.headline)
            Spacer()
            GlassIconButton(symbol: "xmark") {
                stopPreview()
                dismiss()
            }
                .accessibilityLabel(store.localized("Đóng", "Close", "关闭"))
        }
    }

    private var bottomPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Text(item.category).font(.subheadline).foregroundStyle(.secondary)
                if item.is_vip { VIPBadge() }
            }
            Text(item.title)
                .font(.title2.weight(.bold))
                .fixedSize(horizontal: false, vertical: true)
            if item.video_path != nil {
                Button { togglePreview() } label: {
                    Label(inlinePlayer == nil ? store.localized("Xem video", "Watch preview", "观看预览") : store.localized("Dừng video", "Stop preview", "停止预览"), systemImage: inlinePlayer == nil ? "play.fill" : "stop.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(DynorGlassButtonStyle())
            }
            Text(store.localized("Tải vào Bộ sưu tập, sau đó chọn Cài hình nền. Gói mã hóa cần đăng nhập và Internet mỗi lần cài. Nội dung VIP cần tài khoản VIP còn hiệu lực.", "Download to your collection, then choose Install Wallpaper. Encrypted packages need sign-in and Internet each time. VIP content requires active VIP access.", "下载到收藏后，选择安装壁纸。加密包每次安装均需登录和联网。VIP 内容需要有效的 VIP 权限。"))
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var downloadBar: some View {
        HStack(spacing: 12) {
            Button { animateFavorite() } label: {
                Image(systemName: model.favorites.contains(item.id) ? "heart.fill" : "heart")
                    .font(.title3)
                    .scaleEffect(heartPulse ? 1.35 : 1)
                    .frame(width: 48, height: 48)
            }
            .buttonStyle(.plain)
            .foregroundStyle(store.accentColor)
            .accessibilityLabel(store.localized("Yêu thích", "Favorite", "收藏"))
            Button { startDownload() } label: {
                HStack(spacing: 8) {
                    if downloading {
                        Image(systemName: "arrow.down.circle.fill")
                        Text("\(Int(downloadProgress * 100))%")
                            .monospacedDigit()
                    } else {
                        Text(store.localized("Tải hình nền", "Get wallpaper", "下载壁纸"))
                    }
                    if !downloading { Image(systemName: "arrow.down") }
                }
                .font(.body.weight(.semibold))
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(DynorPrimaryButtonStyle())
            .overlay(alignment: .bottomLeading) {
                if downloading {
                    GeometryReader { geo in
                        Capsule().fill(store.accentColor.opacity(0.35))
                            .frame(width: geo.size.width * downloadProgress, height: 4)
                    }.frame(height: 4).padding(.horizontal, 12).padding(.bottom, 3)
                }
            }
            .disabled(downloading)
        }
        .padding(12)
        .modifier(DynorGlass(radius: 28))
        .padding(.horizontal, 16).padding(.vertical, 10)
        .frame(maxWidth: 640)
        .frame(maxWidth: .infinity)
    }

    private func togglePreview() {
        if inlinePlayer != nil { stopPreview(); return }
        guard let path = item.video_path, let url = OnlineConfig.preview(path) else { return }
        let player = AVPlayer(url: url)
        inlinePlayer = player
        player.play()
    }

    private func stopPreview() {
        inlinePlayer?.pause()
        inlinePlayer?.replaceCurrentItem(with: nil)
        inlinePlayer = nil
    }

    private func animateFavorite() {
        withAnimation(.spring(response: 0.22, dampingFraction: 0.45)) { heartPulse = true }
        Task { await model.toggleFavorite(item.id)
            withAnimation(.spring(response: 0.3)) { heartPulse = false }
        }
    }

    private func burstFavorite() {
        withAnimation(.spring(response: 0.22, dampingFraction: 0.55)) { heartBurst = true }
        if !model.favorites.contains(item.id) { animateFavorite() }
        Task {
            try? await Task.sleep(for: .milliseconds(550))
            withAnimation(.easeOut(duration: 0.22)) { heartBurst = false }
        }
    }

    private func startDownload() {
        downloadProgress = 0
        downloading = true
        Task {
            do {
                let downloadedURL = try await model.download(item, progress: { value in
                    withAnimation(.linear(duration: 0.12)) { downloadProgress = value }
                })
                defer { try? FileManager.default.removeItem(at: downloadedURL.deletingLastPathComponent()) }
                let imported = await store.importWallpapers(urls: [downloadedURL])
                if let wallpaper = imported.first {
                    store.message = nil
                    importedWallpaper = store.attachPreview(OnlineConfig.preview(item.cover_path), to: wallpaper.id) ?? wallpaper
                } else {
                    notice = store.message ?? "Chưa nhập được hình nền đã tải."
                    store.message = nil
                }
            } catch { notice = error.localizedDescription }
            downloading = false
        }
    }
}

private struct OnlineVideoView: View {
    @EnvironmentObject private var store: DynorStore
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Group { if let player { VideoPlayer(player: player) } else { ProgressView().tint(.white) } }
                .ignoresSafeArea()
            GlassIconButton(symbol: "xmark") { dismiss() }
                .accessibilityLabel(store.localized("Đóng video", "Close video", "关闭视频"))
                .environment(\.colorScheme, .dark)
                .padding(18)
        }
        .onAppear { let p = AVPlayer(url: url); player = p; p.play() }
        .onDisappear { player?.pause(); player = nil }
    }
}
