import SwiftUI
import AVKit

private enum OnlineConfig {
    static let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    static let key = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    static func preview(_ path: String) -> URL? {
        let trimmed = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        // The admin website stores absolute Supabase Storage URLs.
        if let url = URL(string: trimmed),
           let scheme = url.scheme?.lowercased(),
           scheme == "https" || scheme == "http" {
            return url
        }

        // Legacy records may store a path relative to dynor-previews.
        let relative = trimmed.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let encoded = relative.split(separator: "/").map { segment in
            String(segment).addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? String(segment)
        }.joined(separator: "/")
        return URL(string: "\(base.absoluteString)/storage/v1/object/public/dynor-previews/\(encoded)")
    }
}

private struct OnlineWallpaper: Identifiable, Decodable {
    let id: UUID
    let title: String
    let category: String
    let cover_path: String
    let video_path: String?
    let is_vip: Bool
}

@MainActor
private final class OnlineGalleryModel: ObservableObject {
    @Published var items: [OnlineWallpaper] = []
    @Published var favorites: Set<UUID> = []
    @Published var loading = false
    @Published var error: String?
    private let account = DynorAccountService.shared

    private func request(_ path: String, method: String = "GET", token: String? = nil, body: Data? = nil, prefer: String? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: OnlineConfig.base)?.absoluteURL else { throw GalleryFailure.message("URL không hợp lệ") }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(OnlineConfig.key, forHTTPHeaderField: "apikey")
        if let token { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body { req.httpBody = body; req.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if let prefer { req.setValue(prefer, forHTTPHeaderField: "Prefer") }
        let (data,response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "Không kết nối được Supabase"
            throw GalleryFailure.message("Máy chủ: \(text.prefix(180))")
        }
        return data
    }

    func reload() async {
        loading = true
        defer { loading = false }
        do {
            let data = try await request("rest/v1/dynor_wallpapers?select=id,title,category,cover_path,video_path,is_vip&published=eq.true&order=created_at.desc")
            items = try JSONDecoder().decode([OnlineWallpaper].self, from: data)
            error = nil
            await reloadFavorites()
        } catch { self.error = error.localizedDescription }
    }

    func reloadFavorites() async {
        guard let token = await account.galleryAccessToken() else { favorites = []; return }
        do {
            let data = try await request("rest/v1/dynor_favorites?select=wallpaper_id", token: token)
            struct Favorite: Decodable { let wallpaper_id: UUID }
            favorites = Set(try JSONDecoder().decode([Favorite].self, from: data).map(\.wallpaper_id))
        } catch { self.error = "Không đồng bộ được yêu thích: \(error.localizedDescription)" }
    }

    private func authenticatedUserID(token: String) async throws -> UUID {
        let data = try await request("auth/v1/user", token: token)
        struct AuthUser: Decodable { let id: UUID }
        return try JSONDecoder().decode(AuthUser.self, from: data).id
    }

    func toggleFavorite(_ id: UUID) async {
        guard let token = await account.galleryAccessToken() else { error = "Đăng nhập tài khoản Dynor để lưu yêu thích."; return }
        let wasFavorite = favorites.contains(id)
        do {
            let userID = try await authenticatedUserID(token: token)
            if wasFavorite {
                _ = try await request("rest/v1/dynor_favorites?wallpaper_id=eq.\(id.uuidString)&user_id=eq.\(userID.uuidString)",method:"DELETE",token:token)
                favorites.remove(id)
            } else {
                let body = try JSONSerialization.data(withJSONObject: ["wallpaper_id":id.uuidString, "user_id":userID.uuidString])
                _ = try await request("rest/v1/dynor_favorites",method:"POST",token:token,body:body,prefer:"return=minimal")
                favorites.insert(id)
            }
        } catch { self.error = "Không lưu được yêu thích: \(error.localizedDescription)" }
    }

    func download(_ item: OnlineWallpaper) async throws -> URL {
        guard let token = await account.galleryAccessToken() else { throw GalleryFailure.message("Đăng nhập Dynor trước khi tải.") }
        let body = try JSONSerialization.data(withJSONObject:["id":item.id.uuidString.lowercased()])
        let data = try await request("functions/v1/dynor-wallpaper-download",method:"POST",token:token,body:body)
        struct Signed: Decodable { let url: URL }
        let signed = try JSONDecoder().decode(Signed.self,from:data)
        guard signed.url.scheme == "https", signed.url.host == OnlineConfig.base.host else { throw GalleryFailure.message("Địa chỉ tải không an toàn") }
        let (temporary,response) = try await URLSession.shared.download(from:signed.url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw GalleryFailure.message("Không tải được file") }
        let suggested = response.suggestedFilename ?? "Dynor-Wallpaper"
        let safe = URL(fileURLWithPath:suggested).lastPathComponent
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent(safe)
        try FileManager.default.createDirectory(at:destination.deletingLastPathComponent(),withIntermediateDirectories:true)
        try FileManager.default.moveItem(at:temporary,to:destination)
        return destination
    }
}

private enum GalleryFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
}

struct OnlineGalleryView: View {
    @EnvironmentObject private var store: DynorStore
    @StateObject private var model = OnlineGalleryModel()
    @State private var selected: OnlineWallpaper?
    @State private var onlyFavorites = false
    @State private var query = ""
    @State private var category = "Tất cả"
    @Environment(\.scenePhase) private var phase
    @Environment(\.horizontalSizeClass) private var sizeClass
    private var columns: [GridItem] {
        [GridItem(.adaptive(minimum: sizeClass == .regular ? 190 : 128, maximum: 280), spacing: 14)]
    }
    private var categories: [String] { ["Tất cả"] + Array(Set(model.items.map(\.category))).sorted() }
    private var filtered: [OnlineWallpaper] {
        model.items.filter { item in
            (category == "Tất cả" || item.category == category) &&
            (!onlyFavorites || model.favorites.contains(item.id)) &&
            (query.isEmpty || "\(item.title) \(item.category)".localizedCaseInsensitiveContains(query))
        }
    }
    private var showFeatured: Bool { category == "Tất cả" && query.isEmpty && !onlyFavorites && !model.items.isEmpty }
    private var featured: [OnlineWallpaper] { Array(model.items.prefix(6)) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Text(store.localized("Hình nền tuyển chọn cho iPhone của bạn.", "Selected wallpapers for your iPhone.", "为你的 iPhone 精选壁纸。"))
                    .font(.subheadline).foregroundStyle(.secondary)
                chips
                if showFeatured { featuredSection }
                gridSection
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 24)
            .frame(maxWidth: 960)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .navigationTitle(store.localized("Khám phá", "Explore", "探索"))
        .navigationBarTitleDisplayMode(.large)
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always),
                    prompt: store.localized("Tìm hình nền", "Search wallpapers", "搜索壁纸"))
        .textInputAutocapitalization(.never)
        .autocorrectionDisabled()
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                languageMenu
                Button {
                    onlyFavorites.toggle()
                } label: {
                    Image(systemName: onlyFavorites ? "heart.fill" : "heart")
                }
                .tint(store.accentColor)
                .accessibilityLabel(store.localized("Yêu thích", "Favorites", "收藏"))
                .accessibilityValue(onlyFavorites ? store.localized("Đang lọc", "Filter on", "已筛选") : store.localized("Tất cả", "All", "全部"))
            }
        }
        .refreshable { await model.reload() }
        .task { await model.reload() }
        .onChange(of: phase) { _, newPhase in if newPhase == .active { Task { await model.reload() } } }
        .sheet(item: $selected) { item in
            OnlineWallpaperDetail(item: item, model: model)
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(30)
        }
    }

    private var languageMenu: some View {
        Menu {
            Button { store.appLanguage = "vi" } label: { Text("Tiếng Việt" + (store.appLanguage == "vi" ? "  ✓" : "")) }
            Button { store.appLanguage = "en" } label: { Text("English" + (store.appLanguage == "en" ? "  ✓" : "")) }
            Button { store.appLanguage = "zh-Hans" } label: { Text("中文" + (store.appLanguage == "zh-Hans" ? "  ✓" : "")) }
        } label: {
            Image(systemName: "globe")
        }
        .accessibilityLabel(store.localized("Ngôn ngữ", "Language", "语言"))
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(categories, id: \.self) { value in
                    let active = category == value
                    Button { category = value } label: {
                        Text(value == "Tất cả" ? store.localized("Tất cả", "All", "全部") : value)
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(active ? store.accentTextColor : Color.primary)
                            .lineLimit(1)
                            .padding(.horizontal, 16)
                            .frame(minHeight: 44)
                            .background {
                                if active {
                                    Capsule().fill(store.accentColor)
                                } else {
                                    Capsule().fill(.clear).modifier(DynorGlass(radius: 24, interactive: true))
                                }
                            }
                            .contentShape(Capsule())
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(active ? .isSelected : [])
                }
            }
            .padding(.vertical, 4)
        }
    }

    private var featuredSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(store.localized("Nổi bật", "Featured", "精选"))
                .font(.title3.weight(.semibold))
                .accessibilityAddTraits(.isHeader)
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 12) {
                    ForEach(featured) { item in
                        FeaturedCard(item: item,
                                     isFavorite: model.favorites.contains(item.id),
                                     onOpen: { selected = item },
                                     onFavorite: { Task { await model.toggleFavorite(item.id) } })
                            .containerRelativeFrame(.horizontal) { width, _ in min(width * 0.9, 500) }
                    }
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned)
        }
    }

    private var gridSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            DynorSectionTitle(title: onlyFavorites ? store.localized("Yêu thích", "Favorites", "收藏") : store.localized("Mới nhất", "Latest", "最新"),
                              detail: "\(filtered.count)")
            if model.loading && model.items.isEmpty {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(store.localized("Đang tải hình nền…", "Loading wallpapers…", "正在加载壁纸…")).font(.subheadline).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 40)
            }
            if let error = model.error {
                VStack(alignment: .leading, spacing: 12) {
                    Label(error, systemImage: "wifi.exclamationmark").font(.caption).foregroundStyle(.secondary)
                    Button(store.localized("Thử lại", "Try again", "重试")) { Task { await model.reload() } }
                        .font(.subheadline.weight(.semibold)).tint(store.accentColor)
                }
                .frame(maxWidth: .infinity, alignment: .leading).padding(16)
                .modifier(DynorGlass(radius: 20))
            }
            if filtered.isEmpty && !model.loading && model.error == nil {
                DynorEmptyState(
                    symbol: onlyFavorites ? "heart" : "photo.on.rectangle",
                    title: onlyFavorites ? store.localized("Chưa có yêu thích", "No favorites yet", "暂无收藏") : store.localized("Chưa tìm thấy hình nền", "No wallpapers found", "未找到壁纸"),
                    message: onlyFavorites ? store.localized("Chạm vào trái tim để lưu hình nền tại đây.", "Tap a heart to save a wallpaper here.", "轻点爱心，在这里收藏壁纸。") : store.localized("Thử từ khóa khác hoặc kéo xuống để làm mới.", "Try another search or pull down to refresh.", "尝试其他关键词或下拉刷新。"))
            } else {
                LazyVGrid(columns: columns, spacing: 20) {
                    ForEach(filtered) { item in
                        PosterCard(item: item,
                                   isFavorite: model.favorites.contains(item.id),
                                   onOpen: { selected = item },
                                   onFavorite: { Task { await model.toggleFavorite(item.id) } })
                    }
                }
            }
        }
    }
}

// MARK: - Artwork

private struct RemotePoster: View {
    let url: URL?
    var body: some View {
        AsyncImage(url: url, transaction: Transaction(animation: .easeOut(duration: 0.3))) { phase in
            switch phase {
            case .success(let image):
                image.resizable().scaledToFill()
            case .failure:
                ZStack {
                    DynorDesign.mist
                    Image(systemName: "photo").font(.title2).foregroundStyle(.secondary)
                }
            default:
                ZStack {
                    DynorDesign.mist
                    ProgressView()
                }
            }
        }
    }
}

private struct FavoriteButton: View {
    @EnvironmentObject private var store: DynorStore
    let isFavorite: Bool
    let action: () -> Void
    var body: some View {
        GlassIconButton(symbol: isFavorite ? "heart.fill" : "heart", tint: isFavorite ? store.accentColor : .white, action: action)
            .environment(\.colorScheme, .dark)
            .accessibilityLabel(isFavorite ? store.localized("Bỏ yêu thích", "Remove favorite", "取消收藏") : store.localized("Thêm yêu thích", "Add favorite", "添加收藏"))
    }
}

private struct FeaturedCard: View {
    let item: OnlineWallpaper
    let isFavorite: Bool
    let onOpen: () -> Void
    let onFavorite: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Button(action: onOpen) {
                Color.clear
                    .aspectRatio(1.35, contentMode: .fit)
                    .overlay { RemotePoster(url: OnlineConfig.preview(item.cover_path)) }
                    .overlay {
                        LinearGradient(colors: [.clear, .black.opacity(0.65)], startPoint: .center, endPoint: .bottom)
                    }
                    .overlay(alignment: .bottomLeading) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.title).font(.headline).foregroundStyle(.white).lineLimit(2)
                            Text(item.category).font(.caption).foregroundStyle(.white.opacity(0.8))
                        }
                        .dynamicTypeSize(...DynamicTypeSize.xxxLarge)
                        .padding(18)
                    }
                    .overlay(alignment: .topLeading) {
                        if item.is_vip { VIPBadge().padding(12) }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                    .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            }
            .buttonStyle(DynorPressStyle())
            .accessibilityLabel("\(item.title), \(item.category)")
            FavoriteButton(isFavorite: isFavorite, action: onFavorite).padding(10)
        }
    }
}

private struct VIPBadge: View {
    var body: some View {
        Text("VIP").font(.caption2.weight(.semibold))
            .padding(.horizontal, 8).padding(.vertical, 5)
            .foregroundStyle(.white)
            .background(Color.blue, in: Capsule())
    }
}

private struct PosterCard: View {
    let item: OnlineWallpaper
    let isFavorite: Bool
    let onOpen: () -> Void
    let onFavorite: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .topTrailing) {
                Button(action: onOpen) {
                    Color.clear
                        .aspectRatio(0.66, contentMode: .fit)
                        .overlay { RemotePoster(url: OnlineConfig.preview(item.cover_path)) }
                        .overlay(alignment: .topLeading) {
                            if item.is_vip { VIPBadge().padding(10) }
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                        .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                }
                .buttonStyle(DynorPressStyle())
                .accessibilityLabel("\(item.title), \(item.category)")
                FavoriteButton(isFavorite: isFavorite, action: onFavorite).padding(6)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(item.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                Text(item.category).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            .padding(.horizontal, 2)
        }
    }
}

// MARK: - Detail

private struct OnlineWallpaperDetail: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    @ObservedObject var model: OnlineGalleryModel
    @Environment(\.dismiss) private var dismiss
    @State private var showVideo = false
    @State private var downloading = false
    @State private var importedWallpaper: ImportedWallpaper?
    @State private var notice: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                topBar
                Color.clear
                    .frame(height: 410)
                    .overlay { RemotePoster(url: OnlineConfig.preview(item.cover_path)) }
                    .clipShape(RoundedRectangle(cornerRadius: 24))
                    .accessibilityLabel(store.localized("Ảnh xem trước hình nền", "Wallpaper preview", "壁纸预览"))
                bottomPanel
            }
            .padding(20)
            .frame(maxWidth: 640)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .safeAreaInset(edge: .bottom, spacing: 0) { downloadBar }
        .interactiveDismissDisabled(downloading)
        .sheet(isPresented: $showVideo) {
            if let path = item.video_path, let url = OnlineConfig.preview(path) { OnlineVideoView(url: url) }
        }
        .sheet(item: $importedWallpaper) { wallpaper in
            LibraryPreview(item: wallpaper).environmentObject(store)
        }
        .onChange(of: store.selectedTab) { _, tab in
            if tab != .discover { dismiss() }
        }
        .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) { notice = nil }
        } message: { Text(notice ?? "") }
    }

    private var topBar: some View {
        HStack {
            Text(store.localized("Xem trước", "Preview", "预览")).font(.headline)
            Spacer()
            GlassIconButton(symbol: "xmark") { dismiss() }
                .disabled(downloading)
                .accessibilityLabel(store.localized("Đóng", "Close", "关闭"))
        }
    }

    private var bottomPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Text(item.category).font(.subheadline).foregroundStyle(.secondary)
                if item.is_vip { VIPBadge() }
            }
            Text(item.title)
                .font(.title2.weight(.bold))
                .fixedSize(horizontal: false, vertical: true)
            if item.video_path != nil {
                Button { showVideo = true } label: {
                    Label(store.localized("Xem video", "Watch preview", "观看预览"), systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(DynorGlassButtonStyle())
            }
            Text(store.localized("Tải vào Bộ sưu tập, sau đó chọn Cài hình nền. Gói mã hóa cần đăng nhập và Internet mỗi lần cài. Nội dung VIP cần tài khoản VIP còn hiệu lực.", "Download to your collection, then choose Install Wallpaper. Encrypted packages need sign-in and Internet each time. VIP content requires active VIP access.", "下载到收藏后，选择安装壁纸。加密包每次安装均需登录和联网。VIP 内容需要有效的 VIP 权限。"))
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var downloadBar: some View {
        HStack(spacing: 12) {
            Button { Task { await model.toggleFavorite(item.id) } } label: {
                Image(systemName: model.favorites.contains(item.id) ? "heart.fill" : "heart")
                    .font(.title3)
                    .frame(width: 48, height: 48)
            }
            .buttonStyle(.plain)
            .foregroundStyle(store.accentColor)
            .accessibilityLabel(store.localized("Yêu thích", "Favorite", "收藏"))
            Button { startDownload() } label: {
                HStack(spacing: 8) {
                    if downloading { ProgressView().tint(store.accentTextColor) }
                    Text(downloading ? store.localized("Đang tải…", "Downloading…", "正在下载…") : store.localized("Tải hình nền", "Get wallpaper", "下载壁纸"))
                    if !downloading { Image(systemName: "arrow.down") }
                }
                .font(.body.weight(.semibold))
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(DynorPrimaryButtonStyle())
            .disabled(downloading)
        }
        .padding(12)
        .modifier(DynorGlass(radius: 28))
        .padding(.horizontal, 16).padding(.vertical, 10)
        .frame(maxWidth: 640)
        .frame(maxWidth: .infinity)
    }

    private func startDownload() {
        downloading = true
        Task {
            do {
                let downloadedURL = try await model.download(item)
                defer { try? FileManager.default.removeItem(at: downloadedURL.deletingLastPathComponent()) }
                let imported = await store.importWallpapers(urls: [downloadedURL])
                if let wallpaper = imported.first {
                    store.message = nil
                    importedWallpaper = wallpaper
                } else {
                    notice = store.message ?? "Chưa nhập được hình nền đã tải."
                    store.message = nil
                }
            } catch { notice = error.localizedDescription }
            downloading = false
        }
    }
}

private struct OnlineVideoView: View {
    @EnvironmentObject private var store: DynorStore
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Group { if let player { VideoPlayer(player: player) } else { ProgressView().tint(.white) } }
                .ignoresSafeArea()
            GlassIconButton(symbol: "xmark") { dismiss() }
                .accessibilityLabel(store.localized("Đóng video", "Close video", "关闭视频"))
                .environment(\.colorScheme, .dark)
                .padding(18)
        }
        .onAppear { let p = AVPlayer(url: url); player = p; p.play() }
        .onDisappear { player?.pause(); player = nil }
    }
}
