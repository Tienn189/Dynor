import SwiftUI
import PhotosUI
import UIKit
import CoreMotion
import ImageIO
import UniformTypeIdentifiers

private enum StudioMode: String, CaseIterable, Codable {
    case sleep = "Sleep", locked = "Locked", unlocked = "Unlocked"
}
private struct StudioKeyframe: Codable {
    var x: Double
    var y: Double
    var scale: Double
    var opacity: Double
    var rotation: Double
}

private struct StudioLayer: Identifiable, Codable {
    var id = UUID()
    var kind: String = "text"
    var text: String = "Dynor"
    var x: Double = 0.5
    var y: Double = 0.5
    var scale: Double = 1
    var opacity: Double = 1
    var rotation: Double = 0
    var animate = false
    var startFrame: StudioKeyframe? = nil
    var endFrame: StudioKeyframe? = nil
    var imageData: Data? = nil
    var hidden = false
    var locked = false
}
private struct StudioProject: Codable {
    var layers: [StudioLayer]
    var palette: Int
    var background: Data?
}

/// Native Dynor editor. Previews are not PosterBoard installations.
struct DynorStudioView: View {
    @Environment(\.colorScheme) private var colorScheme
    private var lightCanvas: Bool { colorScheme != .dark }
    @State private var canvasZoom: CGFloat = 0.62
    @State private var canvasZoomBase: CGFloat? = nil
    @State private var showTimeline = false
    @State private var showLayers = false
    @State private var showExport = false
    @State private var showTools = false

    @State private var selection: PhotosPickerItem?
    @State private var imageSelections: [PhotosPickerItem] = []
    @State private var draggingID: UUID?
    @State private var dragStart: CGPoint?
    @State private var scalingID: UUID?
    @State private var scaleStart: Double?
    @State private var rotatingID: UUID?
    @State private var rotationStart: Double?
    @State private var backgroundImage: UIImage?
    @State private var layers: [StudioLayer] = []
    @State private var selectedID: UUID?
    @State private var palette = 0
    @State private var mode: StudioMode = .locked
    @State private var timelineProgress = 0.0
    @State private var playing = false
    @State private var phase = false
    @State private var gyroEnabled = false
    @State private var tilt = CGSize.zero
    @State private var showShare = false
    @State private var exported: UIImage?
    @State private var exportedGIF: URL?
    @State private var exportingGIF = false
    @State private var easingEnabled = true
    @State private var message: String?
    private let motion = CMMotionManager()
    private let palettes: [[UIColor]] = [
        [.systemIndigo, .black], [.systemTeal, .systemBlue],
        [.systemOrange, .systemPink], [.darkGray, .black]
    ]
    private var selectedIndex: Int? { layers.firstIndex(where: { $0.id == selectedID }) }
    private var projectURL: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("DynorStudioProject.json") }

    var body: some View {
        GeometryReader { screen in
            let wallpaperWidth = min(screen.size.width * 0.74, 330.0)
            let wallpaperHeight = wallpaperWidth * 19.5 / 9
            ZStack {
                (lightCanvas ? Color(red: 0.95, green: 0.95, blue: 0.95) : Color(red: 0.105, green: 0.11, blue: 0.12)).ignoresSafeArea()
                StudioGridBackground(light: lightCanvas).ignoresSafeArea()

                // The canvas zoom only scales the viewport. It never rotates or
                // modifies the wallpaper/layer project coordinates.
                GeometryReader { viewport in
                    ZStack {
                        ZStack {
                            LinearGradient(colors: palettes[palette].map { Color(uiColor: $0) },
                                           startPoint: .topLeading, endPoint: .bottomTrailing)
                            if let backgroundImage {
                                Image(uiImage: backgroundImage).resizable().scaledToFill()
                                    .frame(width: wallpaperWidth, height: wallpaperHeight).clipped()
                            }
                            ForEach(layers.filter { !$0.hidden }) { layer in
                                layerView(layer)
                                    .scaleEffect(frame(for: layer).scale)
                                    .opacity(frame(for: layer).opacity)
                                    .rotationEffect(.degrees(frame(for: layer).rotation))
                                    .position(x: wallpaperWidth * frame(for: layer).x + (gyroEnabled ? tilt.width : 0),
                                              y: wallpaperHeight * frame(for: layer).y + (gyroEnabled ? tilt.height : 0))
                                    .contentShape(Rectangle())
                                    .onTapGesture { selectedID = layer.id }
                                    .gesture(DragGesture(minimumDistance: 1)
                                        .onChanged { value in
                                            guard !layer.locked else { return }
                                            if draggingID != layer.id {
                                                draggingID = layer.id
                                                dragStart = CGPoint(x: layer.x, y: layer.y)
                                            }
                                            guard let start = dragStart else { return }
                                            updateLayer(layer.id) { item in
                                                item.x = min(1.5, max(-0.5, Double(start.x) + Double(value.translation.width / wallpaperWidth)))
                                                item.y = min(1.5, max(-0.5, Double(start.y) + Double(value.translation.height / wallpaperHeight)))
                                            }
                                            selectedID = layer.id
                                        }.onEnded { _ in draggingID = nil; dragStart = nil })
                            }
                            if mode == .sleep { Color.black.opacity(0.72).allowsHitTesting(false) }
                            if mode == .locked {
                                VStack {
                                    Text("9:41").font(.system(size: 54, weight: .thin, design: .rounded))
                                    Spacer()
                                }.foregroundStyle(.white).padding(.top, 45).allowsHitTesting(false)
                            }
                        }
                        .frame(width: wallpaperWidth, height: wallpaperHeight)
                        .clipped()
                        .overlay {
                            Rectangle().strokeBorder(lightCanvas ? .black.opacity(0.16) : .white.opacity(0.65), lineWidth: 1)
                        }
                        .overlay {
                            if let selectedID, let layer = layers.first(where: { $0.id == selectedID }), !layer.hidden {
                                Rectangle()
                                    .stroke(Color.cyan, style: StrokeStyle(lineWidth: 1.3, dash: [5, 4]))
                                    .frame(width: 150 * frame(for: layer).scale, height: 190 * frame(for: layer).scale)
                                    .overlay(alignment: .topLeading) { Circle().fill(.white).frame(width: 7, height: 7).offset(x: -4, y: -4) }
                                    .overlay(alignment: .topTrailing) { Circle().fill(.white).frame(width: 7, height: 7).offset(x: 4, y: -4) }
                                    .overlay(alignment: .bottomLeading) { Circle().fill(.white).frame(width: 7, height: 7).offset(x: -4, y: 4) }
                                    .overlay(alignment: .bottomTrailing) { Circle().fill(.white).frame(width: 7, height: 7).offset(x: 4, y: 4) }
                                    .position(x: wallpaperWidth * frame(for: layer).x,
                                              y: wallpaperHeight * frame(for: layer).y)
                                    .allowsHitTesting(false)
                            }
                        }
                        .scaleEffect(canvasZoom)
                        .animation(.interactiveSpring(response: 0.26, dampingFraction: 0.88), value: canvasZoom)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                    .simultaneousGesture(
                        MagnificationGesture()
                            .onChanged { amount in
                                if canvasZoomBase == nil { canvasZoomBase = canvasZoom }
                                canvasZoom = min(1.5, max(0.18, (canvasZoomBase ?? canvasZoom) * amount))
                            }
                            .onEnded { _ in canvasZoomBase = nil }
                    )
                    .onTapGesture { selectedID = nil }
                }
                VStack(spacing: 0) {
                    HStack(spacing: 18) {
                        Text("Studio").font(.headline)
                        Spacer()
                        Button { showTools = true } label: { Image(systemName: "plus.circle") }
                        Button { showLayers = true } label: { Image(systemName: "square.3.layers.3d") }
                        Button { showTimeline = true } label: { Image(systemName: "timeline.selection") }
                        Button { showExport = true } label: { Image(systemName: "square.and.arrow.up") }
                    }
                    .font(.system(size: 20)).foregroundStyle(lightCanvas ? .black : .white)
                    .padding(.horizontal, 18).padding(.vertical, 14)
                    .background(lightCanvas ? Color.white.opacity(0.96) : Color.black.opacity(0.72))
                    Spacer()
                    HStack {
                        Button { withAnimation(.smooth(duration: 0.25)) { canvasZoom = max(0.18, canvasZoom - 0.12) } } label: { Image(systemName: "minus.magnifyingglass") }
                        Spacer()
                        Text("\(Int(canvasZoom * 100))% · Không xoay canvas")
                            .font(.caption.monospacedDigit())
                        Spacer()
                        Button { withAnimation(.smooth(duration: 0.25)) { canvasZoom = min(1.5, canvasZoom + 0.12) } } label: { Image(systemName: "plus.magnifyingglass") }
                    }
                    .foregroundStyle(lightCanvas ? .black : .white)
                    .padding(12).background(lightCanvas ? Color.white.opacity(0.96) : Color.black.opacity(0.78), in: Capsule())
                    .padding(.horizontal, 26)
                    if let selectedID, let layerBinding = bindingForLayer(selectedID) {
                        HStack(spacing: 12) {
                            Button { duplicate(selectedID) } label: { Image(systemName: "plus.square.on.square") }
                            Button { updateLayer(selectedID) { $0.locked.toggle() } } label: { Image(systemName: layerBinding.wrappedValue.locked ? "lock.fill" : "lock.open") }
                            Button { updateLayer(selectedID) { $0.rotation = 0 } } label: { Image(systemName: "rotate.left") }
                            Button { updateLayer(selectedID) { $0.scale = min(8, $0.scale * 1.1) } } label: { Image(systemName: "arrow.up.left.and.arrow.down.right") }
                            Button { updateLayer(selectedID) { $0.scale = max(0.1, $0.scale / 1.1) } } label: { Image(systemName: "arrow.down.right.and.arrow.up.left") }
                            Button(role: .destructive) { layers.removeAll { $0.id == selectedID }; self.selectedID = nil } label: { Image(systemName: "trash") }
                        }
                        .foregroundStyle(lightCanvas ? .black : .white)
                        .padding(12).background(lightCanvas ? Color.white.opacity(0.96) : Color.black.opacity(0.8), in: Capsule())
                        .padding(.top, 10)
                    }
                }
            }
        }
        .navigationBarHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .sheet(isPresented: $showTools) {
            NavigationStack {
                ScrollView {
                    VStack(spacing: 16) {
                        PhotosPicker(selection: $selection, matching: .images) { Label("Chọn ảnh nền", systemImage: "photo") }
                        PhotosPicker(selection: $imageSelections, maxSelectionCount: 20, matching: .images) { Label("Thêm layer ảnh", systemImage: "photo.stack") }
                        Button { addLayer("text") } label: { Label("Thêm chữ", systemImage: "textformat") }
                        Button { addLayer("shape") } label: { Label("Thêm hình", systemImage: "square") }
                        Button { addLayer("particles") } label: { Label("Thêm hạt", systemImage: "sparkles") }
                        HStack {
                            Text("Màu nền")
                            ForEach(0..<palettes.count, id: \.self) { index in
                                Button { palette = index } label: {
                                    Circle().fill(Color(uiColor: palettes[index][0])).frame(width: 30, height: 30)
                                }
                            }
                        }
                        Picker("Trạng thái", selection: $mode) {
                            ForEach(StudioMode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                        }.pickerStyle(.segmented)
                        Toggle("Gyro", isOn: $gyroEnabled)
                        Button("Lưu dự án") { saveProject() }
                        Button("Mở dự án") { loadProject() }
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(22)
                }
                .navigationTitle("Công cụ")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { showTools = false } } }
            }.presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showLayers) {
            NavigationStack {
                List {
                    ForEach(layers) { layer in
                        HStack {
                            Button { selectedID = layer.id; showLayers = false } label: {
                                Text(layer.kind == "text" ? layer.text : layer.kind).lineLimit(1)
                            }
                            Spacer()
                            Button { updateLayer(layer.id) { $0.hidden.toggle() } } label: { Image(systemName: layer.hidden ? "eye.slash" : "eye") }
                            Button { updateLayer(layer.id) { $0.locked.toggle() } } label: { Image(systemName: layer.locked ? "lock.fill" : "lock.open") }
                            Button { move(layer.id, -1) } label: { Image(systemName: "arrow.up") }
                            Button { move(layer.id, 1) } label: { Image(systemName: "arrow.down") }
                        }
                    }
                }
                .navigationTitle("Layer")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { showLayers = false } } }
            }.presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showTimeline) {
            NavigationStack {
                VStack(spacing: 16) {
                    Text(String(format: "%.1f / 3.0 giây", timelineProgress * 3))
                    Slider(value: $timelineProgress, in: 0...1)
                    Toggle("Ease in / out", isOn: $easingEnabled)
                    if let selectedID {
                        Button("Đặt keyframe 0s") {
                            if let item = layers.first(where: { $0.id == selectedID }) {
                                let key = snapshot(item)
                                updateLayer(selectedID) { $0.startFrame = key }
                            }
                        }
                        Button("Đặt keyframe 3s") {
                            if let item = layers.first(where: { $0.id == selectedID }) {
                                let key = snapshot(item)
                                updateLayer(selectedID) { $0.endFrame = key }
                            }
                        }
                    }
                    Spacer()
                }.padding(20)
                .navigationTitle("Timeline")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { showTimeline = false } } }
            }.presentationDetents([.medium])
        }
        .sheet(isPresented: $showExport) {
            NavigationStack {
                VStack(spacing: 22) {
                    Button("Xuất GIF 3 giây") { showExport = false; exportGIF() }
                        .disabled(exportingGIF)
                    Button("Xuất PNG") {
                        if let image = renderWallpaper() { exported = image; exportedGIF = nil; showExport = false; showShare = true }
                    }
                    Text("GIF là tệp chia sẻ, chưa phải hình nền động PosterBoard.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Spacer()
                }.padding(24)
                .buttonStyle(.borderedProminent)
                .navigationTitle("Xuất hình nền")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { showExport = false } } }
            }.presentationDetents([.medium])
        }
        .onChange(of: selection) { _, item in
            Task {
                guard let data = try? await item?.loadTransferable(type: Data.self), let image = UIImage(data: data) else { return }
                await MainActor.run { backgroundImage = image }
            }
        }
        .onChange(of: imageSelections) { _, items in
            Task {
                var imported: [Data] = []
                for item in items {
                    if let data = try? await item.loadTransferable(type: Data.self), let image = UIImage(data: data) {
                        let longest = max(image.size.width, image.size.height)
                        let factor = min(1, 1800 / max(longest, 1))
                        let target = CGSize(width: image.size.width * factor, height: image.size.height * factor)
                        let reduced = UIGraphicsImageRenderer(size: target).image { _ in image.draw(in: CGRect(origin: .zero, size: target)) }
                        if let compressed = reduced.jpegData(compressionQuality: 0.85) { imported.append(compressed) }
                    }
                }
                await MainActor.run {
                    for data in imported {
                        let layer = StudioLayer(kind: "image", text: "Ảnh", imageData: data)
                        layers.append(layer); selectedID = layer.id
                    }
                    imageSelections = []
                }
            }
        }
        .onChange(of: gyroEnabled) { _, enabled in if enabled { startMotion() } else { motion.stopDeviceMotionUpdates(); tilt = .zero } }
        .onDisappear { motion.stopDeviceMotionUpdates() }
        .sheet(isPresented: $showShare, onDismiss: { exportedGIF = nil }) {
            if let exportedGIF { StudioShareSheet(items: [exportedGIF]) }
            else if let exported { StudioShareSheet(items: [exported]) }
        }
        .alert("Studio", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func snapshot(_ layer: StudioLayer) -> StudioKeyframe {
        StudioKeyframe(x: layer.x, y: layer.y, scale: layer.scale,
                       opacity: layer.opacity, rotation: layer.rotation)
    }

    private func frame(for layer: StudioLayer) -> StudioKeyframe {
        let fallback = snapshot(layer)
        guard let start = layer.startFrame, let end = layer.endFrame else { return fallback }
        let t = easingEnabled ? timelineProgress * timelineProgress * (3 - 2 * timelineProgress) : timelineProgress
        func mix(_ a: Double, _ b: Double) -> Double { a + (b - a) * t }
        return StudioKeyframe(x: mix(start.x, end.x), y: mix(start.y, end.y),
                              scale: mix(start.scale, end.scale),
                              opacity: mix(start.opacity, end.opacity),
                              rotation: mix(start.rotation, end.rotation))
    }

    private func bindingForLayer(_ id: UUID) -> Binding<StudioLayer>? {
        guard layers.contains(where: { $0.id == id }) else { return nil }
        return Binding(
            get: { layers.first(where: { $0.id == id }) ?? StudioLayer(id: id) },
            set: { updated in
                guard let index = layers.firstIndex(where: { $0.id == id }) else { return }
                layers[index] = updated
            }
        )
    }

    private func layerView(_ layer: StudioLayer) -> some View {
        Group {
            switch layer.kind {
            case "image":
                if let data = layer.imageData, let image = UIImage(data: data) {
                    Image(uiImage: image).resizable().scaledToFit().frame(width: 175, height: 220)
                } else { Image(systemName: "photo.badge.exclamationmark") }
            case "shape": RoundedRectangle(cornerRadius: 20).fill(.white.opacity(0.75)).frame(width: 90, height: 90)
            case "particles": Image(systemName: "sparkles").font(.system(size: 72)).foregroundStyle(.yellow)
            default: Text(layer.text).font(.system(size: 35, weight: .bold)).foregroundStyle(.white)
                .shadow(color: .black.opacity(0.65), radius: 5).multilineTextAlignment(.center)
            }
        }
    }
    private func slider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 2) { Text(title).font(.subheadline); Slider(value: value, in: range) }
    }
    private func addLayer(_ kind: String) {
        let layer = StudioLayer(kind: kind, text: "Dynor")
        layers.append(layer); selectedID = layer.id
    }
    private func updateLayer(_ id: UUID, _ change: (inout StudioLayer) -> Void) {
        guard let index = layers.firstIndex(where: { $0.id == id }) else { return }
        change(&layers[index])
    }
    private func duplicate(_ id: UUID) {
        guard let original = layers.first(where: { $0.id == id }) else { return }
        var copy = original; copy.id = UUID(); copy.x += 0.04; copy.y += 0.04
        layers.append(copy); selectedID = copy.id
    }
    private func move(_ id: UUID, _ offset: Int) {
        guard let index = layers.firstIndex(where: { $0.id == id }), layers.indices.contains(index + offset) else { return }
        layers.swapAt(index, index + offset)
    }
    private func saveProject() {
        let project = StudioProject(layers: layers, palette: palette, background: backgroundImage?.jpegData(compressionQuality: 0.8))
        do { try JSONEncoder().encode(project).write(to: projectURL, options: .atomic); message = "Đã lưu dự án trên thiết bị." }
        catch { message = "Không thể lưu dự án: \(error.localizedDescription)" }
    }
    private func loadProject() {
        do {
            let project = try JSONDecoder().decode(StudioProject.self, from: Data(contentsOf: projectURL))
            layers = project.layers; palette = min(max(project.palette, 0), palettes.count - 1)
            backgroundImage = project.background.flatMap(UIImage.init(data:)); selectedID = nil
            message = "Đã mở dự án."
        } catch { message = "Không thể mở dự án: \(error.localizedDescription)" }
    }
    private func startMotion() {
        guard motion.isDeviceMotionAvailable else { gyroEnabled = false; message = "Thiết bị không hỗ trợ cảm biến chuyển động."; return }
        motion.deviceMotionUpdateInterval = 1.0 / 30
        motion.startDeviceMotionUpdates(to: .main) { reading, _ in
            guard let reading else { return }
            tilt = CGSize(width: reading.attitude.roll * 12, height: reading.attitude.pitch * 12)
        }
    }
    private func exportGIF() {
        guard !exportingGIF else { return }
        exportingGIF = true
        let file = FileManager.default.temporaryDirectory
            .appendingPathComponent("Dynor-Studio-\(UUID().uuidString).gif")
        // Render on the main actor to keep UIKit rendering and state consistent.
        Task { @MainActor in
            guard let destination = CGImageDestinationCreateWithURL(
                file as CFURL, UTType.gif.identifier as CFString, 30, nil
            ) else {
                exportingGIF = false
                message = "Không thể tạo tệp GIF."
                return
            }
            let loop: [CFString: Any] = [kCGImagePropertyGIFLoopCount: 0]
            CGImageDestinationSetProperties(destination, [kCGImagePropertyGIFDictionary: loop] as CFDictionary)
            let frameProperties: [CFString: Any] = [
                kCGImagePropertyGIFDictionary: [kCGImagePropertyGIFDelayTime: 0.1]
            ]
            for index in 0..<30 {
                let progress = Double(index) / 29
                if let frame = renderWallpaper(progress: progress, size: CGSize(width: 390, height: 845)),
                   let cgImage = frame.cgImage {
                    CGImageDestinationAddImage(destination, cgImage, frameProperties as CFDictionary)
                }
                if index % 5 == 0 { await Task.yield() }
            }
            let success = CGImageDestinationFinalize(destination)
            exportingGIF = false
            if success {
                exported = nil
                exportedGIF = file
                showShare = true
            } else {
                message = "Xuất GIF thất bại. Hãy thử giảm số lượng layer."
            }
        }
    }

    private func exportFrame(for layer: StudioLayer, progress: Double?) -> StudioKeyframe {
        guard let progress, let start = layer.startFrame, let end = layer.endFrame else {
            return snapshot(layer)
        }
        let t = easingEnabled ? progress * progress * (3 - 2 * progress) : progress
        func mix(_ a: Double, _ b: Double) -> Double { a + (b - a) * t }
        return StudioKeyframe(x: mix(start.x, end.x), y: mix(start.y, end.y),
                              scale: mix(start.scale, end.scale), opacity: mix(start.opacity, end.opacity),
                              rotation: mix(start.rotation, end.rotation))
    }

    private func renderWallpaper(progress: Double? = nil, size: CGSize = CGSize(width: 1170, height: 2535)) -> UIImage? {
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let colors = palettes[palette].map(\.cgColor) as CFArray
            if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
                ctx.cgContext.drawLinearGradient(gradient, start: .zero, end: CGPoint(x: size.width, y: size.height), options: [])
            }
            if let image = backgroundImage {
                let ratio = max(size.width / image.size.width, size.height / image.size.height)
                let w = image.size.width * ratio, h = image.size.height * ratio
                image.draw(in: CGRect(x: (size.width - w) / 2, y: (size.height - h) / 2, width: w, height: h))
            }
            for layer in layers where !layer.hidden {
                ctx.cgContext.saveGState()
                let state = exportFrame(for: layer, progress: progress)
                ctx.cgContext.translateBy(x: size.width * state.x, y: size.height * state.y)
                ctx.cgContext.rotate(by: CGFloat(state.rotation * .pi / 180))
                ctx.cgContext.scaleBy(x: state.scale * size.width / 1170, y: state.scale * size.width / 1170)
                ctx.cgContext.setAlpha(state.opacity)
                if layer.kind == "image", let data = layer.imageData, let image = UIImage(data: data) {
                    let maxDimension: CGFloat = 650
                    let ratio = min(maxDimension / max(image.size.width, 1), maxDimension / max(image.size.height, 1))
                    let w = image.size.width * ratio, h = image.size.height * ratio
                    image.draw(in: CGRect(x: -w/2, y: -h/2, width: w, height: h))
                } else if layer.kind == "shape" {
                    UIColor.white.withAlphaComponent(0.75).setFill()
                    UIBezierPath(roundedRect: CGRect(x: -135, y: -135, width: 270, height: 270), cornerRadius: 60).fill()
                } else {
                    let text = layer.kind == "particles" ? "✦" : layer.text
                    let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: layer.kind == "particles" ? 180 : 105), .foregroundColor: layer.kind == "particles" ? UIColor.systemYellow : UIColor.white]
                    let rect = CGRect(x: -500, y: -120, width: 1000, height: 240)
                    (text as NSString).draw(in: rect, withAttributes: attrs)
                }
                ctx.cgContext.restoreGState()
            }
        }
    }
}

private struct StudioShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

private struct StudioGridBackground: View {
    let light: Bool
    var body: some View {
        Canvas { context, size in
            let spacing: CGFloat = 16
            var lines = Path()
            for x in stride(from: CGFloat(0), through: size.width, by: spacing) {
                lines.move(to: CGPoint(x: x, y: 0))
                lines.addLine(to: CGPoint(x: x, y: size.height))
            }
            for y in stride(from: CGFloat(0), through: size.height, by: spacing) {
                lines.move(to: CGPoint(x: 0, y: y))
                lines.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(lines, with: .color(light ? .black.opacity(0.085) : .white.opacity(0.065)), lineWidth: 0.5)
        }
        .background(light ? Color(red: 0.95, green: 0.95, blue: 0.95) : Color(red: 0.105, green: 0.11, blue: 0.12))
        .allowsHitTesting(false)
    }
}
