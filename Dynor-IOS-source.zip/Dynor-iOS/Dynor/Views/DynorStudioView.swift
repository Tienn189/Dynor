import SwiftUI
import PhotosUI
import UIKit

/// A native, self-contained first-stage wallpaper editor.
/// This is not CAPlayground's proprietary editor or PosterBoard installer.
struct DynorStudioView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var selection: PhotosPickerItem?
    @State private var backgroundImage: UIImage?
    @State private var caption = ""
    @State private var textSize: Double = 48
    @State private var textPosition: Double = 0.72
    @State private var palette = 0
    @State private var exported: UIImage?
    @State private var showShare = false
    @State private var status: String?

    private let palettes: [[UIColor]] = [
        [.systemIndigo, .black], [.systemTeal, .systemBlue],
        [.systemOrange, .systemPink], [.darkGray, .black]
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Tạo hình nền của riêng bạn")
                    .font(.headline)
                GeometryReader { geo in
                    ZStack {
                        LinearGradient(colors: palettes[palette].map(Color.init(uiColor:)), startPoint: .topLeading, endPoint: .bottomTrailing)
                        if let backgroundImage {
                            Image(uiImage: backgroundImage)
                                .resizable().scaledToFill()
                                .frame(width: geo.size.width, height: geo.size.height)
                                .clipped()
                        }
                        Text(caption)
                            .font(.system(size: CGFloat(textSize) * geo.size.width / 390, weight: .bold))
                            .foregroundStyle(.white)
                            .shadow(color: .black.opacity(0.65), radius: 6)
                            .multilineTextAlignment(.center)
                            .padding(16)
                            .position(x: geo.size.width / 2, y: geo.size.height * textPosition)
                    }
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipShape(RoundedRectangle(cornerRadius: 24))
                }
                .aspectRatio(9.0 / 19.5, contentMode: .fit)
                .frame(maxWidth: 320)
                .frame(maxWidth: .infinity)

                PhotosPicker(selection: $selection, matching: .images) {
                    Label("Chọn ảnh nền", systemImage: "photo.on.rectangle")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                TextField("Thêm chữ lên hình nền", text: $caption)
                    .textFieldStyle(.roundedBorder)

                VStack(alignment: .leading) {
                    Text("Cỡ chữ")
                    Slider(value: $textSize, in: 20...85)
                    Text("Vị trí chữ")
                    Slider(value: $textPosition, in: 0.12...0.88)
                }

                HStack {
                    Text("Màu nền")
                    Spacer()
                    ForEach(0..<palettes.count, id: \.self) { index in
                        Button {
                            palette = index
                        } label: {
                            Circle().fill(Color(uiColor: palettes[index][0]))
                                .frame(width: 30, height: 30)
                                .overlay(Circle().stroke(.primary, lineWidth: palette == index ? 2 : 0))
                        }
                        .accessibilityLabel("Màu nền \(index + 1)")
                    }
                }

                Button {
                    guard let image = renderWallpaper() else {
                        status = "Không thể xuất hình nền."
                        return
                    }
                    exported = image
                    showShare = true
                } label: {
                    Label("Xuất hình nền tĩnh", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                Text("Studio hiện hỗ trợ ảnh, chữ, màu nền và xuất PNG. Hoạt ảnh CAPlayground, tệp dự án và cài PosterBoard chưa được tích hợp.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .navigationTitle("Studio")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: selection) { _, item in
            Task {
                guard let data = try? await item?.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else { return }
                await MainActor.run { backgroundImage = image }
            }
        }
        .sheet(isPresented: $showShare) {
            if let exported { StudioShareSheet(items: [exported]) }
        }
        .alert("Studio", isPresented: Binding(get: { status != nil }, set: { if !$0 { status = nil } })) {
            Button("OK") { status = nil }
        } message: { Text(status ?? "") }
    }

    private func renderWallpaper() -> UIImage? {
        let size = CGSize(width: 1170, height: 2535)
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { context in
            let bounds = CGRect(origin: .zero, size: size)
            let colors = palettes[palette]
            let cgColors = colors.map(\.cgColor) as CFArray
            if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cgColors, locations: [0, 1]) {
                context.cgContext.drawLinearGradient(gradient, start: .zero, end: CGPoint(x: size.width, y: size.height), options: [])
            }
            if let backgroundImage {
                let imageSize = backgroundImage.size
                let scale = max(size.width / imageSize.width, size.height / imageSize.height)
                let target = CGSize(width: imageSize.width * scale, height: imageSize.height * scale)
                backgroundImage.draw(in: CGRect(x: (size.width - target.width) / 2, y: (size.height - target.height) / 2, width: target.width, height: target.height))
            }
            if !caption.isEmpty {
                let font = UIFont.systemFont(ofSize: CGFloat(textSize) * 3, weight: .bold)
                let style = NSMutableParagraphStyle()
                style.alignment = .center
                let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.white, .paragraphStyle: style, .shadow: {
                    let shadow = NSShadow(); shadow.shadowColor = UIColor.black.withAlphaComponent(0.7); shadow.shadowBlurRadius = 14; return shadow
                }()]
                let text = caption as NSString
                let maxWidth = size.width - 100
                let measured = text.boundingRect(with: CGSize(width: maxWidth, height: size.height), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: attrs, context: nil)
                text.draw(in: CGRect(x: 50, y: size.height * textPosition - measured.height / 2, width: maxWidth, height: measured.height + 8), withAttributes: attrs)
            }
            _ = bounds
        }
    }
}

private struct StudioShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
