import SwiftUI
import PhotosUI
import UIKit
import CoreMotion

private enum StudioMode: String, CaseIterable, Codable {
    case sleep = "Sleep", locked = "Locked", unlocked = "Unlocked"
}
private struct StudioLayer: Identifiable, Codable {
    var id = UUID()
    var kind: String = "text"
    var text: String = "Dynor"
    var x: Double = 0.5
    var y: Double = 0.5
    var scale: Double = 1
    var opacity: Double = 1
    var rotation: Double = 0
    var animate = false
}
private struct StudioProject: Codable {
    var layers: [StudioLayer]
    var palette: Int
    var background: Data?
}

/// Native Dynor editor. Previews are not PosterBoard installations.
struct DynorStudioView: View {
    @State private var selection: PhotosPickerItem?
    @State private var backgroundImage: UIImage?
    @State private var layers: [StudioLayer] = []
    @State private var selectedID: UUID?
    @State private var palette = 0
    @State private var mode: StudioMode = .locked
    @State private var playing = false
    @State private var phase = false
    @State private var gyroEnabled = false
    @State private var tilt = CGSize.zero
    @State private var showShare = false
    @State private var exported: UIImage?
    @State private var message: String?
    private let motion = CMMotionManager()
    private let palettes: [[UIColor]] = [
        [.systemIndigo, .black], [.systemTeal, .systemBlue],
        [.systemOrange, .systemPink], [.darkGray, .black]
    ]
    private var selectedIndex: Int? { layers.firstIndex(where: { $0.id == selectedID }) }
    private var projectURL: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("DynorStudioProject.json") }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Studio · Trình chỉnh sửa").font(.title2.bold())
                Picker("Trạng thái", selection: $mode) {
                    ForEach(StudioMode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                }.pickerStyle(.segmented)
                GeometryReader { geo in
                    ZStack {
                        LinearGradient(colors: palettes[palette].map { Color(uiColor: $0) }, startPoint: .topLeading, endPoint: .bottomTrailing)
                        if let backgroundImage {
                            Image(uiImage: backgroundImage).resizable().scaledToFill()
                                .frame(width: geo.size.width, height: geo.size.height).clipped()
                        }
                        ForEach(layers) { layer in
                            layerView(layer)
                                .scaleEffect(layer.scale * (playing && phase && layer.animate ? 1.12 : 1))
                                .opacity(layer.opacity * (playing && phase && layer.animate ? 0.65 : 1))
                                .rotationEffect(.degrees(layer.rotation + (playing && phase && layer.animate ? 8 : 0)))
                                .position(x: geo.size.width * layer.x + (gyroEnabled ? tilt.width : 0),
                                          y: geo.size.height * layer.y + (gyroEnabled ? tilt.height : 0))
                                .onTapGesture { selectedID = layer.id }
                        }
                        if mode == .sleep { Color.black.opacity(0.72).allowsHitTesting(false) }
                        if mode == .locked {
                            VStack {
                                Text("9:41").font(.system(size: 58, weight: .thin, design: .rounded))
                                Spacer()
                            }.foregroundStyle(.white).padding(.top, 55).allowsHitTesting(false)
                        }
                    }
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                    .animation(.easeInOut(duration: 1.1), value: phase)
                }
                .aspectRatio(9.0 / 19.5, contentMode: .fit)
                .frame(maxWidth: 310).frame(maxWidth: .infinity)
                HStack {
                    Button { playing.toggle(); phase = false; if playing { phase = true } } label: {
                        Label(playing ? "Dừng xem trước" : "Xem hoạt ảnh", systemImage: playing ? "pause.fill" : "play.fill")
                    }
                    Spacer()
                    Toggle("Gyro", isOn: $gyroEnabled).fixedSize()
                }
                .buttonStyle(.bordered)
                PhotosPicker(selection: $selection, matching: .images) {
                    Label("Chọn ảnh nền", systemImage: "photo.on.rectangle").frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent)
                HStack {
                    Button { addLayer("text") } label: { Label("Chữ", systemImage: "textformat") }
                    Button { addLayer("shape") } label: { Label("Hình", systemImage: "square.on.circle") }
                    Button { addLayer("particles") } label: { Label("Hạt", systemImage: "sparkles") }
                }.buttonStyle(.bordered)
                if !layers.isEmpty {
                    Text("Các layer").font(.headline)
                    ForEach(layers) { layer in
                        HStack {
                            Button { selectedID = layer.id } label: {
                                Label(layer.kind == "text" ? layer.text : layer.kind, systemImage: layer.kind == "text" ? "textformat" : "square.stack")
                                    .lineLimit(1)
                            }.tint(selectedID == layer.id ? .accentColor : .primary)
                            Spacer()
                            Button { move(layer.id, -1) } label: { Image(systemName: "arrow.up") }
                            Button { move(layer.id, 1) } label: { Image(systemName: "arrow.down") }
                            Button(role: .destructive) { layers.removeAll { $0.id == layer.id }; if selectedID == layer.id { selectedID = nil } } label: { Image(systemName: "trash") }
                        }.buttonStyle(.borderless).padding(.vertical, 5)
                    }
                }
                if let i = selectedIndex {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Chỉnh sửa layer").font(.headline)
                        if layers[i].kind == "text" { TextField("Nội dung chữ", text: $layers[i].text).textFieldStyle(.roundedBorder) }
                        slider("Vị trí ngang", value: $layers[i].x, range: 0.05...0.95)
                        slider("Vị trí dọc", value: $layers[i].y, range: 0.05...0.95)
                        slider("Kích thước", value: $layers[i].scale, range: 0.3...2.5)
                        slider("Độ trong suốt", value: $layers[i].opacity, range: 0...1)
                        slider("Xoay", value: $layers[i].rotation, range: -180...180)
                        Toggle("Hoạt ảnh keyframe mẫu", isOn: $layers[i].animate)
                    }.padding(12).background(.quaternary.opacity(0.3), in: RoundedRectangle(cornerRadius: 16))
                }
                HStack {
                    Text("Màu nền")
                    Spacer()
                    ForEach(0..<palettes.count, id: \.self) { index in
                        Button { palette = index } label: {
                            Circle().fill(Color(uiColor: palettes[index][0])).frame(width: 29, height: 29)
                                .overlay(Circle().stroke(.primary, lineWidth: palette == index ? 2 : 0))
                        }.accessibilityLabel("Bảng màu \(index + 1)")
                    }
                }
                HStack {
                    Button { saveProject() } label: { Label("Lưu dự án", systemImage: "square.and.arrow.down") }
                    Button { loadProject() } label: { Label("Mở dự án", systemImage: "folder") }
                }.buttonStyle(.bordered)
                Button {
                    guard let image = renderWallpaper() else { message = "Không thể xuất ảnh."; return }
                    exported = image; showShare = true
                } label: { Label("Xuất hình nền PNG", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity) }
                    .buttonStyle(.borderedProminent)
                Text("Hoạt ảnh và gyro hiện chỉ là bản xem trước trong Dynor. PNG là ảnh tĩnh; chưa hỗ trợ xuất dự án CAPlayground, video động, Liquid Glass thực hoặc cài hoạt ảnh vào PosterBoard.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding(20)
        }
        .navigationTitle("Studio").navigationBarTitleDisplayMode(.inline)
        .onChange(of: selection) { _, item in
            Task {
                guard let data = try? await item?.loadTransferable(type: Data.self), let image = UIImage(data: data) else { return }
                await MainActor.run { backgroundImage = image }
            }
        }
        .onChange(of: gyroEnabled) { _, enabled in if enabled { startMotion() } else { motion.stopDeviceMotionUpdates(); tilt = .zero } }
        .onDisappear { motion.stopDeviceMotionUpdates() }
        .sheet(isPresented: $showShare) { if let exported { StudioShareSheet(items: [exported]) } }
        .alert("Studio", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func layerView(_ layer: StudioLayer) -> some View {
        Group {
            switch layer.kind {
            case "shape": RoundedRectangle(cornerRadius: 20).fill(.white.opacity(0.75)).frame(width: 90, height: 90)
            case "particles": Image(systemName: "sparkles").font(.system(size: 72)).foregroundStyle(.yellow)
            default: Text(layer.text).font(.system(size: 35, weight: .bold)).foregroundStyle(.white)
                .shadow(color: .black.opacity(0.65), radius: 5).multilineTextAlignment(.center)
            }
        }
    }
    private func slider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 2) { Text(title).font(.subheadline); Slider(value: value, in: range) }
    }
    private func addLayer(_ kind: String) {
        let layer = StudioLayer(kind: kind, text: "Dynor")
        layers.append(layer); selectedID = layer.id
    }
    private func move(_ id: UUID, _ offset: Int) {
        guard let index = layers.firstIndex(where: { $0.id == id }), layers.indices.contains(index + offset) else { return }
        layers.swapAt(index, index + offset)
    }
    private func saveProject() {
        let project = StudioProject(layers: layers, palette: palette, background: backgroundImage?.jpegData(compressionQuality: 0.8))
        do { try JSONEncoder().encode(project).write(to: projectURL, options: .atomic); message = "Đã lưu dự án trên thiết bị." }
        catch { message = "Không thể lưu dự án: \(error.localizedDescription)" }
    }
    private func loadProject() {
        do {
            let project = try JSONDecoder().decode(StudioProject.self, from: Data(contentsOf: projectURL))
            layers = project.layers; palette = min(max(project.palette, 0), palettes.count - 1)
            backgroundImage = project.background.flatMap(UIImage.init(data:)); selectedID = nil
            message = "Đã mở dự án."
        } catch { message = "Không thể mở dự án: \(error.localizedDescription)" }
    }
    private func startMotion() {
        guard motion.isDeviceMotionAvailable else { gyroEnabled = false; message = "Thiết bị không hỗ trợ cảm biến chuyển động."; return }
        motion.deviceMotionUpdateInterval = 1.0 / 30
        motion.startDeviceMotionUpdates(to: .main) { reading, _ in
            guard let reading else { return }
            tilt = CGSize(width: reading.attitude.roll * 12, height: reading.attitude.pitch * 12)
        }
    }
    private func renderWallpaper() -> UIImage? {
        let size = CGSize(width: 1170, height: 2535)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let colors = palettes[palette].map(\.cgColor) as CFArray
            if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
                ctx.cgContext.drawLinearGradient(gradient, start: .zero, end: CGPoint(x: size.width, y: size.height), options: [])
            }
            if let image = backgroundImage {
                let ratio = max(size.width / image.size.width, size.height / image.size.height)
                let w = image.size.width * ratio, h = image.size.height * ratio
                image.draw(in: CGRect(x: (size.width - w) / 2, y: (size.height - h) / 2, width: w, height: h))
            }
            for layer in layers {
                ctx.cgContext.saveGState()
                ctx.cgContext.translateBy(x: size.width * layer.x, y: size.height * layer.y)
                ctx.cgContext.rotate(by: CGFloat(layer.rotation * .pi / 180))
                ctx.cgContext.scaleBy(x: layer.scale, y: layer.scale)
                ctx.cgContext.setAlpha(layer.opacity)
                if layer.kind == "shape" {
                    UIColor.white.withAlphaComponent(0.75).setFill()
                    UIBezierPath(roundedRect: CGRect(x: -135, y: -135, width: 270, height: 270), cornerRadius: 60).fill()
                } else {
                    let text = layer.kind == "particles" ? "✦" : layer.text
                    let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: layer.kind == "particles" ? 180 : 105), .foregroundColor: layer.kind == "particles" ? UIColor.systemYellow : UIColor.white]
                    let rect = CGRect(x: -500, y: -120, width: 1000, height: 240)
                    (text as NSString).draw(in: rect, withAttributes: attrs)
                }
                ctx.cgContext.restoreGState()
            }
        }
    }
}

private struct StudioShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
