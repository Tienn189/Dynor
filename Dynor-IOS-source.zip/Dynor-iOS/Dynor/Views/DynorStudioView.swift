import SwiftUI
import PhotosUI
import UIKit
import CoreMotion
import ImageIO
import UniformTypeIdentifiers

private enum StudioMode: String, CaseIterable, Codable {
    case sleep = "Sleep", locked = "Locked", unlocked = "Unlocked"
}
private struct StudioKeyframe: Codable {
    var x: Double
    var y: Double
    var scale: Double
    var opacity: Double
    var rotation: Double
}

private struct StudioLayer: Identifiable, Codable {
    var id = UUID()
    var kind: String = "text"
    var text: String = "Dynor"
    var x: Double = 0.5
    var y: Double = 0.5
    var scale: Double = 1
    var opacity: Double = 1
    var rotation: Double = 0
    var animate = false
    var startFrame: StudioKeyframe? = nil
    var endFrame: StudioKeyframe? = nil
    var imageData: Data? = nil
    var hidden = false
    var locked = false
}
private struct StudioProject: Codable {
    var layers: [StudioLayer]
    var palette: Int
    var background: Data?
}

/// Native Dynor editor. Previews are not PosterBoard installations.
struct DynorStudioView: View {
    @State private var showCAPlayground = false
    @State private var selection: PhotosPickerItem?
    @State private var imageSelections: [PhotosPickerItem] = []
    @State private var draggingID: UUID?
    @State private var dragStart: CGPoint?
    @State private var scalingID: UUID?
    @State private var scaleStart: Double?
    @State private var rotatingID: UUID?
    @State private var rotationStart: Double?
    @State private var backgroundImage: UIImage?
    @State private var layers: [StudioLayer] = []
    @State private var selectedID: UUID?
    @State private var palette = 0
    @State private var mode: StudioMode = .locked
    @State private var timelineProgress = 0.0
    @State private var playing = false
    @State private var phase = false
    @State private var gyroEnabled = false
    @State private var tilt = CGSize.zero
    @State private var showShare = false
    @State private var exported: UIImage?
    @State private var exportedGIF: URL?
    @State private var exportingGIF = false
    @State private var easingEnabled = true
    @State private var message: String?
    private let motion = CMMotionManager()
    private let palettes: [[UIColor]] = [
        [.systemIndigo, .black], [.systemTeal, .systemBlue],
        [.systemOrange, .systemPink], [.darkGray, .black]
    ]
    private var selectedIndex: Int? { layers.firstIndex(where: { $0.id == selectedID }) }
    private var projectURL: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("DynorStudioProject.json") }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("DY​NOR STUDIO").font(.caption.bold()).tracking(2).foregroundStyle(.secondary)
                        Text("Trình chỉnh sửa").font(.title2.bold())
                    }
                    Spacer()
                    Text("\(layers.count) layer").font(.caption.monospacedDigit())
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(.quaternary, in: Capsule())
                }
                Button {
                    showCAPlayground = true
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "square.stack.3d.up.fill")
                            .font(.title2)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Mở trình chỉnh sửa CAPlayground").font(.headline)
                            Text("Bản web gốc · yêu cầu Internet · miễn phí trong Dynor")
                                .font(.caption)
                        }
                        Spacer()
                        Image(systemName: "arrow.up.right")
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.bordered)
                .sheet(isPresented: $showCAPlayground) {
                    CAPlaygroundWebEditor()
                }
                Picker("Trạng thái", selection: $mode) {
                    ForEach(StudioMode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                }.pickerStyle(.segmented)
                GeometryReader { geo in
                    ZStack {
                        LinearGradient(colors: palettes[palette].map { Color(uiColor: $0) }, startPoint: .topLeading, endPoint: .bottomTrailing)
                        if let backgroundImage {
                            Image(uiImage: backgroundImage).resizable().scaledToFill()
                                .frame(width: geo.size.width, height: geo.size.height).clipped()
                        }
                        ForEach(layers.filter { !$0.hidden }) { layer in
                            layerView(layer)
                                .scaleEffect(frame(for: layer).scale)
                                .opacity(frame(for: layer).opacity)
                                .rotationEffect(.degrees(frame(for: layer).rotation))
                                .position(x: geo.size.width * frame(for: layer).x + (gyroEnabled ? tilt.width : 0),
                                          y: geo.size.height * frame(for: layer).y + (gyroEnabled ? tilt.height : 0))
                                .contentShape(Rectangle())
                                .onTapGesture { selectedID = layer.id }
                                .gesture(DragGesture(minimumDistance: 1)
                                    .onChanged { value in
                                        guard !layer.locked else { return }
                                        if draggingID != layer.id { draggingID = layer.id; dragStart = CGPoint(x: layer.x, y: layer.y) }
                                        guard let start = dragStart else { return }
                                        updateLayer(layer.id) { item in
                                            item.x = min(1.5, max(-0.5, Double(start.x) + Double(value.translation.width / geo.size.width)))
                                            item.y = min(1.5, max(-0.5, Double(start.y) + Double(value.translation.height / geo.size.height)))
                                        }
                                        selectedID = layer.id
                                    }.onEnded { _ in draggingID = nil; dragStart = nil })
                                .simultaneousGesture(MagnificationGesture()
                                    .onChanged { value in
                                        guard !layer.locked else { return }
                                        if scalingID != layer.id { scalingID = layer.id; scaleStart = layer.scale }
                                        updateLayer(layer.id) { $0.scale = min(8, max(0.1, (scaleStart ?? layer.scale) * Double(value))) }
                                    }.onEnded { _ in scalingID = nil; scaleStart = nil })
                                .simultaneousGesture(RotationGesture()
                                    .onChanged { angle in
                                        guard !layer.locked else { return }
                                        if rotatingID != layer.id { rotatingID = layer.id; rotationStart = layer.rotation }
                                        updateLayer(layer.id) { $0.rotation = (rotationStart ?? layer.rotation) + angle.degrees }
                                    }.onEnded { _ in rotatingID = nil; rotationStart = nil })
                        }
                        if mode == .sleep { Color.black.opacity(0.72).allowsHitTesting(false) }
                        if mode == .locked {
                            VStack {
                                Text("9:41").font(.system(size: 58, weight: .thin, design: .rounded))
                                Spacer()
                            }.foregroundStyle(.white).padding(.top, 55).allowsHitTesting(false)
                        }
                    }
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                    .animation(.easeInOut(duration: 1.1), value: phase)
                }
                .aspectRatio(9.0 / 19.5, contentMode: .fit)
                .frame(maxWidth: 310).frame(maxWidth: .infinity)
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Label("TIMELINE", systemImage: "slider.horizontal.3").font(.caption.bold()).tracking(1)
                        Spacer()
                        Text(String(format: "%.1f / 3.0 s", timelineProgress * 3))
                            .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                    }
                    Slider(value: $timelineProgress, in: 0...1)
                    Toggle("Chuyển động mượt (ease in/out)", isOn: $easingEnabled)
                        .font(.caption)
                    HStack(spacing: 10) {
                        Button("0s") { playing = false; timelineProgress = 0 }
                        Spacer()
                        Button("1.5s") { playing = false; timelineProgress = 0.5 }
                        Spacer()
                        Button("3s") { playing = false; timelineProgress = 1 }
                    }.font(.caption).buttonStyle(.borderless)
                    if let selectedID, layers.contains(where: { $0.id == selectedID }) {
                        HStack {
                            Button {
                                if let current = layers.first(where: { $0.id == selectedID }) {
                                    let key = snapshot(current)
                                    updateLayer(selectedID) { $0.startFrame = key }
                                }
                                message = "Đã lưu keyframe đầu (0s)."
                            } label: { Label("Đặt keyframe 0s", systemImage: "diamond") }
                            Spacer()
                            Button {
                                if let current = layers.first(where: { $0.id == selectedID }) {
                                    let key = snapshot(current)
                                    updateLayer(selectedID) { $0.endFrame = key }
                                }
                                message = "Đã lưu keyframe cuối (3s)."
                            } label: { Label("Đặt keyframe 3s", systemImage: "diamond.fill") }
                        }.font(.caption).buttonStyle(.bordered)
                    }
                    Text("Chọn layer, chỉnh vị trí/kích thước rồi đặt keyframe 0s và 3s. Kéo timeline để xem chuyển động.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                .padding(14).background(.quaternary.opacity(0.22), in: RoundedRectangle(cornerRadius: 18))
                HStack {
                    Button {
                        if playing {
                            playing = false
                            timelineProgress = 0
                        } else {
                            playing = true
                            timelineProgress = 0
                            withAnimation(.linear(duration: 3)) { timelineProgress = 1 }
                        }
                    } label: {
                        Label(playing ? "Dừng xem trước" : "Xem hoạt ảnh", systemImage: playing ? "pause.fill" : "play.fill")
                    }
                    Spacer()
                    Toggle("Gyro", isOn: $gyroEnabled).fixedSize()
                }
                .buttonStyle(.bordered)
                PhotosPicker(selection: $selection, matching: .images) {
                    Label("Chọn ảnh nền", systemImage: "photo.on.rectangle").frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent)
                PhotosPicker(selection: $imageSelections, maxSelectionCount: 20, matching: .images) {
                    Label("Thêm nhiều ảnh (layer)", systemImage: "photo.stack").frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent)
                Text("Chạm chọn layer, kéo bằng một ngón để di chuyển; dùng hai ngón để phóng to hoặc xoay.")
                    .font(.caption).foregroundStyle(.secondary)
                HStack {
                    Button { addLayer("text") } label: { Label("Chữ", systemImage: "textformat") }
                    Button { addLayer("shape") } label: { Label("Hình", systemImage: "square.on.circle") }
                    Button { addLayer("particles") } label: { Label("Hạt", systemImage: "sparkles") }
                }.buttonStyle(.bordered)
                if !layers.isEmpty {
                    Text("Danh sách layer").font(.headline)
                    ForEach(layers) { layer in
                        HStack {
                            Button { selectedID = layer.id } label: {
                                Label(layer.kind == "text" ? layer.text : (layer.kind == "image" ? "Ảnh" : layer.kind), systemImage: layer.kind == "image" ? "photo" : (layer.kind == "text" ? "textformat" : "square.stack"))
                                    .lineLimit(1)
                            }.tint(selectedID == layer.id ? .accentColor : .primary)
                            Spacer()
                            Button { updateLayer(layer.id) { $0.hidden.toggle() } } label: { Image(systemName: layer.hidden ? "eye.slash" : "eye") }
                            Button { updateLayer(layer.id) { $0.locked.toggle() } } label: { Image(systemName: layer.locked ? "lock.fill" : "lock.open") }
                            Button { duplicate(layer.id) } label: { Image(systemName: "plus.square.on.square") }
                            Button { move(layer.id, -1) } label: { Image(systemName: "arrow.up") }
                            Button { move(layer.id, 1) } label: { Image(systemName: "arrow.down") }
                            Button(role: .destructive) { if selectedID == layer.id { selectedID = nil }; layers.removeAll { $0.id == layer.id } } label: { Image(systemName: "trash") }
                        }.buttonStyle(.borderless).padding(.vertical, 5)
                    }
                }
                // Bind by stable layer ID rather than array index: deleting/reordering a
                // layer must not leave SwiftUI with a stale indexed Binding.
                if let selectedID, let layerBinding = bindingForLayer(selectedID) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Chỉnh sửa layer").font(.headline)
                        if layerBinding.wrappedValue.kind == "text" {
                            TextField("Nội dung chữ", text: layerBinding.text).textFieldStyle(.roundedBorder)
                        }
                        slider("Vị trí ngang", value: layerBinding.x, range: 0.05...0.95)
                        slider("Vị trí dọc", value: layerBinding.y, range: 0.05...0.95)
                        slider("Kích thước", value: layerBinding.scale, range: 0.3...2.5)
                        slider("Độ trong suốt", value: layerBinding.opacity, range: 0...1)
                        slider("Xoay", value: layerBinding.rotation, range: -180...180)
                        HStack {
                            Image(systemName: "diamond.fill").foregroundStyle(.tint)
                            Text("Keyframe: \(layerBinding.wrappedValue.startFrame == nil ? "chưa có đầu" : "0s") · \(layerBinding.wrappedValue.endFrame == nil ? "chưa có cuối" : "3s")")
                                .font(.caption)
                        }
                    }.padding(12).background(.quaternary.opacity(0.3), in: RoundedRectangle(cornerRadius: 16))
                }
                HStack {
                    Text("Màu nền")
                    Spacer()
                    ForEach(0..<palettes.count, id: \.self) { index in
                        Button { palette = index } label: {
                            Circle().fill(Color(uiColor: palettes[index][0])).frame(width: 29, height: 29)
                                .overlay(Circle().stroke(.primary, lineWidth: palette == index ? 2 : 0))
                        }.accessibilityLabel("Bảng màu \(index + 1)")
                    }
                }
                HStack {
                    Button { saveProject() } label: { Label("Lưu dự án", systemImage: "square.and.arrow.down") }
                    Button { loadProject() } label: { Label("Mở dự án", systemImage: "folder") }
                }.buttonStyle(.bordered)
                Button {
                    exportGIF()
                } label: {
                    Label(exportingGIF ? "Đang xuất GIF..." : "Xuất hoạt ảnh GIF (3 giây)", systemImage: "film.stack")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .disabled(exportingGIF)
                Button {
                    guard let image = renderWallpaper() else { message = "Không thể xuất ảnh."; return }
                    exported = image; showShare = true
                } label: { Label("Xuất hình nền PNG", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity) }
                    .buttonStyle(.borderedProminent)
                Text("Có thể xuất GIF hoạt ảnh 3 giây để chia sẻ, không phải hình nền động PosterBoard. Chưa hỗ trợ video layer, 3D, định dạng CAPlayground hoặc cài hoạt ảnh vào iOS.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding(20)
        }
        .navigationTitle("Studio").navigationBarTitleDisplayMode(.inline)
        .onChange(of: selection) { _, item in
            Task {
                guard let data = try? await item?.loadTransferable(type: Data.self), let image = UIImage(data: data) else { return }
                await MainActor.run { backgroundImage = image }
            }
        }
        .onChange(of: imageSelections) { _, items in
            Task {
                var imported: [Data] = []
                for item in items {
                    if let data = try? await item.loadTransferable(type: Data.self), let image = UIImage(data: data) {
                        let longest = max(image.size.width, image.size.height)
                        let factor = min(1, 1800 / max(longest, 1))
                        let target = CGSize(width: image.size.width * factor, height: image.size.height * factor)
                        let reduced = UIGraphicsImageRenderer(size: target).image { _ in image.draw(in: CGRect(origin: .zero, size: target)) }
                        if let compressed = reduced.jpegData(compressionQuality: 0.85) { imported.append(compressed) }
                    }
                }
                await MainActor.run {
                    for data in imported {
                        let layer = StudioLayer(kind: "image", text: "Ảnh", imageData: data)
                        layers.append(layer); selectedID = layer.id
                    }
                    imageSelections = []
                }
            }
        }
        .onChange(of: gyroEnabled) { _, enabled in if enabled { startMotion() } else { motion.stopDeviceMotionUpdates(); tilt = .zero } }
        .onDisappear { motion.stopDeviceMotionUpdates() }
        .sheet(isPresented: $showShare, onDismiss: { exportedGIF = nil }) {
            if let exportedGIF { StudioShareSheet(items: [exportedGIF]) }
            else if let exported { StudioShareSheet(items: [exported]) }
        }
        .alert("Studio", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private func snapshot(_ layer: StudioLayer) -> StudioKeyframe {
        StudioKeyframe(x: layer.x, y: layer.y, scale: layer.scale,
                       opacity: layer.opacity, rotation: layer.rotation)
    }

    private func frame(for layer: StudioLayer) -> StudioKeyframe {
        let fallback = snapshot(layer)
        guard let start = layer.startFrame, let end = layer.endFrame else { return fallback }
        let t = easingEnabled ? timelineProgress * timelineProgress * (3 - 2 * timelineProgress) : timelineProgress
        func mix(_ a: Double, _ b: Double) -> Double { a + (b - a) * t }
        return StudioKeyframe(x: mix(start.x, end.x), y: mix(start.y, end.y),
                              scale: mix(start.scale, end.scale),
                              opacity: mix(start.opacity, end.opacity),
                              rotation: mix(start.rotation, end.rotation))
    }

    private func bindingForLayer(_ id: UUID) -> Binding<StudioLayer>? {
        guard layers.contains(where: { $0.id == id }) else { return nil }
        return Binding(
            get: { layers.first(where: { $0.id == id }) ?? StudioLayer(id: id) },
            set: { updated in
                guard let index = layers.firstIndex(where: { $0.id == id }) else { return }
                layers[index] = updated
            }
        )
    }

    private func layerView(_ layer: StudioLayer) -> some View {
        Group {
            switch layer.kind {
            case "image":
                if let data = layer.imageData, let image = UIImage(data: data) {
                    Image(uiImage: image).resizable().scaledToFit().frame(width: 175, height: 220)
                } else { Image(systemName: "photo.badge.exclamationmark") }
            case "shape": RoundedRectangle(cornerRadius: 20).fill(.white.opacity(0.75)).frame(width: 90, height: 90)
            case "particles": Image(systemName: "sparkles").font(.system(size: 72)).foregroundStyle(.yellow)
            default: Text(layer.text).font(.system(size: 35, weight: .bold)).foregroundStyle(.white)
                .shadow(color: .black.opacity(0.65), radius: 5).multilineTextAlignment(.center)
            }
        }
    }
    private func slider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 2) { Text(title).font(.subheadline); Slider(value: value, in: range) }
    }
    private func addLayer(_ kind: String) {
        let layer = StudioLayer(kind: kind, text: "Dynor")
        layers.append(layer); selectedID = layer.id
    }
    private func updateLayer(_ id: UUID, _ change: (inout StudioLayer) -> Void) {
        guard let index = layers.firstIndex(where: { $0.id == id }) else { return }
        change(&layers[index])
    }
    private func duplicate(_ id: UUID) {
        guard let original = layers.first(where: { $0.id == id }) else { return }
        var copy = original; copy.id = UUID(); copy.x += 0.04; copy.y += 0.04
        layers.append(copy); selectedID = copy.id
    }
    private func move(_ id: UUID, _ offset: Int) {
        guard let index = layers.firstIndex(where: { $0.id == id }), layers.indices.contains(index + offset) else { return }
        layers.swapAt(index, index + offset)
    }
    private func saveProject() {
        let project = StudioProject(layers: layers, palette: palette, background: backgroundImage?.jpegData(compressionQuality: 0.8))
        do { try JSONEncoder().encode(project).write(to: projectURL, options: .atomic); message = "Đã lưu dự án trên thiết bị." }
        catch { message = "Không thể lưu dự án: \(error.localizedDescription)" }
    }
    private func loadProject() {
        do {
            let project = try JSONDecoder().decode(StudioProject.self, from: Data(contentsOf: projectURL))
            layers = project.layers; palette = min(max(project.palette, 0), palettes.count - 1)
            backgroundImage = project.background.flatMap(UIImage.init(data:)); selectedID = nil
            message = "Đã mở dự án."
        } catch { message = "Không thể mở dự án: \(error.localizedDescription)" }
    }
    private func startMotion() {
        guard motion.isDeviceMotionAvailable else { gyroEnabled = false; message = "Thiết bị không hỗ trợ cảm biến chuyển động."; return }
        motion.deviceMotionUpdateInterval = 1.0 / 30
        motion.startDeviceMotionUpdates(to: .main) { reading, _ in
            guard let reading else { return }
            tilt = CGSize(width: reading.attitude.roll * 12, height: reading.attitude.pitch * 12)
        }
    }
    private func exportGIF() {
        guard !exportingGIF else { return }
        exportingGIF = true
        let file = FileManager.default.temporaryDirectory
            .appendingPathComponent("Dynor-Studio-\(UUID().uuidString).gif")
        // Render on the main actor to keep UIKit rendering and state consistent.
        Task { @MainActor in
            guard let destination = CGImageDestinationCreateWithURL(
                file as CFURL, UTType.gif.identifier as CFString, 30, nil
            ) else {
                exportingGIF = false
                message = "Không thể tạo tệp GIF."
                return
            }
            let loop: [CFString: Any] = [kCGImagePropertyGIFLoopCount: 0]
            CGImageDestinationSetProperties(destination, [kCGImagePropertyGIFDictionary: loop] as CFDictionary)
            let frameProperties: [CFString: Any] = [
                kCGImagePropertyGIFDictionary: [kCGImagePropertyGIFDelayTime: 0.1]
            ]
            for index in 0..<30 {
                let progress = Double(index) / 29
                if let frame = renderWallpaper(progress: progress, size: CGSize(width: 390, height: 845)),
                   let cgImage = frame.cgImage {
                    CGImageDestinationAddImage(destination, cgImage, frameProperties as CFDictionary)
                }
                if index % 5 == 0 { await Task.yield() }
            }
            let success = CGImageDestinationFinalize(destination)
            exportingGIF = false
            if success {
                exported = nil
                exportedGIF = file
                showShare = true
            } else {
                message = "Xuất GIF thất bại. Hãy thử giảm số lượng layer."
            }
        }
    }

    private func exportFrame(for layer: StudioLayer, progress: Double?) -> StudioKeyframe {
        guard let progress, let start = layer.startFrame, let end = layer.endFrame else {
            return snapshot(layer)
        }
        let t = easingEnabled ? progress * progress * (3 - 2 * progress) : progress
        func mix(_ a: Double, _ b: Double) -> Double { a + (b - a) * t }
        return StudioKeyframe(x: mix(start.x, end.x), y: mix(start.y, end.y),
                              scale: mix(start.scale, end.scale), opacity: mix(start.opacity, end.opacity),
                              rotation: mix(start.rotation, end.rotation))
    }

    private func renderWallpaper(progress: Double? = nil, size: CGSize = CGSize(width: 1170, height: 2535)) -> UIImage? {
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let colors = palettes[palette].map(\.cgColor) as CFArray
            if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
                ctx.cgContext.drawLinearGradient(gradient, start: .zero, end: CGPoint(x: size.width, y: size.height), options: [])
            }
            if let image = backgroundImage {
                let ratio = max(size.width / image.size.width, size.height / image.size.height)
                let w = image.size.width * ratio, h = image.size.height * ratio
                image.draw(in: CGRect(x: (size.width - w) / 2, y: (size.height - h) / 2, width: w, height: h))
            }
            for layer in layers where !layer.hidden {
                ctx.cgContext.saveGState()
                let state = exportFrame(for: layer, progress: progress)
                ctx.cgContext.translateBy(x: size.width * state.x, y: size.height * state.y)
                ctx.cgContext.rotate(by: CGFloat(state.rotation * .pi / 180))
                ctx.cgContext.scaleBy(x: state.scale * size.width / 1170, y: state.scale * size.width / 1170)
                ctx.cgContext.setAlpha(state.opacity)
                if layer.kind == "image", let data = layer.imageData, let image = UIImage(data: data) {
                    let maxDimension: CGFloat = 650
                    let ratio = min(maxDimension / max(image.size.width, 1), maxDimension / max(image.size.height, 1))
                    let w = image.size.width * ratio, h = image.size.height * ratio
                    image.draw(in: CGRect(x: -w/2, y: -h/2, width: w, height: h))
                } else if layer.kind == "shape" {
                    UIColor.white.withAlphaComponent(0.75).setFill()
                    UIBezierPath(roundedRect: CGRect(x: -135, y: -135, width: 270, height: 270), cornerRadius: 60).fill()
                } else {
                    let text = layer.kind == "particles" ? "✦" : layer.text
                    let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: layer.kind == "particles" ? 180 : 105), .foregroundColor: layer.kind == "particles" ? UIColor.systemYellow : UIColor.white]
                    let rect = CGRect(x: -500, y: -120, width: 1000, height: 240)
                    (text as NSString).draw(in: rect, withAttributes: attrs)
                }
                ctx.cgContext.restoreGState()
            }
        }
    }
}

private struct StudioShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
