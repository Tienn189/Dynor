import SwiftUI
import UIKit
import UniformTypeIdentifiers

@MainActor
struct LibraryView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var importing = false
    @State private var pickerIsVisible = false
    @State private var readingFiles = false
    @State private var importResultMessage: String?
    @State private var selecting = false
    @State private var selected = Set<UUID>()
    @State private var confirmDelete = false
    @State private var preview: ImportedWallpaper?
    @State private var showInstaller = false
    @State private var installationFarewell: String?
    @State private var category = "Tendies"
    private var visible: [ImportedWallpaper] {
        store.library.filter { $0.kind.isTendies }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                importCard
                collectionHeader
                if visible.isEmpty {
                    emptyCollection
                } else {
                    VStack(spacing: 0) {
                        ForEach(Array(visible.enumerated()), id: \.element.id) { index, item in
                            collectionItem(item)
                            if index < visible.count - 1 {
                                Divider().padding(.leading, 70).padding(.trailing, 18)
                            }
                        }
                    }
                    .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                }
                // Selection actions are anchored above the tab bar, not in the scroll content.

            }
            .frame(maxWidth: 920)
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if selecting && !selected.isEmpty {
                selectionActionBar.transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.spring(response: 0.38, dampingFraction: 0.84), value: selecting && !selected.isEmpty)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .sheet(isPresented: $showInstaller) {
            NavigationStack {
                PosterBoardView()
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("Đóng") { showInstaller = false }
                        }
                    }
            }
        }
        .alert("Dynor", isPresented: Binding(get: { installationFarewell != nil }, set: { if !$0 { installationFarewell = nil } })) {
            Button("OK") { installationFarewell = nil }
        } message: {
            Text(installationFarewell ?? "")
        }
        .onReceive(NotificationCenter.default.publisher(for: .dynorWallpaperInstalledAndRemoved)) { _ in
            installationFarewell = store.localized("Chúc bạn có những trải nghiệm tuyệt vời cùng Dynor!", "Enjoy a wonderful experience with Dynor!", "祝你在 Dynor 享受美好体验！")
        }
        .navigationTitle(store.localized("Bộ sưu tập", "Collection", "收藏"))
        .navigationBarTitleDisplayMode(.large)
        .sheet(isPresented: $importing, onDismiss: {
            pickerIsVisible = false
            presentImportResult()
        }) {
            WallpaperDocumentPicker(onPick: { urls in
                // Retain and process the selection immediately. Import must not
                // depend on the order of UIKit and SwiftUI dismissal callbacks.
                importing = false
                importPickedDocuments(urls)
            }, onCancel: {
                importing = false
            })
        }
        .overlay {
            if readingFiles {
                ProgressView("Đang nhập tệp…")
                    .padding(24).background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
            }
        }
        .confirmationDialog("Xóa \(selected.count) tệp khỏi Dynor?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Xóa \(selected.count) tệp", role: .destructive) {
                store.removeImported(ids: selected); selected.removeAll(); selecting = false
            }
            Button("Giữ lại", role: .cancel) {}
        } message: { Text("Tệp gốc bên ngoài Dynor vẫn được giữ lại.") }
        .sheet(item: $preview, onDismiss: openNextSelectedPreview) {
            LibraryPreview(item: $0).environmentObject(store)
        }
        .onAppear { presentRequestedWallpaper() }
        .onChange(of: store.pendingLibraryPreview) { _, _ in presentRequestedWallpaper() }
    }

    private var importCard: some View {
        Button(action: showImportPicker) {
            HStack(spacing: 14) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 30, weight: .medium))
                    .foregroundStyle(store.accentColor)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text(store.localized("Nhập hình nền", "Import wallpaper", "导入壁纸"))
                        .font(.headline).foregroundStyle(.primary)
                    Text(store.localized("Chọn gói .tendies hoặc .dynor", "Choose a .tendies or .dynor package", "选择 .tendies 或 .dynor 壁纸包"))
                        .font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                if readingFiles || store.isImporting {
                    ProgressView()
                } else {
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
                }
            }
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .modifier(DynorGlass(radius: 22, interactive: true))
            .contentShape(RoundedRectangle(cornerRadius: 22))
        }
        .buttonStyle(.plain)
        .disabled(readingFiles || store.isImporting || store.isInstallingWallpaper)
    }

    @State private var installQueue: [UUID] = []

    private var collectionHeader: some View {
        VStack(alignment: .leading, spacing: 14) {
            if selecting {
                HStack(spacing: 10) {
                    Button {
                        withAnimation(.smooth(duration: 0.28)) {
                            if selected.count == visible.count { selected.removeAll() }
                            else { selected = Set(visible.map(\.id)) }
                        }
                    } label: {
                        Text(selected.count == visible.count
                             ? store.localized("Bỏ chọn tất cả", "Deselect all", "取消全选")
                             : store.localized("Chọn tất cả", "Select all", "全选"))
                            .font(.subheadline.weight(.medium))
                            .lineLimit(1).minimumScaleFactor(0.78)
                            .foregroundStyle(store.accentColor)
                            .padding(.horizontal, 12).frame(height: 46)
                            .modifier(DynorGlass(radius: 23, interactive: true))
                    }
                    Spacer(minLength: 0)
                    Text(store.localized("Đã chọn \(selected.count)", "Selected \(selected.count)", "已选择 \(selected.count)"))
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(1).minimumScaleFactor(0.8)
                    Spacer(minLength: 0)
                    Button { endSelection() } label: {
                        Text(store.localized("Hoàn tất", "Done", "完成"))
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(store.accentColor)
                            .padding(.horizontal, 14).frame(height: 46)
                            .modifier(DynorGlass(radius: 23, interactive: true))
                    }
                }
                .buttonStyle(.plain)
                .transition(.opacity.combined(with: .move(edge: .top)))
            } else {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(store.localized("Hình nền của bạn", "Your wallpapers", "你的壁纸"))
                            .font(.headline)
                        Text(store.localized("\(visible.count) gói hình nền", "\(visible.count) wallpaper packages", "\(visible.count) 个壁纸包"))
                            .font(.caption).foregroundStyle(DynorDesign.muted)
                    }
                    Spacer()
                    Button {
                        withAnimation(.smooth(duration: 0.3)) { selecting = true; selected.removeAll() }
                    } label: {
                        Text(store.localized("Chọn", "Select", "选择"))
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(store.accentColor)
                            .padding(.horizontal, 16).frame(height: 44)
                            .modifier(DynorGlass(radius: 22, interactive: true))
                    }
                    .buttonStyle(.plain)
                    .disabled(visible.isEmpty || store.isInstallingWallpaper)
                }
            }
        }
        .animation(.smooth(duration: 0.28), value: selecting)
    }

    private var selectionActionBar: some View {
        Button(role: .destructive) { confirmDelete = true } label: {
            Label(store.localized("Xóa (\(selected.count))", "Delete (\(selected.count))", "删除 (\(selected.count))"), systemImage: "trash")
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .foregroundStyle(.red)
                // Match the translucent, outlined floating pill from the reference.
                // Apply glass to the whole button, never to an inner label.
                .background {
                    Capsule(style: .continuous)
                        .fill(.ultraThinMaterial)
                        .overlay {
                            Capsule(style: .continuous)
                                .strokeBorder(.white.opacity(0.92), lineWidth: 1.2)
                        }
                        .shadow(color: .black.opacity(0.07), radius: 16, y: 7)
                }
        }
        .buttonStyle(.plain)
        .disabled(store.isInstallingWallpaper)
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
    }

    private func endSelection() {
        withAnimation(.smooth(duration: 0.28)) { selecting = false; selected.removeAll() }
        installQueue.removeAll()
    }

    private func openNextSelectedPreview() {
        guard !installQueue.isEmpty else { return }
        let next = installQueue.removeFirst()
        if let item = store.library.first(where: { $0.id == next }) {
            // The existing installer requires confirmation for each package.
            DispatchQueue.main.async { preview = item }
        }
    }

    private var emptyCollection: some View {
        ContentUnavailableView {
            Label(store.localized("Chưa có hình nền", "No wallpapers yet", "暂无壁纸"), systemImage: "square.stack")
        } description: {
            Text(store.localized("Nhập gói hình nền từ Tệp hoặc tìm thêm trong Khám phá.", "Import a package from Files or find a wallpaper in Explore.", "从文件导入壁纸包，或前往探索查找壁纸。"))
        } actions: {
            Button(store.localized("Khám phá hình nền", "Explore wallpapers", "探索壁纸")) {
                store.selectedTab = .discover
            }.buttonStyle(.bordered)
        }
        .padding(.vertical, 30)
    }

    private func collectionItem(_ item: ImportedWallpaper) -> some View {
        let isSelected = selected.contains(item.id)
        return Button {
            if selecting {
                withAnimation(.smooth(duration: 0.28)) {
                    if isSelected { selected.remove(item.id) } else { selected.insert(item.id) }
                }
            } else { preview = item }
        } label: {
            HStack(spacing: 16) {
                Image(systemName: "archivebox.fill")
                    .font(.system(size: 23, weight: .medium))
                    .foregroundStyle(store.accentColor)
                    .frame(width: 40, height: 48)
                VStack(alignment: .leading, spacing: 6) {
                    Text(URL(fileURLWithPath: item.displayName).deletingPathExtension().lastPathComponent)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(DynorDesign.ink)
                        .lineLimit(1)
                    Text(store.localized("Collections · 1 hình nền", "Collections · 1 wallpaper", "Collections · 1 张壁纸"))
                        .font(.caption).foregroundStyle(.secondary)
                    Text("\(ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file)) · \(item.addedAt.formatted(date: .abbreviated, time: .shortened))")
                        .font(.caption2).foregroundStyle(DynorDesign.muted)
                        .lineLimit(1).minimumScaleFactor(0.8)
                }
                Spacer(minLength: 0)
                if selecting {
                    Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                        .font(.system(size: 27))
                        .foregroundStyle(isSelected ? store.accentColor : Color.secondary.opacity(0.4))
                        .transition(.scale.combined(with: .opacity))
                } else {
                    Image(systemName: "chevron.right")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 17)
            .contentShape(Rectangle())
        }
        .buttonStyle(DynorPressStyle(scale: 0.99))
        .disabled(store.isInstallingWallpaper)
        .accessibilityLabel(item.displayName)
        .accessibilityValue(selecting ? (isSelected ? store.localized("Đã chọn", "Selected", "已选择") : store.localized("Chưa chọn", "Not selected", "未选择")) : "")
    }

    private func showImportPicker() {
        guard !readingFiles, !store.isImporting, !store.isInstallingWallpaper else { return }
        pickerIsVisible = true
        importing = true
    }

    private func importPickedDocuments(_ urls: [URL]) {
        guard !urls.isEmpty, !readingFiles else { return }
        readingFiles = true
        Task { @MainActor in
            defer {
                readingFiles = false
                presentImportResult()
            }
            let imported = await store.importWallpapers(urls: urls)
            ActivityJournal.shared.add(imported.isEmpty ? "Nhập tệp thất bại" : "Đã nhập tệp", detail: imported.isEmpty ? "Không có tệp hợp lệ" : imported.map(\.displayName).joined(separator: ", "), success: !imported.isEmpty)
            let message = store.message
            store.message = nil
            if urls.count == 1, let item = imported.first {
                store.openInLibrary(item)
            } else {
                importResultMessage = message ?? "Chưa nhập được tệp đã chọn. Hãy thử lại."
            }
        }
    }

    private func presentImportResult() {
        guard !pickerIsVisible, !importing, !readingFiles else { return }
        if let message = importResultMessage {
            importResultMessage = nil
            store.message = message
        }
        presentRequestedWallpaper()
    }

    private func presentRequestedWallpaper() {
        guard !pickerIsVisible, !importing, !readingFiles,
              store.selectedTab == .library, let id = store.pendingLibraryPreview,
              let item = store.library.first(where: { $0.id == id }) else { return }
        category = item.kind.isTendies ? "Tendies" : "Ảnh"
        selecting = false
        selected.removeAll()
        preview = item
        store.pendingLibraryPreview = nil
    }
}

private struct LibraryArtwork: View {
    @EnvironmentObject private var store: DynorStore
    let item: ImportedWallpaper
    var allowsRetry = false
    var body: some View {
        GeometryReader { geometry in
            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                Image(uiImage: image).resizable().scaledToFill().frame(width: geometry.size.width, height: geometry.size.height)
            } else {
                TendiesArtworkPreview(archiveURL: store.fileURL(for: item), encrypted: item.kind == .encryptedTendies, allowsRetry: allowsRetry, previewURL: item.previewURL)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .clipped()
            }
        }
    }
}

@MainActor
struct LibraryPreview: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    let item: ImportedWallpaper
    @State private var saving = false
    @State private var notice: String?
    @State private var installing = false
    @State private var installProgress = 0.0
    @State private var installLog: [String] = []
    @State private var verifiedWrite = false
    @State private var removeAfterAcknowledgement = false
    @State private var confirmSingleDelete = false
    private var compatibility: TendiesCompatibility.Assessment { TendiesCompatibility.current }
    private var prerequisiteWarning: String? { PosterBoardAccess.prerequisiteWarning }

    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
              ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    LibraryArtwork(item: item, allowsRetry: true)
                        .frame(width: min(geometry.size.width - 48, max(100, geometry.size.height * 0.34), 260),
                               height: min(geometry.size.width - 48, max(100, geometry.size.height * 0.34), 260))
                        .clipped()
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .frame(maxWidth: .infinity)
                    DynorSoftCard {
                        VStack(alignment: .leading, spacing: 13) {
                            Label(store.localized("Thông tin hình nền", "Wallpaper information", "壁纸信息"), systemImage: "info.circle").font(.headline)
                            infoRow(store.localized("Ngày nhập", "Imported", "导入日期"), item.addedAt.formatted(date: .abbreviated, time: .shortened))
                            infoRow(store.localized("Dung lượng", "File size", "文件大小"), ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                            infoRow(store.localized("Định dạng", "Format", "格式"), (item.storedFilename as NSString).pathExtension.uppercased())
                            infoRow(store.localized("Nguồn", "Source", "来源"), item.kind == .encryptedTendies ? store.localized("Dynor mã hóa", "Encrypted Dynor", "Dynor 加密") : item.kind == .tendies ? "Tendies" : store.localized("Ảnh", "Image", "图片"))

                        }
                    }
                    if item.kind.isTendies {
                        tendiesControls
                    }
                    if item.kind == .image {
                        Button {
                            saving = true
                            Task {
                                await store.saveImportedToPhotos(item)
                                notice = store.message
                                store.message = nil
                                saving = false
                            }
                        } label: {
                            Label(saving ? "Đang lưu…" : "Lưu vào Ảnh", systemImage: "photo.badge.arrow.down")
                                .frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(DynorPrimaryButtonStyle()).disabled(saving)
                        ShareLink(item: store.fileURL(for: item)) {
                            Label("Chia sẻ ảnh gốc", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(.bordered).disabled(installing)
                    }
                }
                .frame(maxWidth: 620)
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .frame(maxWidth: .infinity)
              }
              .scrollIndicators(.hidden)
            }
            .background(DynorDesign.canvas.ignoresSafeArea())
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(store.localized("Đóng", "Close", "关闭")) { dismiss() }.disabled(installing) } }
            .interactiveDismissDisabled(installing)
            .confirmationDialog("Xóa gói hình nền này?", isPresented: $confirmSingleDelete) {
                Button("Xóa khỏi Dynor", role: .destructive) {
                    store.removeImported(ids: Set([item.id]))
                    dismiss()
                }
                Button("Hủy", role: .cancel) {}
            } message: { Text("Tệp gốc bên ngoài Dynor không bị xóa.") }
            .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button(store.localized("OK", "OK", "确定"), role: .cancel) {
                    notice = nil
                    if removeAfterAcknowledgement {
                        removeAfterAcknowledgement = false
                        store.removeImported(ids: Set([item.id]), showConfirmation: false)
                        dismiss()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            NotificationCenter.default.post(name: .dynorWallpaperInstalledAndRemoved, object: nil)
                        }
                    }
                }
            } message: { Text(notice ?? "") }
        }
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
                .fixedSize(horizontal: false, vertical: true)
        }.font(.subheadline)
            .frame(maxWidth: .infinity)
    }

    @ViewBuilder
    private var tendiesControls: some View {
        if let warning = compatibility.warning {
            Label(warning, systemImage: "info.circle")
                .font(.caption).foregroundStyle(.secondary)
        } else if let warning = prerequisiteWarning {
            Label(warning, systemImage: "exclamationmark.shield")
                .font(.caption).foregroundStyle(.secondary)
            Button("Mở bộ chọn hình nền") {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = "Không thể mở bộ chọn hình nền tự động. Hãy vào Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra."
                }
            }.font(.subheadline)
        }
        if installing {
            ProgressView(value: installProgress)
            Text("Đang ghi và xác minh… Giữ Dynor mở, iPhone mở khóa.")
                .font(.caption).foregroundStyle(.secondary)
        }
        Button {
            installTendies()
        } label: {
            Label(installing ? store.localized("Đang cài hình nền…", "Installing wallpaper…", "正在安装壁纸…") : verifiedWrite ? store.localized("Ghi lại hình nền", "Reinstall wallpaper", "重新安装壁纸") : store.localized("Cài hình nền", "Install wallpaper", "安装壁纸"), systemImage: "iphone.gen3")
                .frame(maxWidth: .infinity).padding(.vertical, 2)
        }
        .buttonStyle(DynorPrimaryButtonStyle())
        .disabled(installing || store.isInstallingWallpaper || prerequisiteWarning != nil || !compatibility.canAttemptInstall)
        if verifiedWrite {
            Button("Mở bộ chọn hình nền") {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = "iOS chưa mở được PosterBoard. Mở Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra. Nếu mẫu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại."
                }
            }.buttonStyle(.bordered)
        }
        if !installLog.isEmpty {
            DisclosureGroup("Chi tiết cài đặt") {
                Text(installLog.joined(separator: "\n"))
                    .font(.caption2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
            }.font(.caption)
        }
    }

    private func installTendies() {
        guard compatibility.canAttemptInstall, !installing, !store.isInstallingWallpaper, prerequisiteWarning == nil else { return }
        installing = true
        store.isInstallingWallpaper = true
        verifiedWrite = false
        installProgress = 0
        installLog = []
        let previousIdleSetting = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        Task { @MainActor in
            defer {
                installing = false
                store.isInstallingWallpaper = false
                UIApplication.shared.isIdleTimerDisabled = previousIdleSetting
            }
            do {
                let receipt = try await TendiesInstaller.shared.install(
                    archiveURL: store.fileURL(for: item),
                    log: { line in
                        Task { @MainActor in
                            installLog.append(line)
                            if installLog.count > 100 { installLog.removeFirst(installLog.count - 100) }
                        }
                    },
                    progress: { value in Task { @MainActor in installProgress = value } }
                )
                verifiedWrite = true
                removeAfterAcknowledgement = true
                ActivityJournal.shared.add("Đã ghi hình nền", detail: "\(item.displayName) · \(receipt.verifiedFileCount) tệp đã xác minh", success: true)
                // Request PosterBoard after successful verification. iOS decides whether
                // it can foreground the system UI; no private multitasking manipulation.
                let opened = PosterBoardAccess.requestOpenPosterBoard()
                notice = opened
                    ? "Đã cài dữ liệu hình nền thành công! Trong PosterBoard, chọn hình nền vừa thêm và bấm Thêm/Đặt làm hình nền. Nếu chưa thấy, mở Cài đặt → Hình nền hoặc khởi động lại iPhone."
                    : "Đã cài dữ liệu hình nền thành công! iOS chưa cho tự mở PosterBoard; vào Cài đặt → Hình nền → Thêm hình nền mới, chọn mẫu vừa cài. Nếu chưa thấy, khởi động lại iPhone."
            } catch {
                removeAfterAcknowledgement = false
                ActivityJournal.shared.add("Cài hình nền thất bại", detail: "\(item.displayName) · \(error.localizedDescription)", success: false)
                notice = "Chưa hoàn tất cài hình nền: \(error.localizedDescription)"
            }
        }
    }
}


private extension Notification.Name {
    static let dynorWallpaperInstalledAndRemoved = Notification.Name("dynor.wallpaper.installedAndRemoved")
}
