import SwiftUI
import WebKit

/// Loads the official hosted CAPlayground editor in a sandboxed WKWebView.
/// This does not bundle or copy CAPlayground source code, and it does not
/// automatically transfer projects to Dynor's native PosterBoard installer.
struct CAPlaygroundWebEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State private var loading = true
    @State private var errorText: String?
    private let url = URL(string: "https://caplayground.vercel.app/projects")!

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if loading {
                    ProgressView("Đang mở CAPlayground…")
                        .padding(8)
                }
                if let errorText {
                    Text(errorText)
                        .font(.caption)
                        .foregroundStyle(.red)
                        .padding(8)
                }
                CAPlaygroundBrowser(url: url, loading: $loading, errorText: $errorText)
            }
            .navigationTitle("CAPlayground")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Đóng") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    ShareLink(item: url) {
                        Image(systemName: "safari")
                    }
                }
            }
        }
    }
}

private struct CAPlaygroundBrowser: UIViewRepresentable {
    let url: URL
    @Binding var loading: Bool
    @Binding var errorText: String?

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.load(URLRequest(url: url))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        var parent: CAPlaygroundBrowser
        init(_ parent: CAPlaygroundBrowser) { self.parent = parent }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            parent.loading = false
            parent.errorText = nil
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!,
                     withError error: Error) {
            parent.loading = false
            parent.errorText = error.localizedDescription
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!,
                     withError error: Error) {
            parent.loading = false
            parent.errorText = error.localizedDescription
        }
    }
}
