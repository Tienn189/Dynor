import SwiftUI
import UIKit

@main
@MainActor
struct DynorApp: App {
    @StateObject private var store = DynorStore()
    @AppStorage("dynor.onboarding.completed") private var onboardingCompleted = false
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var remoteGate = DynorRemoteGate.shared

    init() {
        TendiesInstallWorkspace.removeStale()
        // Do not initialize Airlift globally. The selected backend initializes
        // only when an Airlift install is actually requested (iOS 18–25).
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if onboardingCompleted { RootView() }
                else { DynorOnboardingView { onboardingCompleted = true } }
            }
                .environmentObject(store)
                .overlay { DynorRemoteGateView().environmentObject(store) }
                .task { await remoteGate.refresh() }
                .onOpenURL { url in
                    guard !store.isInstallingWallpaper else {
                        store.message = "Hãy chờ cài hình nền hoàn tất trước khi mở tệp khác."
                        return
                    }
                    Task {
                        store.selectedTab = .library
                        let imported = await store.importWallpapers(urls: [url])
                        if let item = imported.first {
                            store.message = nil
                            store.openInLibrary(item)
                        }
                    }
                }
                .tint(store.accentColor)
                .environment(\.locale, Locale(identifier: store.appLanguage))
                .preferredColorScheme(nil)
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active { store.refreshDailyAccess(); Task { await DynorAccountService.shared.restoreSession(); await remoteGate.refresh() } }
                }
                .task {
                    while !Task.isCancelled {
                        do { try await Task.sleep(for: .seconds(20)) }
                        catch { return }
                        store.refreshDailyAccess()
                        await remoteGate.refresh()
                    }
                }
        }
    }
}

private struct RootView: View {
    @EnvironmentObject private var store: DynorStore

    var body: some View {
        TabView(selection: $store.selectedTab) {
            NavigationStack { OnlineGalleryView() }
                .tabItem { Label(store.localized("Khám phá", "Explore", "探索"), systemImage: "square.grid.2x2") }
                .tag(DynorTab.discover)
            NavigationStack { LibraryView() }
                .tabItem { Label(store.localized("Bộ sưu tập", "Collection", "收藏"), systemImage: "square.stack") }
                .tag(DynorTab.library)
            NavigationStack { InstalledWallpapersView() }
                .tabItem { Label(store.localized("Đã cài", "Installed", "已安装"), systemImage: "iphone") }
                .tag(DynorTab.installed)
            SettingsView()
                .tabItem { Label(store.localized("Cài đặt", "Settings", "设置"), systemImage: "gearshape") }
                .tag(DynorTab.settings)
        }
        .tint(store.accentColor)
        .alert("Dynor", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
            Button(store.localized("Đã hiểu", "OK", "确定"), role: .cancel) { store.message = nil }
        } message: { Text(store.message ?? "") }
    }
}
