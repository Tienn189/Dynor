import Foundation

/// Public, read-only release/maintenance configuration. No privileged credentials are embedded.
@MainActor
final class DynorRemoteGate: ObservableObject {
    static let shared = DynorRemoteGate()
    @Published private(set) var config: Config?
    @Published private(set) var checking = false

    struct Config: Decodable {
        let maintenance_enabled: Bool
        let maintenance_title: String?
        let maintenance_message: String?
        let maintenance_eta: String?
        let force_update: Bool
        let minimum_build: Int
        let latest_version: String?
        let update_title: String?
        let update_message: String?
        let telegram_url: String?
    }

    enum Blocker { case maintenance, update }
    var blocker: Blocker? {
        guard let config else { return nil }
        if config.maintenance_enabled { return .maintenance }
        let current = Int(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "0") ?? 0
        return config.force_update && current < config.minimum_build ? .update : nil
    }

    private let endpoint = URL(string: "https://wkivekbodwbinmvargts.supabase.co/rest/v1/dynor_app_control?id=eq.1&select=*")!
    private let publishableKey = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    private init() {}

    func refresh() async {
        guard !checking else { return }
        checking = true
        defer { checking = false }
        var request = URLRequest(url: endpoint)
        request.timeoutInterval = 12
        request.setValue(publishableKey, forHTTPHeaderField: "apikey")
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else { return }
            if let item = try JSONDecoder().decode([Config].self, from: data).first {
                config = item
            }
        } catch {
            // Keep the last successfully fetched state on transient connection failures.
        }
    }
}
