import Foundation
import Darwin

/// User-facing choice for the PosterBoard install backend. `.automatic` follows
/// the per-version default; the other cases pin a backend when it is allowed.
enum PosterBoardBackendChoice: String, CaseIterable, Identifiable {
    case automatic, airlift, worseQuery

    var id: String { rawValue }

    static let storageKey = "dynor.posterboard.backendChoice"

    static var stored: PosterBoardBackendChoice {
        get {
            PosterBoardBackendChoice(rawValue: UserDefaults.standard.string(forKey: storageKey) ?? "") ?? .automatic
        }
        set { UserDefaults.standard.set(newValue.rawValue, forKey: storageKey) }
    }
}

/// Which on-device backend writes PosterBoard descriptors for a given iOS
/// version. Dynor selects Airlift on iOS 18–26 and worse_query on iOS 27.
/// These are backend selections, not guarantees that every OS build is compatible.
/// Unknown/newer builds are blocked.
enum PosterBoardBackend: String, CaseIterable, Identifiable {
    case airlift, worseQuery

    var id: String { rawValue }

    static func isAvailable(_ backend: PosterBoardBackend, for version: OperatingSystemVersion) -> Bool {
        switch backend {
        case .airlift:
            return version.majorVersion >= 18 && version.majorVersion <= 26
        case .worseQuery:
            if version.majorVersion == 26 {
                return version.minorVersion < 7
                    || (version.minorVersion == 7 && version.patchVersion <= 2)
            }
            if version.majorVersion == 27 {
                return version.minorVersion < 2
                    || (version.minorVersion == 2 && version.patchVersion == 0)
            }
            return false
        }
    }

    /// Backend used when the user picked "automatic" (or picked a backend that
    /// this iOS version no longer allows).
    static func automatic(for version: OperatingSystemVersion) -> PosterBoardBackend {
        version.majorVersion >= 27 ? .worseQuery : .airlift
    }

    /// The backend an install will actually use right now.
    static var current: PosterBoardBackend {
        let version = ProcessInfo.processInfo.operatingSystemVersion
        switch PosterBoardBackendChoice.stored {
        case .automatic:
            return automatic(for: version)
        case .airlift where isAvailable(.airlift, for: version):
            return .airlift
        case .worseQuery where isAvailable(.worseQuery, for: version):
            return .worseQuery
        default:
            return automatic(for: version)
        }
    }

    /// Effective choice shown in Settings: the stored pick, or automatic when
    /// the stored pick is not usable on this iOS version.
    static var effectiveChoice: PosterBoardBackendChoice {
        let version = ProcessInfo.processInfo.operatingSystemVersion
        switch PosterBoardBackendChoice.stored {
        case .automatic:
            return .automatic
        case .airlift where isAvailable(.airlift, for: version):
            return .airlift
        case .worseQuery where isAvailable(.worseQuery, for: version):
            return .worseQuery
        default:
            return .automatic
        }
    }

    var displayName: String {
        switch self {
        case .airlift: return "Airlift"
        case .worseQuery: return "worse_query"
        }
    }

    var rangeDescription: String {
        switch self {
        case .airlift: return "iOS 18.0 – 26.x"
        case .worseQuery: return "iOS 27.0 – 27.2.0"
        }
    }

    /// Marketing version alone cannot tell a 27.3 beta from a 27.3 release;
    /// the build train is shown so users can report exactly what they run.
    static var iosBuildVersion: String {
        var size = 0
        sysctlbyname("kern.osversion", nil, &size, nil, 0)
        guard size > 0 else { return "?" }
        var buffer = [CChar](repeating: 0, count: size)
        guard sysctlbyname("kern.osversion", &buffer, &size, nil, 0) == 0 else { return "?" }
        return String(cString: buffer)
    }
}
