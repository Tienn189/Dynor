// RPPairing host ported from Mak5er/AirCard-iOS PairingController (MIT).
// See ThirdParty/AirCard/LICENSE and provenance.json. The device pairs with
// the on-device host so the Airlift Rust core gets a lockdown/RSD channel.
import Foundation
import AirliftFFI

@MainActor
final class AirLiftPairingController: ObservableObject {

    static let shared = AirLiftPairingController()

    private let hostName = "Dynor"
    private let hostModel = "Mac17,7"   // device sees a Mac-like pairing host
    private let bindAddress = "0.0.0.0"

    private var netService: NetService?
    private let localNetwork = DynorLocalNetworkAuthorization()
    private let keepAlive = DynorKeepAlive()

    @Published private(set) var running = false
    @Published var pairingStatus: String = "idle"
    @Published var pairingPIN: String? = nil

    /// Path to a pairing file adopted from elsewhere (import or discovery).
    nonisolated(unsafe) static var customPairingFilePath: String? = nil

    /// Persisted altIRK keeps the host identity stable across pairings so a
    /// device that has already paired recognises this host.
    nonisolated private static let altIRKKey = "dynor.pairing.hostAltIRK"
    nonisolated private static var storedAltIRK: String {
        get { UserDefaults.standard.string(forKey: altIRKKey) ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: altIRKKey) }
    }

    private var pairContinuation: CheckedContinuation<String, Error>?

    // MARK: - Pairing file storage

    /// Canonical name first; the AirCard/Airlift names are kept as mirrors so
    /// pairing records shared between tools keep working.
    nonisolated static let canonicalNames = ["dynor_pairing.plist", "airlift_pairing.plist", "aircard_pairing.plist"]

    nonisolated private static var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    /// Ensures the given pairing file is mirrored to every canonical name.
    @discardableResult
    nonisolated static func syncCanonicalPairingFile(from sourcePath: String) -> String {
        let dir = documentsDirectory
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: sourcePath)), !data.isEmpty else {
            return sourcePath
        }
        for name in canonicalNames {
            let url = dir.appendingPathComponent(name)
            if sourcePath != url.path {
                try? data.write(to: url, options: .atomic)
            }
        }
        customPairingFilePath = dir.appendingPathComponent(canonicalNames[0]).path
        return customPairingFilePath!
    }

    /// Deletes every credential copy created or adopted by Dynor and clears the
    /// stored AltIRK.
    nonisolated static func deleteStoredPairingCredentials() {
        let dir = documentsDirectory
        for name in canonicalNames {
            try? FileManager.default.removeItem(at: dir.appendingPathComponent(name))
        }
        if let custom = customPairingFilePath {
            if !canonicalNames.contains(where: { dir.appendingPathComponent($0).path == custom }) {
                try? FileManager.default.removeItem(atPath: custom)
            }
            customPairingFilePath = nil
        }
        storedAltIRK = ""
    }

    /// Path where the pairing file is read from. Checks every canonical name,
    /// then any adopted custom path; returns the first canonical path to write.
    nonisolated static func pairingFilePath() -> String {
        let dir = documentsDirectory
        for name in canonicalNames {
            let path = dir.appendingPathComponent(name).path
            if let size = fileSize(at: path), size > 0 {
                if name != canonicalNames[0] {
                    _ = syncCanonicalPairingFile(from: path)
                }
                return dir.appendingPathComponent(canonicalNames[0]).path
            }
        }
        if let custom = customPairingFilePath, let size = fileSize(at: custom), size > 0 {
            _ = syncCanonicalPairingFile(from: custom)
            return dir.appendingPathComponent(canonicalNames[0]).path
        }
        return dir.appendingPathComponent(canonicalNames[0]).path
    }

    nonisolated static func hasPairingFile() -> Bool {
        for name in canonicalNames {
            let path = documentsDirectory.appendingPathComponent(name).path
            if let size = fileSize(at: path), size > 0 { return true }
        }
        if let custom = customPairingFilePath, let size = fileSize(at: custom), size > 0 { return true }
        return false
    }

    /// Copies an imported pairing document into the canonical location.
    @discardableResult
    nonisolated static func importPairingFile(from source: URL) throws -> String {
        let isSecured = source.startAccessingSecurityScopedResource()
        defer { if isSecured { source.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: source), !data.isEmpty else {
            throw PairingError.failed("Tệp pairing trống hoặc không đọc được.")
        }
        let url = documentsDirectory.appendingPathComponent(canonicalNames[0])
        try data.write(to: url, options: .atomic)
        for name in canonicalNames.dropFirst() {
            try? data.write(to: documentsDirectory.appendingPathComponent(name), options: .atomic)
        }
        customPairingFilePath = url.path
        return url.path
    }

    nonisolated private static func fileSize(at path: String) -> Int? {
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: path, isDirectory: &isDirectory), !isDirectory.boolValue else {
            return nil
        }
        return (try? FileManager.default.attributesOfItem(atPath: path)[.size] as? NSNumber)?.intValue
    }

    // MARK: - Public API

    enum PairingError: LocalizedError {
        case busy
        case failed(String)

        var errorDescription: String? {
            switch self {
            case .busy: return "Đang có một phiên ghép nối chạy."
            case let .failed(message): return message
            }
        }
    }

    /// Start the host and resolve with the pairing-file path, or throw.
    func startAndWait() async throws -> String {
        if running {
            softCancel()
            try? await Task.sleep(nanoseconds: 100_000_000)
        }
        return try await withCheckedThrowingContinuation { cont in
            pairContinuation = cont
            start()
        }
    }

    func softCancel() {
        stopAdvertising()
        keepAlive.stopAll()
        running = false
        pairingPIN = nil
        pairingStatus = "Đã hủy"
        resolve(.failure(CancellationError()))
    }

    private func resolve(_ result: Result<String, Error>) {
        guard let cont = pairContinuation else { return }
        pairContinuation = nil
        cont.resume(with: result)
    }

    func start() {
        stopAdvertising()
        keepAlive.stopAll()
        running = true
        pairingPIN = nil
        pairingStatus = "Đang khởi động host cục bộ…"

        Task {
            _ = await localNetwork.request()
            guard running else { return }

            keepAlive.startAudio()
            pairingStatus = "Đang quảng bá… mở Cài đặt để ghép nối"
            runHost()
        }
    }

    // MARK: - Private

    private func runHost() {
        let bind = bindAddress
        let name = hostName
        let model = hostModel
        let outPath = Self.pairingFilePath()
        let altIRK = Self.storedAltIRK
        nonisolated(unsafe) let ctx = UnsafeMutableRawPointer(
            Unmanaged.passRetained(self).toOpaque()
        )

        DispatchQueue.global(qos: .userInitiated).async {
            var result = ALPairResult()
            let rc = bind.withCString { bindC in
                name.withCString { nameC in
                    model.withCString { modelC in
                        outPath.withCString { outC in
                            altIRK.withCString { irkC in
                                al_pairing_run_host(
                                    bindC, 0, nameC, modelC, outC, irkC,
                                    pairReadyCallback, pairPinCallback, ctx, &result)
                            }
                        }
                    }
                }
            }

            let outcome: Outcome
            if rc == 0 {
                let issued = cStr(result.host_alt_irk_hex)
                if !issued.isEmpty { Self.storedAltIRK = issued }
                let devName = cStr(result.device_name)
                let filePath = cStr(result.pairing_file_path)
                outcome = .success(
                    name: devName.isEmpty ? "iPhone" : devName,
                    path: filePath.isEmpty ? outPath : filePath
                )
            } else {
                let msg = cStr(result.error)
                outcome = .failure(msg.isEmpty ? "ghép nối thất bại (mã \(rc))" : msg)
            }
            al_pairing_result_free(&result)

            DispatchQueue.main.async {
                Unmanaged<AirLiftPairingController>.fromOpaque(ctx).release()
                self.finish(outcome)
            }
        }
    }

    private enum Outcome {
        case success(name: String, path: String)
        case failure(String)
    }

    private func finish(_ outcome: Outcome) {
        stopAdvertising()
        // Keep background alive briefly so iOS does not kill the app before the
        // user returns from Settings.
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) { [weak self] in
            self?.keepAlive.stopAll()
        }
        running = false
        pairingPIN = nil

        switch outcome {
        case let .success(name, path):
            let canonical = Self.syncCanonicalPairingFile(from: path)
            if let size = Self.fileSize(at: canonical), size > 0 {
                pairingStatus = "Đã ghép nối: \(name) (\(size)B)"
                resolve(.success(canonical))
            } else {
                pairingStatus = "Thất bại: tệp pairing rỗng"
                resolve(.failure(PairingError.failed("Ghép nối tạo tệp rỗng. Hãy chấp nhận yêu cầu ghép nối rồi thử lại.")))
            }
        case let .failure(message):
            pairingStatus = "Thất bại: \(message)"
            resolve(.failure(PairingError.failed(message)))
        }
    }

    // MARK: - Bonjour advertising

    fileprivate func startAdvertising(serviceID: String, port: Int32, txt: [String: Data]) {
        stopAdvertising()
        let service = NetService(
            domain: "",
            type: "_remotepairing-pairable-host._tcp.",
            name: serviceID,
            port: port
        )
        service.setTXTRecord(NetService.data(fromTXTRecord: txt))
        service.publish()
        netService = service
        pairingStatus = "Đang quảng bá — mở Cài đặt › Quyền riêng tư & Bảo mật › Chế độ nhà phát triển"
    }

    fileprivate func presentPin(_ pin: String) {
        pairingPIN = pin
        pairingStatus = "Nhập mã PIN \(pin) trong Cài đặt › Quyền riêng tư & Bảo mật › Chế độ nhà phát triển › Pair with Dynor"
    }

    private func stopAdvertising() {
        netService?.stop()
        netService = nil
    }
}

// MARK: - C callbacks

private let pairReadyCallback: ALPairReadyCb = { ctx, serviceID, port, keys, vals, count in
    guard let ctx = ctx, let serviceID = serviceID else { return }
    let controller = Unmanaged<AirLiftPairingController>.fromOpaque(ctx).takeUnretainedValue()
    let id = String(cString: serviceID)

    var txt: [String: Data] = [:]
    if let keys = keys, let vals = vals {
        for i in 0..<Int(count) {
            guard let k = keys[i], let v = vals[i] else { continue }
            txt[String(cString: k)] = Data(String(cString: v).utf8)
        }
    }
    DispatchQueue.main.async {
        controller.startAdvertising(serviceID: id, port: Int32(port), txt: txt)
    }
}

private let pairPinCallback: ALPairPinCb = { pin, ctx in
    guard let ctx = ctx, let pin = pin else { return }
    let controller = Unmanaged<AirLiftPairingController>.fromOpaque(ctx).takeUnretainedValue()
    let pinString = String(cString: pin)
    DispatchQueue.main.async {
        controller.presentPin(pinString)
    }
}

private func cStr(_ ptr: UnsafeMutablePointer<CChar>?) -> String {
    guard let ptr = ptr else { return "" }
    return String(cString: ptr)
}
