// NeoSpring-style respring using WebKit (ported from Gester/BQCore).
// Loads respring.html which triggers SpringBoard restart via perspective overload.
import WebKit

enum RespringService {
    private static var webView: WKWebView?
    private static var overlay: UIView?

    private static func keyWindow() -> UIWindow? {
        for scene in UIApplication.shared.connectedScenes {
            guard let windowScene = scene as? UIWindowScene else { continue }
            for window in windowScene.windows where window.isKeyWindow {
                return window
            }
        }
        return UIApplication.shared.windows.first
    }

    static func respring() {
        DispatchQueue.main.async {
            guard let win = keyWindow() else { return }
            print("[RespringService] NeoSpring start")

            let black = UIView(frame: win.bounds)
            black.backgroundColor = .black
            black.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            win.addSubview(black)

            let spinner = UIActivityIndicatorView(style: .large)
            spinner.center = CGPoint(x: black.bounds.midX, y: black.bounds.midY)
            spinner.autoresizingMask = [.flexibleLeftMargin, .flexibleRightMargin, .flexibleTopMargin, .flexibleBottomMargin]
            spinner.color = .white
            spinner.startAnimating()
            black.addSubview(spinner)
            overlay = black

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                let cfg = WKWebViewConfiguration()
                cfg.defaultWebpagePreferences.allowsContentJavaScript = true
                let wv = WKWebView(frame: win.bounds, configuration: cfg)
                wv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
                wv.isUserInteractionEnabled = false
                win.insertSubview(wv, belowSubview: black)

                if let path = Bundle.main.path(forResource: "respring", ofType: "html") {
                    let url = URL(fileURLWithPath: path)
                    wv.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
                } else {
                    print("[RespringService] respring.html missing")
                }
                webView = wv
            }
        }
    }
}
