// Descriptor discovery and identifier preparation adapted from Mak5er/AirCard-iOS (MIT).
// See ThirdParty/AirCard/LICENSE and provenance.json.
import Foundation
import CoreFoundation

/// Works only on an extracted, validated archive; never communicates with the device.
enum TendiesDescriptorCatalog {
    /// Try both names used by PosterBoard across iOS versions, preserving the
    /// archive's extension as the first destination.
    static func destinationExtensions(for identifier: String) -> [String] {
        switch identifier {
        case "com.apple.WallpaperKit.CollectionsPoster":
            return [identifier, "com.apple.Posters.CollectionsPosterApp"]
        case "com.apple.Posters.CollectionsPosterApp":
            return [identifier, "com.apple.WallpaperKit.CollectionsPoster"]
        case "com.apple.MercuryPoster":
            return [identifier, "com.apple.Posters.MercuryPosterApp"]
        case "com.apple.Posters.MercuryPosterApp":
            return [identifier, "com.apple.MercuryPoster"]
        default:
            return [identifier]
        }
    }

    static func validExtension(_ identifier: String) -> Bool {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
        return identifier.hasPrefix("com.apple.") && identifier.contains("Poster") &&
            identifier.count <= 200 && !identifier.contains("..") &&
            identifier.unicodeScalars.allSatisfy { allowed.contains($0) }
    }

    // MARK: - Plist Identifier Randomization (Matches Nugget implementation)

    static func updatePlistIdentifiers(in folderURL: URL, randomizedID: Int) throws {
        // Matches AirCard's flashTendies: when suggestion metadata exists the
        // descriptor is pre-packaged with matching descriptorIdentifier and
        // wallpaper identifiers. Touching them desynchronizes PosterKit's
        // suggestion lookup, so leave every plist untouched in that case.
        let suggestionMetadataURL = folderURL.appendingPathComponent("com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist")
        if FileManager.default.fileExists(atPath: suggestionMetadataURL.path) {
            return
        }

        // If suggestion metadata exists, the descriptor is pre-packaged with matching
        // descriptorIdentifier and wallpaper identifiers (e.g. 7400.DYNAMIC <-> 7400).
        // Randomizing only Wallpaper.plist desynchronizes PosterKit's suggestion lookup!
        let identifierURL = folderURL.appendingPathComponent("com.apple.posterkit.provider.descriptor.identifier")
        let originalIdentifier = (try? String(contentsOf: identifierURL, encoding: .utf8))?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let numericPrefix = originalIdentifier?.split(separator: ".").first.flatMap { Int($0) }
        if let old = numericPrefix, let original = originalIdentifier {
            let suffix = String(original.dropFirst(String(old).count))
            try Data("\(randomizedID)\(suffix)".utf8).write(to: identifierURL, options: .atomic)
        }

        func remap(_ value: Any, old: Int, new: Int) -> Any {
            if let string = value as? String {
                let oldText = String(old)
                if string == oldText { return String(new) }
                if string.hasPrefix(oldText + ".") {
                    return String(new) + String(string.dropFirst(oldText.count))
                }
                return string
            }
            if let number = value as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(),
               number.intValue == old { return new }
            if let array = value as? [Any] { return array.map { remap($0, old: old, new: new) } }
            if let dictionary = value as? [String: Any] {
                return dictionary.mapValues { remap($0, old: old, new: new) }
            }
            return value
        }

        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(
            at: folderURL,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else { return }

        while let fileURL = enumerator.nextObject() as? URL {
            let fileName = fileURL.lastPathComponent

            if fileName == "com.apple.posterkit.provider.descriptor.identifier" && numericPrefix == nil {
                // IMPORTANT: ONLY randomize if the file content is a pure integer!
                // For extensions like Mercury, Unity, Kaleidoscope, descriptor identifiers are
                // required string symbols (e.g. "v6x.colorA", "Unity2025")!
                // Overwriting them breaks extension lookup!
                if let content = try? String(contentsOf: fileURL, encoding: .utf8),
                   let _ = Int(content.trimmingCharacters(in: .whitespacesAndNewlines)) {
                    try Data("\(randomizedID)".utf8).write(to: fileURL, options: .atomic)
                }
            } else if fileName == "com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist",
                      let old = numericPrefix,
                      let data = try? Data(contentsOf: fileURL),
                      let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) {
                let changed = remap(plist, old: old, new: randomizedID)
                let updated = try PropertyListSerialization.data(fromPropertyList: changed, format: .binary, options: 0)
                try updated.write(to: fileURL, options: .atomic)
            } else if fileName == "com.apple.posterkit.provider.contents.userInfo" {
                if let data = try? Data(contentsOf: fileURL),
                   var plist = (try? PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil)) as? [String: Any],
                   plist["wallpaperRepresentingIdentifier"] != nil {
                    plist["wallpaperRepresentingIdentifier"] = randomizedID
                    let updated = try PropertyListSerialization.data(fromPropertyList: plist, format: .binary, options: 0)
                    try updated.write(to: fileURL, options: .atomic)
                }
            } else if fileName.hasSuffix("Wallpaper.plist") {
                if let data = try? Data(contentsOf: fileURL),
                   var plist = (try? PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil)) as? [String: Any] {
                    plist["identifier"] = randomizedID
                    let updated = try PropertyListSerialization.data(fromPropertyList: plist, format: .binary, options: 0)
                    try updated.write(to: fileURL, options: .atomic)
                }
            }
        }
    }

    // MARK: - Find Descriptors With Targeted Extensions

    private static func isDescriptorFolder(_ url: URL) -> Bool {
        let fm = FileManager.default
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else { return false }
        let name = url.lastPathComponent
        if name.hasPrefix(".") || name == "__MACOSX" { return false }

        // Must not be the container root or Library itself
        let ignoredNames: Set<String> = [
            "container", "library", "application support", "prbposterextensiondatastore",
            "extensions", "descriptors", "ordered-descriptors",
            "mercury-descriptors", "mercurydescriptors", "video-descriptors", "videodescriptors"
        ]
        if ignoredNames.contains(name.lowercased()) {
            return false
        }

        func hasFileContents(_ directory: URL) -> Bool {
            guard let files = fm.enumerator(at: directory, includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey], options: [.skipsHiddenFiles]) else { return false }
            while let file = files.nextObject() as? URL {
                if let values = try? file.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
                   values.isRegularFile == true, (values.fileSize ?? 0) > 0 { return true }
            }
            return false
        }
        let versions = url.appendingPathComponent("versions", isDirectory: true)
        if (try? versions.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true,
           hasFileContents(versions) { return true }
        for marker in ["providerInfo.plist", "com.apple.posterkit.provider.descriptor.identifier", "Wallpaper.plist"] {
            let file = url.appendingPathComponent(marker)
            if let values = try? file.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
               values.isRegularFile == true, (values.fileSize ?? 0) > 0 { return true }
        }
        if url.pathExtension.lowercased() == "wallpaper", hasFileContents(url) { return true }

        return false
    }

    private static func determineExtension(for folderURL: URL, rootURL: URL, defaultExt: String) -> String {
        // Ignore names outside the archive. A temporary parent named "video" or
        // "Extensions" must not choose the wallpaper's system extension.
        let rootComponents = rootURL.standardizedFileURL.pathComponents
        let components = Array(folderURL.standardizedFileURL.pathComponents.dropFirst(rootComponents.count))
        let pathLower = components.joined(separator: "/").lowercased()

        // 1. Check path components for .../Extensions/<bundleID>/descriptors/<desc>
        for i in 0..<components.count {
            if components[i].lowercased() == "extensions", i + 1 < components.count {
                let cand = components[i + 1]
                if validExtension(cand) {
                    return cand
                }
            }
            if components[i].lowercased() == "descriptors", i > 0 {
                let cand = components[i - 1]
                if validExtension(cand) {
                    return cand
                }
            }
        }

        // 2. Check metadata inside suggestionMetadata.plist if present
        let metadataURL = folderURL.appendingPathComponent("com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist")
        if let data = try? Data(contentsOf: metadataURL),
           let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
           let objects = plist["$objects"] as? [Any] {
            for obj in objects {
                if let str = obj as? String {
                    if validExtension(str) {
                        return str
                    }
                }
            }
        }

        // 3. Check descriptor identifier content (e.g. "v6x.colorA" or "v5..." -> Mercury)
        let descIdURL = folderURL.appendingPathComponent("com.apple.posterkit.provider.descriptor.identifier")
        if let descId = try? String(contentsOf: descIdURL, encoding: .utf8) {
            let trimmed = descId.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.hasPrefix("v6") || trimmed.hasPrefix("v5") || trimmed.hasPrefix("v4") || trimmed.contains(".color") {
                return "com.apple.MercuryPoster"
            }
        }

        // 4. Path string hints
        if pathLower.contains("mercury") {
            return "com.apple.MercuryPoster"
        }
        if pathLower.contains("video") || pathLower.contains("photo") {
            return "com.apple.PhotosUIPrivate.PhotosPosterProvider"
        }
        if pathLower.contains("collection") || pathLower.contains("wallpaperkit") {
            return "com.apple.WallpaperKit.CollectionsPoster"
        }
        if pathLower.contains("kaleidoscope") {
            return "com.apple.Posters.KaleidoscopePosterApp.KaleidoscopePoster"
        }
        if pathLower.contains("unity") {
            return "com.apple.Posters.UnityPosterApp.UnityPosterExtension"
        }

        return defaultExt
    }

    static func findDescriptorsWithExtensions(in rootURL: URL, defaultExt: String) -> [(ext: String, url: URL)] {
        let fileManager = FileManager.default
        var results: [(ext: String, url: URL)] = []

        if isDescriptorFolder(rootURL) {
            let ext = determineExtension(for: rootURL, rootURL: rootURL, defaultExt: defaultExt)
            return [(ext: ext, url: rootURL)]
        }

        // Recursive traversal to discover all descriptor directories
        guard let enumerator = fileManager.enumerator(
            at: rootURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return [] }

        while let itemURL = enumerator.nextObject() as? URL {
            var isDir: ObjCBool = false
            guard fileManager.fileExists(atPath: itemURL.path, isDirectory: &isDir), isDir.boolValue else { continue }
            if itemURL.lastPathComponent.hasPrefix(".") || itemURL.lastPathComponent == "__MACOSX" {
                enumerator.skipDescendants()
                continue
            }

            if isDescriptorFolder(itemURL) {
                let ext = determineExtension(for: itemURL, rootURL: rootURL, defaultExt: defaultExt)
                results.append((ext: ext, url: itemURL))
                enumerator.skipDescendants() // Do not look for nested descriptors inside a descriptor folder
            }
        }

        return results.sorted { $0.url.path < $1.url.path }
    }
}
