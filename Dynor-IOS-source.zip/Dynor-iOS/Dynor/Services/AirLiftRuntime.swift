// Thin Swift surface over the AirliftFFI Rust core (AirliftFFI.xcframework,
// pinned from Mak5er/AirCard-iOS). Adapted from the previous Dynor/YanDevin
// integration; see ThirdParty/AirCard/LICENSE and provenance.json.
import Foundation
import Darwin
import AirliftFFI
import OSLog

/// Serializes blocking FFI calls off the main thread.
enum AirLift {
    private static let queue = DispatchQueue(label: "com.dynor.airlift", qos: .userInitiated)
    private static var didConfigure = false
    private static let logger = Logger(subsystem: "com.dynor.wallpapers", category: "airlift")

    /// Carries a Swift log closure through the FFI `void *ctx` parameter.
    private final class LogRelay {
        let emit: (String) -> Void
        init(_ emit: @escaping (String) -> Void) { self.emit = emit }
    }

    private static let globalLog: ALLogCallback = { _, message in
        guard let message else { return }
        airLiftGlobalLogger.info("\(String(cString: message), privacy: .public)")
    }

    private static let relayLog: ALLogCallback = { context, message in
        guard let context, let message else { return }
        Unmanaged<LogRelay>.fromOpaque(context).takeUnretainedValue()
            .emit(String(cString: message))
    }

    private static func logContext(_ log: ((String) -> Void)?) -> (relay: LogRelay?, pointer: UnsafeMutableRawPointer?) {
        guard let log else { return (nil, nil) }
        let relay = LogRelay { line in
            log(line)
            logger.info("\(line, privacy: .public)")
        }
        return (relay, Unmanaged.passUnretained(relay).toOpaque())
    }

    enum AirLiftFailure: LocalizedError {
        case needsPairing
        case transport(String)

        var errorDescription: String? {
            switch self {
            case .needsPairing:
                return "Chưa có pairing record. Hãy ghép nối thiết bị trong Cài đặt → Airlift trước."
            case let .transport(message):
                return message
            }
        }
    }

    /// Installs the Rust log sink. The Grappa helper is explicitly retained
    /// and exported by the app link settings so the Airlift runtime can resolve
    /// its C entry point with dlsym(RTLD_DEFAULT, ...) on device.
    static func configure() {
        guard !didConfigure else { return }
        didConfigure = true
        _ = al_log_init(Self.globalLog, nil)
        // Force a direct reference as an additional dead-strip safeguard.
        // The exported-symbol linker setting makes it visible to the FFI's dlsym.
        _ = ALGetGrappaToken(0, 0, 0, nil, 0, nil, nil, 0)
        refreshHosts()
    }

    /// Sends the device IP and every local interface address to the Rust core.
    static func refreshHosts() {
        "10.7.0.1".withCString { _ = al_set_target_host($0) }
        var candidates = ["10.7.0.1"]
        for candidate in DynorNetworkStatus.tunnelHostCandidates() where !candidates.contains(candidate) {
            candidates.append(candidate)
        }
        let strings = candidates.map { strdup($0) }
        defer { strings.forEach { free($0) } }
        let pointers = strings.map { UnsafePointer($0) }
        pointers.withUnsafeBufferPointer { buffer in
            if let base = buffer.baseAddress {
                _ = al_set_target_hosts(base, buffer.count)
            }
        }
    }

    /// Blocking FFI calls run on this serial queue.
    static func perform<T>(_ body: () -> T) -> T {
        queue.sync(execute: body)
    }

    static var pairingPath: String { AirLiftPairingController.pairingFilePath() }

    static var hasPairingFile: Bool {
        let path = pairingPath
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: path, isDirectory: &isDirectory), !isDirectory.boolValue else {
            return false
        }
        let size = (try? FileManager.default.attributesOfItem(atPath: path)[.size] as? NSNumber)?.intValue ?? 0
        return size > 0
    }

    /// Writes every file from `directory` into `target` on the device.
    static func write(directory: String, to target: String,
                      log: ((String) -> Void)? = nil) -> Result<Void, Error> {
        guard hasPairingFile else { return .failure(AirLiftFailure.needsPairing) }
        var outcome = Result<Void, Error>.success(())
        perform {
            var errorPointer: UnsafeMutablePointer<CChar>?
            let pairing = pairingPath
            let (relay, context) = logContext(log)
            let code = pairing.withCString { pairC in
                directory.withCString { sourceC in
                    target.withCString { targetC in
                        al_exploit_write_dir(pairC, sourceC, targetC, Self.relayLog, context, &errorPointer)
                    }
                }
            }
            _ = relay
            if let pointer = errorPointer {
                let description = String(validatingUTF8: pointer) ?? "airlift error"
                al_string_free(pointer)
                outcome = .failure(AirLiftFailure.transport(description))
            } else if code != 0 {
                outcome = .failure(AirLiftFailure.transport("airlift write thất bại (mã \(code))."))
            }
        }
        return outcome
    }

    /// Extracts a .passthm / zip archive with the same Rust reader AirCard uses.
    static func extract(archive: URL, to destination: URL) -> Bool {
        try? FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        var extracted = false
        perform {
            let code = archive.path.withCString { arcC in
                destination.path.withCString { dstC in
                    al_passthm_extract(arcC, dstC)
                }
            }
            if code == 0 {
                extracted = true
                return
            }
            let zipCode = archive.path.withCString { arcC in
                destination.path.withCString { dstC in
                    al_zip_extract_all(arcC, dstC)
                }
            }
            extracted = zipCode == 0
        }
        return extracted
    }

    /// Reboots/resprings the device through Diagnostics Relay. BLOCKS until the
    /// request is sent — the connection drops when the phone restarts.
    static func restartDevice(log: ((String) -> Void)? = nil) -> Result<Void, Error> {
        guard hasPairingFile else { return .failure(AirLiftFailure.needsPairing) }
        var outcome = Result<Void, Error>.success(())
        perform {
            var errorPointer: UnsafeMutablePointer<CChar>?
            let pairing = pairingPath
            let (relay, context) = logContext(log)
            let code = pairing.withCString { pairC in
                al_device_respring(pairC, Self.relayLog, context, &errorPointer)
            }
            _ = relay
            if let pointer = errorPointer {
                let description = String(validatingUTF8: pointer) ?? "airlift error"
                al_string_free(pointer)
                outcome = .failure(AirLiftFailure.transport(description))
            } else if code != 0 {
                outcome = .failure(AirLiftFailure.transport("Yêu cầu khởi động lại thất bại (mã \(code))."))
            }
        }
        return outcome
    }

    /// Quick end-to-end check: one canary file into a harmless cache folder.
    static func testConnection(log: ((String) -> Void)? = nil) -> Result<Void, Error> {
        guard hasPairingFile else { return .failure(AirLiftFailure.needsPairing) }
        refreshHosts()
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("dynor-airlift-test-\(UUID().uuidString)", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            try Data("dynor airlift canary\n".utf8)
                .write(to: directory.appendingPathComponent("dynor-canary.txt"))
        } catch { return .failure(error) }
        defer { try? FileManager.default.removeItem(at: directory) }
        return write(directory: directory.path, to: "/var/mobile/Library/Caches", log: log)
    }
}

/// File-level logger referenced by the capture-free C log callback.
private let airLiftGlobalLogger = Logger(subsystem: "com.dynor.wallpapers", category: "airlift")

@_silgen_name("ALGetGrappaToken")
func ALGetGrappaToken(
    _ inVersion: UInt32,
    _ inDeviceType: UInt32,
    _ inProtocolVersion: UInt32,
    _ outBuf: UnsafeMutablePointer<UInt8>?,
    _ maxLen: Int,
    _ outLen: UnsafeMutablePointer<Int>?,
    _ errBuf: UnsafeMutablePointer<CChar>?,
    _ errLen: Int
) -> Int32
