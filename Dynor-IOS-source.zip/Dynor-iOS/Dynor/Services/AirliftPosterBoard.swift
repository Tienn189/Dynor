// Airlift (AirliftFFI / AirTraffic escape) install path, adapted from the
// previous Dynor TendiesInstaller which was ported from Mak5er/AirCard-iOS
// TendiesEngine (MIT). See ThirdParty/AirCard/LICENSE and provenance.json.
import Foundation
import AirliftFFI

/// PosterBoard install through the on-device Airlift pairing tunnel.
/// Requires a pairing record (Settings → Airlift) and, on iOS 27+, works
/// without a separate VPN; older releases may need LocalDevVPN/WireGuard up.
enum AirliftPosterBoard {

    final class LogSink {
        let receive: (String) -> Void
        init(receive: @escaping (String) -> Void) { self.receive = receive }
    }

    /// PosterBoard's extension store version used by the AirCard-derived flow.
    /// Airlift cannot enumerate remote directories, so the version stays fixed
    /// like the previous Dynor build did.
    private static let structVersion = 61

    /// Written files are confirmed by the FFI result, not by a remote read-back.
    static func install(archiveURL: URL, log: @escaping (String) -> Void,
                        progress: @escaping (Double) -> Void) throws -> TendiesInstallReceipt {
        guard AirLift.hasPairingFile else {
            throw TendiesInstallError(text: "Chưa có pairing record. Vào Cài đặt → Airlift để ghép nối hoặc nhập tệp pairing trước.")
        }
        log("Hệ thống: \(ProcessInfo.processInfo.operatingSystemVersionString)")
        log("Backend: airlift · kết nối qua pairing tunnel, không worse_query")
        log("Đang kiểm tra tệp Tendies…")
        progress(0.02)

        let work = FileManager.default.temporaryDirectory
            .appendingPathComponent("dynor-airlift-install-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: work) }

        let stagedArchive = work.appendingPathComponent("source.tendies")
        let stagedPairing = work.appendingPathComponent("pairing.plist")
        try FileManager.default.copyItem(at: archiveURL, to: stagedArchive)
        try FileManager.default.copyItem(at: URL(fileURLWithPath: AirLift.pairingPath), to: stagedPairing)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: stagedPairing.path)

        // AirCard-compatible extraction: the Rust core's zip reader accepts
        // every tendies layout its own app produces. Fall back to the strict
        // validated extractor only if the Rust reader fails.
        let stage = work.appendingPathComponent("extracted", isDirectory: true)
        if !AirLift.extract(archive: stagedArchive, to: stage) {
            log("Bộ giải nén Rust không đọc được; thử trình giải nén đã kiểm chứng…")
            let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: stagedArchive)
            try TendiesArchiveValidator.extract(at: stagedArchive, to: stage, entries: entries)
            try TendiesArchiveValidator.validateExtraction(at: stage, entries: entries)
        }

        let descriptors = TendiesDescriptorCatalog.findDescriptorsWithExtensions(
            in: stage, defaultExt: "com.apple.WallpaperKit.CollectionsPoster")
        guard !descriptors.isEmpty else {
            throw TendiesInstallError(text: "Tệp không chứa cấu hình hình nền PosterBoard hợp lệ.")
        }
        for descriptor in descriptors {
            guard TendiesDescriptorCatalog.validExtension(descriptor.ext) else {
                throw TendiesInstallError(text: "Tendies chứa mã phần mở rộng hình nền không hợp lệ.")
            }
        }
        log("Đã tìm thấy \(descriptors.count) cấu hình. Đang kết nối thiết bị…")
        progress(0.1)

        AirLift.configure()
        AirLift.refreshHosts()
        let sink = LogSink(receive: log)
        let context = Unmanaged.passUnretained(sink).toOpaque()
        return try withExtendedLifetime(sink) {
            let container = try detectContainer(pairingPath: stagedPairing.path, context: context, log: log)
            guard validContainer(container) else {
                throw TendiesInstallError(text: "Thiết bị trả về đường dẫn PosterBoard không hợp lệ; đã dừng cài.")
            }
            var installed = 0
            do {
                for descriptor in descriptors {
                    log("Đang ghi cấu hình \(installed + 1)/\(descriptors.count)…")
                    try TendiesDescriptorCatalog.updatePlistIdentifiers(
                        in: descriptor.url, randomizedID: Int.random(in: 10000...99999))
                    let identifier = UUID().uuidString.uppercased()
                    let base = container + "/Library/Application Support/PRBPosterExtensionDataStore/\(structVersion)/Extensions/"
                    // AirCard order: the descriptor's own extension is required;
                    // the modern/legacy dual-inject variant is best-effort.
                    let targets = TendiesDescriptorCatalog.destinationExtensions(for: descriptor.ext)
                    var lastFailure: Error?
                    var primarySucceeded = false
                    for (index, extensionID) in targets.enumerated() {
                        do {
                            try inject(folder: descriptor.url,
                                       parent: base + extensionID + "/descriptors",
                                       name: identifier,
                                       pairingPath: stagedPairing.path,
                                       context: context,
                                       log: log)
                            if index == 0 { primarySucceeded = true }
                        } catch {
                            lastFailure = error
                            if index == 0 {
                                log("Không ghi được đích chính \(extensionID): \(error.localizedDescription)")
                            } else {
                                log("Bỏ qua biến thể phụ \(extensionID): \(error.localizedDescription)")
                            }
                        }
                    }
                    // Require the primary destination to succeed, like AirCard.
                    guard primarySucceeded else {
                        throw lastFailure ?? TendiesInstallError(text: "Không ghi được cấu hình hình nền.")
                    }
                    installed += 1
                    progress(0.15 + 0.7 * Double(installed) / Double(descriptors.count))
                }
                log("Đang cập nhật tùy chọn PosterBoard…")
                try refreshPreferences(container: container, pairingPath: stagedPairing.path, context: context, log: log)
                progress(1)
                log("Đã ghi \(installed) cấu hình. Mở tùy chỉnh Màn hình khóa hoặc khởi động lại iPhone để chọn hình nền mới.")
                return TendiesInstallReceipt(descriptorCount: descriptors.count,
                                             verifiedFileCount: installed,
                                             posterBoardContainer: URL(fileURLWithPath: container, isDirectory: true),
                                             backend: .airlift)
            } catch {
                if installed > 0 {
                    throw TendiesInstallError(text: "Đã ghi \(installed)/\(descriptors.count) cấu hình nhưng chưa hoàn tất: \(error.localizedDescription)")
                }
                throw error
            }
        }
    }

    /// Prerequisite shown next to the install button when Airlift is selected.
    static var prerequisiteWarning: String? {
        #if targetEnvironment(simulator)
        return "Simulator không chạy được Airlift pairing."
        #else
        return AirLift.hasPairingFile ? nil
            : "Airlift cần pairing record. Vào Cài đặt → Airlift để ghép nối thiết bị hoặc nhập tệp pairing."
        #endif
    }

    // MARK: - Native calls (blocking; callers run on the installer queue)

    private static let nativeLog: ALLogCallback = { context, message in
        guard let context = context, let message = message else { return }
        Unmanaged<LogSink>.fromOpaque(context).takeUnretainedValue().receive(String(cString: message))
    }

    /// iOS 26 frequently drops the lockdown tunnel mid-install ("channel closed",
    /// "Connection reset", ATC read errors). These markers identify transient
    /// transport failures worth retrying; real errors fail fast.
    private static let transientTunnelMarkers = [
        "connection reset", "channel closed", "broken pipe", "timed out",
        "atc read error", "econnreset", "econnaborted", "socket", "tunnel",
        "peer closed", "reset by peer", "network is unreachable", "host is down"
    ]

    private static func isTransientTunnelError(_ detail: String) -> Bool {
        let lower = detail.lowercased()
        return transientTunnelMarkers.contains { lower.contains($0) }
    }

    /// Runs a blocking tunnel FFI call, retrying transient drops with a
    /// growing delay (1s, 2s, 3s, 4s — up to 5 attempts total).
    private static func withTunnelRetry<T>(operation: String,
                                           log: (String) -> Void,
                                           _ body: () throws -> T) throws -> T {
        let maxAttempts = 5
        var lastError: Error?
        for attempt in 1...maxAttempts {
            do {
                return try body()
            } catch let error as TendiesInstallError {
                lastError = error
                guard attempt < maxAttempts, isTransientTunnelError(error.text) else { throw error }
                let delay = Double(min(attempt, 4))
                log("Tunnel ngắt khi \(operation) (lần \(attempt)/\(maxAttempts)): \(error.text)")
                log("Đang kết nối lại sau \(Int(delay)) giây…")
                // Refresh Bonjour/host state so a re-discovered tunnel endpoint is used.
                AirLift.refreshHosts()
                Thread.sleep(forTimeInterval: delay)
            }
        }
        throw lastError ?? TendiesInstallError(text: "Thao tác tunnel thất bại.")
    }

    private static func detectContainer(pairingPath: String, context: UnsafeMutableRawPointer,
                                        log: (String) -> Void) throws -> String {
        try withTunnelRetry(operation: "tìm PosterBoard", log: log) {
            var output: UnsafeMutablePointer<CChar>?
            var error: UnsafeMutablePointer<CChar>?
            defer {
                if let output = output { al_string_free(output) }
                if let error = error { al_string_free(error) }
            }
            let result = pairingPath.withCString { pairing in
                "com.apple.PosterBoard".withCString { bundle in
                    al_find_app_container(pairing, bundle, nativeLog, context, &output, &error)
                }
            }
            guard result == 0, let output = output else {
                let detail = error.map { String(cString: $0) } ?? "Không tìm thấy PosterBoard."
                throw TendiesInstallError(text: "Chưa kết nối được PosterBoard. Kiểm tra pairing, mở khóa iPhone và bật LocalDevVPN/WireGuard nếu cần. \(detail)")
            }
            var container = String(cString: output)
            if container.hasSuffix("/") { container.removeLast() }
            return container
        }
    }

    private static func inject(folder: URL, parent: String, name: String,
                               pairingPath: String, context: UnsafeMutableRawPointer,
                               log: (String) -> Void) throws {
        try withTunnelRetry(operation: "ghi cấu hình", log: log) {
            var error: UnsafeMutablePointer<CChar>?
            defer { if let error = error { al_string_free(error) } }
            let result = pairingPath.withCString { pair in
                folder.path.withCString { source in
                    parent.withCString { destination in
                        name.withCString { targetName in
                            al_exploit_inject_folder(pair, source, destination, targetName, nativeLog, context, &error)
                        }
                    }
                }
            }
            guard result == 0 else {
                let detail = error.map { String(cString: $0) } ?? "lỗi airlift"
                throw TendiesInstallError(text: "Ghi cấu hình thất bại: \(detail)")
            }
        }
    }

    private static func writePreferences(source: URL, target: String,
                                         pairingPath: String, context: UnsafeMutableRawPointer,
                                         log: (String) -> Void) throws {
        try withTunnelRetry(operation: "ghi tùy chọn", log: log) {
            var error: UnsafeMutablePointer<CChar>?
            defer { if let error = error { al_string_free(error) } }
            let result = pairingPath.withCString { pair in
                source.path.withCString { sourcePath in
                    target.withCString { destination in
                        al_exploit_write_dir(pair, sourcePath, destination, nativeLog, context, &error)
                    }
                }
            }
            guard result == 0 else {
                let detail = error.map { String(cString: $0) } ?? "lỗi airlift"
                throw TendiesInstallError(text: "Ghi thất bại: \(detail)")
            }
        }
    }

    private static func refreshPreferences(container: String, pairingPath: String,
                                           context: UnsafeMutableRawPointer, log: (String) -> Void) throws {
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("dynor-poster-prefs-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let preferences: [String: Any] = [
            "PBF_RESET_FILE_PROTECTIONS": true,
            "PBF_LOCALE_DID_CHANGE": true,
            "PersistedPosterContainerBundleIdentifiers": [
                "com.apple.Posters.CollectionsPosterApp", "com.apple.WallpaperKit.CollectionsPoster",
                "com.apple.MercuryPoster", "com.apple.Posters.MercuryPosterApp",
                "com.apple.PhotosUIPrivate.PhotosPosterProvider"
            ],
            "CompletedPosterBundleIdentifierMigrations": [
                "com.apple.Posters.UnityPosterApp.ExtragalacticPoster",
                "com.apple.Posters.WeatherPosterApp.WeatherPoster",
                "com.apple.Posters.UnityPosterApp.Unity2025Poster",
                "com.apple.Posters.UnityPosterApp.UnityPosterExtension",
                "com.apple.Posters.UnityPosterApp.RhizomePoster",
                "com.apple.Posters.KaleidoscopePosterApp.KaleidoscopePoster"
            ]
        ]
        let data = try PropertyListSerialization.data(fromPropertyList: preferences, format: .binary, options: 0)
        try data.write(to: directory.appendingPathComponent("com.apple.PosterBoard.unprotectedUserDefaults.plist"), options: .atomic)
        try writePreferences(source: directory, target: container + "/Library/Preferences",
                             pairingPath: pairingPath, context: context, log: log)
        do {
            try writePreferences(source: directory, target: "/var/mobile/Library/Preferences",
                                 pairingPath: pairingPath, context: context, log: log)
        } catch {
            // Main PosterBoard preferences succeeded; the global copy is an upstream compatibility fallback.
            log("Tùy chọn PosterBoard đã ghi; bản sao tùy chọn toàn cục chưa ghi được: \(error.localizedDescription)")
        }
    }

    private static func validContainer(_ path: String) -> Bool {
        let normalized = path.hasPrefix("/private/") ? String(path.dropFirst(8)) : path
        let parent = "/var/mobile/Containers/Data/Application/"
        guard normalized.hasPrefix(parent) else { return false }
        let suffix = String(normalized.dropFirst(parent.count))
        return UUID(uuidString: suffix) != nil && !suffix.contains("/")
    }
}
