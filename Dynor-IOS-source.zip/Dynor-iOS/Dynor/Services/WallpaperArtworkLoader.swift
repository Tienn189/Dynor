import Foundation
import CryptoKit
import ImageIO
import UIKit

/// Only a small rendered thumbnail is cached. Decrypted packages stay in the
/// existing protected workspace and are removed after extracting the artwork.
actor WallpaperArtworkLoader {
    static let shared = WallpaperArtworkLoader()
    private let cache = NSCache<NSString, NSData>()
    private var pending: [String: Task<Data, Error>] = [:]
    private let prepareEncrypted: @Sendable (URL) async throws -> PreparedEncryptedTendies

    init(prepareEncrypted: @escaping @Sendable (URL) async throws -> PreparedEncryptedTendies = {
        try await EncryptedTendiesService.shared.prepareForInstallation($0)
    }) {
        self.prepareEncrypted = prepareEncrypted
        cache.totalCostLimit = 24 * 1024 * 1024
    }

    func artwork(at source: URL, encrypted: Bool, previewURL: URL?) async throws -> Data {
        let key = source.path + "|" + (previewURL?.absoluteString ?? "")
        if let data = cache.object(forKey: key as NSString) { return data as Data }
        if let task = pending[key] { return try await task.value }
        let task = Task<Data, Error> {
            let disk = Self.cacheURL(for: key)
            if let bytes = try? Data(contentsOf: disk), bytes.count <= 4_000_000,
               let image = Self.thumbnail(from: bytes) { return image }
            let bytes: Data
            if let previewURL, let cover = try? await Self.remoteCover(previewURL) {
                bytes = cover
            } else if encrypted {
                let prepared = try await prepareEncrypted(source)
                defer { prepared.remove() }
                bytes = try await Task.detached(priority: .utility) {
                    try Self.extractArtwork(at: prepared.url)
                }.value
            } else {
                bytes = try await Task.detached(priority: .utility) {
                    try Self.extractArtwork(at: source)
                }.value
            }
            // This is just a JPEG thumbnail, never the decrypted .tendies archive.
            try? FileManager.default.createDirectory(at: disk.deletingLastPathComponent(), withIntermediateDirectories: true)
            try? bytes.write(to: disk, options: [.atomic, .completeFileProtection])
            return bytes
        }
        pending[key] = task
        defer { pending[key] = nil }
        let bytes = try await task.value
        cache.setObject(bytes as NSData, forKey: key as NSString, cost: bytes.count)
        return bytes
    }

    private static func cacheURL(for key: String) -> URL {
        let name = SHA256.hash(data: Data(key.utf8)).map { String(format: "%02x", $0) }.joined()
        return FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("DynorArtwork", isDirectory: true).appendingPathComponent(name + ".jpg")
    }

    private static func remoteCover(_ url: URL) async throws -> Data {
        guard ["https", "http"].contains(url.scheme?.lowercased() ?? "") else { throw ArtworkError.unavailable }
        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        let (stream, response) = try await URLSession.shared.bytes(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
              response.expectedContentLength <= 12_000_000 else { throw ArtworkError.unavailable }
        var data = Data()
        for try await byte in stream {
            guard data.count < 12_000_000 else { throw ArtworkError.unavailable }
            data.append(byte)
        }
        guard let image = thumbnail(from: data) else { throw ArtworkError.unavailable }
        return image
    }

    static func thumbnail(from data: Data) -> Data? {
        guard !data.isEmpty, data.count <= 12_000_000,
              let source = CGImageSourceCreateWithData(data as CFData, [kCGImageSourceShouldCache: false] as CFDictionary),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 1200,
                kCGImageSourceShouldCacheImmediately: true
              ] as CFDictionary) else { return nil }
        return UIImage(cgImage: image).jpegData(compressionQuality: 0.85)
    }

    static func artworkPriority(_ path: String) -> Int {
        let name = path.lowercased()
        if name.contains("preview") || name.contains("thumbnail") || name.contains("cover") { return 0 }
        if name.contains("lock") { return 1 }
        return 2
    }

    private static func extractArtwork(at source: URL) throws -> Data {
        let entries = try TendiesArchiveValidator.validateBeforeExtraction(at: source)
        let candidates = entries.filter {
            !$0.isDirectory && !$0.isMetadata && $0.uncompressedSize <= 12_000_000 &&
            ["jpg", "jpeg", "png", "heic", "webp"].contains(($0.path as NSString).pathExtension.lowercased())
        }.sorted {
            let left = artworkPriority($0.path), right = artworkPriority($1.path)
            return left == right ? $0.path < $1.path : left < right
        }
        guard !candidates.isEmpty else { throw ArtworkError.unavailable }
        let workspace = try TendiesInstallWorkspace.create()
        defer { try? FileManager.default.removeItem(at: workspace) }
        try TendiesArchiveValidator.extract(at: source, to: workspace, entries: entries)
        for entry in candidates.prefix(15) {
            if let data = try? Data(contentsOf: workspace.appendingPathComponent(entry.path)),
               let image = thumbnail(from: data) { return image }
        }
        throw ArtworkError.unavailable
    }

    private enum ArtworkError: Error { case unavailable }
}
