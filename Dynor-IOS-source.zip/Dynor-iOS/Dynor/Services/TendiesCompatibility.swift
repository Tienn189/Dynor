import Foundation

/// Permission to attempt the on-device backend selected for this iOS version;
/// never a claim of device testing.
enum TendiesCompatibility {
    struct Assessment {
        let warning: String?
        let detail: String
        let backend: PosterBoardBackend
        var canAttemptInstall: Bool { warning == nil }
    }

    static let summary = "Airlift dùng trên iOS 18–26 (cần pairing record); worse_query dùng trên iOS 27.0–27.2.0 (cần App Group hợp lệ trong chữ ký IPA). Tự động chọn theo phiên bản iOS. Các phạm vi này chưa thay thế kiểm thử trên thiết bị thật."

    static var current: Assessment {
        assess(version: ProcessInfo.processInfo.operatingSystemVersion,
               backend: PosterBoardBackend.current)
    }

    static func assess(version: OperatingSystemVersion,
                       backend: PosterBoardBackend? = nil) -> Assessment {
        let backend = backend ?? PosterBoardBackend.current
        let supported = PosterBoardBackend.isAvailable(backend, for: version)
        let warning: String?
        let detail: String
        switch backend {
        case .airlift:
            warning = supported ? nil : "Airlift trong Dynor chỉ được bật trên iOS 18.0–26.x. Bản iOS này nằm ngoài phạm vi; Dynor không thử ghi PosterBoard."
            detail = supported
                ? "Có thể thử cài qua Airlift trên bản iOS này. Cần pairing record (Cài đặt → Airlift) và có thể cần LocalDevVPN/WireGuard. Chưa có xác nhận trên thiết bị này."
                : "Airlift không được bật trên phiên bản iOS này (phạm vi 18.0–26.x)."
        case .worseQuery:
            warning = supported ? nil : "worse_query trong Dynor chỉ được bật trên iOS 26.0–26.7.2 và 27.0–27.2.0. Bản iOS này nằm ngoài phạm vi; Dynor không thử ghi PosterBoard."
            detail = supported
                ? "Có thể thử cài trực tiếp qua worse_query trên bản iOS này. Dynor sẽ kiểm tra App Group và quyền truy cập PosterBoard. Phạm vi upstream chưa phải xác nhận chạy thành công trên thiết bị này."
                : "worse_query không hỗ trợ phiên bản iOS này (phạm vi 26.0–26.7.2 và 27.0–27.2.0)."
        }
        return Assessment(warning: warning, detail: detail, backend: backend)
    }
}
