import Foundation
import Darwin

/// Owns the worse_query lifetime for the single container Dynor needs.
/// Call only on the installer's serialized queue: upstream temporarily replaces
/// the dedicated App Group's Caches directory while issuing each token.
enum PosterBoardAccess {
    private static let bundleIdentifier = "com.apple.PosterBoard"
    private static let cachedContainerKey = "dynor.posterboard.verifiedContainer"
    private static let roots = [
        "/var/mobile/Containers/Data/Application",
        "/var/mobile/Containers/Data/InternalDaemon"
    ]

    struct AccessError: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }

    private struct Match<Value> { let value: Value }

    @MainActor
    static func requestOpenPosterBoard() -> Bool {
        #if targetEnvironment(simulator)
        return false
        #else
        return dynor_open_posterboard()
        #endif
    }

    static var prerequisiteWarning: String? {
        #if targetEnvironment(simulator)
        return "Simulator không có PosterBoard của iPhone. Hãy cài IPA được ký với App Group hợp lệ lên thiết bị thật."
        #else
        do { _ = try configuredGroup(); return nil }
        catch { return error.localizedDescription }
        #endif
    }

    /// Read-only diagnostics. Does not invoke worse_query or modify PosterBoard.
    static func diagnosticReport() -> String {
        let bundle = Bundle.main.bundleIdentifier ?? "(không xác định)"
        let configured = Bundle.main.object(forInfoDictionaryKey: "DynorAppGroupIdentifier") as? String
        let groups = dynor_signed_app_groups()
        var lines = ["Dynor • Chẩn đoán App Group", "Bundle ID: \(bundle)",
                     "iOS: \(ProcessInfo.processInfo.operatingSystemVersionString)",
                     "Group cấu hình: \(configured ?? "(thiếu)")",
                     "Group trong entitlement runtime: \(groups?.joined(separator: ", ") ?? "(không đọc được)")"]
        let candidates = candidateGroups()
        lines.append("Nhóm ứng viên: \(candidates.joined(separator: ", "))")
        guard let selected = try? configuredGroup(),
              let root = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: selected) else {
            lines.append("Kết luận: không tìm được App Group được cấp quyền và có thể đọc/ghi")
            lines.append("Lưu ý: chứng chỉ không có App Group không thể được ứng dụng tự cấp quyền")
            return lines.joined(separator: "\n")
        }
        lines.append("Nhóm được chọn: \(selected)")
        lines.append("Container URL: có (không hiển thị đường dẫn riêng tư)")
        let probe = root.appendingPathComponent(".dynor-diagnostic-\(UUID().uuidString)")
        do {
            let payload = Data("dynor-diagnostic".utf8)
            try payload.write(to: probe, options: .atomic)
            let readback = try Data(contentsOf: probe)
            lines.append(readback == payload ? "Kiểm tra ghi/đọc: THÀNH CÔNG" : "Kiểm tra ghi/đọc: SAI DỮ LIỆU")
        } catch {
            let nsError = error as NSError
            lines.append("Kiểm tra ghi/đọc: LỖI \(nsError.domain) / \(nsError.code): \(nsError.localizedDescription)")
        }
        try? FileManager.default.removeItem(at: probe)
        lines.append("Lưu ý: kiểm tra App Group thành công không chứng minh worse_query hay cài hình nền thành công")
        return lines.joined(separator: "\n")
    }

    /// The closure runs while the verified PosterBoard container token is held.
    /// This verifies access and identity, not that iOS applied a wallpaper.
    static func withAccess<T>(toPosterBoard body: (URL) throws -> T,
                              log: (String) -> Void = { _ in }) throws -> T {
        #if targetEnvironment(simulator)
        throw AccessError(message: prerequisiteWarning ?? "Cần iPhone thật.")
        #else
        let group = try configuredGroup()
        guard let groupRoot = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
            throw AccessError(message: "App Group không còn truy cập được. Hãy mở lại Dynor và kiểm tra chữ ký IPA.")
        }
        // Upstream uses Library/Caches for its temporary symlink. A newly
        // provisioned group may not yet have Library, so create it beforehand.
        try FileManager.default.createDirectory(at: groupRoot.appendingPathComponent("Library"), withIntermediateDirectories: true)
        var hints = [String]()
        if let cached = UserDefaults.standard.string(forKey: cachedContainerKey) { hints.append(cached) }
        if let hint = dynor_posterboard_container_hint() { hints.append(hint) }
        var visited = Set<String>()
        var lastNativeFailure: Int64?

        func attempt(_ path: String) throws -> Match<T>? {
            guard let container = validatedContainerURL(path), visited.insert(container.path).inserted else { return nil }
            // create_dir=true bypasses lstat before a token is acquired: sandbox
            // denial cannot be mistaken for a nonexistent container.
            let handle = worse_query(container.path, group, false, true)
            guard handle >= 0 else {
                lastNativeFailure = handle
                // These failures are independent of the candidate container.
                // Stop rather than spending minutes scanning an unusable route.
                if [-1, -2, -3, -4].contains(handle) {
                    throw AccessError(message: "Không khởi tạo được quyền truy cập PosterBoard (worse_query \(handle)). Kiểm tra App Group, chữ ký IPA và phiên bản iOS; Dynor chưa ghi hình nền.")
                }
                return nil
            }
            defer { worse_query_release(handle) }
            guard try identity(at: container) == bundleIdentifier else { return nil }
            UserDefaults.standard.set(container.path, forKey: cachedContainerKey)
            log("Đã xác minh container com.apple.PosterBoard trên thiết bị.")
            return try Match(value: body(container))
        }

        for hint in hints {
            if let result = try attempt(hint) { return result.value }
        }
        UserDefaults.standard.removeObject(forKey: cachedContainerKey)
        let inode = try baselineInode()
        log("Đang tìm container PosterBoard trên thiết bị; lần đầu có thể mất vài phút (giới hạn inode \(inode)).")
        for root in roots {
            // pathleak can return /private/var paths. Normalize and reject every
            // result outside the allowlisted roots before requesting access.
            // APFS commonly reports canonical /private/var paths; try that
            // spelling first because pristine pathleak compares literal prefixes.
            for spelling in ["/private" + root, root] {
                let paths = pathleak(spelling, inode) ?? []
                for path in paths {
                    if let result = try attempt(path) { return result.value }
                }
                if !paths.isEmpty { break }
            }
        }
        let detail = lastNativeFailure.map { " " + nativeFailureDescription($0) } ?? ""
        throw AccessError(message: "Không tìm được container PosterBoard có danh tính hợp lệ. Mở Cài đặt → Hình nền một lần, giữ iPhone mở khóa rồi thử lại. Kiểm tra App Group trong chữ ký và phiên bản iOS.\(detail)")
        #endif
    }

    private static func nativeFailureDescription(_ code: Int64) -> String {
        switch code {
        case -255: return "worse_query: đường dẫn không tồn tại (-255)."
        case -1: return "worse_query: App Group không truy cập được (-1); kiểm tra provisioning profile."
        case -2: return "worse_query: API native không khả dụng trên bản iOS này (-2)."
        case -3: return "worse_query: không tạo được truy vấn container (-3)."
        case -4: return "worse_query: không chuẩn bị được thư mục cache của App Group (-4)."
        case -5: return "worse_query: hệ thống từ chối truy vấn container (-5)."
        case -6: return "worse_query: hệ thống không cấp quyền truy cập container (-6)."
        default: return "worse_query trả mã \(code); chưa có quyền truy cập hợp lệ."
        }
    }

    /// Prefer the project's configured group when it is actually signed and usable;
    /// otherwise try the other groups granted to this installed app by iOS.
    /// A provisioning profile alone is NOT sufficient to authorize a group.
    private static func candidateGroups() -> [String] {
        guard let signed = dynor_signed_app_groups() else { return [] }
        let valid = Array(Set(signed.filter {
            $0.hasPrefix("group.") && $0.count > 6 && !$0.contains("$(")
        })).sorted()
        let preferred = Bundle.main.object(forInfoDictionaryKey: "DynorAppGroupIdentifier") as? String
        guard let preferred, valid.contains(preferred) else { return valid }
        return [preferred] + valid.filter { $0 != preferred }
    }

    private static func configuredGroup() throws -> String {
        let candidates = candidateGroups()
        guard !candidates.isEmpty else {
            throw AccessError(message: "IPA đã ký không có App Group hợp lệ trong entitlement runtime. LCSign không thể cấp quyền App Group nếu profile/chữ ký không hỗ trợ.")
        }
        var failures = [String]()
        for group in candidates {
            guard let root = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
                failures.append("\(group): iOS không cấp container")
                continue
            }
            let probe = root.appendingPathComponent(".dynor-group-probe-\(UUID().uuidString)")
            do {
                let payload = Data("dynor-probe".utf8)
                try payload.write(to: probe, options: .atomic)
                defer { try? FileManager.default.removeItem(at: probe) }
                guard try Data(contentsOf: probe) == payload else {
                    failures.append("\(group): dữ liệu đọc lại không khớp")
                    continue
                }
                return group
            } catch {
                try? FileManager.default.removeItem(at: probe)
                failures.append("\(group): \(error.localizedDescription)")
            }
        }
        throw AccessError(message: "Không có App Group nào trong chữ ký IPA cho phép đọc/ghi. " + failures.joined(separator: "; "))
    }

    static func validatedContainerURL(_ path: String) -> URL? {
        let normalized = path.hasPrefix("/private/var/") ? String(path.dropFirst(8)) : path
        let components = (normalized as NSString).standardizingPath
        guard roots.contains(where: { components.hasPrefix($0 + "/") }) else { return nil }
        let url = URL(fileURLWithPath: components, isDirectory: true)
        guard UUID(uuidString: url.lastPathComponent) != nil,
              roots.contains(url.deletingLastPathComponent().path),
              components == normalized else { return nil }
        return url
    }

    private static func identity(at container: URL) throws -> String? {
        let attributes = try? container.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard attributes?.isDirectory == true, attributes?.isSymbolicLink != true else { return nil }
        for filename in [".com.apple.mobile_container_manager.metadata.plist", "com.apple.mobile_container_manager.metadata.plist"] {
            let metadata = container.appendingPathComponent(filename)
            if let data = try? Data(contentsOf: metadata),
               let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
               let identifier = plist["MCMMetadataIdentifier"] as? String {
                return identifier
            }
        }
        // The original worse_query PoC identifies containers using this xattr.
        // Require a complete, valid UTF-8 value rather than a prefix match.
        var buffer = [UInt8](repeating: 0, count: 1024)
        let length = container.path.withCString { path in
            buffer.withUnsafeMutableBytes { bytes in
                getxattr(path, "com.apple.containermanager.identifier", bytes.baseAddress, bytes.count, 0, 0)
            }
        }
        guard length > 0, length < buffer.count else { return nil }
        var value = Array(buffer.prefix(length))
        if value.last == 0 { value.removeLast() }
        return String(bytes: value, encoding: .utf8)
    }

    private static func baselineInode() throws -> UInt64 {
        let fm = FileManager.default
        let baseline = fm.temporaryDirectory.appendingPathComponent("dynor-poster-inode-" + UUID().uuidString)
        try Data([0]).write(to: baseline)
        defer { try? fm.removeItem(at: baseline) }
        var info = stat()
        guard baseline.path.withCString({ lstat($0, &info) }) == 0, info.st_ino > 0 else {
            throw AccessError(message: "Không xác định được giới hạn tìm container PosterBoard.")
        }
        return UInt64(info.st_ino)
    }
}
