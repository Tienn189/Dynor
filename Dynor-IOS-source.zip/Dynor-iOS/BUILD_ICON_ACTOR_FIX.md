Sửa lỗi build trong log ngày 23/11/2026: thêm @MainActor cho DynorAppIcon.title vì DynorStore.localized được cô lập trên MainActor. Cả ba lỗi compiler ở các dòng tên icon có cùng nguyên nhân này. Giữ toàn bộ tính năng trước đó.
Chưa thể chạy Xcode build lại trong môi trường Linux.
