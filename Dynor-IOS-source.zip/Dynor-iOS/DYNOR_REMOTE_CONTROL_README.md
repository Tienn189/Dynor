# Dynor remote maintenance and mandatory updates

1. In Supabase SQL Editor, execute `DYNOR_REMOTE_CONTROL_SETUP.sql` once.
2. Edit the row `public.dynor_app_control` with id=1. Maintenance has priority over forced update.
3. Set `maintenance_enabled=true` to block the app and show a Try again button; set it to false to restore access.
4. To require a new IPA, set `force_update=true` and `minimum_build` higher than the installed CFBundleVersion (currently build 6). Set `telegram_url` to the actual channel/group containing the signed IPA. `latest_version`, `update_title`, and `update_message` control the displayed message.
5. Accent color is inherited from DynorStore and used in both dialogs. Both dialogs cover the root app and have no dismissal control. App checks at startup, when foregrounded, and every ~20 seconds.

**Important limits:** Existing installed builds without this code cannot be remotely locked. Network errors retain the last successfully fetched config; first launch while offline cannot reliably enforce a remote lock. To require strict fail-closed access, a server-authorized gate for protected features is needed. This is UI-level blocking, not server-side access revocation. Also verify Telegram link before distribution.

**Build note:** Xcode/macOS is required to compile/test the SwiftUI app. The source archive has not been compiled in this environment.
