-- Run once in Supabase SQL Editor. The public may read ONLY the single app-control row.
CREATE TABLE IF NOT EXISTS public.dynor_app_control (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  maintenance_enabled boolean NOT NULL DEFAULT false,
  maintenance_title text,
  maintenance_message text,
  maintenance_eta text,
  force_update boolean NOT NULL DEFAULT false,
  minimum_build integer NOT NULL DEFAULT 0,
  latest_version text,
  update_title text,
  update_message text,
  telegram_url text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.dynor_app_control ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.dynor_app_control FROM anon, authenticated;
GRANT SELECT ON public.dynor_app_control TO anon, authenticated;
DROP POLICY IF EXISTS "Public can read app control" ON public.dynor_app_control;
CREATE POLICY "Public can read app control" ON public.dynor_app_control FOR SELECT TO anon, authenticated USING (id = 1);
INSERT INTO public.dynor_app_control
(id, maintenance_enabled, maintenance_title, maintenance_message, maintenance_eta, force_update, minimum_build, latest_version, update_title, update_message, telegram_url)
VALUES (1, false, 'Dynor đang bảo trì', 'Hệ thống đang được nâng cấp. Vui lòng quay lại sau.', '', false, 6, '1.3.0', 'Đã có phiên bản Dynor mới!', 'Vào Telegram để tải bản IPA mới nhất.', 'https://t.me/DENRINDZWP')
ON CONFLICT (id) DO NOTHING;

-- To ENABLE maintenance (run separately):
-- UPDATE public.dynor_app_control SET maintenance_enabled = true, maintenance_eta = 'Dự kiến 22:00', updated_at = now() WHERE id = 1;
-- To DISABLE maintenance:
-- UPDATE public.dynor_app_control SET maintenance_enabled = false, updated_at = now() WHERE id = 1;
-- To FORCE UPDATE all builds below 7:
-- UPDATE public.dynor_app_control SET force_update = true, minimum_build = 7, latest_version = '1.3.1', updated_at = now() WHERE id = 1;
-- To DISABLE forced update:
-- UPDATE public.dynor_app_control SET force_update = false, updated_at = now() WHERE id = 1;
