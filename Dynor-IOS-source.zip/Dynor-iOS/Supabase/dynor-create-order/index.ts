import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const respond = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { "Content-Type": "application/json" },
});

Deno.serve(async (req) => {
  if (req.method !== "POST") return respond({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY");
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const account = Deno.env.get("SEPAY_RECEIVER_ACCOUNT");
  const bankCode = Deno.env.get("VIETQR_BANK_CODE") ?? "MB";
  if (!url || !anon || !service || !account) return respond({ error: "Missing server configuration" }, 503);
  const auth = req.headers.get("Authorization") ?? "";
  if (!auth.startsWith("Bearer ")) return respond({ error: "Authentication required" }, 401);
  const authClient = createClient(url, anon, { global: { headers: { Authorization: auth } } });
  const { data: userData, error: userError } = await authClient.auth.getUser(auth.slice(7));
  if (userError || !userData.user) return respond({ error: "Invalid session" }, 401);
  let input: { plan_id?: string };
  try { input = await req.json(); } catch { return respond({ error: "Invalid JSON" }, 400); }
  const plans: Record<string, { amount: number; days: number | null }> = {
    week: { amount: 19000, days: 7 },
    month: { amount: 39000, days: 30 },
    quarter: { amount: 79000, days: 90 },
    credits5: { amount: 10000, days: 0 },
  };
  const plan = typeof input?.plan_id === "string" && Object.hasOwn(plans, input.plan_id) ? plans[input.plan_id] : undefined;
  if (!plan) return respond({ error: "Unsupported plan" }, 400);
  const db = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });
  if (input.plan_id === "credits5") {
    const { data: vip, error: vipError } = await db.from("dynor_vip")
      .select("plan_id,vip_expires_at").eq("user_id", userData.user.id).maybeSingle();
    if (vipError) return respond({ error: "Không kiểm tra được gói VIP. Vui lòng thử lại." }, 503);
    const lifetime = vip?.plan_id === "lifetime" && vip.vip_expires_at === null;
    const active = typeof vip?.vip_expires_at === "string" && Date.parse(vip.vip_expires_at) > Date.now();
    if (!vip || !["month", "quarter", "lifetime"].includes(vip.plan_id) || (!lifetime && !active)) {
      return respond({ error: "Cần gói tháng trở lên còn hạn để mua thêm lượt Crown.", code: "crown_plan_required" }, 403);
    }
  }
  const paymentCode = "DYN" + crypto.randomUUID().replaceAll("-", "").slice(0, 16).toUpperCase();
  const { error } = await db.from("dynor_orders").insert({
    user_id: userData.user.id, payment_code: paymentCode,
    amount: plan.amount, plan_id: input.plan_id, duration_days: plan.days, status: "pending",
  });
  if (error) { console.error("Create order failed", error.code); return respond({ error: "Could not create order" }, 500); }
  const qr = new URL(`https://img.vietqr.io/image/${encodeURIComponent(bankCode)}-${encodeURIComponent(account)}-compact2.png`);
  qr.searchParams.set("amount", String(plan.amount));
  qr.searchParams.set("addInfo", paymentCode);
  return respond({ payment_code: paymentCode, amount: plan.amount,
    bank_name: "MB Bank", bank_account: account, qr_url: qr.toString() });
});
