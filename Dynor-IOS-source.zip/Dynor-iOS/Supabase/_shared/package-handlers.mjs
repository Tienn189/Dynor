import {
  PackageInputError, packageID, contentHash, originalName, decodeBase64,
  importKEK, recipientPublicKey, wrapAtRest, unwrapAtRest, wrapForRecipient,
} from './package-crypto.mjs';

const MAX_BODY_BYTES = 4096;
const HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Max-Age': '600',
  'X-Content-Type-Options': 'nosniff',
};

function reply(body, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(body), { status, headers: { ...HEADERS, ...extraHeaders } });
}

class HTTPFailure extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

async function readBody(req) {
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers.get('content-type') ?? '')) {
    throw new HTTPFailure('Content-Type must be application/json', 415);
  }
  const declared = req.headers.get('content-length');
  if (declared !== null && (!/^\d+$/.test(declared) || Number(declared) > MAX_BODY_BYTES)) {
    throw new HTTPFailure('Request too large', 413);
  }
  if (!req.body) throw new HTTPFailure('Invalid JSON', 400);
  const reader = req.body.getReader();
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_BODY_BYTES) {
        await reader.cancel();
        throw new HTTPFailure('Request too large', 413);
      }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  let result;
  try { result = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); }
  catch { throw new HTTPFailure('Invalid JSON', 400); }
  if (!result || typeof result !== 'object' || Array.isArray(result)) throw new HTTPFailure('Invalid JSON object', 400);
  return result;
}

function isVIP(record, now) {
  return !!record && (
    (record.plan_id === 'lifetime' && record.vip_expires_at === null) ||
    (typeof record.vip_expires_at === 'string' && Date.parse(record.vip_expires_at) > now)
  );
}

// Keep transport/auth/database dependencies injectable so authorization and failure
// handling are exercised without a live Supabase project or production credentials.
export function createPackageHandler(mode, { createClient, env, now = () => Date.now() }) {
  if (mode !== 'register' && mode !== 'key') throw new Error('Unknown package endpoint');
  return async function handle(req) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: HEADERS });
    if (req.method !== 'POST') return reply({ error: 'Method not allowed' }, 405, { Allow: 'POST, OPTIONS' });
    let rawKey;
    try {
      const url = env('SUPABASE_URL');
      const anon = env('SUPABASE_ANON_KEY');
      const service = env('SUPABASE_SERVICE_ROLE_KEY');
      const rawKEK = env('DYNOR_PACKAGE_KEK');
      if (!url || !anon || !service || !rawKEK) throw new HTTPFailure('Package service is not configured', 503);
      let kek;
      try { kek = await importKEK(rawKEK); }
      catch { throw new HTTPFailure('Package service is not configured', 503); }
      const authorization = req.headers.get('authorization') ?? '';
      const match = /^Bearer ([^\s]+)$/i.exec(authorization);
      if (!match) throw new HTTPFailure('Login required', 401);
      const jwt = match[1];
      const auth = createClient(url, anon, {
        global: { headers: { Authorization: `Bearer ${jwt}` } },
        auth: { persistSession: false, autoRefreshToken: false },
      });
      const { data: authData, error: authError } = await auth.auth.getUser(jwt);
      if (authError || !authData?.user?.id) throw new HTTPFailure('Invalid session', 401);
      const userID = authData.user.id;
      const db = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });

      if (mode === 'register') {
        const { data: admin, error } = await db.from('dynor_admins').select('user_id').eq('user_id', userID).maybeSingle();
        if (error) throw new HTTPFailure('Admin verification unavailable', 503);
        if (!admin) throw new HTTPFailure('Admin access required', 403);
      } else {
        // Count attempts before package lookup, including malformed/probing requests.
        // RPC uses a single UPSERT so concurrent calls cannot bypass the limit.
        const { data: allowed, error } = await db.rpc('dynor_consume_package_key_limit', { p_user_id: userID });
        if (error) throw new HTTPFailure('Request verification unavailable', 503);
        if (allowed !== true) return reply({ error: 'Too many key requests; try again later' }, 429, { 'Retry-After': '60' });
      }

      const body = await readBody(req);
      const id = packageID(body.package_id);
      const sha256 = contentHash(body.sha256);
      if (mode === 'register') {
        const name = originalName(body.original_name);
        if (typeof body.requires_vip !== 'boolean') throw new PackageInputError('Invalid requires_vip');
        const tier = body.access_tier ?? (body.requires_vip ? 'crown' : 'free');
        if (!['crown','premium','free'].includes(tier) || body.requires_vip !== (tier !== 'free')) throw new PackageInputError('Invalid access_tier');
        rawKey = decodeBase64(body.key_base64, 32, 'key_base64');
        const wrappedKey = await wrapAtRest(rawKey, kek, id);
        const { error } = await db.from('dynor_encrypted_packages').insert({
          package_id: id, sha256, wrapped_key: wrappedKey, original_name: name,
          requires_vip: body.requires_vip, access_tier: tier, created_by: userID,
        });
        if (error?.code === '23505') throw new HTTPFailure('Package already registered; encrypt as a new package', 409);
        if (error) throw new HTTPFailure('Could not register package', 503);
        return reply({ package_id: id, sha256 }, 201);
      }

      const recipient = await recipientPublicKey(body.public_key);
      const { data: record, error } = await db.from('dynor_encrypted_packages')
        .select('package_id,sha256,wrapped_key,requires_vip,access_tier,active').eq('package_id', id).maybeSingle();
      if (error) throw new HTTPFailure('Package verification unavailable', 503);
      if (!record || record.active !== true || record.sha256 !== sha256) throw new HTTPFailure('Package unavailable', 404);
      if (record.requires_vip) {
        const { data: vip, error: vipError } = await db.from('dynor_vip')
          .select('vip_expires_at,plan_id').eq('user_id', userID).maybeSingle();
        if (vipError) throw new HTTPFailure('VIP verification unavailable', 503);
        if (!isVIP(vip, now())) throw new HTTPFailure('VIP required', 403);
      }
      try { rawKey = await unwrapAtRest(record.wrapped_key, kek, id); }
      catch { throw new HTTPFailure('Package service unavailable', 503); }
      return reply(await wrapForRecipient(rawKey, recipient, id));
    } catch (error) {
      if (error instanceof HTTPFailure) return reply({ error: error.message }, error.status);
      if (error instanceof PackageInputError) return reply({ error: error.message }, 400);
      // Do not echo SDK/crypto exceptions: they may contain request data or keys.
      return reply({ error: 'Package service unavailable' }, 503);
    } finally { rawKey?.fill(0); }
  };
}
