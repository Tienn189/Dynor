# Dynor cumulative VIP quota deployment

1. Run `Supabase/sql/vip_download_quota.sql` in Supabase SQL Editor. It creates cumulative credit and unique-download tables and backfills **all** previously paid orders. Check historic order accuracy before running in production.
2. Run `Supabase/sql/upgrade_settlement_all_plans.sql` to update payment settlement so weekly orders add no Crown credits, monthly orders add 5, and quarterly orders add 10 credits. Lifetime remains unlimited. **This is essential:** updating only the download Edge Function is insufficient.
3. Deploy `Supabase/dynor-wallpaper-download/index.ts` as `dynor-wallpaper-download`.
4. Build and install the updated iOS app to show localized quota messages, plan benefits and profile balance.
5. Verify: weekly+weekly+monthly = 5 credits; weekly entitlement cannot download Crown (including previously claimed wallpapers), distinct VIP wallpapers count once per account; retrying the same wallpaper does not use another credit; deleting a wallpaper does not restore a credit. All credits are usable only while VIP entitlement is active; purchases extend VIP expiry using existing settlement logic.

Important: Previously paid orders are backfilled, so check the paid-order history. Credits remain recorded after expiry but cannot be spent without active VIP. Credits are lifetime cumulative (not per renewal period); repeat downloads do not consume additional credits. Existing downloads are migrated from `dynor_vip_downloads`.
