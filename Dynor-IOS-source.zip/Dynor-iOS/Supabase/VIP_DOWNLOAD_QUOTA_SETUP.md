# VIP download quota setup

1. Run `Supabase/sql/vip_download_quota.sql` in the Supabase SQL Editor (service/admin access).
2. Deploy the updated `Supabase/dynor-wallpaper-download/index.ts` Edge Function.
3. Confirm `dynor-downloads` is PRIVATE, and only the Edge Function issues signed URLs. Any alternate download/key endpoints must enforce the same quota to prevent bypass.
4. Test a weekly user downloading VIP A twice (both allowed), then VIP B (HTTP 429). Test monthly A/B/C then D denied. Test free downloads and lifetime.
5. Renew the subscription using `dynor_settle_payment`: `dynor_vip.updated_at` changes, establishing a fresh quota period. An administrator manually editing `updated_at` also resets quota.

A download is counted when a signed download URL is issued, not after the file finishes transferring. A network failure after URL issuance does not refund the slot, but retrying the same wallpaper is free. VIP entitlement and counters are checked atomically in Postgres under a per-user advisory transaction lock.

Note: the app currently shows raw server error JSON on failures. A future UI improvement can map `quota_exceeded` to localized upgrade prompts.
