-- Run before deploying the new admin, app and download function.
ALTER TABLE public.dynor_wallpapers ADD COLUMN IF NOT EXISTS access_tier text;
UPDATE public.dynor_wallpapers SET access_tier = CASE WHEN is_vip THEN 'crown' ELSE 'free' END WHERE access_tier IS NULL;
ALTER TABLE public.dynor_wallpapers ALTER COLUMN access_tier SET DEFAULT 'free';
ALTER TABLE public.dynor_wallpapers ALTER COLUMN access_tier SET NOT NULL;
ALTER TABLE public.dynor_wallpapers DROP CONSTRAINT IF EXISTS dynor_wallpapers_access_tier_check;
ALTER TABLE public.dynor_wallpapers ADD CONSTRAINT dynor_wallpapers_access_tier_check CHECK (access_tier IN ('crown','premium','free'));
-- Keep is_vip synchronized for older clients, but new clients use access_tier.
CREATE OR REPLACE FUNCTION public.dynor_sync_wallpaper_tier() RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $$ BEGIN NEW.is_vip := (NEW.access_tier = 'crown'); RETURN NEW; END $$;
DROP TRIGGER IF EXISTS dynor_sync_wallpaper_tier_trigger ON public.dynor_wallpapers;
CREATE TRIGGER dynor_sync_wallpaper_tier_trigger BEFORE INSERT OR UPDATE OF access_tier ON public.dynor_wallpapers FOR EACH ROW EXECUTE FUNCTION public.dynor_sync_wallpaper_tier();

ALTER TABLE public.dynor_encrypted_packages ADD COLUMN IF NOT EXISTS access_tier text;
UPDATE public.dynor_encrypted_packages SET access_tier = CASE WHEN requires_vip THEN 'crown' ELSE 'free' END WHERE access_tier IS NULL;
ALTER TABLE public.dynor_encrypted_packages ALTER COLUMN access_tier SET DEFAULT 'crown';
ALTER TABLE public.dynor_encrypted_packages ALTER COLUMN access_tier SET NOT NULL;
ALTER TABLE public.dynor_encrypted_packages DROP CONSTRAINT IF EXISTS dynor_packages_access_tier_check;
ALTER TABLE public.dynor_encrypted_packages ADD CONSTRAINT dynor_packages_access_tier_check CHECK (access_tier IN ('crown','premium','free'));
