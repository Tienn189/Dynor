-- Deploy in Supabase SQL Editor before deploying the updated download Edge Function.
-- One unique VIP wallpaper per user per paid entitlement period. Deletion never refunds.
create table if not exists public.dynor_vip_downloads (
  user_id uuid not null references auth.users(id) on delete cascade,
  period_started_at timestamptz not null,
  wallpaper_id uuid not null references public.dynor_wallpapers(id) on delete restrict,
  downloaded_at timestamptz not null default now(),
  primary key (user_id, period_started_at, wallpaper_id)
);
create index if not exists dynor_vip_downloads_period_idx on public.dynor_vip_downloads(user_id,period_started_at);
alter table public.dynor_vip_downloads enable row level security;
-- No client-side read/write access: only service-role Edge Function can execute the RPC.
create or replace function public.dynor_claim_vip_download(p_user_id uuid, p_wallpaper_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_vip public.dynor_vip%rowtype;
  v_wallpaper public.dynor_wallpapers%rowtype;
  v_limit integer;
  v_used integer;
  v_period timestamptz;
begin
  -- Serialize with payment settlement and concurrent downloads for this account.
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_user_id::text,0));
  select * into v_wallpaper from public.dynor_wallpapers where id=p_wallpaper_id and published=true;
  if not found then return jsonb_build_object('allowed',false,'reason','not_found'); end if;
  if not v_wallpaper.is_vip then return jsonb_build_object('allowed',true,'reason','free'); end if;
  select * into v_vip from public.dynor_vip where user_id=p_user_id for update;
  if not found or (v_vip.plan_id <> 'lifetime' and (v_vip.vip_expires_at is null or v_vip.vip_expires_at <= now())) then
    return jsonb_build_object('allowed',false,'reason','vip_required');
  end if;
  if v_vip.plan_id='lifetime' and v_vip.vip_expires_at is null then
    return jsonb_build_object('allowed',true,'reason','lifetime');
  end if;
  v_limit := case v_vip.plan_id when 'week' then 1 when 'month' then 3 else 0 end;
  if v_limit=0 then return jsonb_build_object('allowed',false,'reason','unknown_plan'); end if;
  -- updated_at changes on successful payment settlement, marking a new entitlement period.
  v_period := v_vip.updated_at;
  if exists(select 1 from public.dynor_vip_downloads where user_id=p_user_id and period_started_at=v_period and wallpaper_id=p_wallpaper_id) then
    select count(*) into v_used from public.dynor_vip_downloads where user_id=p_user_id and period_started_at=v_period;
    return jsonb_build_object('allowed',true,'reason','already_downloaded','used',v_used,'limit',v_limit);
  end if;
  select count(*) into v_used from public.dynor_vip_downloads where user_id=p_user_id and period_started_at=v_period;
  if v_used>=v_limit then return jsonb_build_object('allowed',false,'reason','quota_exceeded','used',v_used,'limit',v_limit); end if;
  insert into public.dynor_vip_downloads(user_id,period_started_at,wallpaper_id) values(p_user_id,v_period,p_wallpaper_id);
  return jsonb_build_object('allowed',true,'reason','new_download','used',v_used+1,'limit',v_limit);
end;
$$;
revoke all on function public.dynor_claim_vip_download(uuid,uuid) from public, anon, authenticated;
grant execute on function public.dynor_claim_vip_download(uuid,uuid) to service_role;
