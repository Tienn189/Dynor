-- Run after vip_download_quota.sql has created the cumulative credit tables.
-- Existing weekly credits are excluded from totals; download history is preserved.
BEGIN;
CREATE OR REPLACE FUNCTION public.dynor_vip_quota_status(p_user_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_vip public.dynor_vip%ROWTYPE; v_total bigint; v_used bigint; v_lifetime boolean;
BEGIN
  SELECT * INTO v_vip FROM public.dynor_vip WHERE user_id=p_user_id;
  v_lifetime := FOUND AND v_vip.plan_id='lifetime' AND v_vip.vip_expires_at IS NULL;
  SELECT coalesce(sum(g.credits),0) INTO v_total FROM public.dynor_vip_credit_grants g JOIN public.dynor_orders o ON o.id=g.order_id WHERE g.user_id=p_user_id AND o.plan_id <> 'week';
  SELECT count(*) INTO v_used FROM public.dynor_vip_unique_downloads WHERE user_id=p_user_id;
  RETURN jsonb_build_object('active', v_lifetime OR coalesce(v_vip.vip_expires_at > now(),false),
    'unlimited',v_lifetime,'used',v_used,'limit',CASE WHEN v_lifetime THEN NULL ELSE v_total END,
    'remaining',CASE WHEN v_lifetime THEN NULL ELSE greatest(v_total-v_used,0) END);
END;
$$;
REVOKE ALL ON FUNCTION public.dynor_vip_quota_status(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.dynor_vip_quota_status(uuid) TO service_role;

-- Client may read only its own quota via auth.uid(); never pass an arbitrary user ID.
CREATE OR REPLACE FUNCTION public.dynor_my_vip_quota()
RETURNS jsonb LANGUAGE sql SECURITY DEFINER SET search_path = '' AS $$
  SELECT public.dynor_vip_quota_status(auth.uid());
$$;
REVOKE ALL ON FUNCTION public.dynor_my_vip_quota() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.dynor_my_vip_quota() TO authenticated;

CREATE OR REPLACE FUNCTION public.dynor_claim_vip_download(p_user_id uuid,p_wallpaper_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_vip public.dynor_vip%ROWTYPE; v_wallpaper public.dynor_wallpapers%ROWTYPE;
  v_total bigint; v_used bigint; v_lifetime boolean;
BEGIN
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_user_id::text,0));
  SELECT * INTO v_wallpaper FROM public.dynor_wallpapers WHERE id=p_wallpaper_id AND published=true;
  IF NOT FOUND THEN RETURN jsonb_build_object('allowed',false,'reason','not_found'); END IF;
  IF NOT v_wallpaper.is_vip THEN RETURN jsonb_build_object('allowed',true,'reason','free'); END IF;
  SELECT * INTO v_vip FROM public.dynor_vip WHERE user_id=p_user_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('allowed',false,'reason','vip_required'); END IF;
  v_lifetime := v_vip.plan_id='lifetime' AND v_vip.vip_expires_at IS NULL;
  IF NOT v_lifetime AND (v_vip.vip_expires_at IS NULL OR v_vip.vip_expires_at <= now()) THEN
    RETURN jsonb_build_object('allowed',false,'reason','vip_required');
  END IF;
  IF v_vip.plan_id = 'week' THEN
    RETURN jsonb_build_object('allowed',false,'reason','crown_plan_required');
  END IF;
  IF v_lifetime THEN RETURN jsonb_build_object('allowed',true,'reason','lifetime'); END IF;
  SELECT coalesce(sum(g.credits),0) INTO v_total FROM public.dynor_vip_credit_grants g JOIN public.dynor_orders o ON o.id=g.order_id WHERE g.user_id=p_user_id AND o.plan_id <> 'week';
  SELECT count(*) INTO v_used FROM public.dynor_vip_unique_downloads WHERE user_id=p_user_id;
  IF EXISTS(SELECT 1 FROM public.dynor_vip_unique_downloads WHERE user_id=p_user_id AND wallpaper_id=p_wallpaper_id) THEN
    RETURN jsonb_build_object('allowed',true,'reason','already_downloaded','used',v_used,'limit',v_total);
  END IF;
  IF v_used >= v_total THEN
    RETURN jsonb_build_object('allowed',false,'reason','quota_exceeded','used',v_used,'limit',v_total);
  END IF;
  INSERT INTO public.dynor_vip_unique_downloads(user_id,wallpaper_id) VALUES(p_user_id,p_wallpaper_id);
  RETURN jsonb_build_object('allowed',true,'reason','new_download','used',v_used+1,'limit',v_total);
END;
$$;
REVOKE ALL ON FUNCTION public.dynor_claim_vip_download(uuid,uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.dynor_claim_vip_download(uuid,uuid) TO service_role;

-- Run in Supabase SQL Editor before accepting month/lifetime payments.
-- Never expose this function to anon/authenticated roles.
CREATE OR REPLACE FUNCTION public.dynor_settle_payment(
  p_payment_code text, p_amount bigint, p_transaction_id text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
  v_order public.dynor_orders%ROWTYPE;
  v_days integer;
  v_start timestamptz;
  v_expiry timestamptz;
  v_existing public.dynor_vip%ROWTYPE;
BEGIN
  IF p_payment_code IS NULL OR p_payment_code = '' OR
     p_amount IS NULL OR p_amount <= 0 OR
     p_transaction_id IS NULL OR p_transaction_id = '' THEN
    RETURN jsonb_build_object('processed',false,'reason','invalid_input');
  END IF;

  SELECT * INTO v_order FROM public.dynor_orders
  WHERE payment_code = p_payment_code FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('processed',false,'reason','order_not_found');
  END IF;
  IF v_order.status = 'paid' THEN
    RETURN jsonb_build_object('processed',false,'reason','already_paid');
  END IF;
  IF v_order.status <> 'pending' THEN
    RETURN jsonb_build_object('processed',false,'reason','order_not_pending');
  END IF;
  IF v_order.amount <> p_amount THEN
    RETURN jsonb_build_object('processed',false,'reason','amount_mismatch');
  END IF;
  IF v_order.plan_id NOT IN ('week','month','quarter') OR v_order.plan_id IS NULL THEN
    RETURN jsonb_build_object('processed',false,'reason','unsupported_plan');
  END IF;
  IF (v_order.plan_id = 'week' AND v_order.amount <> 19000) OR
     (v_order.plan_id = 'month' AND v_order.amount <> 39000) OR
     (v_order.plan_id = 'quarter' AND v_order.amount <> 79000) THEN
    RETURN jsonb_build_object('processed',false,'reason','invalid_plan_price');
  END IF;

  v_days := CASE v_order.plan_id WHEN 'week' THEN 7 WHEN 'month' THEN 30 WHEN 'quarter' THEN 90 ELSE NULL END;

  -- Serialize entitlement changes for this user across concurrent orders.
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(v_order.user_id::text, 0));
  SELECT * INTO v_existing FROM public.dynor_vip
  WHERE user_id = v_order.user_id FOR UPDATE;

  -- Existing lifetime entitlements remain lifetime after further purchases.
  IF FOUND AND v_existing.plan_id = 'lifetime' AND v_existing.vip_expires_at IS NULL THEN
    v_expiry := NULL;
    ELSE
    v_start := greatest(coalesce(v_existing.vip_expires_at, now()), now());
    v_expiry := v_start + pg_catalog.make_interval(days => v_days);
  END IF;

  UPDATE public.dynor_orders
  SET status = 'paid', paid_at = now(), sepay_transaction_id = p_transaction_id,
      duration_days = v_days
  WHERE id = v_order.id;

  INSERT INTO public.dynor_vip(user_id, vip_expires_at, plan_id, updated_at)
  VALUES(v_order.user_id, v_expiry,
         CASE WHEN v_expiry IS NULL THEN 'lifetime' ELSE v_order.plan_id END, now())
  ON CONFLICT (user_id) DO UPDATE
  SET vip_expires_at = EXCLUDED.vip_expires_at,
      plan_id = EXCLUDED.plan_id,
      updated_at = now();

  -- Every paid order contributes its own credits, even when another plan is active.
  INSERT INTO public.dynor_vip_credit_grants(order_id,user_id,credits)
  VALUES (v_order.id,v_order.user_id,CASE v_order.plan_id WHEN 'week' THEN 0 WHEN 'month' THEN 5 WHEN 'quarter' THEN 10 ELSE 0 END)
  ON CONFLICT (order_id) DO NOTHING;

  RETURN jsonb_build_object('processed',true,'order_id',v_order.id,'vip_expires_at',v_expiry);
EXCEPTION WHEN unique_violation THEN
  RETURN jsonb_build_object('processed',false,'reason','transaction_already_used');
END;
$$;
REVOKE ALL ON FUNCTION public.dynor_settle_payment(text,bigint,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.dynor_settle_payment(text,bigint,text) TO service_role;

COMMIT;
