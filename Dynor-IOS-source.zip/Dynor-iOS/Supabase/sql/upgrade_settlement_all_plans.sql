-- Run in Supabase SQL Editor before accepting month/lifetime payments.
-- Never expose this function to anon/authenticated roles.
CREATE OR REPLACE FUNCTION public.dynor_settle_payment(
  p_payment_code text, p_amount bigint, p_transaction_id text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
  v_order public.dynor_orders%ROWTYPE;
  v_days integer;
  v_start timestamptz;
  v_expiry timestamptz;
  v_existing public.dynor_vip%ROWTYPE;
BEGIN
  IF p_payment_code IS NULL OR p_payment_code = '' OR
     p_amount IS NULL OR p_amount <= 0 OR
     p_transaction_id IS NULL OR p_transaction_id = '' THEN
    RETURN jsonb_build_object('processed',false,'reason','invalid_input');
  END IF;

  SELECT * INTO v_order FROM public.dynor_orders
  WHERE payment_code = p_payment_code FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('processed',false,'reason','order_not_found');
  END IF;
  IF v_order.status = 'paid' THEN
    RETURN jsonb_build_object('processed',false,'reason','already_paid');
  END IF;
  IF v_order.status <> 'pending' THEN
    RETURN jsonb_build_object('processed',false,'reason','order_not_pending');
  END IF;
  IF v_order.amount <> p_amount THEN
    RETURN jsonb_build_object('processed',false,'reason','amount_mismatch');
  END IF;
  IF v_order.plan_id NOT IN ('week','month','lifetime') OR v_order.plan_id IS NULL THEN
    RETURN jsonb_build_object('processed',false,'reason','unsupported_plan');
  END IF;
  IF (v_order.plan_id = 'week' AND v_order.amount <> 39000) OR
     (v_order.plan_id = 'month' AND v_order.amount <> 59000) OR
     (v_order.plan_id = 'lifetime' AND v_order.amount <> 99000) THEN
    RETURN jsonb_build_object('processed',false,'reason','invalid_plan_price');
  END IF;

  v_days := CASE v_order.plan_id WHEN 'week' THEN 7 WHEN 'month' THEN 30 ELSE NULL END;

  -- Serialize entitlement changes for this user across concurrent orders.
  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(v_order.user_id::text, 0));
  SELECT * INTO v_existing FROM public.dynor_vip
  WHERE user_id = v_order.user_id FOR UPDATE;

  -- Existing lifetime entitlements remain lifetime after further purchases.
  IF FOUND AND v_existing.plan_id = 'lifetime' AND v_existing.vip_expires_at IS NULL THEN
    v_expiry := NULL;
  ELSIF v_order.plan_id = 'lifetime' THEN
    v_expiry := NULL;
  ELSE
    v_start := pg_catalog.greatest(pg_catalog.coalesce(v_existing.vip_expires_at, now()), now());
    v_expiry := v_start + pg_catalog.make_interval(days => v_days);
  END IF;

  UPDATE public.dynor_orders
  SET status = 'paid', paid_at = now(), sepay_transaction_id = p_transaction_id,
      duration_days = v_days
  WHERE id = v_order.id;

  INSERT INTO public.dynor_vip(user_id, vip_expires_at, plan_id, updated_at)
  VALUES(v_order.user_id, v_expiry,
         CASE WHEN v_expiry IS NULL THEN 'lifetime' ELSE v_order.plan_id END, now())
  ON CONFLICT (user_id) DO UPDATE
  SET vip_expires_at = EXCLUDED.vip_expires_at,
      plan_id = EXCLUDED.plan_id,
      updated_at = now();

  RETURN jsonb_build_object('processed',true,'order_id',v_order.id,'vip_expires_at',v_expiry);
EXCEPTION WHEN unique_violation THEN
  RETURN jsonb_build_object('processed',false,'reason','transaction_already_used');
END;
$$;
REVOKE ALL ON FUNCTION public.dynor_settle_payment(text,bigint,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.dynor_settle_payment(text,bigint,text) TO service_role;
