
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
const reply = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers });
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async req => {
  if (req.method !== 'POST') return reply({ error: 'Method not allowed' }, 405);
  const url = Deno.env.get('SUPABASE_URL');
  const anon = Deno.env.get('SUPABASE_ANON_KEY');
  const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anon || !service) return reply({ error: 'Server configuration missing' }, 500);

  const jwt = req.headers.get('Authorization')?.replace(/^Bearer\s+/i, '') ?? '';
  if (!jwt) return reply({ error: 'Login required' }, 401);
  const auth = createClient(url, anon, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: { user }, error: authError } = await auth.auth.getUser(jwt);
  if (authError || !user) return reply({ error: 'Invalid session' }, 401);

  let id: unknown;
  try { id = (await req.json()).id; } catch { return reply({ error: 'Invalid JSON' }, 400); }
  if (typeof id !== 'string' || !uuid.test(id)) return reply({ error: 'Invalid id' }, 400);

  const db = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: w, error } = await db.from('dynor_wallpapers')
    .select('file_path,file_name,access_tier,published').eq('id', id).maybeSingle();
  if (error) {
    console.error('Wallpaper lookup failed:', error.message);
    return reply({ error: 'Wallpaper lookup unavailable' }, 503);
  }
  if (!w || !w.published) return reply({ error: 'Not found' }, 404);

  const tier = w.access_tier;
  if (!['free', 'premium', 'crown'].includes(tier))
    return reply({ error: 'Invalid wallpaper access tier' }, 503);

  // Premium: kiểm tra VIP, không trừ lượt
  if (tier === 'premium') {
    const { data: vip, error: vipError } = await db.from('dynor_vip')
      .select('plan_id,vip_expires_at').eq('user_id', user.id).maybeSingle();
    if (vipError) {
      console.error('VIP lookup failed:', vipError.message);
      return reply({ error: 'VIP verification unavailable' }, 503);
    }
    const permanent = vip?.plan_id === 'lifetime' && vip.vip_expires_at === null;
    const active = typeof vip?.vip_expires_at === 'string' &&
      Number.isFinite(Date.parse(vip.vip_expires_at)) && Date.parse(vip.vip_expires_at) > Date.now();
    if (!permanent && !active) return reply({ error: 'VIP required', code: 'vip_required' }, 403);
  }

  // Weekly memberships never include Crown, even for previously downloaded items.
  if (tier === 'crown') {
    const { data: vip, error: vipError } = await db.from('dynor_vip')
      .select('plan_id,vip_expires_at').eq('user_id', user.id).maybeSingle();
    if (vipError) return reply({ error: 'VIP verification unavailable' }, 503);
    const permanent = vip?.plan_id === 'lifetime' && vip.vip_expires_at === null;
    const active = typeof vip?.vip_expires_at === 'string' &&
      Number.isFinite(Date.parse(vip.vip_expires_at)) && Date.parse(vip.vip_expires_at) > Date.now();
    if (!permanent && !active) return reply({ error: 'VIP required', code: 'vip_required' }, 403);
    if (!['month', 'quarter', 'lifetime'].includes(vip?.plan_id)) {
      return reply({ error: 'Monthly plan or above required for Crown', code: 'crown_plan_required' }, 403);
    }
  }

  // Tạo link tải có hiệu lực 60 giây
  const { data: signed, error: signError } = await db.storage.from('dynor-downloads')
    .createSignedUrl(w.file_path, 60, { download: w.file_name });
  if (signError || !signed?.signedUrl) return reply({ error: 'File unavailable' }, 503);

  // Crown: kiểm tra và trừ lượt tải
  if (tier === 'crown') {
    const { data: claim, error: claimError } = await db.rpc('dynor_claim_vip_download', {
      p_user_id: user.id, p_wallpaper_id: id
    });
    if (claimError) {
      console.error('Crown quota RPC failed:', claimError.message);
      return reply({ error: 'Crown quota verification failed' }, 503);
    }
    if (!claim || claim.allowed !== true) {
      const reason = claim?.reason ?? 'vip_required';
      return reply({
        error: reason === 'quota_exceeded' ? 'Crown download limit reached' :
          reason === 'vip_required' ? 'VIP required' :
          reason === 'crown_plan_required' ? 'Monthly plan or above required for Crown' : 'Download not allowed',
        code: reason,
        used: claim?.used ?? null,
        limit: claim?.limit ?? null
      }, reason === 'not_found' ? 404 : 403);
    }
  }

  return reply({ url: signed.signedUrl, expires_in: 60 });
});
