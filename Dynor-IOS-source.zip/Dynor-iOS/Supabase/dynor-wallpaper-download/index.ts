import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
const reply = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers });
Deno.serve(async req => {
  if (req.method !== 'POST') return reply({error:'Method not allowed'},405);
  const url = Deno.env.get('SUPABASE_URL');
  const anon = Deno.env.get('SUPABASE_ANON_KEY');
  const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anon || !service) return reply({error:'Server configuration missing'},500);
  const jwt = req.headers.get('Authorization')?.replace(/^Bearer\s+/i,'') ?? '';
  if (!jwt) return reply({error:'Login required'},401);
  const auth = createClient(url,anon,{global:{headers:{Authorization:`Bearer ${jwt}`}},auth:{persistSession:false}});
  const {data:{user},error:authError} = await auth.auth.getUser(jwt);
  if (authError || !user) return reply({error:'Invalid session'},401);
  let id: unknown;
  try { id = (await req.json()).id; } catch { return reply({error:'Invalid JSON'},400); }
  if (typeof id !== 'string' || !/^[a-f0-9-]{36}$/i.test(id)) return reply({error:'Invalid id'},400);
  const db = createClient(url,service,{auth:{persistSession:false}});
  const {data:w,error} = await db.from('dynor_wallpapers').select('file_path,file_name,is_vip,published').eq('id',id).maybeSingle();
  if (error || !w || !w.published) return reply({error:'Not found'},404);
  // Generate the URL before claiming quota so missing storage files do not consume a slot.
  const {data:s,error:signError} = await db.storage.from('dynor-downloads').createSignedUrl(w.file_path,60,{download:w.file_name});
  if (signError || !s?.signedUrl) return reply({error:'File unavailable'},503);
  if (w.is_vip) {
    const {data:claim,error:claimError} = await db.rpc('dynor_claim_vip_download',{
      p_user_id:user.id,p_wallpaper_id:id
    });
    if (claimError) return reply({error:'VIP quota verification failed'},503);
    if (!claim?.allowed) {
      const reason = claim?.reason ?? 'vip_required';
      return reply({error:reason,used:claim?.used,limit:claim?.limit},reason === 'quota_exceeded' ? 429 : 403);
    }
  }
  return reply({url:s.signedUrl,expires_in:60});
});
