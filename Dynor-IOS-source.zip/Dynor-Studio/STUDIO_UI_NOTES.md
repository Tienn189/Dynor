# Dynor Studio UI

Ngày bàn giao: 21/11/2026. Thiết kế lại từ `Dynor-IOS-source.zip`.

## Thiết kế

- Bảng màu giấy kem / xanh mực, điểm nhấn mint; có màu tương ứng cho dark mode.
- Tiêu đề serif, nhãn mục nhỏ, khoảng cách và bo góc thống nhất.
- Thay giao diện kính mờ ở các màn đang sử dụng bằng bề mặt phẳng, viền nhẹ.
- Thanh điều hướng riêng giữ bốn mục, trạng thái đang chọn và nhãn VoiceOver.
  Thanh ẩn khi mở bàn phím; cỡ chữ Accessibility chuyển thành hai hàng.
- Khám phá: nhận diện DYNOR mới, tìm kiếm, bộ lọc danh mục gạch chân,
  ảnh tiêu điểm, lưới thích ứng và màn chi tiết có nút tải cố định.
- Bộ sưu tập: thẻ nhập tệp nền mực, trạng thái trống, quản lý chọn nhiều,
  metadata gọn và trang xem trước đồng bộ.
- Đã cài: tóm tắt thiết bị/số lượng, làm mới, lưới ảnh và trạng thái trống.
- Cài đặt: tài khoản gọn, banner VIP, ô chọn sáng/tối/tự động,
  nhóm tùy chọn nâng cao có thể thu gọn.
- Đồng bộ màn tài khoản/VIP, bảng màu, PosterBoard và nhật ký hoạt động.

Không thêm package hoặc yêu cầu build mới. Giữ bundle ID, cấu hình ký,
App Group, tài nguyên ảnh và pipeline build hiện tại. Màu đã chọn được
lưu từ bản trước vẫn được dùng; mặc định của bản cài mới là mint/forest.

## Kiểm tra đã chạy

- Parse toàn bộ 32 tệp Swift bằng tree-sitter-swift: không lỗi cú pháp.
- Đối chiếu source gốc: toàn bộ `Dynor/Services` và `DynorTests` giữ nguyên.
- Model gallery và các hàm nghiệp vụ nhập, tải, đăng nhập, thanh toán,
  ghi/gỡ hình nền giữ nguyên; store chỉ đổi mặc định và sắc độ mint.
- `scripts/verify_dependencies.py`: sáu hash dependency hợp lệ.
- 18 kiểm thử Python hiện có về ký/kiểm tra IPA: đạt.
- Bộ kiểm thử Node cho encrypted packages: đạt.

Các kiểm tra này không thay thế biên dịch SwiftUI hoặc chạy app. Môi trường
Linux không có Swift/Xcode/iOS SDK; chưa build IPA, chưa chạy XCTest hoặc
kiểm tra hiển thị trên simulator/iPhone. Cần xác nhận bằng Xcode, đặc biệt
với thiết bị nhỏ, iPad, dark mode, bàn phím và cỡ chữ lớn.

## Build

Dùng Mac có full Xcode và XcodeGen theo `BUILD_IPA.md` / `GITHUB_ACTIONS.md`.
Lệnh build hiện có, chạy từ thư mục dự án:

```sh
bash scripts/build_ipa.sh
```
