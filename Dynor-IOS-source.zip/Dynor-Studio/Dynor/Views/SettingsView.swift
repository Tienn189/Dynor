import SwiftUI
import UIKit

struct SettingsView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var activeSheet: SettingsSheet?
    @State private var confirmReset = false
    @State private var resetting = false
    @State private var resetMessage: String?

    @StateObject private var account = DynorAccountService.shared
    private var appVersion: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
        return store.localized("Phiên bản \(version) (build \(build))", "Version \(version) (build \(build))", "版本 \(version)（构建 \(build)）")
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    DynorHero(index: "04 / YOUR SPACE", title: store.localized("Của riêng bạn", "Your space", "你的空间"), subtitle: store.localized("Một chút tinh chỉnh. Một chất riêng.", "Small details. Your own signature.", "细节之间，尽显个性。"), symbol: "slider.horizontal.3")
                    accountCard
                    vipCard
                    sectionLabel(store.localized("CÁ NHÂN HÓA", "MAKE IT YOURS", "个性化"))
                    appearanceCard
                    sectionLabel(store.localized("KHÔNG GIAN LÀM VIỆC", "YOUR WORKSPACE", "工作空间"))
                    activityCard
                    informationCard
                    DisclosureGroup {
                        VStack(spacing: 14) {
                            deviceCard
                            compatibilityCard
                            maintenanceCard
                        }.padding(.top, 16)
                    } label: {
                        Label(store.localized("Thiết bị & nâng cao", "Device & advanced", "设备与高级设置"), systemImage: "slider.horizontal.3")
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(DynorDesign.ink)
                            .padding(.vertical, 8)
                    }
                    .tint(DynorDesign.muted)
                    VStack(spacing: 6) {
                        Text("DYNOR / STUDIO").font(.system(size: 11, weight: .bold, design: .monospaced)).tracking(2)
                        Text(appVersion).font(.caption2)
                    }
                    .foregroundStyle(DynorDesign.muted)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 18)
                }
                .frame(maxWidth: 680)
                .padding(.horizontal, 24)
                .padding(.top, 16)
                .padding(.bottom, 24)
                .frame(maxWidth: .infinity)
            }
            .scrollIndicators(.hidden)
            .background(DynorDesign.canvas)
            .toolbar(.hidden, for: .navigationBar)
            .confirmationDialog("Đặt lại các hình nền Dynor đã ghi?", isPresented: $confirmReset) {
                Button("Xóa cấu hình Dynor", role: .destructive) { resetInstalled() }
            } message: { Text("Chỉ xóa các cấu hình Dynor đã ghi, không xóa hình nền hệ thống khác.") }
            .alert("Đặt lại bộ sưu tập", isPresented: Binding(get: { resetMessage != nil }, set: { if !$0 { resetMessage = nil } })) {
                Button("OK") { resetMessage = nil }
            } message: { Text(resetMessage ?? "") }
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .account: SettingsAccountSheet()
                case .vip: SettingsVIPSheet()
                case .contact: SettingsInformationSheet(title: "Thông tin liên hệ", symbol: "envelope", text: "Thông tin liên hệ của nhà phát triển chưa được cung cấp. Email, số điện thoại và liên kết hỗ trợ cần được cập nhật trước khi phát hành.")
                case .credits: SettingsCreditsSheet()
                case .colors: ThemeColorPickerView()
                case .privacy: SettingsInformationSheet(title: "Dữ liệu ở lại với bạn", symbol: "lock.shield", text: "Ảnh và tệp Tendies bạn nhập được sao chép vào vùng lưu trữ riêng của Dynor trên thiết bị. Tên hồ sơ trải nghiệm, ID, giao diện, yêu thích và tiến trình quảng cáo mô phỏng được lưu cục bộ.\n\nGói Tendies được kiểm tra và ghi trực tiếp vào container PosterBoard qua worse_query. Cơ chế này cần App Group được cấp quyền trong chữ ký IPA. Dynor đọc lại và đối chiếu dữ liệu đã ghi; bạn chọn hình nền trong bộ chọn của iOS.\n\nBản này chưa có tài khoản được xác thực hoặc đồng bộ đám mây. Gỡ ứng dụng có thể làm mất dữ liệu cục bộ. Ảnh đã lưu vào ứng dụng Ảnh được quản lý riêng bởi iOS.")
                }
            }
        }
    }


    private var deviceCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 13) {
                Label("Thông tin thiết bị", systemImage: "iphone.gen3").font(.headline)
                deviceRow("Thiết bị", UIDevice.current.model)
                deviceRow("Tên thiết bị", UIDevice.current.name)
                deviceRow("Hệ điều hành", "iOS " + UIDevice.current.systemVersion)
                deviceRow("Phiên bản Dynor", appVersion)
                deviceRow("Bundle ID", Bundle.main.bundleIdentifier ?? "—")
                deviceRow("App Group", PosterBoardAccess.prerequisiteWarning == nil ? "Có quyền truy cập" : "Chưa sẵn sàng")
            }
        }
    }
    private func deviceRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 8)
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
        }.font(.subheadline)
    }
    private var compatibilityCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("Phiên bản iOS hỗ trợ", systemImage: "checkmark.shield").font(.headline)
                Text("Phạm vi cơ chế worse_query được khai báo; không đồng nghĩa mọi bản đều đã kiểm thử.")
                    .font(.caption).foregroundStyle(.secondary)
                compatibilityRow("iOS 26.0 – 26.7.2", "Có thể thử", .green)
                compatibilityRow("iOS 27.0 – 27.2.0", "Có thể thử", .green)
                compatibilityRow("Các phiên bản khác", "Chưa hỗ trợ", .orange)
                Divider()
                Label(TendiesCompatibility.current.canAttemptInstall ? "Phiên bản iOS hiện tại nằm trong phạm vi thử nghiệm" : "Phiên bản iOS hiện tại nằm ngoài phạm vi", systemImage: "info.circle")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }
    private func compatibilityRow(_ version: String, _ status: String, _ color: Color) -> some View {
        HStack { Text(version); Spacer(); Text(status).font(.caption.weight(.semibold)).foregroundStyle(color) }.font(.subheadline)
    }
    private var activityCard: some View {
        SettingsGlassCard {
            NavigationLink {
                ActivityHistoryView()
            } label: {
                HStack {
                    settingsIcon("clock.arrow.circlepath")
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Nhật ký hoạt động").font(.subheadline.weight(.medium))
                        Text("Lịch sử nhập và cài hình nền").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.system(size: 11, weight: .semibold)).foregroundStyle(DynorDesign.muted)
                }
            }.buttonStyle(.plain)
        }
    }

    private func sectionLabel(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 10, weight: .bold, design: .monospaced))
            .tracking(2)
            .foregroundStyle(DynorDesign.muted)
            .padding(.top, 4)
            .padding(.bottom, -12)
    }

    private var accountCard: some View {
        Button { activeSheet = .account } label: {
            HStack(spacing: 16) {
                SettingsAvatar()
                VStack(alignment: .leading, spacing: 5) {
                    Text(account.email ?? store.profile?.name ?? store.localized("Chào bạn.", "Hello, you.", "你好。"))
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(DynorDesign.ink)
                        .lineLimit(1)
                    Text(account.email == nil
                         ? store.localized("Đăng nhập để lưu cảm hứng", "Sign in to save your inspiration", "登录以保存灵感")
                         : (account.isVIP ? "Dynor VIP" : store.localized("Quản lý tài khoản", "Manage account", "管理账户")))
                        .font(.caption).foregroundStyle(DynorDesign.muted)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.up.right")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(DynorDesign.ink)
            }
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(DynorDesign.outline, lineWidth: 1))
            .contentShape(RoundedRectangle(cornerRadius: 24))
        }
        .buttonStyle(DynorPressStyle())
    }

    private var appearanceCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 12) {
                    settingsIcon("circle.lefthalf.filled")
                    VStack(alignment: .leading, spacing: 3) {
                        Text(store.localized("Diện mạo", "Appearance", "外观")).font(.subheadline.weight(.semibold))
                        Text(store.localized("Đổi theo nhịp ngày của bạn", "Set the mood for your day", "随心切换每日心情"))
                            .font(.caption).foregroundStyle(DynorDesign.muted)
                    }
                }
                HStack(spacing: 8) {
                    themeOption(.light, title: store.localized("Sáng", "Light", "浅色"), symbol: "sun.max")
                    themeOption(.dark, title: store.localized("Tối", "Dark", "深色"), symbol: "moon")
                    themeOption(.system, title: store.localized("Tự động", "Auto", "自动"), symbol: "circle.lefthalf.filled")
                }
                Divider().overlay(DynorDesign.outline)
                Button { activeSheet = .colors } label: {
                    HStack(spacing: 12) {
                        Circle().fill(store.accentColor).frame(width: 25, height: 25)
                            .overlay(Circle().strokeBorder(DynorDesign.outline, lineWidth: 1))
                        Text(store.localized("Màu nhấn", "Accent color", "强调色")).font(.subheadline.weight(.medium))
                        Spacer()
                        Image(systemName: "chevron.right").font(.system(size: 11, weight: .semibold)).foregroundStyle(DynorDesign.muted)
                    }
                    .frame(minHeight: 32)
                    .foregroundStyle(DynorDesign.ink)
                    .contentShape(Rectangle())
                }.buttonStyle(.plain)
            }
        }
    }

    private func themeOption(_ mode: ThemeMode, title: String, symbol: String) -> some View {
        let selected = store.theme == mode
        return Button { store.theme = mode } label: {
            VStack(spacing: 8) {
                Image(systemName: symbol).font(.system(size: 20, weight: .light))
                Text(title).font(.caption.weight(.medium))
            }
            .foregroundStyle(selected ? DynorDesign.ink : DynorDesign.muted)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(selected ? DynorDesign.mist : DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(selected ? store.accentColor : Color.clear, lineWidth: 1.5))
            .contentShape(RoundedRectangle(cornerRadius: 16))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }

    private func settingsIcon(_ symbol: String) -> some View {
        Image(systemName: symbol)
            .font(.system(size: 17, weight: .regular))
            .foregroundStyle(DynorDesign.ink)
            .frame(width: 38, height: 38)
            .background(DynorDesign.mist, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private var vipCard: some View {
        Button { activeSheet = .vip } label: {
            HStack(alignment: .center, spacing: 18) {
                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 6) {
                        Image(systemName: "sparkle")
                        Text("DYNOR VIP").tracking(2)
                    }
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(Color(red: 0.69, green: 0.89, blue: 0.78))
                    Text(store.localized("Thêm một chút\ncảm hứng.", "A little more\ninspiration.", "更多灵感。"))
                        .font(.system(size: 27, weight: .medium, design: .serif))
                        .foregroundStyle(.white)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(store.localized("Khám phá VIP · Từ 39.000đ / tuần", "Explore VIP · From 39,000₫ / week", "探索 VIP · 每周 39,000₫ 起"))
                        .font(.caption).foregroundStyle(.white.opacity(0.68))
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.up.right")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundStyle(Color(red: 0.69, green: 0.89, blue: 0.78))
                    .frame(width: 44, height: 44)
                    .background(.white.opacity(0.08), in: Circle())
            }
            .padding(24)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.deepInk, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 24))
        }
        .buttonStyle(DynorPressStyle())
        .accessibilityLabel(store.localized("Khám phá các gói Dynor VIP", "Explore Dynor VIP plans", "探索 Dynor VIP 计划"))
    }

    private var maintenanceCard: some View {
        SettingsGlassCard {
            Button(role: .destructive) { confirmReset = true } label: {
                HStack {
                    Label("Đặt lại bộ sưu tập đã cài", systemImage: "arrow.counterclockwise")
                    Spacer()
                    if resetting { ProgressView() }
                }.font(.subheadline.weight(.semibold))
            }.disabled(resetting)
            Text("Chỉ gỡ cấu hình PosterBoard do Dynor ghi; không xóa gói trong Bộ sưu tập hoặc hình nền hệ thống khác.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
    private func resetInstalled() {
        resetting = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: PosterBoardDescriptorWriter.installedPaths()) }
            await MainActor.run {
                resetting = false
                switch result {
                case .success(let count): resetMessage = "Đã xóa \(count) cấu hình Dynor."
                case .failure(let error): resetMessage = error.localizedDescription
                }
            }
        }
    }
    private var informationCard: some View {
        SettingsGlassCard {
            VStack(alignment: .leading, spacing: 3) {
                SettingsLinkRow(title: "Thông tin liên hệ", symbol: "envelope") { activeSheet = .contact }
                Divider()
                SettingsLinkRow(title: "Về Dynor & ghi công", symbol: "sparkles") { activeSheet = .credits }
                Divider()
                SettingsLinkRow(title: "Dữ liệu của bạn", symbol: "lock.shield") { activeSheet = .privacy }
            }
        }
    }
}

private enum SettingsSheet: String, Identifiable {
    case account, vip, contact, credits, privacy, colors
    var id: String { rawValue }
}

private struct SettingsHeader: View {
    let eyebrow: String
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(eyebrow).font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(2).foregroundStyle(DynorDesign.muted)
            Text(title).font(.system(size: 36, weight: .medium, design: .serif)).foregroundStyle(DynorDesign.ink)
            Text(subtitle).font(.subheadline).foregroundStyle(DynorDesign.muted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 10)
    }
}

private struct SettingsGlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(DynorDesign.outline, lineWidth: 1))
    }
}

private struct SettingsAvatar: View {
    var body: some View {
        Text("d.")
            .font(.system(size: 33, weight: .medium, design: .serif))
            .foregroundStyle(DynorDesign.ink)
            .frame(width: 54, height: 54)
            .background(DynorDesign.mist, in: Circle())
            .accessibilityHidden(true)
    }
}

private struct SettingsLinkRow: View {
    let title: String
    let symbol: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 16, weight: .regular))
                    .foregroundStyle(DynorDesign.ink)
                    .frame(width: 34, height: 34)
                    .background(DynorDesign.canvas, in: RoundedRectangle(cornerRadius: 10))
                Text(title)
                Spacer()
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
            }
            .font(.subheadline)
            .foregroundStyle(.primary)
            .padding(.vertical, 6)
            .frame(minHeight: 44)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

private struct SettingsAccountSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var inputEmail = ""
    @State private var otp = ""
    @State private var awaitingOTP = false
    @State private var working = false
    @State private var errorText: String?

    private var validEmail: Bool {
        let value = inputEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.contains("@") && value.split(separator: "@").last?.contains(".") == true
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 14) {
                        Text("D")
                            .font(.system(size: 26, weight: .bold))
                            .foregroundStyle(store.accentTextColor)
                            .frame(width: 52, height: 52)
                            .background(store.accentColor, in: RoundedRectangle(cornerRadius: 16))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Dynor").font(.title3.bold())
                            Text("Không gian của riêng bạn")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.bottom, 32)

                    VStack(alignment: .leading, spacing: 23) {
                        HStack {
                            Image(systemName: "crown.fill").font(.title2)
                            Spacer()
                            Image(systemName: "sparkle").foregroundStyle(.secondary)
                        }
                        Text(account.email == nil ? "Chào mừng trở lại." : "Tài khoản của bạn.")
                            .font(.system(size: 34, weight: .medium, design: .serif))
                            .minimumScaleFactor(0.8)
                            .lineLimit(2)
                        Text(account.email == nil
                             ? "Đăng nhập bằng email để khám phá trải nghiệm Dynor của bạn."
                             : "Tài khoản Dynor của bạn đã được xác minh.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)

                        if let email = account.email {
                            VStack(alignment: .leading, spacing: 13) {
                                Text("EMAIL ĐANG ĐĂNG NHẬP")
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text(email).font(.headline).textSelection(.enabled)
                                Label(account.isVIP ? "Dynor VIP đang hoạt động" : "Tài khoản thường",
                                      systemImage: account.isVIP ? "crown.fill" : "person.crop.circle")
                                if let date = account.vipExpiresAt, account.isVIP {
                                    Text("VIP đến: \(date.formatted(date: .abbreviated, time: .shortened))")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                }
                                Button("Kiểm tra lại trạng thái VIP") {
                                    Task { await account.refreshVIP() }
                                }
                                .foregroundStyle(.primary)
                                Button("Đăng xuất", role: .destructive) {
                                    account.signOut(); awaitingOTP = false; otp = ""
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                        } else {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Địa chỉ email").font(.subheadline.weight(.semibold))
                                TextField(text: $inputEmail, prompt: Text("tenban@gmail.com").foregroundColor(Color(uiColor: .lightGray))) { EmptyView() }
                                    .textContentType(.emailAddress)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                    .padding(16)
                                    .background(DynorDesign.canvas,
                                                in: RoundedRectangle(cornerRadius: 15))
                                    
                                    .disabled(awaitingOTP)
                                if awaitingOTP {
                                    Text("Mã xác minh gồm 6 chữ số")
                                        .font(.subheadline.weight(.semibold))
                                    TextField(text: $otp, prompt: Text("Nhập mã OTP").foregroundColor(.gray)) { EmptyView() }
                                        .keyboardType(.numberPad)
                                        .textContentType(.oneTimeCode)
                                        .padding(16)
                                        .background(DynorDesign.canvas,
                                                    in: RoundedRectangle(cornerRadius: 15))
                                        
                                    Button {
                                        Task {
                                            await perform {
                                                try await account.verifyOTP(email: inputEmail, code: otp)
                                            }
                                            if account.email != nil { awaitingOTP = false }
                                        }
                                    } label: {
                                        primaryButton("Xác minh & đăng nhập")
                                    }
                                    .disabled(working || otp.count != 6)
                                    Button("Gửi lại mã") {
                                        Task { await perform { try await account.sendOTP(to: inputEmail) } }
                                    }.disabled(working)
                                    Button("Đổi email") { awaitingOTP = false; otp = "" }
                                } else {
                                    Button {
                                        Task {
                                            await perform { try await account.sendOTP(to: inputEmail) }
                                            if errorText == nil { awaitingOTP = true }
                                        }
                                    } label: {
                                        primaryButton("Nhận mã xác minh")
                                    }
                                    .disabled(working || !validEmail)
                                }
                            }
                        }
                        if working { ProgressView() }
                        if let errorText {
                            Text(errorText).font(.footnote).foregroundStyle(.red)
                        }
                        if !account.statusMessage.isEmpty {
                            Text(account.statusMessage)
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                        if account.email == nil {
                            Text("Mã OTP gồm 6 chữ số sẽ được gửi tới email của bạn.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .padding(22)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(DynorDesign.surface,
                                in: RoundedRectangle(cornerRadius: 26))
                    
                    .padding(.bottom, 24)

                    Text("DYNOR / YOUR SPACE\nTài khoản được bảo vệ bằng mã xác minh email")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                }
                .frame(maxWidth: 620)
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .frame(maxWidth: .infinity)
                .padding(.bottom, 40)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Tài khoản")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }

    private func primaryButton(_ title: String) -> some View {
        HStack {
            Spacer()
            Text(title).font(.headline)
            Image(systemName: "arrow.right")
            Spacer()
        }
        .foregroundStyle(store.accentTextColor)
        .padding(.vertical, 17)
        .background(store.accentColor, in: RoundedRectangle(cornerRadius: 17))
    }

    private func perform(_ operation: @escaping () async throws -> Void) async {
        working = true; errorText = nil
        defer { working = false }
        do { try await operation() }
        catch { errorText = error.localizedDescription }
    }
}

private struct SettingsVIPSheet: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var account = DynorAccountService.shared
    @State private var selected = SettingsVIPPlan.month
    @State private var order: DynorPaymentOrder?
    @State private var paymentError: String?
    @State private var busy = false
    @State private var checking = false
    @State private var paidNotice = false
    @State private var completedCode: String?
    @State private var pollingTask: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Image(systemName: "crown.fill")
                        .font(.system(size: 30, weight: .light))
                        .foregroundStyle(DynorDesign.ink)
                    SettingsHeader(eyebrow: "DYNOR VIP", title: store.localized("Không giới hạn.", "Unlimited.", "无限制。"), subtitle: store.localized("Mọi hình nền, không cần xem quảng cáo khi VIP còn hạn.", "All wallpapers, without ads while VIP is active.", "VIP 有效期间畅享所有壁纸，无需观看广告。"))
                    ForEach(SettingsVIPPlan.allCases) { plan in
                        Button {
                            stopPolling()
                            selected = plan
                            order = nil
                            paymentError = nil
                            paidNotice = false
                        } label: {
                            HStack(spacing: 14) {
                                Image(systemName: selected == plan ? "checkmark.circle.fill" : "circle")
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(store.localized(plan.title, plan.englishTitle, plan.chineseTitle)).font(.headline)
                                    Text(store.localized(plan.duration, plan.englishDuration, plan.chineseDuration)).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(plan.price).font(.headline)
                            }
                            .padding(18)
                            .background(selected == plan ? DynorDesign.mist : DynorDesign.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(selected == plan ? store.accentColor : Color.clear, lineWidth: 1.5))
                        }.buttonStyle(.plain)
                    }
                    if account.isVIP {
                        Label("VIP đang hoạt động", systemImage: "checkmark.seal.fill")
                        if let date = account.vipExpiresAt {
                            Text("Hạn: \(date.formatted(date: .numeric, time: .shortened))")
                        } else {
                            Text("Gói VIP vĩnh viễn")
                        }
                    }
                    if paidNotice {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Label("Thanh toán thành công!", systemImage: "checkmark.seal.fill")
                                    .font(.headline)
                                    .foregroundStyle(.green)
                                Text("Gói VIP đã được cập nhật. Mã QR cũ đã được ẩn để tránh chuyển khoản trùng.")
                                    .font(.subheadline)
                                if let date = account.vipExpiresAt {
                                    Text("Hạn VIP mới: \(date.formatted(date: .numeric, time: .shortened))")
                                        .font(.subheadline.weight(.semibold))
                                }
                                Button("Mua thêm gói VIP") {
                                    paidNotice = false
                                    completedCode = nil
                                }
                                .font(.subheadline.weight(.semibold))
                            }
                        }
                    }
                    if let order, !paidNotice {
                        SettingsGlassCard {
                            VStack(alignment: .leading, spacing: 14) {
                                Text("Chuyển khoản để kích hoạt VIP").font(.headline)
                                if let url = order.qrURL {
                                    AsyncImage(url: url) { image in
                                        image.resizable().scaledToFit()
                                    } placeholder: {
                                        ProgressView().frame(height: 240)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 260)
                                    .accessibilityLabel("QR thanh toán ngân hàng")
                                }
                                Text("Ngân hàng: \(order.bankName)")
                                Text("Số tài khoản: \(order.bankAccount)").textSelection(.enabled)
                                Text("Số tiền: \(order.amount.formatted())đ").font(.headline)
                                Text("Nội dung chuyển khoản:").font(.caption).foregroundStyle(.secondary)
                                Text(order.paymentCode)
                                    .font(.system(.body, design: .monospaced).weight(.semibold))
                                    .textSelection(.enabled)
                                ShareLink("Chia sẻ mã thanh toán", item: order.paymentCode)
                                HStack(spacing: 8) {
                                    ProgressView().controlSize(.small)
                                    Text("Đang tự động kiểm tra thanh toán...")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Text("Chỉ chuyển khoản đúng số tiền và nội dung trên. Sau khi ngân hàng ghi nhận, mã QR sẽ tự ẩn.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if let paymentError {
                        Text(paymentError).font(.caption).foregroundStyle(.red)
                    }
                    if order == nil && !paidNotice {
                        Button { Task { await createOrder() } } label: {
                            HStack {
                                Spacer()
                                if busy { ProgressView().tint(.white) }
                                Text("Tạo đơn trong Dynor").font(.headline)
                                Spacer()
                            }
                            .padding(.vertical, 17)
                            .foregroundStyle(store.accentTextColor)
                            .background(store.accentColor, in: RoundedRectangle(cornerRadius: 18))
                        }
                        .disabled(busy || account.email == nil)
                    }
                    if account.email == nil {
                        Text("Đăng nhập tài khoản Dynor trước khi tạo đơn.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Button {
                        Task {
                            if let code = order?.paymentCode {
                                await checkPayment(code: code, showError: true)
                            } else {
                                await account.refreshVIP()
                            }
                        }
                    } label: {
                        HStack {
                            if checking { ProgressView().controlSize(.small) }
                            Text("Kiểm tra lại VIP")
                        }
                    }
                    .disabled(checking)
                    .foregroundStyle(.primary)
                }
                .frame(maxWidth: 620)
                .padding(24)
                .frame(maxWidth: .infinity)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Dynor VIP")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
        .tint(store.accentColor)
        .onDisappear { stopPolling() }
    }

    private func stopPolling() {
        pollingTask?.cancel()
        pollingTask = nil
    }

    private func startPolling(code: String) {
        stopPolling()
        pollingTask = Task {
            while !Task.isCancelled {
                await checkPayment(code: code, showError: false)
                if Task.isCancelled || completedCode == code || order?.paymentCode != code {
                    break
                }
                try? await Task.sleep(for: .seconds(5))
            }
        }
    }

    private func checkPayment(code: String, showError: Bool) async {
        guard order?.paymentCode == code, completedCode != code, !checking else { return }
        checking = true
        defer { checking = false }
        do {
            let status = try await account.paymentStatus(for: code)
            guard !Task.isCancelled, order?.paymentCode == code else { return }
            if status == "paid" {
                completedCode = code
                order = nil
                paidNotice = true
                paymentError = nil
                stopPolling()
                await account.refreshVIP()
            } else if status == "expired" {
                order = nil
                stopPolling()
                paymentError = "Đơn hàng đã hết hạn. Hãy tạo đơn mới."
            } else if showError {
                paymentError = "Máy chủ chưa xác nhận thanh toán. Vui lòng đợi ngân hàng và SePay xử lý."
            }
        } catch {
            if showError { paymentError = error.localizedDescription }
        }
    }

    private func createOrder() async {
        busy = true
        paymentError = nil
        paidNotice = false
        stopPolling()
        defer { busy = false }
        do {
            let newOrder = try await account.createVIPOrder(plan: selected.rawValue)
            order = newOrder
            completedCode = nil
            startPolling(code: newOrder.paymentCode)
        } catch {
            order = nil
            paymentError = error.localizedDescription
        }
    }
}

private enum SettingsVIPPlan: String, CaseIterable, Identifiable {
    case week, month, lifetime
    var id: String { rawValue }
    var title: String { switch self { case .week: return "Thẻ tuần"; case .month: return "Thẻ tháng"; case .lifetime: return "Vĩnh viễn" } }
    var englishTitle: String { switch self { case .week: return "Weekly"; case .month: return "Monthly"; case .lifetime: return "Lifetime" } }
    var chineseTitle: String { switch self { case .week: return "周卡"; case .month: return "月卡"; case .lifetime: return "永久" } }
    var englishDuration: String { switch self { case .week: return "7 days of inspiration"; case .month: return "30 days of discovery"; case .lifetime: return "One purchase, forever" } }
    var chineseDuration: String { switch self { case .week: return "7 天灵感"; case .month: return "30 天探索"; case .lifetime: return "一次购买，永久使用" } }
    var price: String { switch self { case .week: return "39.000đ"; case .month: return "59.000đ"; case .lifetime: return "99.000đ" } }
    var duration: String { switch self { case .week: return "7 ngày cảm hứng"; case .month: return "30 ngày khám phá"; case .lifetime: return "Một lần chọn, mãi mãi" } }
}

private struct SettingsInformationSheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let symbol: String
    let text: String
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    Image(systemName: symbol).font(.system(size: 36)).foregroundStyle(.secondary)
                    Text(title).font(.system(size: 32, weight: .medium, design: .serif))
                    Text(text).font(.body).foregroundStyle(.secondary).lineSpacing(5)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(DynorDesign.canvas)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

private struct SettingsCreditsSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    SettingsAvatar()
                    Text("Dynor").font(.system(size: 40, weight: .medium, design: .serif))
                    Text("Một màn hình. Một thế giới mới.").font(.title3)
                    Text("Ứng dụng iOS viết bằng SwiftUI theo yêu cầu của bạn. Icon sử dụng ảnh bạn cung cấp. Hình nền trưng bày: Unsplash.")
                        .foregroundStyle(.secondary)
                    Divider()
                    Text("Ghi công công nghệ").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    Text("worse_query").font(.title.weight(.bold))
                    Text("Phát triển bởi forcequitOS. Cơ chế truy cập container được sử dụng trong tính năng cài hình nền PosterBoard của Dynor.")
                        .font(.subheadline).foregroundStyle(.secondary)
                    Link("Mã nguồn worse_query", destination: URL(string: "https://github.com/forcequitOS/worse_query")!)
                    Text("Dynor cũng ghi nhận các thành phần bên thứ ba khác theo giấy phép và thông báo trong thư mục ThirdParty của source.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(25)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Về Dynor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

