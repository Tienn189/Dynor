import SwiftUI
import UIKit
import UniformTypeIdentifiers

@MainActor
struct LibraryView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var importing = false
    @State private var pickerIsVisible = false
    @State private var readingFiles = false
    @State private var importResultMessage: String?
    @State private var selecting = false
    @State private var selected = Set<UUID>()
    @State private var confirmDelete = false
    @State private var preview: ImportedWallpaper?
    @State private var showInstaller = false
    @State private var category = "Tendies"
    private let columns = [GridItem(.adaptive(minimum: 128, maximum: 250), spacing: 14)]
    private var visible: [ImportedWallpaper] {
        store.library.filter { $0.kind.isTendies }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                DynorHero(index: "02 / COLLECTION", title: store.localized("Bộ sưu tập", "Collection", "收藏"), subtitle: store.localized("Những tác phẩm mang dấu ấn của bạn.", "A space for your personal favorites.", "属于你的个性作品空间。"), symbol: "square.stack.3d.up")
                importCard
                collectionHeader
                if visible.isEmpty {
                    emptyCollection
                } else {
                    LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                        ForEach(visible) { item in collectionItem(item) }
                    }
                }
                if selecting {
                    HStack {
                        Text(store.localized("Đã chọn \(selected.count) / \(visible.count)", "Selected \(selected.count) of \(visible.count)", "已选择 \(selected.count) / \(visible.count)"))
                            .font(.footnote).foregroundStyle(DynorDesign.muted)
                        Spacer()
                        if !selected.isEmpty {
                            Button(role: .destructive) { confirmDelete = true } label: {
                                Label(store.localized("Xóa", "Delete", "删除"), systemImage: "trash")
                                    .font(.subheadline.weight(.semibold)).padding(12)
                            }.disabled(store.isInstallingWallpaper)
                        }
                    }
                    .padding(.horizontal, 14)
                    .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
                }
            }
            .frame(maxWidth: 920)
            .padding(.horizontal, 24)
            .padding(.top, 12)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .sheet(isPresented: $showInstaller) {
            NavigationStack {
                PosterBoardView()
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("Đóng") { showInstaller = false }
                        }
                    }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(action: showImportPicker) {
            if readingFiles { ProgressView() } else { Image(systemName: "plus") }
        }.disabled(readingFiles || store.isImporting || store.isInstallingWallpaper)
            .accessibilityLabel("Nhập Tendies") } }
        .sheet(isPresented: $importing, onDismiss: {
            pickerIsVisible = false
            presentImportResult()
        }) {
            WallpaperDocumentPicker(onPick: { urls in
                // Retain and process the selection immediately. Import must not
                // depend on the order of UIKit and SwiftUI dismissal callbacks.
                importing = false
                importPickedDocuments(urls)
            }, onCancel: {
                importing = false
            })
        }
        .overlay {
            if readingFiles {
                ProgressView("Đang nhập tệp…")
                    .padding(24).background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
            }
        }
        .confirmationDialog("Xóa \(selected.count) tệp khỏi Dynor?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Xóa \(selected.count) tệp", role: .destructive) {
                store.removeImported(ids: selected); selected.removeAll(); selecting = false
            }
            Button("Giữ lại", role: .cancel) {}
        } message: { Text("Tệp gốc bên ngoài Dynor vẫn được giữ lại.") }
        .sheet(item: $preview) { LibraryPreview(item: $0).environmentObject(store) }
        .onAppear { presentRequestedWallpaper() }
        .onChange(of: store.pendingLibraryPreview) { _, _ in presentRequestedWallpaper() }
    }

    private var importCard: some View {
        Button(action: showImportPicker) {
            HStack(spacing: 16) {
                Image(systemName: "plus")
                    .font(.system(size: 23, weight: .medium))
                    .foregroundStyle(DynorDesign.accent)
                    .frame(width: 48, height: 48)
                    .background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 15))
                VStack(alignment: .leading, spacing: 5) {
                    Text(store.localized("Thêm tác phẩm", "Add to your collection", "添加新作品"))
                        .font(.headline)
                    Text(store.localized("Nhập gói .tendies hoặc .dynor", "Import a .tendies or .dynor package", "导入 .tendies 或 .dynor 壁纸包"))
                        .font(.caption).foregroundStyle(.white.opacity(0.65))
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                if readingFiles || store.isImporting {
                    ProgressView().tint(.white)
                } else {
                    Image(systemName: "arrow.up.right").font(.system(size: 17, weight: .medium))
                }
            }
            .foregroundStyle(.white)
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.deepInk, in: RoundedRectangle(cornerRadius: 24))
            .contentShape(RoundedRectangle(cornerRadius: 24))
        }
        .buttonStyle(DynorPressStyle(scale: 0.98))
        .disabled(readingFiles || store.isImporting || store.isInstallingWallpaper)
    }

    private var collectionHeader: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 4) {
                Text(store.localized("Tác phẩm của bạn", "Your collection", "你的收藏"))
                    .font(.system(.title3, design: .serif, weight: .semibold))
                Text(store.localized("\(visible.count) gói hình nền", "\(visible.count) wallpaper packages", "\(visible.count) 个壁纸包"))
                    .font(.caption).foregroundStyle(DynorDesign.muted)
            }
            Spacer()
            Menu {
                Button {
                    selecting.toggle()
                    selected.removeAll()
                } label: {
                    Label(selecting ? store.localized("Xong", "Done", "完成") : store.localized("Chọn nhiều", "Select multiple", "多选"), systemImage: selecting ? "checkmark" : "checklist")
                }
                if selecting && !visible.isEmpty {
                    Button {
                        let ids = Set(visible.map(\.id))
                        if selected.isSuperset(of: ids) { selected.subtract(ids) }
                        else { selected.formUnion(ids) }
                    } label: {
                        Label(selected.count == visible.count ? store.localized("Bỏ chọn tất cả", "Deselect all", "取消全选") : store.localized("Chọn tất cả", "Select all", "全选"), systemImage: "checkmark.circle")
                    }
                }
            } label: {
                HStack(spacing: 7) {
                    Text(selecting ? store.localized("Đang chọn", "Selecting", "选择中") : store.localized("Quản lý", "Manage", "管理"))
                    Image(systemName: "ellipsis")
                }
                .font(.caption.weight(.semibold))
                .foregroundStyle(DynorDesign.ink)
                .padding(.horizontal, 14).frame(height: 44)
                .background(DynorDesign.surface, in: Capsule())
            }
            .disabled(visible.isEmpty || store.isInstallingWallpaper)
            .accessibilityLabel(store.localized("Tùy chọn chọn hình nền", "Wallpaper selection options", "壁纸选择选项"))
        }
    }

    private var emptyCollection: some View {
        VStack(spacing: 22) {
            ZStack {
                RoundedRectangle(cornerRadius: 16).fill(DynorDesign.mist)
                    .frame(width: 72, height: 100).rotationEffect(.degrees(-12)).offset(x: -22, y: 5)
                RoundedRectangle(cornerRadius: 16).fill(DynorDesign.surface)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(DynorDesign.outline, lineWidth: 1))
                    .frame(width: 72, height: 100).rotationEffect(.degrees(10)).offset(x: 22)
                Image(systemName: "sparkle").font(.system(size: 28, weight: .light)).foregroundStyle(DynorDesign.ink)
            }
            .frame(height: 120).accessibilityHidden(true)
            VStack(spacing: 8) {
                Text(store.localized("Một bộ sưu tập rất riêng", "Make it your own", "打造专属收藏"))
                    .font(.system(.title2, design: .serif, weight: .medium))
                Text(store.localized("Thêm gói hình nền đầu tiên, hoặc tìm cảm hứng mới trong Khám phá.", "Import your first wallpaper package, or find inspiration in Explore.", "导入第一个壁纸包，或在探索页面寻找灵感。"))
                    .font(.subheadline).foregroundStyle(DynorDesign.muted)
                    .multilineTextAlignment(.center).fixedSize(horizontal: false, vertical: true)
            }
            Button {
                store.selectedTab = .discover
            } label: {
                HStack(spacing: 8) {
                    Text(store.localized("Đến Khám phá", "Explore wallpapers", "探索壁纸"))
                    Image(systemName: "arrow.right")
                }
                .font(.subheadline.weight(.semibold)).foregroundStyle(DynorDesign.ink)
                .padding(.horizontal, 20).frame(minHeight: 46)
                .background(DynorDesign.mist, in: Capsule())
            }.buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity).padding(.horizontal, 20).padding(.vertical, 30)
    }

    private func collectionItem(_ item: ImportedWallpaper) -> some View {
        Button {
            if selecting {
                if selected.contains(item.id) { selected.remove(item.id) }
                else { selected.insert(item.id) }
            } else { preview = item }
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                LibraryArtwork(item: item)
                    .aspectRatio(0.72, contentMode: .fit)
                    .clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                    .overlay(alignment: .topTrailing) {
                        if selecting {
                            Image(systemName: selected.contains(item.id) ? "checkmark.circle.fill" : "circle")
                                .font(.system(size: 26, weight: .semibold))
                                .foregroundStyle(selected.contains(item.id) ? store.accentColor : .white)
                                .padding(10)
                                .background(.black.opacity(0.12), in: Circle()).padding(6)
                        }
                    }
                Text(item.displayName).font(.subheadline.weight(.semibold)).foregroundStyle(DynorDesign.ink).lineLimit(1)
                HStack(spacing: 6) {
                    Text((item.storedFilename as NSString).pathExtension.uppercased())
                        .font(.system(size: 9, weight: .semibold, design: .monospaced)).tracking(0.7)
                    Circle().frame(width: 2, height: 2)
                    Text(ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                        .font(.caption2)
                }.foregroundStyle(DynorDesign.muted)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(DynorPressStyle(scale: 0.98))
        .disabled(store.isInstallingWallpaper)
        .accessibilityLabel(item.displayName)
        .accessibilityValue(selecting ? (selected.contains(item.id) ? store.localized("Đã chọn", "Selected", "已选择") : store.localized("Chưa chọn", "Not selected", "未选择")) : "")
    }

    private func showImportPicker() {
        guard !readingFiles, !store.isImporting, !store.isInstallingWallpaper else { return }
        pickerIsVisible = true
        importing = true
    }

    private func importPickedDocuments(_ urls: [URL]) {
        guard !urls.isEmpty, !readingFiles else { return }
        readingFiles = true
        Task { @MainActor in
            defer {
                readingFiles = false
                presentImportResult()
            }
            let imported = await store.importWallpapers(urls: urls)
            ActivityJournal.shared.add(imported.isEmpty ? "Nhập tệp thất bại" : "Đã nhập tệp", detail: imported.isEmpty ? "Không có tệp hợp lệ" : imported.map(\.displayName).joined(separator: ", "), success: !imported.isEmpty)
            let message = store.message
            store.message = nil
            if urls.count == 1, let item = imported.first {
                store.openInLibrary(item)
            } else {
                importResultMessage = message ?? "Chưa nhập được tệp đã chọn. Hãy thử lại."
            }
        }
    }

    private func presentImportResult() {
        guard !pickerIsVisible, !importing, !readingFiles else { return }
        if let message = importResultMessage {
            importResultMessage = nil
            store.message = message
        }
        presentRequestedWallpaper()
    }

    private func presentRequestedWallpaper() {
        guard !pickerIsVisible, !importing, !readingFiles,
              store.selectedTab == .library, let id = store.pendingLibraryPreview,
              let item = store.library.first(where: { $0.id == id }) else { return }
        category = item.kind.isTendies ? "Tendies" : "Ảnh"
        selecting = false
        selected.removeAll()
        preview = item
        store.pendingLibraryPreview = nil
    }
}

private struct LibraryArtwork: View {
    @EnvironmentObject private var store: DynorStore
    let item: ImportedWallpaper
    var body: some View {
        GeometryReader { geometry in
            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                Image(uiImage: image).resizable().scaledToFill().frame(width: geometry.size.width, height: geometry.size.height)
            } else if item.kind == .tendies {
                TendiesArtworkPreview(archiveURL: store.fileURL(for: item))
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .clipped()
            } else {
                ZStack {
                    LinearGradient(colors: [.init(red: 0.12, green: 0.24, blue: 0.22), .init(red: 0.44, green: 0.65, blue: 0.53)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    VStack(spacing: 20) {
                        Image(systemName: item.kind == .encryptedTendies ? "lock.shield" : "square.3.layers.3d").font(.system(size: 42, weight: .ultraLight))
                        Text(item.kind == .encryptedTendies ? "DYNOR" : "TENDIES").font(.system(size: 10, weight: .medium, design: .monospaced)).tracking(2.5)
                    }.foregroundStyle(.white)
                }
            }
        }
    }
}

@MainActor
struct LibraryPreview: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    let item: ImportedWallpaper
    @State private var saving = false
    @State private var notice: String?
    @State private var installing = false
    @State private var installProgress = 0.0
    @State private var installLog: [String] = []
    @State private var verifiedWrite = false
    @State private var previewMode: WallpaperPreviewMode = .locked
    @State private var confirmSingleDelete = false
    private var compatibility: TendiesCompatibility.Assessment { TendiesCompatibility.current }
    private var prerequisiteWarning: String? { PosterBoardAccess.prerequisiteWarning }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(spacing: 16) {
                        ZStack(alignment: .top) {
                            GeometryReader { geometry in
                                Group {
                                    if item.kind == .tendies {
                                        TendiesArtworkPreview(archiveURL: store.fileURL(for: item), phase: previewMode.rawValue)
                                    } else {
                                        LibraryArtwork(item: item)
                                    }
                                }
                                .frame(width: geometry.size.width, height: geometry.size.height)
                                .clipped()
                            }
                                .frame(height: 440).clipped()
                                .scaleEffect(previewMode == .sleep ? 1.07 : previewMode == .unlock ? 1.02 : 1)
                                .animation(.easeInOut(duration: 0.85), value: previewMode)
                            if true {
                                VStack(spacing: 6) {
                                    Text(Date.now, format: .dateTime.weekday(.wide).month(.abbreviated).day())
                                        .font(.caption.weight(.medium))
                                    Text(Date.now, format: .dateTime.hour().minute())
                                        .font(.system(size: 62, weight: .thin, design: .rounded))
                                }
                                .foregroundStyle(.white)
                                .shadow(color: .black.opacity(0.5), radius: 8)
                                .padding(.top, 52)
                            }
                            if previewMode == .sleep {
                                Color.black.opacity(0.68).allowsHitTesting(false)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                        Picker(store.localized("Chế độ xem trước", "Preview mode", "预览模式"), selection: $previewMode.animation(.easeInOut(duration: 0.85))) {
                            ForEach(WallpaperPreviewMode.allCases) { mode in
                                Text(mode.title).tag(mode)
                            }
                        }
                        .pickerStyle(.segmented)
                        Text(store.localized("Chế độ này xem trước ảnh đại diện của từng trạng thái. Animation CAML gốc cần trình dựng tương thích và chưa được phát trong Dynor.", "This preview shows still images for each state. Original CAML animations require a compatible renderer and cannot yet play in Dynor.", "此预览显示各状态的静态图。原始 CAML 动画需要兼容的渲染器，Dynor 暂不支持播放。"))
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                    DynorSoftCard {
                        VStack(alignment: .leading, spacing: 13) {
                            Label(store.localized("Thông tin hình nền", "Wallpaper information", "壁纸信息"), systemImage: "info.circle").font(.headline)
                            infoRow(store.localized("Ngày nhập", "Imported", "导入日期"), item.addedAt.formatted(date: .abbreviated, time: .shortened))
                            infoRow(store.localized("Dung lượng", "File size", "文件大小"), ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                            infoRow(store.localized("Định dạng", "Format", "格式"), (item.storedFilename as NSString).pathExtension.uppercased())
                            infoRow(store.localized("Nguồn", "Source", "来源"), item.kind == .encryptedTendies ? store.localized("Dynor mã hóa", "Encrypted Dynor", "Dynor 加密") : item.kind == .tendies ? "Tendies" : store.localized("Ảnh", "Image", "图片"))
                            if item.kind == .image, let image = UIImage(contentsOfFile: store.fileURL(for: item).path) {
                                infoRow(store.localized("Kích thước", "Dimensions", "尺寸"), "\(Int(image.size.width * image.scale)) × \(Int(image.size.height * image.scale)) px")
                            } else {
                                infoRow(store.localized("Kích thước", "Dimensions", "尺寸"), store.localized("Không có metadata ảnh đại diện", "No preview dimensions available", "没有预览图尺寸信息"))
                            }
                        }
                    }
                    Text(item.displayName).font(.system(.title2, design: .serif, weight: .semibold))
                    Text(item.kind.isTendies ? store.localized("Giữ iPhone mở khóa khi cài. Dynor ghi trực tiếp vào PosterBoard; sau đó mở bộ chọn hình nền để kiểm tra và chọn mẫu mới.", "Keep your iPhone unlocked during installation. Open the wallpaper picker afterward to apply your wallpaper.", "安装期间请保持 iPhone 解锁。完成后打开壁纸选择器，检查并应用新壁纸。") : store.localized("Lưu ảnh vào Ảnh, sau đó chọn Chia sẻ → Dùng làm hình nền.", "Save the image to Photos, then select Share → Use as Wallpaper.", "将图片保存到照片，然后选择共享 → 用作墙纸。"))
                        .font(.subheadline).foregroundStyle(.secondary)
                    if item.kind == .encryptedTendies {
                        Label("Đăng nhập Dynor và kết nối Internet mỗi lần cài gói mã hóa. Gói VIP cần tài khoản VIP còn hiệu lực. Dynor không xuất tệp đã giải mã.", systemImage: "lock.shield")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if item.kind.isTendies {
                        tendiesControls
                    }
                    if item.kind == .image {
                        Button {
                            saving = true
                            Task {
                                await store.saveImportedToPhotos(item)
                                notice = store.message
                                store.message = nil
                                saving = false
                            }
                        } label: {
                            Label(saving ? "Đang lưu…" : "Lưu vào Ảnh", systemImage: "photo.badge.arrow.down")
                                .frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(DynorPrimaryButtonStyle()).disabled(saving)
                        ShareLink(item: store.fileURL(for: item)) {
                            Label("Chia sẻ ảnh gốc", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(8)
                        }.buttonStyle(.bordered).disabled(installing)
                    }
                }
                .frame(maxWidth: 620)
                .padding(24)
                .frame(maxWidth: .infinity)
            }
            .background(DynorDesign.canvas.ignoresSafeArea())
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button(store.localized("Đóng", "Close", "关闭")) { dismiss() }.disabled(installing) } }
            .interactiveDismissDisabled(installing)
            .confirmationDialog("Xóa gói hình nền này?", isPresented: $confirmSingleDelete) {
                Button("Xóa khỏi Dynor", role: .destructive) {
                    store.removeImported(ids: Set([item.id]))
                    dismiss()
                }
                Button("Hủy", role: .cancel) {}
            } message: { Text("Tệp gốc bên ngoài Dynor không bị xóa.") }
            .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
                .fixedSize(horizontal: false, vertical: true)
        }.font(.subheadline)
            .frame(maxWidth: .infinity)
    }

    @ViewBuilder
    private var tendiesControls: some View {
        if compatibility.warning == nil {
            Label(compatibility.detail, systemImage: "iphone")
                .font(.caption).foregroundStyle(.secondary)
        }
        if let warning = compatibility.warning {
            Label(warning, systemImage: "info.circle")
                .font(.caption).foregroundStyle(.secondary)
        } else if let warning = prerequisiteWarning {
            Label(warning, systemImage: "exclamationmark.shield")
                .font(.caption).foregroundStyle(.secondary)
            Button("Mở bộ chọn hình nền") {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = "Không thể mở bộ chọn hình nền tự động. Hãy vào Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra."
                }
            }.font(.subheadline)
        }
        if installing {
            ProgressView(value: installProgress)
            Text("Đang ghi và xác minh… Giữ Dynor mở, iPhone mở khóa.")
                .font(.caption).foregroundStyle(.secondary)
        }
        Button {
            installTendies()
        } label: {
            Label(installing ? store.localized("Đang cài hình nền…", "Installing wallpaper…", "正在安装壁纸…") : verifiedWrite ? store.localized("Ghi lại hình nền", "Reinstall wallpaper", "重新安装壁纸") : store.localized("Cài hình nền", "Install wallpaper", "安装壁纸"), systemImage: "iphone.gen3")
                .frame(maxWidth: .infinity).padding(8)
        }
        .buttonStyle(DynorPrimaryButtonStyle())
        .disabled(installing || store.isInstallingWallpaper || prerequisiteWarning != nil || !compatibility.canAttemptInstall)
        if verifiedWrite {
            Button("Mở bộ chọn hình nền") {
                if !PosterBoardAccess.requestOpenPosterBoard() {
                    notice = "iOS chưa mở được PosterBoard. Mở Cài đặt → Hình nền → Thêm hình nền mới để kiểm tra. Nếu mẫu chưa xuất hiện, khởi động lại iPhone rồi kiểm tra lại."
                }
            }.buttonStyle(.bordered)
        }
        if !installLog.isEmpty {
            DisclosureGroup("Chi tiết cài đặt") {
                Text(installLog.joined(separator: "\n"))
                    .font(.caption2.monospaced())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
            }.font(.caption)
        }
    }

    private func installTendies() {
        guard compatibility.canAttemptInstall, !installing, !store.isInstallingWallpaper, prerequisiteWarning == nil else { return }
        installing = true
        store.isInstallingWallpaper = true
        verifiedWrite = false
        installProgress = 0
        installLog = []
        let previousIdleSetting = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        Task { @MainActor in
            defer {
                installing = false
                store.isInstallingWallpaper = false
                UIApplication.shared.isIdleTimerDisabled = previousIdleSetting
            }
            do {
                let receipt = try await TendiesInstaller.shared.install(
                    archiveURL: store.fileURL(for: item),
                    log: { line in
                        Task { @MainActor in
                            installLog.append(line)
                            if installLog.count > 100 { installLog.removeFirst(installLog.count - 100) }
                        }
                    },
                    progress: { value in Task { @MainActor in installProgress = value } }
                )
                verifiedWrite = true
                ActivityJournal.shared.add("Đã ghi hình nền", detail: "\(item.displayName) · \(receipt.verifiedFileCount) tệp đã xác minh", success: true)
                // Request PosterBoard after successful verification. iOS decides whether
                // it can foreground the system UI; no private multitasking manipulation.
                let opened = PosterBoardAccess.requestOpenPosterBoard()
                notice = opened
                    ? "Đã cài dữ liệu hình nền thành công! Dynor đã xác minh \(receipt.verifiedFileCount) tệp. Trong PosterBoard, chọn hình nền vừa thêm và bấm Thêm/Đặt làm hình nền. Nếu chưa thấy, mở Cài đặt → Hình nền hoặc khởi động lại iPhone."
                    : "Đã cài dữ liệu hình nền thành công! Dynor đã xác minh \(receipt.verifiedFileCount) tệp. iOS chưa cho tự mở PosterBoard; vào Cài đặt → Hình nền → Thêm hình nền mới, chọn mẫu vừa cài. Nếu chưa thấy, khởi động lại iPhone."
            } catch {
                ActivityJournal.shared.add("Cài hình nền thất bại", detail: "\(item.displayName) · \(error.localizedDescription)", success: false)
                notice = "Chưa hoàn tất cài hình nền: \(error.localizedDescription)"
            }
        }
    }
}

private enum WallpaperPreviewMode: String, CaseIterable, Identifiable {
    case sleep, locked, unlock
    var id: String { rawValue }
    var title: String {
        switch self {
        case .sleep: "Sleep"
        case .locked: "Locked"
        case .unlock: "Unlock"
        }
    }
}
