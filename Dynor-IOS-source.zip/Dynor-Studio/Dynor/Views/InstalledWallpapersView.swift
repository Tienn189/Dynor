import SwiftUI
import UIKit

/// iOS does not expose a public API to enumerate all system wallpapers.
/// This screen displays descriptors successfully written by Dynor.
struct InstalledWallpapersView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var paths: [String] = []
    @State private var thumbnails: [String: UIImage] = [:]
    @State private var selected = Set<String>()
    @State private var selecting = false
    @State private var busy = false
    @State private var message: String?
    @State private var confirmDelete = false
    @State private var previewPath: String?
    private let columns = [GridItem(.adaptive(minimum: 128, maximum: 250), spacing: 14)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                DynorHero(index: "03 / ON DEVICE", title: store.localized("Đã cài đặt", "On your device", "已安装"), subtitle: store.localized("Không gian mới cho màn hình của bạn.", "A fresh perspective, already yours.", "让屏幕焕然一新。"), symbol: "iphone")
                deviceSummary
                HStack {
                    Text(store.localized("Hình nền đã cài", "Installed wallpapers", "已安装的壁纸"))
                        .font(.system(.title3, design: .serif, weight: .semibold))
                    Spacer(minLength: 8)
                    Button {
                        selecting.toggle()
                        selected.removeAll()
                    } label: {
                        Text(selecting ? store.localized("Xong", "Done", "完成") : store.localized("Chọn", "Select", "选择"))
                            .font(.caption.weight(.semibold)).foregroundStyle(DynorDesign.ink)
                            .padding(.horizontal, 16).frame(height: 44)
                            .background(DynorDesign.surface, in: Capsule())
                    }.disabled(paths.isEmpty || busy)
                }
                if paths.isEmpty {
                    VStack(spacing: 18) {
                        DynorEmptyState(symbol: "iphone", title: store.localized("Màn hình mới đang chờ", "Your next look awaits", "新壁纸正在等你"), message: store.localized("Cài một gói từ Bộ sưu tập. Hình nền của bạn sẽ được lưu tại đây.", "Install a package from Collection. Your wallpapers will appear here.", "从收藏中安装一个壁纸包，它就会出现在这里。"))
                        Button {
                            store.selectedTab = .library
                        } label: {
                            HStack(spacing: 8) {
                                Text(store.localized("Mở Bộ sưu tập", "Open Collection", "打开收藏"))
                                Image(systemName: "arrow.right")
                            }
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(DynorDesign.ink)
                            .padding(.horizontal, 20).frame(minHeight: 46)
                            .background(DynorDesign.mist, in: Capsule())
                        }.buttonStyle(.plain)
                    }
                    .padding(.bottom, 24)
                } else {
                    LazyVGrid(columns: columns, alignment: .leading, spacing: 22) {
                        ForEach(paths, id: \.self) { path in installedItem(path) }
                    }
                }
                if selecting && !selected.isEmpty {
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label(store.localized("Xóa \(selected.count) hình nền", "Delete \(selected.count) wallpapers", "删除 \(selected.count) 张壁纸"), systemImage: "trash")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity).padding(16)
                            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
                    }.disabled(busy)
                }
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "info.circle").padding(.top, 1)
                    Text(store.localized("Chỉ hiển thị hình nền do Dynor cài. Một số gói không có ảnh xem trước.", "Shows wallpapers installed by Dynor. Some packages do not include a preview.", "仅显示 Dynor 安装的壁纸。部分壁纸包不含预览图。"))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .font(.caption).foregroundStyle(DynorDesign.muted)
            }
            .frame(maxWidth: 920)
            .padding(.horizontal, 24)
            .padding(.top, 12)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { reload() }
        .sheet(item: Binding(get: { previewPath.map { PreviewSelection(path: $0) } },
                             set: { previewPath = $0?.path })) { item in
            NavigationStack {
                VStack(spacing: 18) {
                    Spacer()
                    if let image = thumbnails[item.path] {
                        Image(uiImage: image).resizable().scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                            .padding(.horizontal, 28)
                    } else {
                        DynorEmptyState(symbol: "photo", title: store.localized("Không có ảnh xem trước", "No preview available", "暂无预览图"), message: store.localized("Gói hình nền không chứa ảnh tĩnh có thể hiển thị.", "This wallpaper package does not include a still preview.", "此壁纸包不含静态预览图。"))
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .background(DynorDesign.canvas)
                .navigationTitle("Xem trước hình nền")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) {
                    Button("Đóng") { previewPath = nil }
                } }
            }
        }
        .confirmationDialog("Xóa hình nền đã chọn?", isPresented: $confirmDelete) {
            Button("Xóa", role: .destructive) { deleteSelected() }
        }
        .alert("Dynor", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: { Text(message ?? "") }
    }

    private var deviceSummary: some View {
        HStack(spacing: 18) {
            Image(systemName: "iphone.gen3")
                .font(.system(size: 30, weight: .light))
                .foregroundStyle(DynorDesign.ink)
                .frame(width: 62, height: 72)
                .background(DynorDesign.mist, in: RoundedRectangle(cornerRadius: 20))
            VStack(alignment: .leading, spacing: 6) {
                Text(store.localized("TRÊN THIẾT BỊ", "ON YOUR DEVICE", "在你的设备上"))
                    .font(.system(size: 9, weight: .semibold, design: .monospaced)).tracking(1.5)
                    .foregroundStyle(DynorDesign.muted)
                Text(store.localized("\(paths.count) hình nền", "\(paths.count) wallpapers", "\(paths.count) 张壁纸"))
                    .font(.system(.title2, design: .serif, weight: .medium))
            }
            Spacer(minLength: 0)
            Button(action: reload) {
                if busy { ProgressView() }
                else { Image(systemName: "arrow.clockwise").font(.system(size: 16, weight: .medium)) }
            }
            .frame(width: 44, height: 44)
            .foregroundStyle(DynorDesign.ink)
            .background(DynorDesign.canvas, in: Circle())
            .disabled(busy)
            .accessibilityLabel(store.localized("Làm mới hình nền đã cài", "Refresh installed wallpapers", "刷新已安装壁纸"))
        }
        .padding(18)
        .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 24))
    }

    private func installedItem(_ path: String) -> some View {
        Button {
            if selecting {
                if selected.contains(path) { selected.remove(path) }
                else { selected.insert(path) }
            } else { previewPath = path }
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                GeometryReader { geometry in
                    ZStack {
                        DynorDesign.mist
                        if let image = thumbnails[path] {
                            Image(uiImage: image).resizable().scaledToFill()
                                .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                        } else {
                            VStack(spacing: 12) {
                                Image(systemName: "photo.artframe").font(.system(size: 28, weight: .light))
                                Text("DYNOR").font(.system(size: 9, weight: .medium, design: .monospaced)).tracking(2)
                            }.foregroundStyle(DynorDesign.muted)
                        }
                    }
                }
                .aspectRatio(0.72, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 22))
                .overlay(alignment: .topTrailing) {
                    if selecting {
                        Image(systemName: selected.contains(path) ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 26, weight: .semibold))
                            .foregroundStyle(selected.contains(path) ? store.accentColor : .white)
                            .padding(10).background(.black.opacity(0.12), in: Circle()).padding(6)
                    } else {
                        Image(systemName: "checkmark")
                            .font(.system(size: 10, weight: .bold)).foregroundStyle(DynorDesign.deepInk)
                            .frame(width: 28, height: 28)
                            .background(DynorDesign.accent, in: Circle())
                            .padding(10)
                    }
                }
                Text(store.localized("Hình nền Dynor", "Dynor wallpaper", "Dynor 壁纸"))
                    .font(.subheadline.weight(.semibold)).foregroundStyle(DynorDesign.ink)
                Text(URL(fileURLWithPath: path).lastPathComponent.prefix(8).uppercased())
                    .font(.system(size: 10, weight: .medium, design: .monospaced)).tracking(1)
                    .foregroundStyle(DynorDesign.muted)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(DynorPressStyle(scale: 0.98))
        .disabled(busy)
        .accessibilityLabel(store.localized("Hình nền Dynor", "Dynor wallpaper", "Dynor 壁纸") + " " + String(URL(fileURLWithPath: path).lastPathComponent.prefix(8)))
        .accessibilityValue(selecting ? (selected.contains(path) ? store.localized("Đã chọn", "Selected", "已选择") : store.localized("Chưa chọn", "Not selected", "未选择")) : "")
    }

    private func reload() {
        paths = PosterBoardDescriptorWriter.installedPaths()
        let current = paths
        Task.detached(priority: .utility) {
            let loaded = PosterBoardDescriptorWriter.previewImages(paths: current)
            await MainActor.run { thumbnails = loaded }
        }
    }

    private func deleteSelected() {
        let targets = Array(selected)
        busy = true
        Task.detached(priority: .userInitiated) {
            let result = Result { try PosterBoardDescriptorWriter.removeManaged(paths: targets) }
            await MainActor.run {
                busy = false
                switch result {
                case .success(let count): message = "Đã xóa \(count) hình nền Dynor."
                case .failure(let error): message = error.localizedDescription
                }
                reload()
                selected.removeAll()
                selecting = false
            }
        }
    }
}

private struct PreviewSelection: Identifiable {
    let path: String
    var id: String { path }
}
