import SwiftUI
import UIKit

struct ThemeColorPickerView: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedColor = Color.blue

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    DynorHero(index: "STUDIO / PALETTE", title: "Một chút sắc riêng.", subtitle: "Chọn màu nhấn cho không gian của bạn.", symbol: "paintpalette")
                    HStack(spacing: 14) {
                        RoundedRectangle(cornerRadius: 16).fill(store.accentColor)
                            .frame(width: 52, height: 64)
                            .overlay(Image(systemName: "sparkle").font(.title2).foregroundStyle(store.accentTextColor))
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Dynor Studio").font(.system(.title3, design: .serif, weight: .medium))
                            Text("Màu nhấn đang sử dụng").font(.caption).foregroundStyle(DynorDesign.muted)
                        }
                        Spacer()
                        Image(systemName: "checkmark.circle.fill").foregroundStyle(store.accentColor)
                    }
                    .padding(18).modifier(DynorGlass(radius: 22))
                    Text("BẢNG MÀU").font(.caption.weight(.semibold)).tracking(2).foregroundStyle(DynorDesign.muted)
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 18) {
                        ForEach(ThemeAccent.allCases.filter { $0 != .custom }) { option in
                            Button {
                                store.accent = option
                                selectedColor = option.color
                            } label: {
                                VStack(spacing: 8) {
                                    Circle().fill(option.color).frame(width: 54, height: 54)
                                        .overlay {
                                            if store.accent == option {
                                                Image(systemName: "checkmark").font(.headline.bold()).foregroundStyle(store.accentTextColor)
                                            }
                                        }
                                    Text(option.title).font(.caption).foregroundStyle(.primary)
                                }
                                .frame(maxWidth: .infinity, minHeight: 92)
                                .background(store.accent == option ? DynorDesign.mist : DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
                            }.buttonStyle(DynorPressStyle())
                            .accessibilityLabel(option.title)
                            .accessibilityAddTraits(store.accent == option ? [.isSelected] : [])
                        }
                    }
                    Divider()
                    ColorPicker("Tự chọn màu", selection: $selectedColor, supportsOpacity: false)
                        .font(.headline)
                    Button("Áp dụng màu tự chọn") {
                        let color = UIColor(selectedColor)
                        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
                        color.getRed(&r, green: &g, blue: &b, alpha: &a)
                        store.customAccentHex = String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
                        store.accent = .custom
                    }
                    .buttonStyle(DynorPrimaryButtonStyle())
                    .tint(store.accentColor)
                    Text("Màu đã chọn áp dụng cho các thành phần nhấn của Dynor, không thay đổi màu ảnh nền.")
                        .font(.caption).foregroundStyle(.secondary)
                }.padding(24).frame(maxWidth: 700)
                    .frame(maxWidth: .infinity)
            }
            .background(DynorDesign.canvas)
            .navigationTitle("Màu chủ đề")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
            .onAppear { selectedColor = store.accentColor }
        }
    }
}
