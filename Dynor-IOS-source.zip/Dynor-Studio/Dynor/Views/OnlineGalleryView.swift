import SwiftUI
import AVKit

private enum OnlineConfig {
    static let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    static let key = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    static func preview(_ path: String) -> URL? {
        let trimmed = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }

        // The admin website stores absolute Supabase Storage URLs.
        if let url = URL(string: trimmed),
           let scheme = url.scheme?.lowercased(),
           scheme == "https" || scheme == "http" {
            return url
        }

        // Legacy records may store a path relative to dynor-previews.
        let relative = trimmed.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let encoded = relative.split(separator: "/").map { segment in
            String(segment).addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? String(segment)
        }.joined(separator: "/")
        return URL(string: "\(base.absoluteString)/storage/v1/object/public/dynor-previews/\(encoded)")
    }
}

private struct OnlineWallpaper: Identifiable, Decodable {
    let id: UUID
    let title: String
    let category: String
    let cover_path: String
    let video_path: String?
    let is_vip: Bool
}

@MainActor
private final class OnlineGalleryModel: ObservableObject {
    @Published var items: [OnlineWallpaper] = []
    @Published var favorites: Set<UUID> = []
    @Published var loading = false
    @Published var error: String?
    private let account = DynorAccountService.shared

    private func request(_ path: String, method: String = "GET", token: String? = nil, body: Data? = nil, prefer: String? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: OnlineConfig.base)?.absoluteURL else { throw GalleryFailure.message("URL không hợp lệ") }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(OnlineConfig.key, forHTTPHeaderField: "apikey")
        if let token { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body { req.httpBody = body; req.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        if let prefer { req.setValue(prefer, forHTTPHeaderField: "Prefer") }
        let (data,response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "Không kết nối được Supabase"
            throw GalleryFailure.message("Máy chủ: \(text.prefix(180))")
        }
        return data
    }

    func reload() async {
        loading = true
        defer { loading = false }
        do {
            let data = try await request("rest/v1/dynor_wallpapers?select=id,title,category,cover_path,video_path,is_vip&published=eq.true&order=created_at.desc")
            items = try JSONDecoder().decode([OnlineWallpaper].self, from: data)
            error = nil
            await reloadFavorites()
        } catch { self.error = error.localizedDescription }
    }

    func reloadFavorites() async {
        guard let token = await account.galleryAccessToken() else { favorites = []; return }
        do {
            let data = try await request("rest/v1/dynor_favorites?select=wallpaper_id", token: token)
            struct Favorite: Decodable { let wallpaper_id: UUID }
            favorites = Set(try JSONDecoder().decode([Favorite].self, from: data).map(\.wallpaper_id))
        } catch { self.error = "Không đồng bộ được yêu thích: \(error.localizedDescription)" }
    }

    private func authenticatedUserID(token: String) async throws -> UUID {
        let data = try await request("auth/v1/user", token: token)
        struct AuthUser: Decodable { let id: UUID }
        return try JSONDecoder().decode(AuthUser.self, from: data).id
    }

    func toggleFavorite(_ id: UUID) async {
        guard let token = await account.galleryAccessToken() else { error = "Đăng nhập tài khoản Dynor để lưu yêu thích."; return }
        let wasFavorite = favorites.contains(id)
        do {
            let userID = try await authenticatedUserID(token: token)
            if wasFavorite {
                _ = try await request("rest/v1/dynor_favorites?wallpaper_id=eq.\(id.uuidString)&user_id=eq.\(userID.uuidString)",method:"DELETE",token:token)
                favorites.remove(id)
            } else {
                let body = try JSONSerialization.data(withJSONObject: ["wallpaper_id":id.uuidString, "user_id":userID.uuidString])
                _ = try await request("rest/v1/dynor_favorites",method:"POST",token:token,body:body,prefer:"return=minimal")
                favorites.insert(id)
            }
        } catch { self.error = "Không lưu được yêu thích: \(error.localizedDescription)" }
    }

    func download(_ item: OnlineWallpaper) async throws -> URL {
        guard let token = await account.galleryAccessToken() else { throw GalleryFailure.message("Đăng nhập Dynor trước khi tải.") }
        let body = try JSONSerialization.data(withJSONObject:["id":item.id.uuidString.lowercased()])
        let data = try await request("functions/v1/dynor-wallpaper-download",method:"POST",token:token,body:body)
        struct Signed: Decodable { let url: URL }
        let signed = try JSONDecoder().decode(Signed.self,from:data)
        guard signed.url.scheme == "https", signed.url.host == OnlineConfig.base.host else { throw GalleryFailure.message("Địa chỉ tải không an toàn") }
        let (temporary,response) = try await URLSession.shared.download(from:signed.url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw GalleryFailure.message("Không tải được file") }
        let suggested = response.suggestedFilename ?? "Dynor-Wallpaper"
        let safe = URL(fileURLWithPath:suggested).lastPathComponent
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent(safe)
        try FileManager.default.createDirectory(at:destination.deletingLastPathComponent(),withIntermediateDirectories:true)
        try FileManager.default.moveItem(at:temporary,to:destination)
        return destination
    }
}

private enum GalleryFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
}

struct OnlineGalleryView: View {
    @EnvironmentObject private var store: DynorStore
    @StateObject private var model = OnlineGalleryModel()
    @State private var selected: OnlineWallpaper?
    @State private var onlyFavorites = false
    @State private var query = ""
    @State private var category = "Tất cả"
    @Environment(\.scenePhase) private var phase
    @Environment(\.horizontalSizeClass) private var sizeClass
    private var columns: [GridItem] {
        [GridItem(.adaptive(minimum: sizeClass == .regular ? 190 : 128, maximum: 280), spacing: 16)]
    }
    private var categories: [String] { ["Tất cả"] + Array(Set(model.items.map(\.category))).sorted() }
    private var filtered: [OnlineWallpaper] {
        model.items.filter { item in
            (category == "Tất cả" || item.category == category) &&
            (!onlyFavorites || model.favorites.contains(item.id)) &&
            (query.isEmpty || "\(item.title) \(item.category)".localizedCaseInsensitiveContains(query))
        }
    }
    private var showFeatured: Bool { category == "Tất cả" && query.isEmpty && !onlyFavorites && !model.items.isEmpty }
    private var featured: [OnlineWallpaper] { Array(model.items.prefix(6)) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                header
                searchBar
                if showFeatured { featuredSection }
                chips
                gridSection
            }
            .padding(.horizontal, 22)
            .padding(.top, 14)
            .padding(.bottom, 28)
            .frame(maxWidth: 960)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
        .refreshable { await model.reload() }
        .task { await model.reload() }
        .onChange(of: phase) { _, newPhase in if newPhase == .active { Task { await model.reload() } } }
        .sheet(item: $selected) { item in
            OnlineWallpaperDetail(item: item, model: model)
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(32)
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 30) {
            HStack(spacing: 10) {
                Image(systemName: "asterisk")
                    .font(.system(size: 20, weight: .black))
                    .frame(width: 36, height: 36)
                    .background(DynorDesign.accent, in: RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(Color.black)
                    .accessibilityHidden(true)
                Text("DYNOR").font(.system(size: 16, weight: .heavy)).tracking(3)
                Spacer(minLength: 8)
                Menu {
                    Button { store.appLanguage = "vi" } label: { Text("Tiếng Việt" + (store.appLanguage == "vi" ? "  ✓" : "")) }
                    Button { store.appLanguage = "en" } label: { Text("English" + (store.appLanguage == "en" ? "  ✓" : "")) }
                    Button { store.appLanguage = "zh-Hans" } label: { Text("中文" + (store.appLanguage == "zh-Hans" ? "  ✓" : "")) }
                } label: {
                    HStack(spacing: 4) {
                        Text(store.appLanguage == "zh-Hans" ? "中文" : store.appLanguage == "en" ? "EN" : "VI")
                        Image(systemName: "chevron.down").font(.system(size: 9, weight: .bold))
                    }
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(DynorDesign.ink)
                    .frame(minWidth: 44, minHeight: 44)
                }
                .accessibilityLabel(store.localized("Ngôn ngữ", "Language", "语言"))
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { onlyFavorites.toggle() }
                } label: {
                    Image(systemName: onlyFavorites ? "heart.fill" : "heart")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(onlyFavorites ? store.accentColor : DynorDesign.ink)
                        .frame(width: 44, height: 44)
                        .background(DynorDesign.surface, in: Circle())
                        .overlay(Circle().strokeBorder(DynorDesign.outline, lineWidth: 1))
                }
                .buttonStyle(DynorPressStyle())
                .accessibilityLabel(store.localized("Yêu thích", "Favorites", "收藏"))
                .accessibilityValue(onlyFavorites ? store.localized("Đang lọc", "Filter on", "已筛选") : store.localized("Tất cả", "All", "全部"))
            }
            VStack(alignment: .leading, spacing: 12) {
                Text(store.localized("KHÔNG GIAN CẢM HỨNG", "YOUR DAILY INSPIRATION", "每日灵感"))
                    .font(.system(size: 10, weight: .semibold)).tracking(2)
                    .foregroundStyle(.secondary)
                Text(store.localized("Thêm một chút\ncảm hứng.", "A little more\ninspiration.", "让灵感\n点亮屏幕。"))
                    .font(.system(.largeTitle, design: .serif, weight: .medium))
                    .tracking(-1.2)
                    .foregroundStyle(DynorDesign.ink)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityAddTraits(.isHeader)
                Text(store.localized("Hình nền đẹp. Phong cách của riêng bạn.", "Beautiful wallpapers. Uniquely yours.", "精选壁纸，专属你的风格。"))
                    .font(.subheadline).foregroundStyle(.secondary)
            }
        }
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 16)).foregroundStyle(.secondary)
                TextField(store.localized("Tìm cảm hứng của bạn", "Find your inspiration", "寻找你的灵感"), text: $query)
                    .font(.subheadline)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                if !query.isEmpty {
                    Button { query = "" } label: {
                        Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary)
                            .frame(minWidth: 32, minHeight: 44)
                    }
                    .accessibilityLabel(store.localized("Xóa tìm kiếm", "Clear search", "清除搜索"))
                }
            }
            .padding(.horizontal, 16).frame(minHeight: 54)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(DynorDesign.outline, lineWidth: 1))
            Menu {
                Button(store.localized("Tất cả", "All", "全部")) { category = "Tất cả"; onlyFavorites = false }
                Button(store.localized("Yêu thích", "Favorites", "收藏")) { onlyFavorites = true }
                ForEach(categories.filter { $0 != "Tất cả" }, id: \.self) { value in
                    Button(value) { category = value }
                }
            } label: {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(DynorDesign.canvas)
                    .frame(width: 54, height: 54)
                    .background(DynorDesign.ink, in: RoundedRectangle(cornerRadius: 16))
            }
            .accessibilityLabel(store.localized("Lọc hình nền", "Filter wallpapers", "筛选壁纸"))
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 26) {
                ForEach(categories, id: \.self) { value in
                    let active = category == value
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) { category = value }
                    } label: {
                        VStack(spacing: 12) {
                            Text(value == "Tất cả" ? store.localized("Tất cả", "All", "全部") : value)
                                .font(.subheadline.weight(active ? .semibold : .regular))
                                .foregroundStyle(active ? DynorDesign.ink : Color.secondary)
                                .lineLimit(1)
                            Capsule().fill(active ? DynorDesign.ink : .clear).frame(height: 2)
                        }
                        .padding(.top, 10)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(active ? .isSelected : [])
                }
            }
        }
        .overlay(alignment: .bottom) { Rectangle().fill(DynorDesign.outline).frame(height: 1).allowsHitTesting(false) }
    }

    private var featuredSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text(store.localized("TIÊU ĐIỂM", "IN THE SPOTLIGHT", "灵感精选"))
                    .font(.system(size: 10, weight: .semibold)).tracking(2).foregroundStyle(.secondary)
                Spacer()
                Text(String(format: "%02d", featured.count))
                    .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 14) {
                    ForEach(featured) { item in
                        FeaturedCard(item: item,
                                     isFavorite: model.favorites.contains(item.id),
                                     onOpen: { selected = item },
                                     onFavorite: { Task { await model.toggleFavorite(item.id) } })
                            .containerRelativeFrame(.horizontal) { width, _ in min(width * 0.9, 520) }
                    }
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned)
        }
    }

    private var gridSection: some View {
        VStack(alignment: .leading, spacing: 20) {
            DynorSectionTitle(title: onlyFavorites ? store.localized("Đã yêu thích", "Saved for you", "我的收藏") : store.localized("Khám phá thêm", "Keep exploring", "探索更多"),
                              detail: String(format: "%02d", filtered.count))
            if model.loading && model.items.isEmpty {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(store.localized("Đang tải cảm hứng…", "Gathering inspiration…", "正在加载灵感…")).font(.subheadline).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 60)
            }
            if let error = model.error {
                VStack(alignment: .leading, spacing: 12) {
                    Label(error, systemImage: "wifi.exclamationmark").font(.caption).foregroundStyle(.secondary)
                    Button(store.localized("Thử lại", "Try again", "重试")) { Task { await model.reload() } }
                        .font(.subheadline.weight(.semibold)).tint(store.accentColor)
                }
                .frame(maxWidth: .infinity, alignment: .leading).padding(18)
                .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
            }
            if filtered.isEmpty && !model.loading && model.error == nil {
                DynorEmptyState(
                    symbol: onlyFavorites ? "heart" : "sparkles",
                    title: onlyFavorites ? store.localized("Giữ lại điều bạn thích", "Save what inspires you", "收藏你的灵感") : store.localized("Chưa tìm thấy hình nền", "No wallpapers found", "未找到壁纸"),
                    message: onlyFavorites ? store.localized("Chạm vào trái tim để lưu hình nền tại đây.", "Tap a heart to keep a wallpaper here.", "轻点爱心，在这里收藏壁纸。") : store.localized("Thử từ khóa khác hoặc kéo xuống để làm mới.", "Try another search or pull down to refresh.", "尝试其他关键词或下拉刷新。"))
            } else {
                LazyVGrid(columns: columns, spacing: 24) {
                    ForEach(filtered) { item in
                        PosterCard(item: item,
                                   isFavorite: model.favorites.contains(item.id),
                                   onOpen: { selected = item },
                                   onFavorite: { Task { await model.toggleFavorite(item.id) } })
                    }
                }
            }
        }
    }
}

// MARK: - Artwork

private struct RemotePoster: View {
    let url: URL?
    var body: some View {
        AsyncImage(url: url, transaction: Transaction(animation: .easeOut(duration: 0.3))) { phase in
            switch phase {
            case .success(let image):
                image.resizable().scaledToFill()
            case .failure:
                ZStack {
                    DynorDesign.mist
                    Image(systemName: "photo.artframe").font(.system(size: 30, weight: .ultraLight)).foregroundStyle(.secondary)
                }
            default:
                ZStack {
                    DynorDesign.mist
                    ProgressView().tint(DynorDesign.ink)
                }
            }
        }
    }
}

private struct FavoriteButton: View {
    @EnvironmentObject private var store: DynorStore
    let isFavorite: Bool
    var size: CGFloat = 44
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: isFavorite ? "heart.fill" : "heart")
                .font(.system(size: 17, weight: .medium))
                .foregroundStyle(isFavorite ? Color(red: 1, green: 0.49, blue: 0.49) : Color.white)
                .frame(width: max(size, 44), height: max(size, 44))
                .background(Color.black.opacity(0.30), in: Circle())
        }
        .buttonStyle(DynorPressStyle())
        .accessibilityLabel(isFavorite ? store.localized("Bỏ yêu thích", "Remove favorite", "取消收藏") : store.localized("Thêm yêu thích", "Add favorite", "添加收藏"))
    }
}

private struct FeaturedCard: View {
    let item: OnlineWallpaper
    let isFavorite: Bool
    let onOpen: () -> Void
    let onFavorite: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Button(action: onOpen) {
                Color.clear
                    .aspectRatio(1.07, contentMode: .fit)
                    .overlay { RemotePoster(url: OnlineConfig.preview(item.cover_path)) }
                    .overlay {
                        LinearGradient(colors: [.clear, .black.opacity(0.65)], startPoint: .center, endPoint: .bottom)
                    }
                    .overlay(alignment: .bottomLeading) {
                        HStack(alignment: .bottom, spacing: 12) {
                            VStack(alignment: .leading, spacing: 9) {
                                Text(item.category.uppercased())
                                    .font(.system(size: 10, weight: .semibold)).tracking(2)
                                    .foregroundStyle(.white.opacity(0.75))
                                Text(item.title)
                                    .font(.system(.title, design: .serif, weight: .medium))
                                    .dynamicTypeSize(...DynamicTypeSize.xxxLarge)
                                    .foregroundStyle(.white).lineLimit(2)
                            }
                            Spacer(minLength: 0)
                            Image(systemName: "arrow.up.right")
                                .font(.system(size: 18))
                                .foregroundStyle(.white)
                                .frame(width: 40, height: 40)
                                .overlay(Circle().strokeBorder(.white.opacity(0.45), lineWidth: 1))
                                .accessibilityHidden(true)
                        }
                        .padding(22)
                    }
                    .overlay(alignment: .topLeading) {
                        if item.is_vip { VIPBadge().padding(16) }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
                    .contentShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
            }
            .buttonStyle(DynorPressStyle(scale: 0.985))
            .accessibilityLabel("\(item.title), \(item.category)")
            FavoriteButton(isFavorite: isFavorite, action: onFavorite).padding(12)
        }
    }
}

private struct VIPBadge: View {
    var body: some View {
        Text("VIP").font(.system(size: 9, weight: .heavy)).tracking(1)
            .padding(.horizontal, 9).padding(.vertical, 6)
            .foregroundStyle(Color.black)
            .background(DynorDesign.accent, in: RoundedRectangle(cornerRadius: 6))
    }
}

private struct PosterCard: View {
    let item: OnlineWallpaper
    let isFavorite: Bool
    let onOpen: () -> Void
    let onFavorite: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            ZStack(alignment: .topTrailing) {
                Button(action: onOpen) {
                    Color.clear
                        .aspectRatio(0.72, contentMode: .fit)
                        .overlay { RemotePoster(url: OnlineConfig.preview(item.cover_path)) }
                        .overlay(alignment: .topLeading) {
                            if item.is_vip { VIPBadge().padding(12) }
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                }
                .buttonStyle(DynorPressStyle(scale: 0.98))
                .accessibilityLabel("\(item.title), \(item.category)")
                FavoriteButton(isFavorite: isFavorite, action: onFavorite).padding(6)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title).font(.subheadline.weight(.semibold)).foregroundStyle(DynorDesign.ink).lineLimit(1)
                Text(item.category).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            .padding(.horizontal, 2)
        }
    }
}

// MARK: - Detail

private struct OnlineWallpaperDetail: View {
    @EnvironmentObject private var store: DynorStore
    let item: OnlineWallpaper
    @ObservedObject var model: OnlineGalleryModel
    @Environment(\.dismiss) private var dismiss
    @State private var showVideo = false
    @State private var downloading = false
    @State private var importedWallpaper: ImportedWallpaper?
    @State private var notice: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                topBar
                Color.clear
                    .frame(height: 410)
                    .overlay { RemotePoster(url: OnlineConfig.preview(item.cover_path)) }
                    .clipShape(RoundedRectangle(cornerRadius: 26))
                    .accessibilityLabel(store.localized("Ảnh xem trước hình nền", "Wallpaper preview", "壁纸预览"))
                bottomPanel
            }
            .padding(22)
            .frame(maxWidth: 640)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
        .background(DynorDesign.canvas.ignoresSafeArea())
        .safeAreaInset(edge: .bottom, spacing: 0) { downloadBar }
        .interactiveDismissDisabled(downloading)
        .sheet(isPresented: $showVideo) {
            if let path = item.video_path, let url = OnlineConfig.preview(path) { OnlineVideoView(url: url) }
        }
        .sheet(item: $importedWallpaper) { wallpaper in
            LibraryPreview(item: wallpaper).environmentObject(store)
        }
        .onChange(of: store.selectedTab) { _, tab in
            if tab != .discover { dismiss() }
        }
        .alert("Dynor", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
            Button("OK", role: .cancel) { notice = nil }
        } message: { Text(notice ?? "") }
    }

    private var topBar: some View {
        HStack {
            Text("DYNOR / STUDIO")
                .font(.system(size: 10, weight: .semibold)).tracking(2).foregroundStyle(.secondary)
            Spacer()
            GlassIconButton(symbol: "xmark") { dismiss() }
                .disabled(downloading)
                .accessibilityLabel(store.localized("Đóng", "Close", "关闭"))
        }
    }

    private var bottomPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 8) {
                Text(item.category.uppercased())
                    .font(.system(size: 10, weight: .semibold)).tracking(2).foregroundStyle(.secondary)
                if item.is_vip { VIPBadge() }
            }
            Text(item.title)
                .font(.system(.largeTitle, design: .serif, weight: .medium))
                .tracking(-0.8).foregroundStyle(DynorDesign.ink)
                .fixedSize(horizontal: false, vertical: true)
            if item.video_path != nil {
                Button { showVideo = true } label: {
                    Label(store.localized("Xem chuyển động", "Preview in motion", "观看动态预览"), systemImage: "play.circle")
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity, minHeight: 52)
                        .foregroundStyle(DynorDesign.ink)
                        .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 16))
                        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(DynorDesign.outline, lineWidth: 1))
                }
                .buttonStyle(DynorPressStyle())
            }
            Text(store.localized("Tải hình nền vào Bộ sưu tập, sau đó chọn Cài hình nền. Gói mã hóa cần đăng nhập và Internet mỗi lần cài. Nội dung VIP cần tài khoản VIP còn hiệu lực.", "Download to your collection, then choose Install Wallpaper. Encrypted packages need sign-in and Internet each time. VIP content requires active VIP access.", "下载到收藏后，选择安装壁纸。加密包每次安装均需登录和联网。VIP 内容需要有效的 VIP 权限。"))
                .font(.caption).foregroundStyle(.secondary).lineSpacing(4)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var downloadBar: some View {
        HStack(spacing: 12) {
            Button { Task { await model.toggleFavorite(item.id) } } label: {
                Image(systemName: model.favorites.contains(item.id) ? "heart.fill" : "heart")
                    .font(.system(size: 20))
                    .frame(width: 54, height: 54)
                    .foregroundStyle(store.accentColor)
                    .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 18))
                    .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(DynorDesign.outline, lineWidth: 1))
            }
            .buttonStyle(DynorPressStyle())
            .accessibilityLabel(store.localized("Yêu thích", "Favorite", "收藏"))
            Button { startDownload() } label: {
                HStack(spacing: 10) {
                    if downloading { ProgressView().tint(DynorDesign.paper) }
                    Text(downloading ? store.localized("Đang tải…", "Downloading…", "正在下载…") : store.localized("Tải hình nền", "Get wallpaper", "下载壁纸"))
                    Spacer(minLength: 0)
                    if !downloading { Image(systemName: "arrow.down") }
                }
            }
            .buttonStyle(DynorPrimaryButtonStyle())
            .disabled(downloading)
        }
        .padding(.horizontal, 22).padding(.vertical, 14)
        .frame(maxWidth: 640)
        .frame(maxWidth: .infinity)
        .background(DynorDesign.canvas)
        .overlay(alignment: .top) { Rectangle().fill(DynorDesign.outline).frame(height: 1) }
    }

    private func startDownload() {
        downloading = true
        Task {
            do {
                let downloadedURL = try await model.download(item)
                defer { try? FileManager.default.removeItem(at: downloadedURL.deletingLastPathComponent()) }
                let imported = await store.importWallpapers(urls: [downloadedURL])
                if let wallpaper = imported.first {
                    store.message = nil
                    importedWallpaper = wallpaper
                } else {
                    notice = store.message ?? "Chưa nhập được hình nền đã tải."
                    store.message = nil
                }
            } catch { notice = error.localizedDescription }
            downloading = false
        }
    }
}

private struct OnlineVideoView: View {
    @EnvironmentObject private var store: DynorStore
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var player: AVPlayer?
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Group { if let player { VideoPlayer(player: player) } else { ProgressView().tint(.white) } }
                .ignoresSafeArea()
            GlassIconButton(symbol: "xmark") { dismiss() }
                .accessibilityLabel(store.localized("Đóng video", "Close video", "关闭视频"))
                .environment(\.colorScheme, .dark)
                .padding(18)
        }
        .onAppear { let p = AVPlayer(url: url); player = p; p.play() }
        .onDisappear { player?.pause(); player = nil }
    }
}
