import SwiftUI
import UIKit

/// Studio palette: warm paper, quiet borders and ink. Colors adapt to the user's theme.
enum DynorDesign {
    private static func adaptive(_ light: UInt32, _ dark: UInt32) -> Color {
        func uiColor(_ hex: UInt32) -> UIColor {
            UIColor(red: CGFloat((hex >> 16) & 255) / 255,
                    green: CGFloat((hex >> 8) & 255) / 255,
                    blue: CGFloat(hex & 255) / 255, alpha: 1)
        }
        return Color(uiColor: UIColor { traits in
            uiColor(traits.userInterfaceStyle == .dark ? dark : light)
        })
    }

    static let canvas = adaptive(0xF5F4EF, 0x111816)
    static let surface = adaptive(0xFFFEFA, 0x1C2521)
    static let ink = adaptive(0x182B25, 0xF3F4ED)
    static let muted = adaptive(0x66716B, 0xA5B2AA)
    static let outline = adaptive(0xDDD7CD, 0x35443C)
    static let mist = adaptive(0xE7EBE2, 0x28382F)
    static let accent = Color(red: 0.68, green: 0.86, blue: 0.74)
    static let deepInk = Color(red: 0.09, green: 0.17, blue: 0.14)
    static let paper = Color(red: 0.97, green: 0.97, blue: 0.93)
    static let radius: CGFloat = 24

    // Compatibility for screens that still use the historical accent token name.
    static var yellow: Color {
        ThemeAccent(rawValue: UserDefaults.standard.string(forKey: "accent") ?? "mint")?.color ?? accent
    }
    static var deepYellow: Color { yellow }
}

struct DynorHero: View {
    let index: String
    let title: String
    let subtitle: String
    let symbol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: symbol).font(.system(size: 12, weight: .semibold))
                Text(index).font(.system(.caption2, design: .monospaced, weight: .medium)).tracking(2)
            }
            .foregroundStyle(DynorDesign.muted)
            Text(title)
                .font(.system(.largeTitle, design: .serif, weight: .medium))
                .tracking(-1)
                .foregroundStyle(DynorDesign.ink)
                .fixedSize(horizontal: false, vertical: true)
            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(DynorDesign.muted)
                .lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 12)
        .padding(.bottom, 8)
    }
}

struct DynorQuietAction: ViewModifier {
    func body(content: Content) -> some View {
        content
            .foregroundStyle(DynorDesign.ink)
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(DynorDesign.mist, in: RoundedRectangle(cornerRadius: 16))
    }
}

struct DynorSoftCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: DynorDesign.radius))
            .overlay(RoundedRectangle(cornerRadius: DynorDesign.radius).strokeBorder(DynorDesign.outline.opacity(0.65), lineWidth: 0.7))
    }
}

struct DynorSectionTitle: View {
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(title).font(.system(.title3, design: .serif, weight: .semibold)).foregroundStyle(DynorDesign.ink)
            Spacer(minLength: 4)
            Text(detail).font(.caption.monospaced()).foregroundStyle(DynorDesign.muted)
        }
        .padding(.top, 8)
    }
}

struct DynorEmptyState: View {
    let symbol: String
    let title: String
    let message: String

    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 25).fill(DynorDesign.mist)
                    .frame(width: 92, height: 108).rotationEffect(.degrees(-9))
                RoundedRectangle(cornerRadius: 25).fill(DynorDesign.surface)
                    .frame(width: 92, height: 108).rotationEffect(.degrees(8))
                    .overlay(RoundedRectangle(cornerRadius: 25).strokeBorder(DynorDesign.outline))
                Image(systemName: symbol).font(.system(size: 30, weight: .light)).foregroundStyle(DynorDesign.ink)
            }
            .frame(height: 130).accessibilityHidden(true)
            Text(title).font(.system(.title2, design: .serif, weight: .medium)).foregroundStyle(DynorDesign.ink)
            Text(message).font(.subheadline).foregroundStyle(DynorDesign.muted)
                .lineSpacing(4).fixedSize(horizontal: false, vertical: true)
        }
        .multilineTextAlignment(.center)
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 24)
        .padding(.vertical, 36)
    }
}

struct DynorPrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(DynorDesign.paper)
            .frame(maxWidth: .infinity, minHeight: 52)
            .padding(.horizontal, 18)
            .background(DynorDesign.deepInk, in: RoundedRectangle(cornerRadius: 16))
            .opacity(isEnabled ? (configuration.isPressed ? 0.8 : 1) : 0.45)
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.98 : 1)
    }
}

// Retains the existing call sites while replacing translucent glass with a quiet solid surface.
struct DynorGlass: ViewModifier {
    var radius: CGFloat = 22
    func body(content: Content) -> some View {
        content.background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: radius))
            .overlay(RoundedRectangle(cornerRadius: radius).strokeBorder(DynorDesign.outline.opacity(0.7), lineWidth: 0.7))
    }
}

struct DynorPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var scale: CGFloat = 0.98
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.8 : 1)
            .scaleEffect(configuration.isPressed && !reduceMotion ? scale : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: configuration.isPressed)
    }
}

struct DynorGlassButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled
    var destructive = false
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(destructive ? Color.red : DynorDesign.ink)
            .frame(maxWidth: .infinity, minHeight: 52)
            .modifier(DynorGlass(radius: 16))
            .opacity(isEnabled ? (configuration.isPressed ? 0.7 : 1) : 0.45)
    }
}

struct GlassIconButton: View {
    let symbol: String
    var tint: Color? = nil
    var size: CGFloat = 44
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: size * 0.36, weight: .medium))
                .foregroundStyle(tint ?? DynorDesign.ink)
                .frame(width: size, height: size)
                .modifier(DynorGlass(radius: 16))
                .contentShape(RoundedRectangle(cornerRadius: 16))
        }
        .buttonStyle(DynorPressStyle())
    }
}
