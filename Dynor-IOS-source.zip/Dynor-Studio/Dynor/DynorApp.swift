import SwiftUI
import UIKit

@main
@MainActor
struct DynorApp: App {
    @StateObject private var store = DynorStore()
    @Environment(\.scenePhase) private var scenePhase

    init() {
        TendiesInstallWorkspace.removeStale()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .onOpenURL { url in
                    guard !store.isInstallingWallpaper else {
                        store.message = "Hãy chờ cài hình nền hoàn tất trước khi mở tệp khác."
                        return
                    }
                    Task {
                        store.selectedTab = .library
                        let imported = await store.importWallpapers(urls: [url])
                        if let item = imported.first {
                            store.message = nil
                            store.openInLibrary(item)
                        }
                    }
                }
                .tint(store.accentColor)
                .environment(\.locale, Locale(identifier: store.appLanguage))
                .preferredColorScheme(store.theme.colorScheme)
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active { store.refreshDailyAccess(); Task { await DynorAccountService.shared.restoreSession() } }
                }
                .task {
                    while !Task.isCancelled {
                        do { try await Task.sleep(for: .seconds(20)) }
                        catch { return }
                        store.refreshDailyAccess()
                    }
                }
        }
    }
}

private struct RootView: View {
    @EnvironmentObject private var store: DynorStore
    @State private var keyboardVisible = false
    var body: some View {
        TabView(selection: $store.selectedTab) {
            NavigationStack { OnlineGalleryView().toolbar(.hidden, for: .tabBar) }
                .tabItem { Label(store.localized("Khám phá", "Explore", "探索"), systemImage: "square.grid.2x2") }
                .tag(DynorTab.discover)
            NavigationStack { LibraryView().toolbar(.hidden, for: .tabBar) }
                .tabItem { Label(store.localized("Bộ sưu tập", "Collection", "收藏"), systemImage: "square.stack") }
                .tag(DynorTab.library)
            NavigationStack { InstalledWallpapersView().toolbar(.hidden, for: .tabBar) }
                .tabItem { Label(store.localized("Thư viện", "Installed", "已安装"), systemImage: "rectangle.stack") }
                .tag(DynorTab.installed)
            SettingsView()
                .toolbar(.hidden, for: .tabBar)
                .tabItem { Label(store.localized("Cài đặt", "Settings", "设置"), systemImage: "gearshape") }
                .tag(DynorTab.settings)
        }
        .tint(store.accentColor)
        .toolbar(.hidden, for: .tabBar)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if !keyboardVisible { StudioTabBar() }
        }
        .background(DynorDesign.canvas)
        .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in
            keyboardVisible = true
        }
        .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)) { _ in
            keyboardVisible = false
        }
        .alert("Dynor", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
            Button(store.localized("Đã hiểu", "OK", "确定"), role: .cancel) { store.message = nil }
        } message: { Text(store.message ?? "") }
    }
}


/// A quiet navigation rail; keeps TabView's independent navigation stacks and selection binding.
private struct StudioTabBar: View {
    @EnvironmentObject private var store: DynorStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.dynamicTypeSize) private var typeSize

    var body: some View {
        VStack(spacing: 4) {
            if typeSize.isAccessibilitySize {
                HStack(spacing: 4) { discoverItem; collectionItem }
                HStack(spacing: 4) { installedItem; settingsItem }
            } else {
                HStack(spacing: 4) { discoverItem; collectionItem; installedItem; settingsItem }
            }
        }
        .padding(8)
        .frame(maxWidth: 620)
        .background(DynorDesign.surface, in: RoundedRectangle(cornerRadius: 26))
        .overlay(RoundedRectangle(cornerRadius: 26).strokeBorder(DynorDesign.outline.opacity(0.8), lineWidth: 0.7))
        .padding(.horizontal, 16)
        .padding(.top, 10)
        .padding(.bottom, 6)
        .frame(maxWidth: .infinity)
        .background(DynorDesign.canvas)
    }

    private var discoverItem: some View {
        item(.discover, title: store.localized("Khám phá", "Explore", "探索"), symbol: "safari", selectedSymbol: "safari.fill")
    }
    private var collectionItem: some View {
        item(.library, title: store.localized("Bộ sưu tập", "Collection", "收藏"), symbol: "square.stack", selectedSymbol: "square.stack.fill")
    }
    private var installedItem: some View {
        item(.installed, title: store.localized("Đã cài", "Installed", "已安装"), symbol: "iphone.gen3", selectedSymbol: "iphone.gen3")
    }
    private var settingsItem: some View {
        item(.settings, title: store.localized("Cài đặt", "Settings", "设置"), symbol: "slider.horizontal.3", selectedSymbol: "slider.horizontal.3")
    }

    private func item(_ tab: DynorTab, title: String, symbol: String, selectedSymbol: String) -> some View {
        let active = store.selectedTab == tab
        return Button {
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.18)) {
                store.selectedTab = tab
            }
        } label: {
            Group {
                if typeSize.isAccessibilitySize {
                    HStack(spacing: 8) {
                        Image(systemName: active ? selectedSymbol : symbol).font(.body)
                        Text(title).font(.caption.weight(active ? .semibold : .medium)).lineLimit(2)
                    }.padding(.horizontal, 8).padding(.vertical, 6)
                } else {
                    VStack(spacing: 5) {
                        Image(systemName: active ? selectedSymbol : symbol)
                            .font(.system(size: 19, weight: active ? .semibold : .regular))
                            .frame(height: 23)
                        Text(title)
                            .font(.caption2.weight(active ? .semibold : .medium))
                            .lineLimit(1).minimumScaleFactor(0.8)
                    }
                }
            }
            .foregroundStyle(active ? DynorDesign.ink : DynorDesign.muted)
            .frame(maxWidth: .infinity, minHeight: 54)
            .background(active ? DynorDesign.mist : Color.clear, in: RoundedRectangle(cornerRadius: 18))
            .contentShape(RoundedRectangle(cornerRadius: 18))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(title)
        .accessibilityAddTraits(active ? [.isSelected] : [])
    }
}
