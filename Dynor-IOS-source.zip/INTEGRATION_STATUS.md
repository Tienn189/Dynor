# Trạng thái tích hợp 1.3.0 / build 6

- Giữ com.dynor.wallpapers, nội dung/giao diện thư viện/khám phá/cài đặt.
- Pairing chuyển thành tab PosterBoard. Xóa AirliftFFI, transport VPN, ghép nối,
  quyền audio/Bonjour/Mạng cục bộ và dependency Rust. Dọn credentials cũ trong
  vùng lưu trữ riêng của Dynor khi nâng cấp.
- worse_query native kèm source và hash pin, App Group entitlement gắn với đúng
  cấu hình Info.plist, kiểm tra entitlement từ chữ ký thực tế khi chạy.
- Container PosterBoard phải có UUID hợp lệ và metadata/xattr đúng danh tính.
- Kiểm tra ZIP/CRC/giới hạn giải nén; bảo toàn descriptor symbolic identifiers;
  chọn provider thật, đối chiếu SHA-256 toàn bộ tập tệp sau ghi; rollback lượt cài.
- Không thông báo đã áp dụng wallpaper chỉ từ kết quả ghi. Người dùng chọn trong iOS.
- Build script/CI chạy XCTest và archive IPA unsigned; ký App Group là bước riêng.
- Chưa chạy xcodebuild hoặc thử trên thiết bị. Xem VERIFICATION.md và BUILD_IPA.md.
