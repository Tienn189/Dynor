# Dynor Yellow redesign
- Three tabs: Khám phá / Bộ sưu tập / Cài đặt. PosterBoard moved into Library install tool and Settings.
- Library lists Tendies and encrypted Dynor packages only; image files are excluded from the library listing (existing data is not deleted).
- Yellow accent and dark mode via existing theme picker.
- Activity log in monospaced timestamped console style, with copy, share and delete.
- PosterBoard installation backend untouched.
- Build and device validation required; no Xcode build performed here.
