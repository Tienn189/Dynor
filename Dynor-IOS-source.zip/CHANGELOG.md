# 1.3.0 (6) — PosterBoard trực tiếp

- Bundle ID com.dynor.wallpapers; giữ nội dung Khám phá, Thư viện, tài khoản,
  gói mã hóa, ảnh và Cài đặt. Vị trí tab Pairing chuyển thành PosterBoard.
- Thay installer Airlift bằng worse_query native kèm source và provenance.
  Xóa pairing/VPN, FFI binary, Rust dependency và quyền không còn dùng.
- App Group được khai báo trong project/entitlements, kiểm tra từ chữ ký thật.
- Xác minh container PosterBoard; chọn datastore/provider tồn tại trên thiết bị.
- Giữ kiểm tra ZIP/CRC và identifiers, thêm SHA-256 toàn bộ tệp sau ghi.
  Rollback descriptor mới khi lỗi; giữ descriptor cũ và preferences khác.
- Thông báo chỉ xác nhận dữ liệu đã đọc lại; không tự tuyên bố iOS đã áp dụng mẫu.
- Bổ sung test giao dịch filesystem và cấu hình ký; thống nhất script build IPA
  trên Mac, GitHub Actions và Codemagic.

Kiểm chứng thực tế và các giới hạn: VERIFICATION.md. Hướng dẫn build/ký: BUILD_IPA.md.

- Bổ sung ký IPA trực tiếp trong GitHub Actions bằng cert/profile từ repository
  secrets, kiểm tra App Group trước khi xuất artifact signed. Giữ lựa chọn unsigned.
