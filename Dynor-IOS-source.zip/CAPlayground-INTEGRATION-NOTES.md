# CAPlayground / Dynor integration

This build adds an in-app WKWebView entry point to the **official hosted CAPlayground editor** at https://caplayground.vercel.app/projects.
It is available to all Dynor users (Free and VIP), with no entitlement check.

IMPORTANT: This is NOT a bundled copy of the CAPlayground repository, nor a native port of its React/Next.js editor.
The hosted editor needs internet access; mobile layout and login are controlled by CAPlayground.
Projects created in the web editor do not automatically appear in Dynor's native project library, and do not install to PosterBoard.

For a fully bundled/offline integration, vendor the upstream repository at a pinned commit, isolate the client-only editor modules,
adapt them to a standalone SPA bundle (not a Next.js server route), and implement a versioned native JS bridge
for import/export, file picker, and project persistence. Test licenses, signing, WebKit media and iOS memory limits.
