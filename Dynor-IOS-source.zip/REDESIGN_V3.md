# Dynor full-screen redesign V3

Changed SwiftUI views: DynorDesign.swift (new design system), OnlineGalleryView.swift (new hero, search, category chips, photo grid), LibraryView.swift (new collection hero, Tendies-only grid), SettingsView.swift (new settings hero, updated card surface, worse_query credits), ActivityHistoryView.swift (console-style journal), DynorApp.swift (navigation theme), DynorStore.swift (accent).

Retained: existing account, download, import, encrypted .dynor, PosterBoard installer, worse_query implementation, activity storage, entitlement, and signing configuration.

Credits: forcequitOS / worse_query, https://github.com/forcequitOS/worse_query. Keep third-party licenses in ThirdParty/.

No iOS/macOS Xcode toolchain available in this environment. This is a source patch, not a verified iOS build or device test. Build with Codemagic and share compiler errors if any.
