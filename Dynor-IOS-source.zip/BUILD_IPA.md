# Build IPA Dynor

Bundle ID được giữ cố định là `com.dynor.wallpapers`. Cơ chế Worse Poster dùng
`worse_query` đã kèm source Objective-C trong `Dynor/Native`; không cần tải
AirliftFFI, cài Rust, ghép nối hoặc chạy ứng dụng hỗ trợ trên iPhone.

## Build và kiểm thử trên Mac

Cần macOS, full Xcode 16 trở lên, Command Line Tools trỏ tới Xcode đó, một iPhone
Simulator iOS 18+ và XcodeGen. Dùng Xcode hỗ trợ phiên bản iOS của thiết bị khi
chạy trực tiếp trên iPhone.

```bash
brew install xcodegen
cd Dynor-iOS
bash scripts/build_ipa.sh
```

Script xác minh SHA-256 của source native, tạo icon/project Xcode, chạy XCTest
trên Simulator có sẵn rồi archive cho iPhone arm64. Script dừng khi bước nào lỗi.
Kết quả:

- `build/ipa/Dynor-unsigned.ipa`
- `build/logs/dynor-build.log`, `build/logs/dynor-tests.log`
- `build/DynorTests-*.xcresult`

Nếu máy không có Simulator, có thể dùng `bash scripts/build_ipa.sh --skip-tests`
để chỉ archive; tùy chọn này không được xem là đã chạy XCTest. Cả Intel Mac và
Apple Silicon đều có thể biên dịch source native này.

Linux trong phiên chỉnh sửa không có Xcode/SDK iOS. Kiểm tra Python/Node, hash
và cấu hình source trên Linux không thay thế kết quả `xcodebuild` trên Mac.

## Ký IPA với App Group thật

`worse_query` cần App Group do nhóm phát triển ký ứng dụng sở hữu. Build được
hoặc thêm entitlement bằng công cụ ký lại chưa đủ để có quyền truy cập.

1. Trong Apple Developer, đăng ký hoặc dùng App ID `com.dynor.wallpapers` thuộc
   nhóm của bạn và bật **App Groups**. Nhóm ký phải có quyền dùng đúng Bundle ID
   này để giữ yêu cầu của Dynor.
2. Đăng ký App Group mặc định `group.com.dynor.wallpapers` rồi gán cho App ID.
   Nếu dùng tên group khác, sửa `DYNOR_APP_GROUP_IDENTIFIER` trong `project.yml`
   trước khi chạy lại XcodeGen. Giá trị này được dùng chung cho Info.plist và
   `Dynor/Dynor.entitlements`.
3. Mở `Dynor.xcodeproj`, chọn target **Dynor → Signing & Capabilities**, chọn
   đúng Team và kiểm tra App Group đã bật trong provisioning profile. Giữ
   Bundle ID `com.dynor.wallpapers`.
4. Chọn thiết bị iOS thật hoặc **Any iOS Device**, chạy **Product → Archive**.
   Trong Organizer, xuất Development/Ad Hoc IPA bằng profile có App Group đó,
   hoặc chạy trực tiếp trên iPhone bằng Xcode.
5. Kiểm tra app đã ký trước khi cài. Nếu đã xuất IPA, giải nén IPA để lấy
   `Payload/Dynor.app`, sau đó chạy:

```bash
python3 scripts/verify_signed_app.py /duong-dan/Payload/Dynor.app
```

Script kiểm tra chữ ký, Bundle ID, App Group trong entitlement đã ký, group
được provisioning profile cho phép và hạn dùng profile. Nó không xác nhận
PosterBoard đã nhận hoặc chọn hình nền trên iPhone.

Một dịch vụ ký/sideload thay Bundle ID hoặc bỏ App Groups sẽ làm cơ chế này
không dùng được. Cần giữ Bundle ID, group khớp nhau và profile hợp lệ khi ký
lại IPA unsigned.

## GitHub Actions / Codemagic

Đưa **toàn bộ nội dung bên trong thư mục Dynor-iOS** lên gốc repository.
GitHub Actions: chạy workflow **Build Dynor native IPA** rồi tải artifact
**Dynor-native-unsigned-IPA**. Artifact **Dynor-native-build-evidence** chứa log
và kết quả XCTest. Codemagic: chạy workflow **Dynor iOS IPA**, lấy
`Dynor-unsigned.ipa` và các log/test artifacts.

Hai cấu hình cũng nhận ZIP ở gốc repository khi không có source đã giải nén;
mặc định tên `Dynor-iOS-source.zip`. Nếu dùng cách này phải đặt workflow
`.github/workflows/build-ipa.yml` hoặc `codemagic.yaml` bên ngoài ZIP tại đúng
vị trí của repository. Source đã giải nén được ưu tiên để không build nhầm ZIP
cũ. Cả hai pipeline gọi cùng `scripts/build_ipa.sh`.

Mặc định push/PR xuất IPA **unsigned**. Khi chạy thủ công GitHub Actions, có
thể chọn `sign_ipa` để runner ký bằng cert/profile của bạn trong GitHub Secrets
và xuất thêm **Dynor-native-signed-IPA**. Xem [GITHUB_ACTIONS.md](GITHUB_ACTIONS.md)
để thêm ba secrets và giữ workflow cũ nếu muốn. Kết quả Simulator/archive không chứng minh cài hình nền trên
iOS 26.6; xem README và VERIFICATION để kiểm chứng trên iPhone mục tiêu.
