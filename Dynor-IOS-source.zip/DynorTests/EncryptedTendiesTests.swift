import Foundation
import CryptoKit
import XCTest
@testable import Dynor

final class EncryptedTendiesTests: XCTestCase {
    // TEST ONLY: independent deterministic Node/OpenSSL vector. These published
    // bytes are never used by the encryptor or the app for real content.
    private let packageID = UUID(uuidString: "01234567-89ab-4cde-8fab-0123456789ab")!
    private let testKeyBase64 = "AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8="
    private let expectedPlaintextBase64 = "UEsDBBQAAAAAAAAAIVxJhs0EHgAAAB4AAAALAAAAZml4dHVyZS50eHREeW5vciBUZW5kaWVzIGludGVyb3AgZml4dHVyZQpQSwECFAMUAAAAAAAAACFcSYbNBB4AAAAeAAAACwAAAAAAAAAAAAAAgAEAAAAAZml4dHVyZS50eHRQSwUGAAAAAAEAAQA5AAAARwAAAAAA"
    private let encryptedBase64 = "RFlOT1JUMDEBI0VniatM3o+rASNFZ4mroKGio6SlpqeoqaqrtlN/KVHLAr9iZYfTJiaJWL2oRxCSt1xsnA4thn+rE2iqAjKNygwnRSvYfaZmCKOtInUiIQejOhcvKm4sywCl1t3E8RpCwO6wv+P9DIzazLrNC6ukxeDFM2i4OoSxmk2Kj4QroAOuj5ue2wZQhYjtqCVQYa7eU/JEW7qswZohijmVWrV500KAFzZZ/4srSpHWz9mta77QpSTOvX8mPa0JPRa160woZw=="

    func testWebCryptoOpenSSLPackageDecryptsWithExpectedHeaderAndHash() throws {
        let bytes = try XCTUnwrap(Data(base64Encoded: encryptedBase64))
        let envelope = try EncryptedTendiesEnvelope(data: bytes)
        XCTAssertEqual(envelope.packageID, packageID)
        XCTAssertEqual(envelope.header, EncryptedTendiesEnvelope.header(for: packageID))
        XCTAssertEqual(envelope.header.map { String(format: "%02x", $0) }.joined(),
                       "44594e4f525430310123456789ab4cde8fab0123456789ab")
        XCTAssertEqual(envelope.sha256, "b343a42fdd55d7b175caeef9b0485db8ca992954df4626c0d0f533ac3a202844")
        let key = SymmetricKey(data: try XCTUnwrap(Data(base64Encoded: testKeyBase64)))
        XCTAssertEqual(try envelope.decrypt(using: key), try XCTUnwrap(Data(base64Encoded: expectedPlaintextBase64)))
    }

    func testHeaderCiphertextAndTagTamperingAreRejected() throws {
        let original = try XCTUnwrap(Data(base64Encoded: encryptedBase64))
        let key = SymmetricKey(data: try XCTUnwrap(Data(base64Encoded: testKeyBase64)))
        for index in [8, 24, 40, original.count - 1] {
            var damaged = original
            damaged[index] ^= 1
            let envelope = try EncryptedTendiesEnvelope(data: damaged)
            XCTAssertThrowsError(try envelope.decrypt(using: key), "tampered byte \(index)")
        }
        let envelope = try EncryptedTendiesEnvelope(data: original)
        XCTAssertThrowsError(try envelope.decrypt(using: SymmetricKey(size: .bits256)))
        XCTAssertThrowsError(try envelope.decrypt(using: SymmetricKey(size: .bits128)))
    }

    func testMalformedHeaderEmptyBodyAndSizeLimitAreRejected() throws {
        let valid = try XCTUnwrap(Data(base64Encoded: encryptedBase64))
        for count in [0, 7, 23, 24, EncryptedTendiesEnvelope.overhead] {
            XCTAssertThrowsError(try EncryptedTendiesEnvelope(data: Data(valid.prefix(count))))
        }
        var wrongMagic = valid
        wrongMagic[0] ^= 1
        XCTAssertThrowsError(try EncryptedTendiesEnvelope(data: wrongMagic))
        XCTAssertThrowsError(try EncryptedTendiesEnvelope(data: Data(count: EncryptedTendiesEnvelope.maximumFileBytes + 1)))
    }

    func testAuthenticatedNonZIPContentStillRejected() throws {
        let header = EncryptedTendiesEnvelope.header(for: packageID)
        let key = SymmetricKey(size: .bits256)
        let box = try AES.GCM.seal(Data("not a wallpaper archive".utf8), using: key, authenticating: header)
        let package = header + (try XCTUnwrap(box.combined))
        let envelope = try EncryptedTendiesEnvelope(data: package)
        XCTAssertThrowsError(try envelope.decrypt(using: key))
    }

    func testRecipientKeyWrappingAuthenticatesPackageAndRecipient() throws {
        // TEST ONLY: scalar 1 and scalar 2, HKDF and AES-GCM calculated
        // independently with Node/OpenSSL, rather than CryptoKit's seal path.
        let privateBytes = try XCTUnwrap(Data(base64Encoded:
            "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE="))
        let recipient = try P256.KeyAgreement.PrivateKey(rawRepresentation: privateBytes)
        let header = EncryptedTendiesEnvelope.header(for: packageID)
        let contentKey = try XCTUnwrap(Data(base64Encoded: testKeyBase64))
        let response = EncryptedTendiesKeyResponse(
            ephemeralPublicKey: "BHzyexiNA09+ilI4AwS1GsPAiWnid/IbNaYLSPxHZpl4B3dVENuO0EApPZrGn3Qw27p9reY86YIpngS3nSJ4c9E=",
            salt: "PDw8PDw8PDw8PDw8PDw8PA==",
            wrappedKey: "QEFCQ0RFRkdISUpLben2YLqV74X8DHyPoP5grchhaGCXiu+RmZQwmD70WipGQV++4ZucRdMJeJMwo8yn")
        let recipientSecret = try recipient.sharedSecretFromKeyAgreement(with: response.publicKey())
        let result = try response.unwrap(sharedSecret: recipientSecret, header: header)
        XCTAssertEqual(result.withUnsafeBytes { Data($0) }, contentKey)
        XCTAssertThrowsError(try response.unwrap(sharedSecret: recipientSecret,
            header: EncryptedTendiesEnvelope.header(for: UUID())))
        let otherRecipient = P256.KeyAgreement.PrivateKey()
        let wrongSecret = try otherRecipient.sharedSecretFromKeyAgreement(with: response.publicKey())
        XCTAssertThrowsError(try response.unwrap(sharedSecret: wrongSecret, header: header))
    }

    func testMalformedRecipientKeyResponseIsRejected() throws {
        let secret = try P256.KeyAgreement.PrivateKey().sharedSecretFromKeyAgreement(with: P256.KeyAgreement.PrivateKey().publicKey)
        let response = EncryptedTendiesKeyResponse(ephemeralPublicKey: Data(repeating: 0, count: 65).base64EncodedString(),
                                                  salt: "not base64", wrappedKey: "")
        XCTAssertThrowsError(try response.publicKey())
        XCTAssertThrowsError(try response.unwrap(sharedSecret: secret,
            header: EncryptedTendiesEnvelope.header(for: packageID)))
    }

    func testCiphertextFileReadDoesNotProduceADecryptedLibraryCopy() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let source = root.appendingPathComponent("wallpaper.dynor")
        let original = try XCTUnwrap(Data(base64Encoded: encryptedBase64))
        try original.write(to: source)
        let envelope = try EncryptedTendiesEnvelope(contentsOf: source)
        XCTAssertEqual(envelope.packageID, packageID)
        XCTAssertEqual(try Data(contentsOf: source), original)
        XCTAssertEqual(try FileManager.default.contentsOfDirectory(atPath: root.path), ["wallpaper.dynor"])
    }

    func testLegacyLibraryKindsRemainDecodable() throws {
        XCTAssertEqual(try JSONDecoder().decode(ImportedKind.self, from: Data("\"tendies\"".utf8)), .tendies)
        XCTAssertEqual(try JSONDecoder().decode(ImportedKind.self, from: Data("\"image\"".utf8)), .image)
        XCTAssertEqual(try JSONDecoder().decode(ImportedKind.self, from: Data("\"encryptedTendies\"".utf8)), .encryptedTendies)
        XCTAssertTrue(ImportedKind.encryptedTendies.isTendies)
        XCTAssertFalse(ImportedKind.image.isTendies)
    }
}
