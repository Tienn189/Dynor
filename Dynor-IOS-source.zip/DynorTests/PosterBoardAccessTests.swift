import Foundation
import XCTest
@testable import Dynor

final class PosterBoardAccessTests: XCTestCase {
    private let identifier = "A34B07D4-CA70-44F4-B085-15ADB25A49BB"

    func testContainerHintsAreLimitedToAnImmediateUUIDChildOfAllowedRoots() {
        let application = "/var/mobile/Containers/Data/Application/" + identifier
        XCTAssertEqual(PosterBoardAccess.validatedContainerURL(application)?.path, application)
        XCTAssertEqual(PosterBoardAccess.validatedContainerURL("/private" + application)?.path, application)
        let daemon = "/var/mobile/Containers/Data/InternalDaemon/" + identifier
        XCTAssertEqual(PosterBoardAccess.validatedContainerURL(daemon)?.path, daemon)

        for path in [
            "/var/mobile/Containers/Data/Application/not-a-uuid",
            application + "/Library",
            application + "/../" + identifier,
            "/var/mobile/Containers/Data/ApplicationExtra/" + identifier,
            "/var/mobile/Containers/Shared/AppGroup/" + identifier,
            "/var/mobile/Library/" + identifier,
            "var/mobile/Containers/Data/Application/" + identifier
        ] {
            XCTAssertNil(PosterBoardAccess.validatedContainerURL(path), path)
        }
    }

    #if targetEnvironment(simulator)
    func testSimulatorCannotEnterTheDeviceWriteClosure() {
        var entered = false
        XCTAssertNotNil(PosterBoardAccess.prerequisiteWarning)
        XCTAssertThrowsError(try PosterBoardAccess.withAccess(toPosterBoard: { _ in entered = true }))
        XCTAssertFalse(entered)
    }
    #endif
}
