import Foundation
import XCTest
@testable import Dynor

/// Exercises the filesystem transaction using temporary directories only.
/// These tests do not acquire a sandbox extension or claim device installation.
final class PosterBoardDescriptorWriterTests: XCTestCase {
    private let fm = FileManager.default
    private let collections = "com.apple.WallpaperKit.CollectionsPoster"
    private let preferencesName = "com.apple.PosterBoard.unprotectedUserDefaults.plist"
    private var work: URL!
    private var container: URL!

    override func setUpWithError() throws {
        work = fm.temporaryDirectory.appendingPathComponent("DynorWriterTests-" + UUID().uuidString, isDirectory: true)
        container = work.appendingPathComponent("PosterBoard", isDirectory: true)
        try fm.createDirectory(at: container, withIntermediateDirectories: true)
    }

    override func tearDownWithError() throws {
        try fm.removeItem(at: work)
    }

    private func storeVersion(_ version: String) -> URL {
        container.appendingPathComponent("Library/Application Support/PRBPosterExtensionDataStore/" + version, isDirectory: true)
    }

    private func provider(_ identifier: String, version: String = "61") throws -> URL {
        let directory = storeVersion(version).appendingPathComponent("Extensions/" + identifier, isDirectory: true)
        try fm.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }

    private func descriptor(files: [String: Data]) throws -> URL {
        let directory = work.appendingPathComponent("Source-" + UUID().uuidString, isDirectory: true)
        try fm.createDirectory(at: directory, withIntermediateDirectories: true)
        for (relative, bytes) in files {
            let file = directory.appendingPathComponent(relative)
            try fm.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
            try bytes.write(to: file)
        }
        return directory
    }

    private func children(_ directory: URL) throws -> [URL] {
        try fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
    }

    private func writePreferences(_ value: Any) throws -> (url: URL, data: Data) {
        let directory = container.appendingPathComponent("Library/Preferences", isDirectory: true)
        try fm.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = directory.appendingPathComponent(preferencesName)
        let data = try PropertyListSerialization.data(fromPropertyList: value, format: .binary, options: 0)
        try data.write(to: url)
        return (url, data)
    }

    func testInstallPreservesExistingDescriptorsAndUnrelatedPreferences() throws {
        let target = try provider(collections).appendingPathComponent("descriptors", isDirectory: true)
        let existing = target.appendingPathComponent("ORIGINAL", isDirectory: true)
        try fm.createDirectory(at: existing, withIntermediateDirectories: true)
        try Data("keep existing wallpaper".utf8).write(to: existing.appendingPathComponent("providerInfo.plist"))
        let existingManifest = try PosterBoardDescriptorWriter.manifest(at: existing)
        let preferences = try writePreferences([
            "UnrelatedUserChoice": "preserve",
            "PersistedPosterContainerBundleIdentifiers": ["com.apple.ExistingProvider"],
            "OpaquePayload": Data([0, 1, 2, 255])
        ])
        let source = try descriptor(files: [
            "providerInfo.plist": Data("new provider".utf8),
            "versions/1/Wallpaper.plist": Data("new wallpaper".utf8),
            ".hidden-metadata": Data([7, 8, 9])
        ])
        let expected = try PosterBoardDescriptorWriter.manifest(at: source)

        let verifiedCount = try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: source)], log: { _ in }, progress: { _ in })

        XCTAssertEqual(verifiedCount, 3)
        XCTAssertEqual(try PosterBoardDescriptorWriter.manifest(at: existing), existingManifest)
        let additions = try children(target).filter { $0.lastPathComponent != "ORIGINAL" }
        let installed = try XCTUnwrap(additions.first)
        XCTAssertEqual(additions.count, 1)
        XCTAssertNotNil(UUID(uuidString: installed.lastPathComponent))
        XCTAssertEqual(try PosterBoardDescriptorWriter.manifest(at: installed), expected)
        XCTAssertEqual(try PosterBoardDescriptorWriter.manifest(at: source), expected)
        let values = try XCTUnwrap(PropertyListSerialization.propertyList(
            from: Data(contentsOf: preferences.url), format: nil) as? [String: Any])
        XCTAssertEqual(values["UnrelatedUserChoice"] as? String, "preserve")
        XCTAssertEqual(values["PersistedPosterContainerBundleIdentifiers"] as? [String], ["com.apple.ExistingProvider"])
        XCTAssertEqual(values["OpaquePayload"] as? Data, Data([0, 1, 2, 255]))
        XCTAssertEqual(values["PBF_RESET_FILE_PROTECTIONS"] as? Bool, true)
        XCTAssertEqual(values["PBF_LOCALE_DID_CHANGE"] as? Bool, true)
    }

    func testMissingSecondProviderRollsBackOnlyThisTransactionsAdditions() throws {
        let target = try provider(collections).appendingPathComponent("descriptors", isDirectory: true)
        let existing = target.appendingPathComponent("PREVIOUS", isDirectory: true)
        try fm.createDirectory(at: existing, withIntermediateDirectories: true)
        try Data("original".utf8).write(to: existing.appendingPathComponent("Wallpaper.plist"))
        let original = try PosterBoardDescriptorWriter.manifest(at: existing)
        let preferences = try writePreferences(["Unrelated": "original"])
        let first = try descriptor(files: ["Wallpaper.plist": Data("first".utf8)])
        let second = try descriptor(files: ["Wallpaper.plist": Data("second".utf8)])

        XCTAssertThrowsError(try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: first), (ext: "com.apple.MissingPosterProvider", url: second)],
            log: { _ in }, progress: { _ in }))

        XCTAssertEqual(try children(target).map(\.lastPathComponent), ["PREVIOUS"])
        XCTAssertEqual(try PosterBoardDescriptorWriter.manifest(at: existing), original)
        XCTAssertEqual(try Data(contentsOf: preferences.url), preferences.data)
        XCTAssertTrue(fm.fileExists(atPath: first.appendingPathComponent("Wallpaper.plist").path))
        XCTAssertTrue(fm.fileExists(atPath: second.appendingPathComponent("Wallpaper.plist").path))
    }

    func testAliasesChooseProvidersPresentOnDeviceWithoutInventingProviderDirectories() throws {
        let aliases = [
            ("com.apple.WallpaperKit.CollectionsPoster", "com.apple.Posters.CollectionsPosterApp"),
            ("com.apple.MercuryPoster", "com.apple.Posters.MercuryPosterApp")
        ]
        let source = try descriptor(files: ["Wallpaper.plist": Data("alias".utf8)])
        let expected = try PosterBoardDescriptorWriter.manifest(at: source)
        for (requested, installedAlias) in aliases {
            let actualProvider = try provider(installedAlias)
            let count = try PosterBoardDescriptorWriter(container: container).install(
                descriptors: [(ext: requested, url: source)], log: { _ in }, progress: { _ in })
            XCTAssertEqual(count, 1)
            let destinations = try children(actualProvider.appendingPathComponent("descriptors"))
            XCTAssertEqual(destinations.count, 1)
            XCTAssertEqual(try PosterBoardDescriptorWriter.manifest(at: XCTUnwrap(destinations.first)), expected)
            let invented = actualProvider.deletingLastPathComponent().appendingPathComponent(requested)
            XCTAssertFalse(fm.fileExists(atPath: invented.path))
        }
    }

    func testDatastoreUsesHighestNumericVersionWithAnExtensionsDirectory() throws {
        let old = try provider(collections, version: "61")
        let current = try provider(collections, version: "100")
        let named = try provider(collections, version: "newest")
        // A higher version without Extensions is not a usable datastore.
        try fm.createDirectory(at: storeVersion("101"), withIntermediateDirectories: true)
        let source = try descriptor(files: ["Wallpaper.plist": Data("versioned".utf8)])

        _ = try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: source)], log: { _ in }, progress: { _ in })

        XCTAssertEqual(try children(current.appendingPathComponent("descriptors")).count, 1)
        XCTAssertFalse(fm.fileExists(atPath: old.appendingPathComponent("descriptors").path))
        XCTAssertFalse(fm.fileExists(atPath: named.appendingPathComponent("descriptors").path))
    }

    func testManifestMatchesKnownSHA256AndDetectsSameLengthChangesBeyondFirstChunk() throws {
        var payload = Data(repeating: 0x41, count: 2 * 64 * 1024 + 17)
        let source = try descriptor(files: ["abc": Data("abc".utf8), "versions/1/asset": payload])
        let before = try PosterBoardDescriptorWriter.manifest(at: source)
        let knownDigest = Data([
            0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea,
            0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
            0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c,
            0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad
        ])
        XCTAssertEqual(before["abc"], knownDigest)
        payload[payload.count - 1] = 0x42
        try payload.write(to: source.appendingPathComponent("versions/1/asset"))
        let after = try PosterBoardDescriptorWriter.manifest(at: source)
        XCTAssertEqual(before["abc"], after["abc"])
        XCTAssertNotEqual(before["versions/1/asset"], after["versions/1/asset"])
        XCTAssertNotEqual(before, after)
    }

    func testManifestIncludesRelativeNamesAndHiddenFiles() throws {
        let source = try descriptor(files: ["one/asset": Data([1, 2]), ".metadata": Data([3])])
        let before = try PosterBoardDescriptorWriter.manifest(at: source)
        XCTAssertEqual(Set(before.keys), Set(["one/asset", ".metadata"]))
        try fm.moveItem(at: source.appendingPathComponent("one/asset"), to: source.appendingPathComponent("renamed"))
        let after = try PosterBoardDescriptorWriter.manifest(at: source)
        XCTAssertEqual(before["one/asset"], after["renamed"])
        XCTAssertNotEqual(before, after)
    }

    func testManifestRejectsAnUnreadableSubtreeInsteadOfReturningPartialHashes() throws {
        let source = try descriptor(files: [
            "readable": Data("visible".utf8),
            "restricted/asset": Data("must not be silently omitted".utf8)
        ])
        let restricted = source.appendingPathComponent("restricted", isDirectory: true)
        try fm.setAttributes([.posixPermissions: 0o000], ofItemAtPath: restricted.path)
        defer { try? fm.setAttributes([.posixPermissions: 0o700], ofItemAtPath: restricted.path) }
        guard !fm.isReadableFile(atPath: restricted.path) else {
            throw XCTSkip("This test needs a process that respects POSIX directory permissions.")
        }
        XCTAssertThrowsError(try PosterBoardDescriptorWriter.manifest(at: source))
    }

    func testSymlinkInSourceIsRejectedBeforeAnyDescriptorIsInstalled() throws {
        let target = try provider(collections).appendingPathComponent("descriptors", isDirectory: true)
        try fm.createDirectory(at: target, withIntermediateDirectories: true)
        let source = try descriptor(files: ["Wallpaper.plist": Data("descriptor".utf8)])
        let outside = try descriptor(files: ["secret": Data("untouched".utf8)])
        let original = try PosterBoardDescriptorWriter.manifest(at: outside)
        try fm.createSymbolicLink(at: source.appendingPathComponent("linked-assets"), withDestinationURL: outside)

        XCTAssertThrowsError(try PosterBoardDescriptorWriter.manifest(at: source))
        XCTAssertThrowsError(try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: source)], log: { _ in }, progress: { _ in }))
        XCTAssertTrue(try children(target).isEmpty)
        XCTAssertEqual(try PosterBoardDescriptorWriter.manifest(at: outside), original)
    }

    func testSymlinkProviderAndDescriptorTargetsCannotRedirectWrites() throws {
        let outside = try descriptor(files: ["existing": Data("untouched".utf8)])
        let original = try PosterBoardDescriptorWriter.manifest(at: outside)
        let source = try descriptor(files: ["Wallpaper.plist": Data("descriptor".utf8)])
        let actualProvider = try provider(collections)
        try fm.removeItem(at: actualProvider)
        try fm.createSymbolicLink(at: actualProvider, withDestinationURL: outside)
        XCTAssertThrowsError(try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: source)], log: { _ in }, progress: { _ in }))
        XCTAssertEqual(try PosterBoardDescriptorWriter.manifest(at: outside), original)

        try fm.removeItem(at: actualProvider)
        try fm.createDirectory(at: actualProvider, withIntermediateDirectories: true)
        try fm.createSymbolicLink(at: actualProvider.appendingPathComponent("descriptors"), withDestinationURL: outside)
        XCTAssertThrowsError(try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: source)], log: { _ in }, progress: { _ in }))
        XCTAssertEqual(try PosterBoardDescriptorWriter.manifest(at: outside), original)
    }

    func testEmptyDescriptorIsRejectedAndPreferencesAreNotTouched() throws {
        let target = try provider(collections).appendingPathComponent("descriptors", isDirectory: true)
        try fm.createDirectory(at: target, withIntermediateDirectories: true)
        let source = try descriptor(files: [:])
        let preferences = try writePreferences(["Unrelated": "original"])
        XCTAssertThrowsError(try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: source)], log: { _ in }, progress: { _ in }))
        XCTAssertTrue(try children(target).isEmpty)
        XCTAssertEqual(try Data(contentsOf: preferences.url), preferences.data)
    }

    func testMalformedPreferencesArePreservedAndReloadFailureIsReportedSeparately() throws {
        let target = try provider(collections).appendingPathComponent("descriptors", isDirectory: true)
        let source = try descriptor(files: ["Wallpaper.plist": Data("descriptor".utf8)])
        let preferences = try writePreferences(["not", "a", "dictionary"])
        var messages: [String] = []

        let count = try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: source)], log: { messages.append($0) }, progress: { _ in })

        XCTAssertEqual(count, 1)
        XCTAssertEqual(try children(target).count, 1)
        XCTAssertEqual(try Data(contentsOf: preferences.url), preferences.data)
        XCTAssertTrue(messages.contains { $0.contains("chưa yêu cầu nạp lại được") })
    }

    func testSymlinkPreferencesArePreservedWithoutFollowingTheTarget() throws {
        _ = try provider(collections)
        let source = try descriptor(files: ["Wallpaper.plist": Data("descriptor".utf8)])
        let preferences = try writePreferences(["Unrelated": "keep"])
        let outside = work.appendingPathComponent("outside-preferences.plist")
        try fm.moveItem(at: preferences.url, to: outside)
        try fm.createSymbolicLink(at: preferences.url, withDestinationURL: outside)
        var messages: [String] = []

        let count = try PosterBoardDescriptorWriter(container: container).install(
            descriptors: [(ext: collections, url: source)], log: { messages.append($0) }, progress: { _ in })

        XCTAssertEqual(count, 1)
        XCTAssertEqual(try Data(contentsOf: outside), preferences.data)
        XCTAssertEqual(try fm.destinationOfSymbolicLink(atPath: preferences.url.path), outside.path)
        XCTAssertTrue(messages.contains { $0.contains("chưa yêu cầu nạp lại được") })
    }
}
