import Foundation
import XCTest
@testable import Dynor

final class TendiesDescriptorCatalogTests: XCTestCase {
    private let collections = "com.apple.WallpaperKit.CollectionsPoster"
    private let mercury = "com.apple.MercuryPoster"
    private let descriptorIdentifier = "com.apple.posterkit.provider.descriptor.identifier"
    private let suggestionMetadata = "com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist"

    private func temporaryDirectory() throws -> URL {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        addTeardownBlock { try? FileManager.default.removeItem(at: directory) }
        return directory
    }

    private func write(_ text: String, to path: String, in directory: URL) throws {
        let target = directory.appendingPathComponent(path)
        try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
        try Data(text.utf8).write(to: target)
    }

    private func writePlist(_ plist: [String: Any], to path: String, in directory: URL) throws {
        let target = directory.appendingPathComponent(path)
        try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
        try PropertyListSerialization.data(fromPropertyList: plist, format: .binary, options: 0).write(to: target)
    }

    private func readPlist(at path: String, in directory: URL) throws -> [String: Any] {
        let data = try Data(contentsOf: directory.appendingPathComponent(path))
        return try XCTUnwrap(PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any])
    }

    func testModernExportsAlsoTargetLegacyPosterExtensions() {
        let modernCollections = "com.apple.Posters.CollectionsPosterApp"
        let modernMercury = "com.apple.Posters.MercuryPosterApp"
        XCTAssertEqual(TendiesDescriptorCatalog.destinationExtensions(for: modernCollections), [modernCollections, collections])
        XCTAssertEqual(TendiesDescriptorCatalog.destinationExtensions(for: modernMercury), [modernMercury, mercury])
        XCTAssertEqual(TendiesDescriptorCatalog.destinationExtensions(for: collections), [collections, modernCollections])
        XCTAssertEqual(TendiesDescriptorCatalog.destinationExtensions(for: mercury), [mercury, modernMercury])
    }

    func testFullContainerFindsMultipleDescriptorsAndSkipsMacMetadata() throws {
        let root = try temporaryDirectory()
        let prefix = "container/Library/Application Support/PRBPosterExtensionDataStore/61/Extensions/"
        try write("v6x.colorA", to: prefix + mercury + "/descriptors/FIRST/" + descriptorIdentifier, in: root)
        try write("7400", to: prefix + collections + "/descriptors/SECOND/" + descriptorIdentifier, in: root)
        try write("999", to: "__MACOSX/FAKE/" + descriptorIdentifier, in: root)
        let descriptors = TendiesDescriptorCatalog.findDescriptorsWithExtensions(in: root, defaultExt: collections)
        XCTAssertEqual(descriptors.count, 2)
        XCTAssertEqual(Set(descriptors.map { $0.url.lastPathComponent }), ["FIRST", "SECOND"])
        XCTAssertEqual(Set(descriptors.map { $0.ext }), [mercury, collections])
    }

    func testUnrelatedParentAndWrapperNamesDoNotOverrideDescriptorIdentity() throws {
        let temp = try temporaryDirectory()
        let root = temp.appendingPathComponent("video/Extensions/com.example.wrapper/extracted", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try write("7400", to: "collections/REAL/" + descriptorIdentifier, in: root)
        let descriptors = TendiesDescriptorCatalog.findDescriptorsWithExtensions(in: root, defaultExt: collections)
        XCTAssertEqual(descriptors.count, 1)
        XCTAssertEqual(descriptors.first?.ext, collections)

        // The dotted outer wrapper is not a system extension. Use the actual
        // descriptor marker to recognize Mercury instead of rejecting the archive.
        try write("v6x.colorA", to: "Extensions/com.example.wrapper/descriptors/MERCURY/" + descriptorIdentifier, in: root)
        let wrapped = TendiesDescriptorCatalog.findDescriptorsWithExtensions(in: root, defaultExt: collections)
        XCTAssertEqual(wrapped.first { $0.url.lastPathComponent == "MERCURY" }?.ext, mercury)
    }

    func testMetadataKeepsSuggestionAndWallpaperIdentifiersTogether() throws {
        let root = try temporaryDirectory()
        try writePlist(["$objects": ["7400.DYNAMIC", collections]], to: suggestionMetadata, in: root)
        try write("7400.DYNAMIC", to: descriptorIdentifier, in: root)
        try writePlist(["identifier": 7400, "name": "Wallpaper"], to: "versions/0/Wallpaper.plist", in: root)
        let original = try Data(contentsOf: root.appendingPathComponent("versions/0/Wallpaper.plist"))
        try TendiesDescriptorCatalog.updatePlistIdentifiers(in: root, randomizedID: 55555)
        XCTAssertEqual(try Data(contentsOf: root.appendingPathComponent("versions/0/Wallpaper.plist")), original)
        XCTAssertEqual(try String(contentsOf: root.appendingPathComponent(descriptorIdentifier), encoding: .utf8), "7400.DYNAMIC")
        XCTAssertEqual(TendiesDescriptorCatalog.findDescriptorsWithExtensions(in: root, defaultExt: mercury).first?.ext, collections)
    }

    func testNumericTemplateIdentifiersChangeTogetherAndSymbolsStayIntact() throws {
        let root = try temporaryDirectory()
        try write("7400", to: descriptorIdentifier, in: root)
        try write("v6x.colorA", to: "versions/0/" + descriptorIdentifier, in: root)
        try writePlist(["wallpaperRepresentingIdentifier": 7400, "name": "Template"],
                      to: "com.apple.posterkit.provider.contents.userInfo", in: root)
        try writePlist(["identifier": 7400, "name": "Template"], to: "versions/0/Wallpaper.plist", in: root)
        try TendiesDescriptorCatalog.updatePlistIdentifiers(in: root, randomizedID: 55555)
        XCTAssertEqual(try String(contentsOf: root.appendingPathComponent(descriptorIdentifier), encoding: .utf8), "55555")
        XCTAssertEqual(try String(contentsOf: root.appendingPathComponent("versions/0/" + descriptorIdentifier), encoding: .utf8), "v6x.colorA")
        XCTAssertEqual(try readPlist(at: "versions/0/Wallpaper.plist", in: root)["identifier"] as? Int, 55555)
        XCTAssertEqual(try readPlist(at: "com.apple.posterkit.provider.contents.userInfo", in: root)["wallpaperRepresentingIdentifier"] as? Int, 55555)
    }

    func testEmptyDescriptorIsNotInstallable() throws {
        let root = try temporaryDirectory()
        try FileManager.default.createDirectory(at: root.appendingPathComponent("EMPTY/versions"), withIntermediateDirectories: true)
        XCTAssertTrue(TendiesDescriptorCatalog.findDescriptorsWithExtensions(in: root, defaultExt: collections).isEmpty)
    }
}
