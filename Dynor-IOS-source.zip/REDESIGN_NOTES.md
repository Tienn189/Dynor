# Dynor redesign

- PosterBoard: removed verbose diagnostic card and source footer, replaced with compact hero and installation actions.
- Settings: device information, iOS compatibility matrix, activity log and existing credits.
- Library: validated .tendies archives display a candidate image preview; encrypted .dynor packages retain a placeholder until decrypted.
- Install: on successful write/readback, requests PosterBoard foreground and shows follow-up instructions. iOS controls whether system UI can open; cannot force the multitasking switcher.
- Activity log: local UserDefaults history (up to 150 events).

Important: successful file verification is not proof iOS applied the wallpaper. No Xcode compilation or device test performed here.
