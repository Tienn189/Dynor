#!/usr/bin/env python3
"""Check configuration and signed entitlements of an IPA on macOS."""
import pathlib, sys, zipfile, tempfile, plistlib, subprocess, shutil
EXPECTED_BUNDLE = "com.dynor.wallpapers"
EXPECTED_GROUP = "group.3fae94347e97b250.4"
if len(sys.argv) != 2:
    sys.exit("Usage: python3 scripts/check_signed_ipa.py /path/to/LC-signed.ipa")
if shutil.which("codesign") is None or sys.platform != "darwin":
    sys.exit("Signed-entitlement verification requires macOS codesign; do not treat this as a passing check.")
with tempfile.TemporaryDirectory() as temp:
    with zipfile.ZipFile(sys.argv[1]) as archive:
        names = archive.namelist()
        apps = {n.split("/")[1] for n in names if n.startswith("Payload/") and len(n.split("/")) > 2 and n.split("/")[1].endswith(".app")}
        if len(apps) != 1: sys.exit("Expected exactly one Payload/*.app")
        prefix = "Payload/" + apps.pop() + "/"
        for name in names:
            if not name.startswith(prefix): continue
            target = pathlib.Path(temp) / name
            if not target.resolve().is_relative_to(pathlib.Path(temp).resolve()): sys.exit("Unsafe archive path")
            if name.endswith("/"): target.mkdir(parents=True,exist_ok=True)
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(archive.read(name))
        app = next((pathlib.Path(temp)/"Payload").glob("*.app"))
        info = plistlib.loads((app/"Info.plist").read_bytes())
        print("Bundle ID:",info.get("CFBundleIdentifier"))
        print("Configured group:",info.get("DynorAppGroupIdentifier"))
        if info.get("CFBundleIdentifier") != EXPECTED_BUNDLE: sys.exit("FAIL: Bundle ID mismatch")
        if info.get("DynorAppGroupIdentifier") != EXPECTED_GROUP: sys.exit("FAIL: Built Info.plist uses unexpected group")
        result = subprocess.run(["codesign","-d","--entitlements", "-",str(app)],capture_output=True)
        if result.returncode: sys.exit("FAIL: Cannot read signed entitlements: "+result.stderr.decode(errors="replace"))
        data = result.stdout
        try: entitlements=plistlib.loads(data)
        except Exception as exc: sys.exit(f"FAIL: Cannot parse signed entitlements: {exc}")
        groups=entitlements.get("com.apple.security.application-groups",[])
        print("Signed App Groups:",groups)
        if EXPECTED_GROUP not in groups: sys.exit("FAIL: LCSsign signature does not grant required group")
        verify=subprocess.run(["codesign","--verify","--strict","--verbose=2",str(app)],capture_output=True,text=True)
        if verify.returncode: sys.exit("FAIL: codesign verification: "+verify.stderr)
        print("PASS: Bundle ID, Info.plist App Group, signed App Group and codesign verified")
        print("NOTE: This does not verify actual PosterBoard installation on iOS.")
