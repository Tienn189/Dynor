#!/usr/bin/env python3
"""Check an installed/exported Dynor .app's signature and App Group provisioning on macOS."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path
import plistlib
import subprocess
import sys


def validate_entitlements(info: dict, entitlements: dict, profile: dict) -> str:
    if info.get("CFBundleIdentifier") != "com.dynor.wallpapers":
        raise ValueError("Expected Bundle ID com.dynor.wallpapers.")
    group = info.get("DynorAppGroupIdentifier")
    if not isinstance(group, str) or not group.startswith("group.") or "$" in group:
        raise ValueError("Info.plist has no resolved DynorAppGroupIdentifier.")
    if group not in entitlements.get("com.apple.security.application-groups", []):
        raise ValueError(f"Signed app is missing App Group entitlement {group}.")
    allowed = profile.get("Entitlements", {})
    if group not in allowed.get("com.apple.security.application-groups", []):
        raise ValueError(f"Provisioning profile does not authorize App Group {group}.")
    app_id = entitlements.get("application-identifier", "")
    if not app_id.endswith(".com.dynor.wallpapers"):
        raise ValueError("Signed application-identifier does not match Dynor's Bundle ID.")
    profile_id = allowed.get("application-identifier", "")
    if profile_id != app_id and not (profile_id.endswith(".*") and app_id.startswith(profile_id[:-1])):
        raise ValueError("Provisioning application-identifier does not match the signed app.")
    expiration = profile.get("ExpirationDate")
    if not isinstance(expiration, datetime):
        raise ValueError("Provisioning profile has no expiration date.")
    if expiration.replace(tzinfo=timezone.utc) <= datetime.now(timezone.utc):
        raise ValueError("Provisioning profile has expired.")
    return group


def verify_signed_app(app: Path) -> None:
    if sys.platform != "darwin":
        raise RuntimeError("Signature verification requires macOS codesign and security.")
    app = app.resolve()
    profile_path = app / "embedded.mobileprovision"
    if app.suffix != ".app" or not profile_path.is_file():
        raise ValueError("Provide a signed Dynor.app containing embedded.mobileprovision.")
    subprocess.run(["codesign", "--verify", "--deep", "--strict", str(app)], check=True)
    signed = subprocess.check_output(["codesign", "--display", "--entitlements", "-", str(app)])
    profile = subprocess.check_output(["security", "cms", "-D", "-i", str(profile_path)])
    group = validate_entitlements(plistlib.loads((app / "Info.plist").read_bytes()),
                                  plistlib.loads(signed), plistlib.loads(profile))
    print(f"Signature and App Group provisioning verified: {group}")
    print("This does not verify PosterBoard writes or wallpaper selection on a physical iPhone.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("app", type=Path, help="Signed .app (extract Payload/Dynor.app from the signed IPA)")
    args = parser.parse_args()
    try:
        verify_signed_app(args.app)
    except (ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        parser.exit(1, f"Verification failed: {error}\n")
