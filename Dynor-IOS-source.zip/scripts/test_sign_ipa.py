"""Pure provisioning/signing preflight tests; no certificate private keys used."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from sign_ipa import SigningError, decode_secret, prepare_entitlements, select_identity, validate_input_archive


class ProvisioningSigningTests(unittest.TestCase):
    def setUp(self):
        self.info = {
            "CFBundleIdentifier": "com.dynor.wallpapers",
            "CFBundleSupportedPlatforms": ["iPhoneOS"],
            "DynorAppGroupIdentifier": "group.com.dynor.wallpapers",
        }
        self.profile = {
            "ApplicationIdentifierPrefix": ["APP_PREFIX"],
            "TeamIdentifier": ["TEAM_ID"],
            "Platform": ["iOS"],
            "ProvisionedDevices": ["registered-test-device"],
            "ExpirationDate": datetime.now(timezone.utc) + timedelta(days=1),
            "DeveloperCertificates": [b"public test certificate"],
            "Entitlements": {
                "application-identifier": "APP_PREFIX.com.dynor.wallpapers",
                "com.apple.developer.team-identifier": "TEAM_ID",
                "com.apple.security.application-groups": ["group.com.dynor.wallpapers", "group.unrelated.app"],
                "keychain-access-groups": ["APP_PREFIX.*"],
                "get-task-allow": True,
                "unrelated-capability": True,
            },
        }

    def test_request_only_own_group_and_resolve_default_keychain_group(self):
        before = deepcopy(self.profile)
        result = prepare_entitlements(self.info, self.profile)
        self.assertEqual(result["com.apple.security.application-groups"], ["group.com.dynor.wallpapers"])
        self.assertEqual(result["keychain-access-groups"], ["APP_PREFIX.com.dynor.wallpapers"])
        self.assertEqual(result["com.apple.developer.team-identifier"], "TEAM_ID")
        self.assertNotIn("unrelated-capability", result)
        self.assertEqual(self.profile, before)

    def test_missing_group_is_rejected_not_synthesized(self):
        self.profile["Entitlements"]["com.apple.security.application-groups"] = []
        with self.assertRaisesRegex(ValueError, "App Group"):
            prepare_entitlements(self.info, self.profile)

    def test_wildcard_app_profile_is_rejected(self):
        self.profile["Entitlements"]["application-identifier"] = "APP_PREFIX.*"
        with self.assertRaisesRegex(ValueError, "explicitly authorize"):
            prepare_entitlements(self.info, self.profile)

    def test_wrong_team_is_rejected(self):
        self.profile["TeamIdentifier"] = ["ANOTHER_TEAM"]
        with self.assertRaisesRegex(ValueError, "team identifier"):
            prepare_entitlements(self.info, self.profile)

    def test_app_store_profile_cannot_be_presented_as_installable_ipa(self):
        self.profile.pop("ProvisionedDevices")
        with self.assertRaisesRegex(ValueError, "App Store"):
            prepare_entitlements(self.info, self.profile)

    def test_enterprise_profile_without_udids_is_accepted(self):
        self.profile.pop("ProvisionedDevices")
        self.profile["ProvisionsAllDevices"] = True
        self.assertTrue(prepare_entitlements(self.info, self.profile))

    def test_expired_naive_utc_profile_is_rejected(self):
        self.profile["ExpirationDate"] = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=1)
        with self.assertRaisesRegex(ValueError, "expired"):
            prepare_entitlements(self.info, self.profile)

    def test_simulator_app_cannot_be_signed_as_device_ipa(self):
        self.info["CFBundleSupportedPlatforms"] = ["iPhoneSimulator"]
        with self.assertRaisesRegex(ValueError, "Simulator"):
            prepare_entitlements(self.info, self.profile)

    def test_identity_must_match_profile_certificate(self):
        matching = hashlib.sha1(self.profile["DeveloperCertificates"][0]).hexdigest().upper()
        identity_output = f'  1) {"A" * 40} "Other identity"\n  2) {matching} "Matched identity"\n     2 valid identities found\n'
        self.assertEqual(select_identity(identity_output, self.profile), matching)
        with self.assertRaisesRegex(ValueError, "does not match"):
            select_identity(f'1) {"A" * 40} "Other identity"', self.profile)

    def test_base64_credentials_are_required_and_not_in_error_output(self):
        with patch.dict(os.environ, {"DYNOR_TEST_SECRET": ""}):
            with self.assertRaisesRegex(SigningError, "Missing GitHub Actions secret"):
                decode_secret("DYNOR_TEST_SECRET")
        with patch.dict(os.environ, {"DYNOR_TEST_SECRET": "invalid-sensitive-certificate-data!"}):
            with self.assertRaises(SigningError) as context:
                decode_secret("DYNOR_TEST_SECRET")
            self.assertNotIn("invalid-sensitive", str(context.exception))

    def test_input_archive_rejects_path_escape_before_ditto(self):
        with tempfile.TemporaryDirectory() as temporary:
            archive = Path(temporary) / "input.ipa"
            with zipfile.ZipFile(archive, "w") as bundle:
                bundle.writestr("Payload/Dynor.app/Info.plist", b"test")
            validate_input_archive(archive)
            with zipfile.ZipFile(archive, "w") as bundle:
                bundle.writestr("Payload/../../outside", b"test")
            with self.assertRaisesRegex(ValueError, "unsafe paths"):
                validate_input_archive(archive)


if __name__ == "__main__":
    unittest.main()
