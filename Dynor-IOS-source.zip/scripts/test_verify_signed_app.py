"""Signing preflight regressions: compiling or resigning must not imply native access."""
from datetime import datetime, timedelta, timezone
import unittest

from verify_signed_app import validate_entitlements


class SigningPreflightTests(unittest.TestCase):
    def setUp(self):
        self.group = "group.com.dynor.wallpapers"
        self.info = {"CFBundleIdentifier": "com.dynor.wallpapers", "DynorAppGroupIdentifier": self.group}
        self.entitlements = {
            "com.apple.security.application-groups": [self.group],
            "application-identifier": "ABCDE12345.com.dynor.wallpapers",
        }
        self.profile = {
            "Entitlements": dict(self.entitlements),
            "ExpirationDate": datetime.now(timezone.utc) + timedelta(days=1),
        }

    def test_authorized_matching_signature(self):
        self.assertEqual(validate_entitlements(self.info, self.entitlements, self.profile), self.group)

    def test_resigner_removed_app_group(self):
        self.entitlements.pop("com.apple.security.application-groups")
        with self.assertRaisesRegex(ValueError, "missing App Group"):
            validate_entitlements(self.info, self.entitlements, self.profile)

    def test_forged_entitlement_not_authorized_by_profile(self):
        self.profile["Entitlements"].pop("com.apple.security.application-groups")
        with self.assertRaisesRegex(ValueError, "does not authorize"):
            validate_entitlements(self.info, self.entitlements, self.profile)

    def test_wrong_bundle_id(self):
        self.info["CFBundleIdentifier"] = "com.other.app"
        with self.assertRaisesRegex(ValueError, "Bundle ID"):
            validate_entitlements(self.info, self.entitlements, self.profile)

    def test_expired_profile(self):
        self.profile["ExpirationDate"] = datetime.now(timezone.utc) - timedelta(days=1)
        with self.assertRaisesRegex(ValueError, "expired"):
            validate_entitlements(self.info, self.entitlements, self.profile)

    def test_unexpanded_build_setting(self):
        self.info["DynorAppGroupIdentifier"] = "$(DYNOR_APP_GROUP_IDENTIFIER)"
        with self.assertRaisesRegex(ValueError, "resolved"):
            validate_entitlements(self.info, self.entitlements, self.profile)

    def test_mismatched_profile_identifier(self):
        self.profile["Entitlements"]["application-identifier"] = "OTHER12345.com.dynor.wallpapers"
        with self.assertRaisesRegex(ValueError, "does not match"):
            validate_entitlements(self.info, self.entitlements, self.profile)


if __name__ == "__main__":
    unittest.main()
