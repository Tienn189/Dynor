#!/usr/bin/env python3
"""Sign Dynor's device IPA using an App Group enabled Apple provisioning profile.

Credentials come only from environment variables. No Apple account login or
network operation is performed. The temporary keychain is never made default
and the user's keychain search list is not changed.
"""
from __future__ import annotations

import argparse
import base64
import binascii
from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path, PurePosixPath
import plistlib
import re
import secrets
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile

from verify_signed_app import validate_entitlements

BUNDLE_ID = "com.dynor.wallpapers"


class SigningError(RuntimeError):
    pass


def prepare_entitlements(info: dict, profile: dict, now: datetime | None = None) -> dict:
    """Validate the provisioned identity and request only Dynor's capabilities."""
    if info.get("CFBundleIdentifier") != BUNDLE_ID:
        raise ValueError("Bundle ID must remain com.dynor.wallpapers.")
    if "iPhoneOS" not in info.get("CFBundleSupportedPlatforms", []):
        raise ValueError("Input must be an iPhoneOS device app, not a Simulator app.")
    group = info.get("DynorAppGroupIdentifier")
    if not isinstance(group, str) or not group.startswith("group.") or "$" in group:
        raise ValueError("Built Info.plist has no resolved DynorAppGroupIdentifier.")
    allowed = profile.get("Entitlements", {})
    if not isinstance(allowed, dict):
        raise ValueError("Provisioning profile has no Entitlements dictionary.")
    if group not in allowed.get("com.apple.security.application-groups", []):
        raise ValueError("Provisioning profile does not authorize Dynor's configured App Group.")
    prefixes = profile.get("ApplicationIdentifierPrefix", [])
    app_id = allowed.get("application-identifier")
    if not isinstance(prefixes, list) or not any(
        isinstance(prefix, str) and app_id == prefix + "." + BUNDLE_ID for prefix in prefixes
    ):
        raise ValueError("Profile must explicitly authorize com.dynor.wallpapers; wildcard App IDs are not accepted.")
    team = allowed.get("com.apple.developer.team-identifier")
    if not isinstance(team, str) or team not in profile.get("TeamIdentifier", []):
        raise ValueError("Provisioning profile team identifier is inconsistent.")
    expiration = profile.get("ExpirationDate")
    if not isinstance(expiration, datetime):
        raise ValueError("Provisioning profile has no expiration date.")
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    expiry = expiration if expiration.tzinfo else expiration.replace(tzinfo=timezone.utc)
    if expiry <= current:
        raise ValueError("Provisioning profile has expired.")
    devices = profile.get("ProvisionedDevices", [])
    if not profile.get("ProvisionsAllDevices") and not (
        isinstance(devices, list) and devices and all(isinstance(device, str) and device for device in devices)
    ):
        raise ValueError("Use a Development/Ad Hoc profile containing your iPhone UDID, or an Enterprise profile; App Store profiles cannot install this IPA directly.")
    if "iOS" not in profile.get("Platform", []):
        raise ValueError("Provisioning profile is not for iOS.")
    if not profile.get("DeveloperCertificates") or not all(
        isinstance(cert, bytes) and cert for cert in profile["DeveloperCertificates"]
    ):
        raise ValueError("Provisioning profile has no signing certificates.")
    entitlements = {
        "application-identifier": app_id,
        "com.apple.developer.team-identifier": team,
        "com.apple.security.application-groups": [group],
        "get-task-allow": bool(allowed.get("get-task-allow", False)),
    }
    # Dynor uses its default Keychain group. Resolve only the profile's allowed
    # prefix wildcard; do not copy unrelated apps' shared groups/capabilities.
    keychain_groups = allowed.get("keychain-access-groups", [])
    if any(isinstance(value, str) and (value == app_id or value.endswith(".*") and app_id.startswith(value[:-1]))
           for value in keychain_groups):
        entitlements["keychain-access-groups"] = [app_id]
    validate_entitlements(info, entitlements, profile)
    return entitlements


def select_identity(output: str, profile: dict) -> str:
    """Select a valid imported private-key identity authorized by this profile."""
    available = set(re.findall(r'^\s*\d+\)\s+([0-9A-Fa-f]{40})\s+"', output, flags=re.MULTILINE))
    permitted = {hashlib.sha1(cert).hexdigest().upper() for cert in profile.get("DeveloperCertificates", [])}
    matches = sorted(identity.upper() for identity in available if identity.upper() in permitted)
    if not matches:
        raise ValueError("P12 private key/certificate does not match a valid signing certificate in the provisioning profile.")
    return matches[0]


def decode_secret(name: str) -> bytes:
    value = os.environ.get(name, "")
    if not value.strip():
        raise SigningError(f"Missing GitHub Actions secret: {name}.")
    try:
        result = base64.b64decode("".join(value.split()), validate=True)
    except (ValueError, binascii.Error):
        raise SigningError(f"{name} is not valid Base64.") from None
    if not result:
        raise SigningError(f"{name} decoded to an empty file.")
    return result


def run(command: list[str], description: str) -> bytes:
    # Never print the command: import/keychain arguments include passwords.
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise SigningError(f"{description} failed (exit {result.returncode}). Check certificate password, profile and keychain compatibility.")
    return result.stdout


def validate_input_archive(ipa: Path) -> None:
    """Only unpack the bounded app structure produced by build_ipa.sh."""
    with zipfile.ZipFile(ipa) as archive:
        entries = archive.infolist()
        if not entries or len(entries) > 20_000 or sum(entry.file_size for entry in entries) > 1024 * 1024 * 1024:
            raise ValueError("Input IPA is empty or exceeds signing limits.")
        seen = set()
        for entry in entries:
            path = PurePosixPath(entry.filename)
            if (path.is_absolute() or ".." in path.parts or "\\" in entry.filename or
                    not path.parts or path.parts[0] != "Payload" or entry.filename in seen or
                    stat.S_ISLNK(entry.external_attr >> 16) or entry.flag_bits & 1):
                raise ValueError("Input IPA has unsupported or unsafe paths.")
            seen.add(entry.filename)


def sign_ipa(input_ipa: Path, output_ipa: Path) -> None:
    if sys.platform != "darwin":
        raise SigningError("IPA signing requires macOS codesign/security. Run this step on the GitHub macos runner.")
    input_ipa, output_ipa = input_ipa.resolve(), output_ipa.resolve()
    if input_ipa == output_ipa:
        raise SigningError("Signed output must be different from the unsigned input IPA.")
    output_ipa.parent.mkdir(parents=True, exist_ok=True)
    output_ipa.unlink(missing_ok=True)
    if not input_ipa.is_file():
        raise SigningError("Unsigned input IPA is missing. Run scripts/build_ipa.sh first.")
    certificate = decode_secret("DYNOR_CERTIFICATE_P12_BASE64")
    profile_data = decode_secret("DYNOR_PROVISION_PROFILE_BASE64")
    certificate_password = os.environ.get("DYNOR_CERTIFICATE_PASSWORD", "")
    validate_input_archive(input_ipa)
    with tempfile.TemporaryDirectory(prefix="dynor-sign-") as temporary:
        work = Path(temporary)
        certificate_path = work / "certificate.p12"
        profile_path = work / "profile.mobileprovision"
        certificate_path.write_bytes(certificate)
        profile_path.write_bytes(profile_data)
        certificate_path.chmod(0o600)
        profile_path.chmod(0o600)
        profile = plistlib.loads(run(["security", "cms", "-D", "-i", str(profile_path)], "Decode provisioning profile"))
        unpacked = work / "unpacked"
        run(["ditto", "-x", "-k", str(input_ipa), str(unpacked)], "Unpack IPA")
        apps = list((unpacked / "Payload").glob("*.app"))
        if len(apps) != 1:
            raise ValueError("Input IPA must contain exactly one Dynor.app.")
        app = apps[0]
        info = plistlib.loads((app / "Info.plist").read_bytes())
        entitlements = prepare_entitlements(info, profile)
        # Current Dynor links its native sources statically and has no nested
        # executable bundles. Refuse to leave future nested code unsigned.
        if any(app.rglob("*.framework")) or any(app.rglob("*.appex")) or any(app.rglob("*.dylib")):
            raise ValueError("Nested dynamic code needs an explicit signing order; this script supports the current static Dynor app only.")
        entitlements_path = work / "entitlements.plist"
        entitlements_path.write_bytes(plistlib.dumps(entitlements))
        shutil.copyfile(profile_path, app / "embedded.mobileprovision")
        keychain = work / "signing.keychain-db"
        keychain_password = secrets.token_urlsafe(32)
        created = False
        try:
            run(["security", "create-keychain", "-p", keychain_password, str(keychain)], "Create temporary keychain")
            created = True
            run(["security", "set-keychain-settings", "-lut", "21600", str(keychain)], "Configure temporary keychain")
            run(["security", "unlock-keychain", "-p", keychain_password, str(keychain)], "Unlock temporary keychain")
            run(["security", "import", str(certificate_path), "-k", str(keychain), "-P", certificate_password,
                 "-T", "/usr/bin/codesign"], "Import signing identity")
            run(["security", "set-key-partition-list", "-S", "apple-tool:,apple:,codesign:", "-s",
                 "-k", keychain_password, str(keychain)], "Authorize codesign access")
            identities = run(["security", "find-identity", "-v", "-p", "codesigning", str(keychain)], "Find signing identity").decode()
            identity = select_identity(identities, profile)
            run(["codesign", "--force", "--sign", identity, "--keychain", str(keychain), "--timestamp=none",
                 "--generate-entitlement-der", "--entitlements", str(entitlements_path), str(app)], "Sign Dynor app")
            run([sys.executable, str(Path(__file__).with_name("verify_signed_app.py")), str(app)], "Verify signed App Group and profile")
            staged_output = work / "Dynor-signed.ipa"
            run(["ditto", "-c", "-k", "--keepParent", str(unpacked / "Payload"), str(staged_output)], "Package signed IPA")
            with zipfile.ZipFile(staged_output) as archive:
                if archive.testzip() is not None:
                    raise SigningError("Signed IPA ZIP integrity check failed.")
            shutil.copyfile(staged_output, output_ipa)
        finally:
            if created:
                subprocess.run(["security", "delete-keychain", str(keychain)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"Signed IPA verified and packaged: {output_ipa}")
    print("Use a device included in this provisioning profile. Wallpaper installation still requires an iPhone test.")


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=root / "build/ipa/Dynor-unsigned.ipa")
    parser.add_argument("--output", type=Path, default=root / "build/ipa/Dynor-signed.ipa")
    arguments = parser.parse_args()
    try:
        sign_ipa(arguments.input, arguments.output)
    except (SigningError, ValueError, OSError, zipfile.BadZipFile, plistlib.InvalidFileException) as error:
        parser.exit(1, f"Signing failed: {error}\n")
