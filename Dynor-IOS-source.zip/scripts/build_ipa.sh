#!/bin/bash
# Build an unsigned device IPA. Signing and physical-device installation are separate checks.
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RUN_TESTS=yes
if [ "$#" -eq 1 ] && [ "$1" = "--skip-tests" ]; then
  RUN_TESTS=no
elif [ "$#" -ne 0 ]; then
  echo "Usage: bash scripts/build_ipa.sh [--skip-tests]" >&2
  exit 2
fi
if [ "$(uname -s)" != Darwin ]; then
  echo "iOS archive requires macOS with full Xcode; this machine cannot build an IPA." >&2
  exit 1
fi
for tool in xcodebuild xcrun xcodegen python3 ditto; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "Missing $tool. Install full Xcode and XcodeGen (brew install xcodegen)." >&2
    exit 1
  fi
done
cd "$SOURCE_DIR"
mkdir -p build/logs build/ipa
# A failed new run must not leave an older IPA looking like its output.
rm -f build/ipa/Dynor-unsigned.ipa
xcodebuild -version | tee build/logs/xcode-version.log
python3 scripts/verify_dependencies.py --source-root .
python3 -m unittest discover -s scripts -p 'test_*.py'
python3 scripts/prepare_icons.py --source-root .
xcodegen generate --spec project.yml

if [ "$RUN_TESTS" = yes ]; then
  xcrun simctl list devices available --json > build/simulators.json
  SIMULATOR_ID="$(python3 - <<'PY'
import json
from pathlib import Path
import re
devices = json.loads(Path("build/simulators.json").read_text())["devices"]
candidates = []
for runtime, entries in devices.items():
    if ".iOS-" not in runtime:
        continue
    version = tuple(int(n) for n in re.findall(r"\d+", runtime.rsplit(".iOS-", 1)[1]))
    if not version or version[0] < 18:
        continue
    for device in entries:
        if device.get("isAvailable") and device.get("name", "").startswith("iPhone"):
            candidates.append((version, device.get("state") == "Booted", device["udid"]))
if not candidates:
    raise SystemExit("Install an iOS 18+ iPhone Simulator runtime in Xcode Settings > Components.")
print(max(candidates)[2])
PY
  )"
  # Xcode refuses to overwrite an existing result bundle; retain previous runs.
  RESULT_PATH="build/DynorTests-$(date -u +%Y%m%dT%H%M%SZ)-$$.xcresult"
  xcodebuild -project Dynor.xcodeproj -scheme Dynor -configuration Debug \
    -sdk iphonesimulator -destination "platform=iOS Simulator,id=$SIMULATOR_ID" \
    -destination-timeout 120 -parallel-testing-enabled NO \
    -derivedDataPath build/TestDerivedData -resultBundlePath "$RESULT_PATH" \
    CODE_SIGNING_ALLOWED=NO test 2>&1 | tee build/logs/dynor-tests.log
fi

xcodebuild -project Dynor.xcodeproj -scheme Dynor -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath build/DerivedData -archivePath build/Dynor.xcarchive \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" DEVELOPMENT_TEAM="" \
  archive 2>&1 | tee build/logs/dynor-build.log

python3 - <<'PY'
from pathlib import Path
import plistlib
import subprocess
import tempfile

apps = list(Path("build/Dynor.xcarchive/Products/Applications").glob("*.app"))
if len(apps) != 1:
    raise SystemExit("Archive must contain exactly one native iOS app.")
app = apps[0]
info = plistlib.loads((app / "Info.plist").read_bytes())
if info.get("CFBundleIdentifier") != "com.dynor.wallpapers":
    raise SystemExit("Bundle ID changed; refusing to package.")
if "iPhoneOS" not in info.get("CFBundleSupportedPlatforms", []):
    raise SystemExit("Archive is not an iPhoneOS device app.")
group = info.get("DynorAppGroupIdentifier")
if not isinstance(group, str) or not group.startswith("group.") or "$" in group:
    raise SystemExit("DynorAppGroupIdentifier was not resolved in the built Info.plist.")
architectures = subprocess.check_output(["lipo", "-archs", str(app / info["CFBundleExecutable"])], text=True).split()
if "arm64" not in architectures:
    raise SystemExit("Device executable is missing arm64.")
ipa = Path("build/ipa/Dynor-unsigned.ipa").resolve()
with tempfile.TemporaryDirectory(prefix="dynor-ipa-") as temporary:
    payload = Path(temporary) / "Payload"
    payload.mkdir()
    subprocess.run(["ditto", str(app), str(payload / app.name)], check=True)
    subprocess.run(["ditto", "-c", "-k", "--keepParent", str(payload), str(ipa)], check=True)
subprocess.run(["unzip", "-tq", str(ipa)], check=True)
print(f"Unsigned IPA: {ipa}")
print("Sign with an App Group enabled provisioning profile before installation.")
print("No physical-device PosterBoard test has been performed by this build script.")
PY
