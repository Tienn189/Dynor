# Dynor V5 — minimalist rounded redesign
- DynorDesign.swift: new neutral canvas/surface tokens (light #F5F5F7 / dark near-black), DynorRadius scale (card 28, tile 26, control 20), quieter large title, flat borderless cards with a very soft shadow.
- Explore, Collection, Library, Settings: posters 26pt, featured 30pt, cards 28pt, capsule action buttons, wider grid spacing.
- Liquid glass (DynorGlass, DynorGlassButtonStyle, GlassIconButton) is byte-for-byte unchanged.
- No Xcode build was run here; build with Codemagic and report compiler errors if any.
