# Dynor V5 — Atelier redesign

Thiết kế lại toàn bộ giao diện theo phong cách Apple: tối giản, sang trọng, nhiều chiều sâu. Giữ nguyên hiệu ứng liquid glass (material + viền specular).

## Hệ thống thiết kế (DynorDesign.swift)
- Chữ: SF Pro thay cho serif; tiêu đề lớn 38 bold, số liệu dùng SF Rounded.
- Nền: canvas đen/trắng sứ trung tính + một vầng sáng accent nhẹ ở đỉnh màn hình (thay cho 3 vệt màu cũ).
- Kính: material + lớp phủ + vệt sáng đỉnh + viền specular + bóng đổ mềm (DynorGlass, GlassIconButton, nút, chip).
- Chip chọn: nền đảo màu (trắng/đen) thay vì tô accent đậm.
- Nút chính: gradient accent tinh tế, cao 54, viền sáng.
- Thành phần mới: DynorCaption (nhãn kính nổi trên ảnh), DynorDesign.numeral, DynorDesign.specular, DynorDesign.hairline.
- Toàn bộ API cũ được giữ nguyên nên mọi màn hình khác tự thừa hưởng phong cách mới.

## Màn hình
- Thanh tab: kính nổi, icon + nhãn nhỏ, "thấu kính" kính trượt dưới tab đang chọn.
- Khám phá: tìm kiếm kính, carousel nổi bật lớn hơn (bo 34), thẻ lưới có nhãn kính nổi, panel chi tiết kính.
- Bộ sưu tập / Thư viện: thẻ nhập dạng kính, thẻ hình nền dùng DynorCaption, viền chọn gọn hơn.
- Cài đặt: icon tile kiểu Settings của iOS, tiêu đề thẻ mới, avatar và thẻ VIP tinh chỉnh.

## Không đổi
Logic tài khoản, tải về, nhập/giải mã .dynor, cài PosterBoard, worse_query, nhật ký, entitlement, ký IPA.

Lưu ý: chưa build bằng Xcode (môi trường Linux). Build bằng Codemagic và gửi lỗi compiler nếu có.
